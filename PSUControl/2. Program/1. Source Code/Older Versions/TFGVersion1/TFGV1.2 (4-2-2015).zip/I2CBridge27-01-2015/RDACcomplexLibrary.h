/*
 * RDACcomplexLibrary.h
 *
 *  Created on: 02-feb-2015
 *      Author: Alberto
 */

#ifndef RDACCOMPLEXLIBRARY_H_
#define RDACCOMPLEXLIBRARY_H_


#endif /* RDACCOMPLEXLIBRARY_H_ */

#include "RDACLibrary.h"
#include "I2CLibrary.h"

void configRDAC(int value, BYTE slaveSelect, BYTE I2CAdress);
void highImpRDAC(int slaveSelect, BYTE I2CAdress);
void readRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress);
void readCtrlRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress);
