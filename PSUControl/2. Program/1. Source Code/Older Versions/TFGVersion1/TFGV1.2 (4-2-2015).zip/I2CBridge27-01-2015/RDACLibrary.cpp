/*
 * ad5291.c
 *
 *  Created on: 27-ene-2015
 *      Author: Alberto
 */

#include "RDACLibrary.h"

// All the messages are stored in the first 2 bytes of the input buffer

void donothing(BYTE* buffer){
	BYTE donothing[2] = {0x00, 0x00};
	mergeBuffer(buffer, donothing, 2);
}

void writeReg(BYTE* buffer, int value ){
	if (value >0x3FF){
		value=0x200;
	}
	BYTE writeValue[2] = {0x04+((value & 0x300)>>8), (value & 0x0FF)};
	mergeBuffer(buffer, writeValue, 2);
}

void readReg(BYTE* buffer){
	BYTE readValue[2] = {0x08, 0x00};
	mergeBuffer(buffer, readValue, 2);
}

void storeRegtoMem(BYTE* buffer){
	BYTE storeRegtoMem[2] = {0x0C, 0x00};
	mergeBuffer(buffer, storeRegtoMem, 2);
}

void reset(BYTE* buffer){
	BYTE reset[2] = {0x10, 0x00};
	mergeBuffer(buffer, reset, 2);
}

void readMem(BYTE* buffer, BYTE direction ){
	BYTE readMem[2] = {0x14, direction};
	mergeBuffer(buffer, readMem, 2);
}

void writeCtrl(BYTE* buffer, BOOL calibrationDisable, BOOL regWriteEnable, BOOL programEnable  ){
	BYTE writeCtrl[2] = {0x18, 0x04*calibrationDisable+ 0x02*regWriteEnable + 0x01*programEnable};
	mergeBuffer(buffer, writeCtrl, 2);
}

void readCtrl(BYTE* buffer){
	BYTE readCtrl[2] = {0x1C, 0x00};
	mergeBuffer(buffer, readCtrl, 2);
}

void shutdown(BYTE* buffer, BOOL shutdownModeOn){
	BYTE shutdown[2] = {0x20, 0x00 + 0x01*shutdownModeOn};
	mergeBuffer(buffer, shutdown, 2);
}

void highImp(BYTE* buffer){
	BYTE highImp[2] = {0x80, 0x01};
	mergeBuffer(buffer, highImp, 2);
}
