/*
 * RDACcomplexLibrary.cpp
 *
 *  Created on: 02-feb-2015
 *      Author: Alberto
 */

#include "RDACComplexLibrary.h"
#include "I2CLibrary.h"

BOOL config = false;
BYTE outputBuffer[I2C_MAX_BUF_SIZE];			// Used to send every message
BYTE inputBuffer[I2C_MAX_BUF_SIZE];				// Used to receive every message

float Rpsu1 = 800;								// Different for each PSU

void configRDAC(int value, BYTE slaveSelect, BYTE I2CAdress){
	if (!config){
		writeCtrl(outputBuffer, false, true, false);
		sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
		config=true;
	}
	/*float scaledValue = (1-((((float)volt/1.25)-1)*Rpsu1/20000))*1024;*/
	writeReg(outputBuffer, value );
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	iprintf("Configured value %d in slave %d\n\n", value, slaveSelect );
}

void highImpRDAC(int slaveSelect, BYTE I2CAdress){
	highImp(outputBuffer);
	BYTE* poutBuf = outputBuffer;
	poutBuf+=2;
	donothing(poutBuf);
	sendSPImessage ( outputBuffer, 4, slaveSelect,I2CAdress);
	iprintf("High Impedance in slave %d\n\n", slaveSelect );
}

void readRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress){
	readReg(outputBuffer);
	BYTE* poutBuf = outputBuffer;
	poutBuf+=2;
	donothing(poutBuf);
	sendSPImessage ( outputBuffer, 4, slaveSelect, I2CAdress);
	readBridgeBuffer(inputBuffer, 4);
	mergeBuffer(ibuf, inputBuffer, 2);
}

void readCtrlRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress){
	readCtrl(outputBuffer);
	BYTE* poutBuf = outputBuffer;
	poutBuf+=2;
	donothing(poutBuf);
	sendSPImessage ( outputBuffer, 4, slaveSelect, I2CAdress);
	readBridgeBuffer(inputBuffer, 4);
	mergeBuffer(ibuf, inputBuffer, 2);
}
