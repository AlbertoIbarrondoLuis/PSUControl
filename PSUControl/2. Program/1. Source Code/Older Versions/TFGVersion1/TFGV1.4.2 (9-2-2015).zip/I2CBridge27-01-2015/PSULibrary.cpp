/*
 * PSULibrary.cpp
 *
 *  Created on: 04-feb-2015
 *      Author: Alberto


#include "RDACLibrary.h"
#include "I2CLibrary.h"

typedef struct PSU {
	BOOLEAN powerOn;
	float voltageProg;					// Programmed voltage
	BYTE rdacDir;						// PSU rdac direction
	float alarmLimits[2][2];			// inferior (0,0) and superior (0,1) voltage alarm limits; and inferior (1,0) and superior (1,1) current alarm limits.
	int alarmTimes[2][2];				// inferior (0,0) and superior (0,1) voltage alarm times; and inferior (1,0) and superior (1,1) current alarm times.
	-	accionAlarma		Int Array 2x2x3 - las posiciones de la matriz 2x2 son iguales a
	las de valorAlarma y TiempoAlarma, la tercera dimensi�n es para activar o desactivar las distintas acciones a realizar en caso de alarma: (0) Desactivar fuentes, (1) Modificar Tensi�n, (2) Mandar Mensaje UDP.
	-	desactAlarma		Boolean Array 2x2x14 - Fuentes a desactivar en caso de acci�n
	de Desactivar fuentes.
	-	mensajeAlarma	String Array 2x2 - Mensajes a enviar en caso de acci�n
	de Mandar Mensaje UDP. (No se si se puede hacer un array de strings, creo que no. En ese caso se cambiar�a por 4 variables y su control en el setter)
	-	voltAlarma		Double Array 2x2 - Porcentajes a variar la tensi�n de esta fuente
	si se produce alarma con Modificar Tensi�n activo
	-	contadorAlarma	Int Array 1x4 - contadores de alarma encendida para l�mite
	inferior (0) y superior (1) del voltaje, y para l�mite inferior (2) y
	superior (3) de la corriente. El array de 2x2 se transforma en fila para recorrerlo con mayor facilidad. {INF/SUP + 2* VOLT/CORR}
	-	estadoAlarma		Int Array 1x4 - contadores de alarma encendida para l�mite
	inferior (0) y superior (1) del voltaje, y para l�mite inferior (2) y
	superior (3) de la corriente

};
*/
