/*
 * RDACLibrary.h
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#include "predef.h"
#include <ctype.h>
#include <basictypes.h>
#include <system.h>
#include <constants.h>
#include "GeneralLibrary.h"

#ifndef RDACLIBRARY_H_
#define RDACLIBRARY_H_


#endif /* RDACLIBRARY_H_ */

void doNothingCOM(BYTE* buffer);
void writeRegCOM(BYTE* buffer, int value );
void readRegCOM(BYTE* buffer);
void storeRegtoMemCOM(BYTE* buffer);
void resetCOM(BYTE* buffer);
void readMemCOM(BYTE* buffer, BYTE direction );
void writeCtrlCOM(BYTE* buffer, BOOL programEnable, BOOL regWriteEnable, BOOL calibrationDisable );
void readCtrlCOM(BYTE* buffer);
void shutdownCOM(BYTE* buffer, BOOL shutdownModeOn);
void highImpCOM(BYTE* buffer);
