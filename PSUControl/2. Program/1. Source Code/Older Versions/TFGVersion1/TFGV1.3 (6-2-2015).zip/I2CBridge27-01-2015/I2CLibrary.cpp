/*
 * I2CLibrary.cpp
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#include "i2CLibrary.h"


//---------------------------------------Variables---------------------------------------------------//
BYTE I2CStat;
BYTE bridgeAddress = 0x2F; // 0x28 to 0x2F possible. 3 last bits are configurable with switches

BYTE sendBuffer[I2C_MAX_BUF_SIZE];   	// User created I2C output buffer
BYTE* pSendBuf = sendBuffer;         	// Pointer to user I2C output buffer
BYTE receiveBuffer[I2C_MAX_BUF_SIZE];   	// User created I2C output buffer
BYTE* pRecBuf = receiveBuffer;         	// Pointer to user I2C output buffer

//-------------------------------------------------------------------------------------------------------
// sendI2CMessage sends the bufSize Bytes from bufi2c to the bridgeAddress through I2C including a null at the end
//-------------------------------------------------------------------------------------------------------
void sendI2CMessage ( BYTE outputBuffer[], int bufSize, BYTE I2CAdress){
		iprintf( "Sending message to I2C address 0x%x\r\n", I2CAdress );
		printBuffer(outputBuffer, bufSize);
		I2CStat = I2CSendBuf(I2CAdress, outputBuffer, bufSize);// Send the buffer size plus one to include the null character
		if( I2CStat == I2C_OK )
		   iprintf( "I2C Sent successfully\r\n\r\n" );
		else
		   iprintf( "Failed to send to address %x due to error: %d\r\n\r\n", I2CAdress ,I2CStat);
}



//-------------------------------------------------------------------------------------------------------
// configureSPI sends 2 bytes using outputBuffer to configure the SPI channel using the bridge.
// Initialize Order (MSB/LSB first) Clock Polarity (cpol) and Phase (cpha)
// Values from 0 to 3 possible. Default is 0.
//	0 -> 1.8MHz; 1 -> 461KHz; 2 -> 115KHz; 3 -> 58KHz;
//-------------------------------------------------------------------------------------------------------
void configureSPI( BOOL order, BOOL cpol, BOOL cpha, int clkRate, BYTE I2CAdress){
		BYTE configureSPI[2] = {0xF0, 0x20 * order + 0x08 * cpol + 0x04 * cpha+ (((clkRate < 4) && (clkRate > 0))?clkRate:0)};
		iprintf( "Configuring SPI channel...\r\n" );
		printBuffer( configureSPI, 2);
		sendI2CMessage( configureSPI, 2, I2CAdress);
}



//-------------------------------------------------------------------------------------------------------
// sendSPImessage sends bufSize Bytes from the BufSPI buffer to the selected SPI Slaves (0x0 to 0xF possible)
//-------------------------------------------------------------------------------------------------------
void sendSPImessage ( BYTE outputBuffer[], int bufSize, BYTE slaveSelect, BYTE I2CAdress){
		if (slaveSelect>0x0F){
			iprintf("Wrong SPI address");
		}
		else{
			*pSendBuf++=slaveSelect;
			mergeBuffer(pSendBuf, outputBuffer, bufSize);
			pSendBuf = sendBuffer;
			sendI2CMessage( sendBuffer, bufSize + 1 , I2CAdress);
			OSTimeDly( 1 );
		}
}



//-------------------------------------------------------------------------------------------------------
// receiveMessage reads the bufSize Bytes from the Bridge buffer and writes them into inputBuffer
//-------------------------------------------------------------------------------------------------------
void readBridgeBuffer ( BYTE inputBuffer[], int bufSize){
		iprintf( "Reading bridge buffer...\r\n" );
		I2CStat = I2CReadBuf(bridgeAddress, inputBuffer, bufSize);
		if( I2CStat == I2C_OK )
		{
			iprintf("Data Received: " );
			printBuffer(inputBuffer, bufSize);
			iprintf("I2C Receive successfully\r\n" );
		}
		else
		   iprintf("Failed to read due to error: %d\r\n", I2CStat);
}



