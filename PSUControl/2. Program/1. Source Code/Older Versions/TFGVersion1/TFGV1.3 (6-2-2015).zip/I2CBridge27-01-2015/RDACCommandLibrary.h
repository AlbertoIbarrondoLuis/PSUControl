/*
 * RDACLibrary.h
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#include "predef.h"
#include <ctype.h>
#include <basictypes.h>
#include <system.h>
#include <constants.h>
#include "GeneralLibrary.h"

#ifndef RDACLIBRARY_H_
#define RDACLIBRARY_H_


#endif /* RDACLIBRARY_H_ */

void donothing(BYTE* buffer);
void writeReg(BYTE* buffer, int value );
void readReg(BYTE* buffer);
void storeRegtoMem(BYTE* buffer);
void reset(BYTE* buffer);
void readMem(BYTE* buffer, BYTE direction );
void writeCtrl(BYTE* buffer, BOOL programEnable, BOOL regWriteEnable, BOOL calibrationDisable );
void readCtrl(BYTE* buffer);
void shutdown(BYTE* buffer, BOOL shutdownModeOn);
void highImp(BYTE* buffer);
