/*
 * GeneralLibrary.cpp
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#include "GeneralLibrary.h"

//-------------------------------------------------------------------------------------------------------
// mergeBuffer writes size bytes from buf2 to buf1
//-------------------------------------------------------------------------------------------------------
	void mergeBuffer(BYTE buf1[], BYTE buf2[], int size){
		BYTE* paux1 = buf1;
		BYTE* paux2 = buf2;
		for (int i = 0; i<size; i++){
			*paux1 = *paux2;
			paux2++; paux1++;
		}

	}

//-------------------------------------------------------------------------------------------------------
// printBuffer displays the contents of a buffer or array using iprintf
//-------------------------------------------------------------------------------------------------------
	void printBuffer(BYTE buf1[], uint bufferSize){
		iprintf("Buffer contents: [");
		for (uint i = 0; i<bufferSize; i++){
			iprintf(", %x (%d)", buf1[i], i);
		}
		iprintf("]\r\n");
	}

//-------------------------------------------------------------------------------------------------------
// Ascii2Byte converts the first two ASCII chars of a string to a single hex value
//-------------------------------------------------------------------------------------------------------
	BYTE Ascii2Byte( char* buf ){
	   char conv[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
	   BYTE temp = 0;
	   for( int i = 0; i<16; i++)
		  if ( toupper(buf[1]) == conv[i] )
			 temp = i;
	   for( int i = 0; i<16; i++)
		  if ( toupper(buf[0]) == conv[i] )
			 temp |= i<<4;
	   return temp;
	}
