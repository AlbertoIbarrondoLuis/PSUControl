
/******************************************************************************
 * 								MCF5213 RDAC Configuration
 *   This program configures the RDAC with different values, configuring I2C and
 *   SPI buses in the process.
 *
 *   Author: Alberto Ibarrondo
 *
 *****************************************************************************/




#include "GeneralLibrary.h"
#include "I2CLibrary.h"
#include "RDACCommandLibrary.h"
#include "RDACComplexLibrary.h"



//====================================INICIALIZACIONES===============================================//
extern "C" { void UserMain( void * pd); }
void initialize (void);

//---------------------------------------Constants---------------------------------------------------//
const char * AppName="I2CBridge27-01-2015";
int freqDiv = 0x19;
BYTE nburnAddress = 0x29;			// Can be changed from 0x28 to 0x2F
BYTE i2CtoSPIAddress = 0x2F;		// Defined by 3 switches.
BYTE bufc[I2C_MAX_BUF_SIZE];
BYTE* pbufc = bufc;



//========================================USERMAIN====================================================//
void UserMain(void * pd) {
	initialize();					// Defined below. Contains all the configuration issues.
    iprintf("Application started\nPRESS ONE KEY TO BEGIN \n\n");
    char c = sgetchar( 0 );			// Frequently used to stop program until input is received

//--------------------------------------Main Loop-----------------------------------------------------//
    while (1) {
    	iprintf("\n\n\n\nResetting  RDAC\n\n");
		resetRDAC(2, i2CtoSPIAddress);
		c = sgetchar( 0 );

    	iprintf("\n\n\n\nReading CTRL RDAC\n\n");
    	readCtrlRDAC(bufc, 2, i2CtoSPIAddress);
    	c = sgetchar( 0 );

    	iprintf("\n\n\n\nConfiguring RDAC\n\n");
    	setRDAC(0x3ff, 2, i2CtoSPIAddress);
		c = sgetchar( 0 );

		iprintf("\n\n\n\nReading RDAC\n\n");
		getRDAC(bufc, 2, i2CtoSPIAddress);
		c = sgetchar( 0 );

		iprintf("\n\n\n\nReading CTRL RDAC\n\n");
		readCtrlRDAC(bufc, 2, i2CtoSPIAddress);
    	c = sgetchar( 0 );

		iprintf("\n\n\n\nResetting  RDAC\n\n");
		resetRDAC(2, i2CtoSPIAddress);
		c = sgetchar( 0 );

		iprintf("\n\n\n\nReading CTRL RDAC\n\n");
		readCtrlRDAC(bufc, 2, i2CtoSPIAddress);
    	c = sgetchar( 0 );

		iprintf("\n\n\n\nConfiguring RDAC SECOND TIME\n\n");
		setRDAC(700, 2, i2CtoSPIAddress);
		c = sgetchar( 0 );

    	iprintf("\n\n\n\nPROGRAM ENDED\n\n");
    	c = sgetchar( 0 );
    }
}













void initialize (void){
	//-------------------------------------General System--------------------------------------------//
	SimpleUart(0,SystemBaud);assign_stdio(0);	// Serial port 0 for Data
	SimpleUart(1,SystemBaud);					// Serial port 1 for Debug
	#ifdef _DEBUG
		InitGDBStubNoBreak( 1, 115200 );
	#endif

	OSChangePrio(MAIN_PRIO);					//Other
	EnableSerialUpdate();
	#ifndef _DEBUG
	EnableSmartTraps();
	#endif


	//--------------------------------------I2C Bus Connection---------------------------------------//
	I2CInit(nburnAddress, freqDiv); // Initialize I2C with Predefined Address (0x20)
									// Set frequency division to 1280 (66Mhz CF clock --> 25 Khz I2C bus)
									// which is half of the default freqDiv (0x15 = 640)
	iprintf("\r\nInitialized I2C address for MCF5213: 0x%x\r\n",nburnAddress);
	iprintf("Set I2C Frequency division: %x\r\n",freqDiv);


	//-------------------------------------SPI Bus Connection----------------------------------------//
	configureSPI( false, false, false, 2, i2CtoSPIAddress);	// MSB first, CLK low when idle, data clocked in on leading edge
											// frequency = 115KHz;

}
