/*
 * RDACLibrary.h
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#include "predef.h"
#include <ctype.h>
#include <basictypes.h>
#include <system.h>
#include <constants.h>
#include "GeneralLibrary.h"

#ifndef RDACLIBRARY_H_
#define RDACLIBRARY_H_


#endif /* RDACLIBRARY_H_ */

void donothing(BYTE* auxBuffer);
void writeSPItoReg(BYTE* auxBuffer, int value );
void storeRegtoMem(BYTE* auxBuffer);
void reset(BYTE* auxBuffer);
void readMem(BYTE* auxBuffer, BYTE direction );
BYTE readInternalStatus(BYTE* auxBuffer);
void writeSPItoCtrl(BYTE* auxBuffer, BOOL programEnable, BOOL regWriteEnable, BOOL calibrationDisable );
void readCtrl(BYTE* auxBuffer);
void shutdown(BYTE* auxBuffer, BOOL shutdownModeOn);

