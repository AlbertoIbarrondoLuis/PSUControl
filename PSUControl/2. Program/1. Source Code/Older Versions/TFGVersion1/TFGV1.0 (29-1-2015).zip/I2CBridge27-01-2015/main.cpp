
/******************************************************************************
 * 								Mod5213 I2CBridge
 *   Explanation
 *
 *   Alberto Ibarrondo
 *
 *****************************************************************************/

#include "GeneralLibrary.h"
#include "I2CLibrary.h"
#include "RDACLibrary.h"

//====================================INICIALIZACIONES===============================================//
extern "C" { void UserMain( void * pd); }

//---------------------------------------Constants---------------------------------------------------//
const char * AppName="I2CBridge27-01-2015";
BYTE nburnAddress = 0x50;


//========================================USERMAIN===================================================//
void UserMain(void * pd) {
    SimpleUart(0,SystemBaud);
    assign_stdio(0);
    SimpleUart(1,SystemBaud);
    OSChangePrio(MAIN_PRIO);
    EnableSerialUpdate();

    #ifndef _DEBUG
    EnableSmartTraps();
    #endif

    #ifdef _DEBUG
    InitGDBStubNoBreak( 1, 115200 );
    #endif

    I2CInit( nburnAddress );   // Initialize I2C with Predefined Address (0x50)
    iprintf("\r\nInitialized address for NetBurner: %x\r\n",nburnAddress);
    iprintf("Application started\nPRESS ONE KEY TO BEGIN \n\n");
    char c = sgetchar( 0 );


//--------------------------------------Main Loop-----------------------------------------------------//
    while (1) {

    	iprintf("\nFunction tests \n\n");
		OSTimeDly(TICKS_PER_SECOND);
		BYTE bufa[5] = {7,6,5,2,1};
		printBuffer(bufa, sizeof(bufa));
		iprintf("\r\n");
		c = sgetchar( 0 );
		configureSPI (true, true, true, 2);
		c = sgetchar( 0 );
		sendSPImessage (bufa, 4, 0x0D);
		c = sgetchar( 0 );
		receiveMessage( 3 );
		c = sgetchar( 0 );
    }
}

