/*
 * ad5291.c
 *
 *  Created on: 27-ene-2015
 *      Author: Alberto
 */

#include "RDACLibrary.h"

// All the messages are stored in auxBuffer. To use them, simply copy those contents into another buffer

void donothing(BYTE* auxBuffer){
	BYTE donothing[2] = {0x00, 0x00};
	mergeBuffer(auxBuffer, donothing, 2);
}

void writeSPItoReg(BYTE* auxBuffer, int value ){
	if (value >0x3FF)
		value=0x200;
	BYTE writeValue[2] = {0x04+((value & 0x300)>>8), (value & 0x0FF)};
	mergeBuffer(auxBuffer, writeValue, 2);
}

void storeRegtoMem(BYTE* auxBuffer){
	BYTE storeRegtoMem[2] = {0x0C, 0x00};
	mergeBuffer(auxBuffer, storeRegtoMem, 2);
}

void reset(BYTE* auxBuffer){
	BYTE reset[2] = {0x10, 0x00};
	mergeBuffer(auxBuffer, reset, 2);
}

void readMem(BYTE* auxBuffer, BYTE direction ){
	BYTE readMem[2] = {0x14, direction};
	mergeBuffer(auxBuffer, readMem, 2);
}

/*BYTE readInternalStatus(BYTE* auxBuffer){ //TODO: incorrect function. Not to be used until changed
	readMem(0x14); //TODO: save response contents into auxBuffer
	BYTE n= 0;
	int i, aux = 0x100*auxBuffer[0]+auxBuffer[1];
	for (i=0; i<10; i++){
		n+= aux & 0x01;
		aux =aux <<1;
	}
	readMem(0x15); //TODO: save response contents into auxBuffer
	for (i=0; i<10; i++){
		n+= aux & 0x01;
		aux =aux <<1;
	}
	return n;
}*/

void writeSPItoCtrl(BYTE* auxBuffer, BOOL programEnable, BOOL regWriteEnable, BOOL calibrationDisable ){
	BYTE writeSPItoCtrl[2] = {0x18, 0x04*programEnable + 0x02*regWriteEnable + 0x01*calibrationDisable};
	mergeBuffer(auxBuffer, writeSPItoCtrl, 2);
}

void readCtrl(BYTE* auxBuffer){
	BYTE readCtrl[2] = {0x1C, 0x00};
	mergeBuffer(auxBuffer, readCtrl, 2);
}

void shutdown(BYTE* auxBuffer, BOOL shutdownModeOn){
	BYTE shutdown[2] = {0x20, 0x00 + 0x01*shutdownModeOn};
	mergeBuffer(auxBuffer, shutdown, 2);
}


