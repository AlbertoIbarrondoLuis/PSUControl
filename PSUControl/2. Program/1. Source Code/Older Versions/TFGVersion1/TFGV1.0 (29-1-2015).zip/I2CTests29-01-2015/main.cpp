#include "predef.h"
#include <ctype.h>
#include <basictypes.h>
#include <system.h>
#include <constants.h>
#include <ucos.h>
#include <ucosmcfc.h>
#include <serialirq.h>
#include <stdio.h>
#include <smarttrap.h>
#include <serialupdate.h>
#include "i2cmulti.h"             		//Used for Multi-Master I2C
#include <string.h>
#include <Pins.h>
#include <bsp.h>            			// MOD5213 board support package interface
#include <gdbstub.h>
#include <utils.h>          			// Include for usage of carrier board LEDs
#include <sim5213.h>        			// Access to MCF5213 register structures
#include <stdlib.h>
#include "RDACLibrary.h"
#include "GeneralLibrary.h"

#define print_name(x) printf(#x "   -->  ")


extern "C" {
void UserMain(void * pd);
}

const char * AppName="I2CTests29-01-2015";

void UserMain(void * pd) {
    SimpleUart(0,SystemBaud);
    assign_stdio(0);
    SimpleUart(1,SystemBaud);
    OSChangePrio(MAIN_PRIO);
    EnableSerialUpdate();

    #ifndef _DEBUG
    EnableSmartTraps();
    #endif

    #ifdef _DEBUG
    InitGDBStubNoBreak( 1, 115200 );
    #endif

    iprintf("Tests started\n\n\n");
    char c = sgetchar( 0 );
    while (1) {
		BYTE bufa[5] = {7,6,5,2,1};
		//BYTE bufb[5] = {1,2,3,4,5};

	    iprintf("1. donothing\n");
		donothing(bufa);
		print_name(bufa);printBuffer(bufa, 2);
		c = sgetchar( 0 );

		iprintf("2. writeSPItoReg\n");
		writeSPItoReg(bufa, 1000 );
		print_name(bufa);printBuffer(bufa, 2);
		c = sgetchar( 0 );

		iprintf("3. storeRegtoMem\n");
		storeRegtoMem(bufa);
		print_name(bufa);printBuffer(bufa, 2);
		c = sgetchar( 0 );

		iprintf("4. reset\n");
		reset(bufa);
		print_name(bufa);printBuffer(bufa, 2);
		c = sgetchar( 0 );

		iprintf("5. readMem\n");
		readMem(bufa, 0x04);
		print_name(bufa);printBuffer(bufa, 2);
		c = sgetchar( 0 );

		iprintf("6. writeSPItoCtrl\n");
		writeSPItoCtrl(bufa, true,1,0);
		print_name(bufa);printBuffer(bufa, 2);
		c = sgetchar( 0 );

		iprintf("7. readCtrl\n");
		readCtrl(bufa);
		print_name(bufa);printBuffer(bufa, 2);
		c = sgetchar( 0 );

		iprintf("8. Shutdown\n");
		shutdown(bufa, true);
		print_name(bufa);printBuffer(bufa, 2);
		c = sgetchar( 0 );
    }
}
