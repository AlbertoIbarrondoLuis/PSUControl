/*
 * PSULibrary.cpp
 *
 *  Created on: 04-feb-2015
 *      Author: Alberto
*/

#include "RDACCommandLibrary.h"
#include "I2CLibrary.h"

#define OFF	false;
#define ON	true;

#define INFERIOR 0;
#define SUPERIOR 1;

#define VOLTAGE 0;
#define CURRENT 1;

#define PROTOCOL_SHUTDOWN 0;		//(0) Shut down certain PSUs
#define PROTOCOL_MODIFY_VOLTAGE 1;	//(1) Modify Voltage
#define PROTOCOL_MESSAGE 2;			//(2) Send Alarm Message

typedef struct PSU_TYPE {
	BOOLEAN releStatus;					// Rel� activated
	BOOLEAN psuStatus;					// psu being used or not

	float rdacValue;					// Programmed voltage
	BYTE rdacDir;						// PSU rdac direction


	float alarmLimitValues[2][2];			// inferior (0,0) and superior (0,1) voltage alarm limits; and inferior (1,0) and superior (1,1) current alarm limits.
	int alarmLimitTimes[2][2];				// inferior (0,0) and superior (0,1) voltage alarm times; and inferior (1,0) and superior (1,1) current alarm times.
	int alarmProtocols[2][2][3];		// inferior (0,0) and superior (0,1) voltage alarm; and inferior (1,0) and superior (1,1) current alarm.
										// Third dimension is to activate or ignore the protocols when the alarm pops up: (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
	BYTE alarmProtocolShutdown[2][2];			// PSU list to shutdown in alarm protocol Shutdown (. bit 0 is for PSU 1, and so on.

	//const char * AlarmMessage="ALARM";		// message to be sent in case of alarm protocol Message
	float alarmProtocolVoltage[2][2];	// New values for this PSU's voltage in case of alarm Protocol Modify Voltage
	int alarmCounters[2][2];			// variables being increased on each scanning period if an alarm is ON, until they reach the alarmLimits
										// They also serve for shutting down alarms when not active for a period of time.
										// Idea: El array de 2x2 se transforma en fila para recorrerlo con mayor facilidad. {INF/SUP + 2* VOLT/CORR}
	BOOL alarmStatus[2][2];				// FALSE: alarm is OFF, not performing any alarm protocols. TRUE: alarm is ON, performing alarm protocols.
	BOOL alarmLimitReached[2][2];		// FALSE: alarm hasn't reached the limit. If alarmStatus was ON, it will start decreasing the alarmCounter until alarmStatus is OFF(ntimes = alarmLimitTimes). TRUE: alarm has reached the limit, beginning to increase the alarmCounter until alarmStatus is ON (ntimes = alarmLimitTimes).
	BOOL alarmWatch[2][2];				// FALSE: alarm is not configured, it will neither analyze the system nor trigger the alarmStatus ON.
										// TRUE: alarm is configured and working, will analyze the system, set the alarmStatus ON when a limit is reached, and execute the defined alarmProtocols



	int rShunt;							// Internal resistor used for RDAC configuration

	int divisorTension1;	// valor de la resistencia R1 del divisor a la entrada del CAD para lectura tension. R303 a R310 y R319 a R322
	int divisorTension2;	// valor de la resistencia R2 del divisor a la entrada del CAD para lectura tension. R311 a R311 y R323 a R326
	int rAdicPotDigital;	// valor de la resistencia R203
	int rDivisorPotDigital;	// valor de la resistencia R202

	int vOut;							// CAD value of the output voltage
	int cOut;							// CAD value of the output current

	// Initialization timing and boolean
	int temporizadoEncendido;  // x100 ms temporizado inicial de encendido de la fuente
	BOOL ReadyToConnect;	// indica si la fuente se ha cumplido la temporizacion para el encendido
};






// Variables
BOOL powerONProcess = true; 	// indica si estamos en proceso de encendido
char bufferMOD5270[80]; 		// buffer mensajes tx y rx con MOD5270 via UART
int decimasDesdeArranque=0; 	// decdimas de segundo desde que se ordena arranque para encendido retardado
#define ALL_PSUS_INIT 0xFFF;
PSU_TYPE psuList[12];

// inicializa todas las fuentes seg�n datos en RAM
void initializePSUs(int selectPSUs ){
	int i; int aux = selectPSUs;
	// ajustar fuentes
	for (i=0;i<12;i++){
		if(aux & 0x001){
		 if (psuList[i].psuStatus) {
			 // TODO: adjust digital potentiometer to initial value
		 }
		}
		aux=aux>>1;
 	}
	 OSTimeDly(TICKS_PER_SECOND); // retardo para ajuste de los reguladores
}

// conecta el rel� de la fuente y activa led Out On. Modifica fuente[].fuenteOn
void ConectarFuente(int psuNum){
	BYTE mascara,dato;
	psuList[psuNum].psuStatus=true; // modificar var en RAM
	psuList[psuNum].ReadyToConnect=false; // para no volverla a encender
	//TODO: initialize reles
	/*
	if (numFuente<8){
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(1,0xFF,mascara);
	} else {
		numFuente=numFuente-8;
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(2,0xFF,mascara);
	}
	// activar LED OUT ON
	dato=0x80;
	mascara=!dato;
	EscribeEnDriver(2,dato,mascara);
	*/
}


void turnONPSUs(void){
	int i;
	for (i=0;i<12;i++){
		if (psuList[i].ReadyToConnect==true && psuList[i].psuStatus==false) {
			// la fuente esta apagada y lista para encender
			ConectarFuente(i);
		}
	}
}


// control y monitorizacion de la fuente retorna 0 si OK y si no retorna numFuente con alarma
int MonitoryControl(int numFuente){
	int i;
	turnONPSUs(); // comprobar si hay que encender alguna fuente
	for (i=0;i<12;i++){
		if (psuList[i].psuStatus) {
			/*
			MonitorTension(i);
			MonitorCorriente(i);*/
		}
	}
	return 0;
}




/*



#define VERIFY_KEY (0x48666051)  // NV Settings key code







// realiza lectura de tensi�n y gestiona alarmas
void MonitorTension(int numFuente){
	LeerTensionFuente(numFuente); // lectura tension
	if (fuente[numFuente].vigilarVolts) { // se ha de supervisar el voltaje
		if (TensionEnLimites(numFuente)){ // fuente en limites
			if (fuente[numFuente].segsSinAlarmaVolts<=0 && fuente[numFuente].alarmaVolts) { // cancelar condicion alarma
				fuente[numFuente].segsAlarmaVolts=0; // restablecer contador
				fuente[numFuente].alarmaVolts=false;
				fuente[numFuente].alarma=false;
			}
		} else { //fuente fuera de l�mites
			if (fuente[numFuente].segsAlarmaVolts>=fuente[numFuente].filtroAlarmaVolts) { //disparar condicion alarma
				fuente[numFuente].segsSinAlarmaVolts=fuente[numFuente].filtroSinAlarmaVolts; // restablecer contador
				fuente[numFuente].alarmaVolts=true;
				fuente[numFuente].alarma=true;
				TrataAlarma(numFuente);
			}
		}
	}
	if (fuente[numFuente].autorregVolts) RegulacionVolts(numFuente);
}


// realiza lectura de corriente y gestiona alarmas
void MonitorCorriente(int numFuente){
	LeerCorrienteFuente(numFuente); // lectura corriente
	if (fuente[numFuente].vigilarCurrent) { // se ha de supervisar el corriente
		if (TensionEnLimites(numFuente)){ // fuente en limites
			if (fuente[numFuente].segsSinAlarmaCurr<=0 && fuente[numFuente].alarmaCurrent) { // cancelar condicion alarma
				fuente[numFuente].segsAlarmaCurr=0; // restablecer contador
				fuente[numFuente].alarmaCurrent=false;
				fuente[numFuente].alarma=false;
			}
		} else { //fuente fuera de l�mites
			if (fuente[numFuente].segsAlarmaCurr>=fuente[numFuente].filtroAlarmaCurrent) { //disparar condicion alarma
				fuente[numFuente].segsSinAlarmaCurr=fuente[numFuente].filtroSinAlarmaCurr; // restablecer contador
				fuente[numFuente].alarmaCurrent=true;
				fuente[numFuente].alarma=true;
				TrataAlarma(numFuente);
			}
		}
	}
}

// pendiente de definir comportamiento
void RegulacionVolts(int numFuente){


}
// interrumpe cada segundo. Actualiza los temporizadores de alarma en tensi�n
BOOL ActualizaTemporizadoresAlarmaTension(void){
	int i;
	for (i=0;i<12;i++){
		if(!fuente[i].TransicionEn_TensionEnLimites){ // nos fiamos del estado por estar estable
			if(fuente[i].tensionEnLimites){ // fuente ok t_odo el tiempo
				if(fuente[i].segsSinAlarmaVolts>0) fuente[i].segsSinAlarmaVolts--; // decrementar timer anulacion alarma
			} else {
				if(fuente[i].segsAlarmaVolts<fuente[i].filtroAlarmaVolts) fuente[i].segsAlarmaVolts++; // incrementar timer anulacion alarma
			}
		} else { // situacion inestable
			fuente[i].TransicionEn_TensionEnLimites=false; // limpiar flag de transici�n
			// si estabamos descontando timer para liberar alarma volver a reiniciar
			if(fuente[i].alarmaVolts){
				fuente[i].segsSinAlarmaVolts=fuente[i].filtroSinAlarmaVolts; // restablecer contador
			} else{
				fuente[i].segsAlarmaVolts=0; // como no se mantuvo cte alarma se reinicia contador
			}
		}
	}
	return true;
}

// interrumpe cada segundo. Actualiza los temporizadores de alarma en corriente
BOOL ActualizaTemporizadoresAlarmaCurrent(void){
	int i;
	for (i=0;i<12;i++){
		if(!fuente[i].TransicionEn_CurrEnLimites){ // nos fiamos del estado por estar estable
			if(fuente[i].currentEnLimites){ // fuente ok t_odo el tiempo
				if(fuente[i].segsSinAlarmaCurr>0) fuente[i].segsSinAlarmaCurr--; // decrementar timer anulacion alarma
			} else {
				if(fuente[i].segsAlarmaCurr<fuente[i].filtroAlarmaCurrent) fuente[i].segsAlarmaCurr++; // incrementar timer anulacion alarma
			}
		} else { // situacion inestable
			fuente[i].TransicionEn_CurrEnLimites=false; // limpiar flag de transici�n
			// si estabamos descontando timer para liberar alarma volver a reiniciar
			if(fuente[i].alarmaCurrent){
				fuente[i].segsSinAlarmaCurr=fuente[i].filtroSinAlarmaCurr; // restablecer contador
			} else {
				fuente[i].segsAlarmaCurr=0; // cmo no se mantuvo cte alarma se reinicia contador
			}
		}
	}
	return true;
}

// se encarga de preparar encendido retardado de las fuentes.Las enciende el monitor
void ActualizaPreparadoEncendido(void){
	int i;
	if (enProcesoEncendidoFuentes){
		decimasDesdeArranque++;
		if(decimasDesdeArranque <= encendidoFuente[11][0]){ // todavia en proceso de encendido
			enProcesoEncendidoFuentes=true;
			// preparar encendido de las fuentes con esta temporizacion
			for (i=0 ; i<12 ; i++){
				if (decimasDesdeArranque >= fuente[i].temporizadoEncendido) fuente[i].ReadyToConnect=true; //preparada var para que monitro haga el encendido
			}
		} else {
			enProcesoEncendidoFuentes=false; // se termin� de encender la ultima fuente
		}
	}
}

// rutina de atenci�n de alarmas en fuentes
// desconecta la fuente. Envia alarma y desconecta fuentes dependientes
void TrataAlarma(int numFuente){
	int i;
	if (fuente[numFuente].desconSiAlarmCurr && fuente[numFuente].alarmaCurrent){
		DesconectarFuente(numFuente); // desconectar fuente con alarma
		if (fuente[numFuente].enviarAlarmas) EnviaAlarma(numFuente);
	}
	if (fuente[numFuente].desconSiAlarmVolts && fuente[numFuente].alarmaVolts){
		DesconectarFuente(numFuente); // desconectar fuente con alarma
		if (fuente[numFuente].enviarAlarmas) EnviaAlarma(numFuente);
	}

	// desconectar el resto de las fuentes
	for (i=0;i<12;i++){
		if (fuente[i].apagarSiAlarmaEnOtraFuente) DesconectarFuente(numFuente);
	}
}


// desconecta el rel� de la fuente si necesario (configurable ante situacion alarma)
// envia mensaje alarma si necesario (configurable ante situacion alarma)
void DesconectarFuente(int numFuente){
	BYTE mascara,dato;
	extern BYTE driverA; // declarar la variable definida comunicaciones.cpp
	extern BYTE driverB; // declarar la variable definida comunicaciones.cpp

	if (numFuente<8){
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(1,0x00,mascara);
	} else {
		numFuente=numFuente-8;
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(2,0x00,mascara);
	}
	// comprobar si se ha de desactivar  led Out On
	if (driverA==0) {
		 if ((driverB & 0x0F)==0){
			 dato=0x80;
			 mascara=!dato;
			 EscribeEnDriver(2,0,mascara);
		 }
	}
}


// conecta el rel� de la fuente y activa led Out On. Modifica fuente[].fuenteOn
void ConectarFuente(int numFuente){
	BYTE mascara,dato;
	fuente[numFuente].fuenteOn=true; // modificar var en RAM
	fuente[numFuente].ReadyToConnect=false; // para no volverla a encender
	if (numFuente<8){
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(1,0xFF,mascara);
	} else {
		numFuente=numFuente-8;
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(2,0xFF,mascara);
	}
	// activar LED OUT ON
	dato=0x80;
	mascara=!dato;
	EscribeEnDriver(2,dato,mascara);
}

// actualizar con los nuevos campos!!!
//lee los datos de una fuente de flash y los mete en RAM
void LeeFuente(int i,tipo *pFuente){
		//fuente[i]=*pFuente; // esta instrucci�n deber�a sustituir las siguientes
		  fuente[i].potInicial=pFuente->potInicial; // m�ximo 256
		  fuente[i].fuenteOnInicio = pFuente->fuenteOnInicio;
		  fuente[i].maxCurrent=pFuente->maxCurrent;
		  fuente[i].minCurrent=pFuente->minCurrent;
		//  fuente[i].FiltroAlarmaCurrent=pFuente->FiltroAlarmaCurrent;
		//  fuente[i].FiltroSinAlarmaCurrent=pFuente->FiltroSinAlarmaCurrent;
		//  fuente[i].segsAlarmaCurrent=pFuente->segsSinAlarmaCurrent;
		//  fuente[i].segsSinAlarmaCurrent=pFuente->segsSinAlarmaCurrent;
		  fuente[i].TransicionEn_CurrEnLimites=pFuente->TransicionEn_CurrEnLimites;
		  fuente[i].currentEnLimites=pFuente->currentEnLimites;
		  fuente[i].alarmaCurrent =pFuente->alarmaCurrent;
		//  fuente[i].vigilarCurrent=pFuente->FiltroSinAlarmaCurrent;
		  fuente[i].maxVolts=pFuente->maxVolts;
		  fuente[i].minVolts=pFuente->minVolts;
		  //fuente[i].segsAlarmaVolts=pFuente->segsAlarmaVolts;
		  fuente[i].alarmaVolts =pFuente->alarmaVolts;
		  fuente[i].enviarAlarmas = pFuente->enviarAlarmas;
		  fuente[i].maxPot=pFuente->maxPot;
		  fuente[i].minPot=pFuente->minPot;
		  fuente[i].autorregVolts = pFuente->autorregVolts;
		  fuente[i].apagarSiAlarmaEnOtraFuente =pFuente->apagarSiAlarmaEnOtraFuente;
		  fuente[i].rShunt=pFuente->rShunt;
		  fuente[i].divisorTension1=pFuente->divisorTension1;
		  fuente[i].divisorTension2=pFuente->divisorTension2;
		  fuente[i].rAdicPotDigital=pFuente->rAdicPotDigital;
		  fuente[i].rDivisorPotDigital=pFuente->rDivisorPotDigital;
		    // variables
		  fuente[i].alarma = pFuente->alarma;
		  fuente[i].vout=pFuente->vout;
		  fuente[i].current=pFuente->current;
		  fuente[i]. pot=pFuente->pot;
		  fuente[i].fuenteOn= pFuente->fuenteOn;
		  fuente[i].voutMedia=pFuente->voutMedia;
		  fuente[i].currentMedia=pFuente->currentMedia;
		  fuente[i].VerifyKey =pFuente->VerifyKey;
}

// actualizar con los nuevos campos
//inicializa la fuente con los datos por defecto
void InicializaParametrosFuente(int i){
	  fuente[i].potInicial=128; // m�ximo 256
	  fuente[i].fuenteOnInicio = false;
	  fuente[i].maxCurrent=0;
	  fuente[i].minCurrent=0;
	  fuente[i].filtroAlarmaCurrent=0;
	  fuente[i].filtroSinAlarmaCurr=0;
	  fuente[i].segsAlarmaCurr=0;
	  fuente[i].segsSinAlarmaCurr=0;
	  fuente[i].TransicionEn_CurrEnLimites=false;
	  fuente[i].currentEnLimites=0;
	  fuente[i].alarmaCurrent = false;
	  fuente[i].vigilarCurrent=false;
	  fuente[i].desconSiAlarmCurr=true;
	  fuente[i].maxVolts=0;
	  fuente[i].minVolts=0;
	  fuente[i].filtroAlarmaVolts=0;
	  fuente[i].filtroSinAlarmaVolts=0;
	  fuente[i].segsAlarmaVolts=0;
	  fuente[i].segsSinAlarmaVolts=0;
	  fuente[i].TransicionEn_TensionEnLimites=false;
	  fuente[i].tensionEnLimites=false;
	  fuente[i].alarmaVolts = false;
	  fuente[i].vigilarVolts = false;
	  fuente[i].desconSiAlarmVolts = true;
	  fuente[i].enviarAlarmas = true;
	  fuente[i].ackAlarma = false;
	  fuente[i].maxPot=128; // m�ximo 256
	  fuente[i].minPot=128; // m�ximo 256
	  fuente[i].autorregVolts = false;
	  fuente[i].segsAutorregVolts = 0;
	  fuente[i].apagarSiAlarmaEnOtraFuente = true;
	  fuente[i].rShunt=1;
	  fuente[i].divisorTension1=1;
	  fuente[i].divisorTension2=1;
	  fuente[i].rAdicPotDigital=0;
	  fuente[i].rDivisorPotDigital=1;
	  fuente[i].temporizadoEncendido = 0;
	  fuente[i].ReadyToConnect = false;
	    // variables
	  fuente[i].alarma = false;
	  fuente[i].vout=0;
	  fuente[i].current=0;
	  fuente[i]. pot=128;
	  fuente[i].fuenteOn= false;
	  fuente[i].fuenteDesactivada=true;
	  fuente[i].voutMedia=0;
	  fuente[i].currentMedia=0;
	  fuente[i].VerifyKey = VERIFY_KEY;
}

// lee la BBDD de flash de todas las fuentes y verifica que no este corrompida.
// Si lo esta inicializa con datos por defecto para la fuente da�ada (alarma y apagada)
// y graba los datos de todas las fuentes en flash. Retorna true si ha habido error en la BBDD
int LeerParametrosFuente(void){
	 BOOL grabar=FALSE;
	 BYTE i=0;
	 tipo *pData = ( tipo * ) GetUserParameters();
	 //iprintf("Verify key = 0x%lX\r\n", pData->VerifyKey);
	 for (i=0;i<12;i++){
	      if ( pData->VerifyKey != VERIFY_KEY ){ // datos incorrectos
	    	  //iprintf("La clave de verificaci�n de la fuente %d no es v�lida\r\n",i);
	    	  InicializaParametrosFuente(i);
			  grabar=TRUE;
          }else { //datos correctos
			LeeFuente(i,pData);
		  }
	      pData++; //apuntar al siguiente registro
	  }
     if (grabar){
    	// iprintf("Grabando nueva Flash\r\n");
    	 SaveUserParameters( &fuente, sizeof( fuente ) );
     }
 return grabar;
}

// Env�a la informaci�n de la fuente por el puerto de serie
void EnviaInfoDeFuente(int numFuente){
	char buf[80]="Parametros de la fuente: ";
	char buf2[10]; //para meter dato
	char *f=buf2; // puntero que apunta a dato
	AnadeEnteroAMensaje(buf,numFuente); // a�adir numero de fuente
	AnadeEnteroAMensaje(buf,fuente[numFuente].potInicial);
	AnadeEnteroAMensaje(buf,fuente[numFuente].fuenteOnInicio);
	AnadeEnteroAMensaje(buf,fuente[numFuente].maxCurrent);
	AnadeEnteroAMensaje(buf,fuente[numFuente].minCurrent);
	AnadeEnteroAMensaje(buf,fuente[numFuente].filtroAlarmaCurrent);
	AnadeEnteroAMensaje(buf,fuente[numFuente].segsAlarmaCurr);
	AnadeEnteroAMensaje(buf,fuente[numFuente].segsSinAlarmaCurr);
	AnadeEnteroAMensaje(buf,fuente[numFuente].TransicionEn_CurrEnLimites);
	AnadeEnteroAMensaje(buf,fuente[numFuente].currentEnLimites);
	AnadeEnteroAMensaje(buf,fuente[numFuente].alarmaCurrent);
	AnadeEnteroAMensaje(buf,fuente[numFuente].vigilarCurrent);
	AnadeEnteroAMensaje(buf,fuente[numFuente].desconSiAlarmCurr);
	AnadeEnteroAMensaje(buf,fuente[numFuente].maxVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].minVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].filtroAlarmaVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].filtroSinAlarmaVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].segsAlarmaVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].segsSinAlarmaVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].TransicionEn_TensionEnLimites);
	AnadeEnteroAMensaje(buf,fuente[numFuente].tensionEnLimites);
	AnadeEnteroAMensaje(buf,fuente[numFuente].alarmaVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].vigilarVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].desconSiAlarmVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].enviarAlarmas);
	AnadeEnteroAMensaje(buf,fuente[numFuente].ackAlarma);
	AnadeEnteroAMensaje(buf,fuente[numFuente].maxPot);
	AnadeEnteroAMensaje(buf,fuente[numFuente].minPot);
	AnadeEnteroAMensaje(buf,fuente[numFuente].autorregVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].segsAutorregVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].apagarSiAlarmaEnOtraFuente);
	AnadeEnteroAMensaje(buf,fuente[numFuente].rShunt);
	AnadeEnteroAMensaje(buf,fuente[numFuente].divisorTension1);
	AnadeEnteroAMensaje(buf,fuente[numFuente].divisorTension2);
	AnadeEnteroAMensaje(buf,fuente[numFuente].rAdicPotDigital);
	AnadeEnteroAMensaje(buf,fuente[numFuente].rDivisorPotDigital);
	AnadeEnteroAMensaje(buf,fuente[numFuente].temporizadoEncendido);
	AnadeEnteroAMensaje(buf,fuente[numFuente].ReadyToConnect);
	AnadeEnteroAMensaje(buf,fuente[numFuente].alarma);
	AnadeEnteroAMensaje(buf,fuente[numFuente].vout);
	AnadeEnteroAMensaje(buf,fuente[numFuente].current);
	AnadeEnteroAMensaje(buf,fuente[numFuente].pot);
	AnadeEnteroAMensaje(buf,fuente[numFuente].fuenteOn);
	AnadeEnteroAMensaje(buf,fuente[numFuente].fuenteDesactivada);
	AnadeEnteroAMensaje(buf,fuente[numFuente].voutMedia);
	AnadeEnteroAMensaje(buf,fuente[numFuente].currentMedia);
	AnadeStringAMensaje(buf,"#");
	f=buf;
	//EnvioUart(f); // activar cuando esten activas las comunicaciones

}

// a�ade campo para la generaci�n de mensajes hacia MOD5270 incluyendo separador '#' al inicio
char *  AnadeEnteroAMensaje(char * buffer, int dato){
		char buf2[10];
		char *f=buf2;
		AnadeStringAMensaje(buffer,"#");
		itoa(dato,f);
		strcat(buffer,f);
		return buffer;
}

char *  AnadeStringAMensaje(char * buffer, char *dato){
		strcat(buffer,dato);
		return buffer;
}



// extrae campo del mensaje recibido del MOD5270 y retorna puntero a mensaje en la nueva posicion
char * ExtraeCampoAMensaje(char * mensaje){
return mensaje;
}

// itoa:  convert n to characters in s
void itoa(int n, char s[]){
     int i, sign;
     if ((sign = n) < 0)  // record sign
         n = -n;          // make n positive
     i = 0;
     do {       // generate digits in reverse order
         s[i++] = n % 10 + '0';   // get next digit
     } while ((n /= 10) > 0);     // delete it
     if (sign < 0)
         s[i++] = '-';
     s[i] = '\0';
     reverse(s);
}

// reverse:  reverse string s in place
void reverse(char s[]){
     int i, j;
     char c;
     for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
         c = s[i];
         s[i] = s[j];
         s[j] = c;
     }
}



// ajusta el potenci�metro de la tension de salida
void AjustarPotenciometroVout(int numFuente,int valor){
	SeleccionaSCL(numFuente); // seleccionar SCL1,2,3 seg�n fuente...
	EscribeEnPotDig(SeleccionaAddressPotDig(numFuente),valor); // modifica valor pot
	fuente[numFuente].pot=valor; // actualizar RAM

}

//  Comprueba que la tensi�n esta dentro de los l�mites y actualiza valor vout y tension en l�mites  en ram
BOOL TensionEnLimites(int numFuente){
	BOOL enLimites=true;
	float volts = ( (float)fuente[numFuente].vout / (4095.0)) * 3.3;
	volts=volts*fuente[numFuente].divisorTension2/(fuente[numFuente].divisorTension1+fuente[numFuente].divisorTension2);
	if (volts>fuente[numFuente].maxVolts || volts<fuente[numFuente].minVolts) enLimites=false;
	if(fuente[numFuente].tensionEnLimites!=enLimites){ // es estado que tenia antes no coincide con el actual
		fuente[numFuente].TransicionEn_TensionEnLimites=true; // detectada transicion
		fuente[numFuente].tensionEnLimites=enLimites; // actualizar al nuevo estado
	}
	return enLimites;
}



// actualiza en Ram el valor de la tensi�n(cuentas cad)
void LeerTensionFuente(int numFuente){
	int cuentas;
	SeleccionLecturaTension(numFuente); // prepara los muxes para lectura de tensi�n.
	cuentas=LecturaCAD();
	fuente[numFuente].vout=cuentas;
}


// actualiza en Ram el valor de la corriente(cuentas cad)
void LeerCorrienteFuente(int numFuente){
	int cuentas;
	SeleccionLecturaCorriente(numFuente); // prepara los muxes para lectura de tensi�n.
	cuentas=LecturaCAD();
	fuente[numFuente].current=cuentas;
}

// rutina llamada por monitor. Enciende las fuentes pendientes
void EncenderFuentes(void){
	int i;
	for (i=0;i<12;i++){
		if (fuente[i].ReadyToConnect==true && fuente[i].fuenteOn==false) {
			// la fuente esta apagada y lista para encender
			ConectarFuente(i);
		}
	}
}
*/
