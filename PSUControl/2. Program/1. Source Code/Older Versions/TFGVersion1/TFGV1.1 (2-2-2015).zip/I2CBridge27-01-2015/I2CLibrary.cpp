/*
 * I2CLibrary.c
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#include "i2CLibrary.h"


//---------------------------------------Variables---------------------------------------------------//
BYTE I2CStat;
BYTE bridgeAddress = 0x2F; // 0x28 to 0x2F possible. 3 last bits are configurable with switches

BYTE outputBuffer[I2C_MAX_BUF_SIZE];   	// User created I2C output buffer
BYTE* poutbuf = outputBuffer;         	// Pointer to user I2C output buffer


//-------------------------------------------------------------------------------------------------------
// sendI2CMessage sends the bufSize Bytes from bufi2c to the bridgeAddress through I2C including a null at the end
//-------------------------------------------------------------------------------------------------------
void sendI2CMessage ( BYTE bufi2c[], int bufSize, BYTE destAddress){
		iprintf( "Sending message to I2C address 0x%x\r\n", destAddress );
		printBuffer(bufi2c, bufSize);
		I2CStat = I2CSendBuf(destAddress, bufi2c, bufSize);// Send the buffer size plus one to include the null character
		if( I2CStat == I2C_OK )
		   iprintf( "Sent successfully\r\n\r\n" );
		else
		   iprintf( "Failed to send to address %x due to error: %d\r\n\r\n", destAddress ,I2CStat);
}



//-------------------------------------------------------------------------------------------------------
// configureSPI sends 2 bytes using outputBuffer to configure the SPI channel using the bridge.
//-------------------------------------------------------------------------------------------------------
void configureSPI( BOOL order, BOOL cpol, BOOL cpha, int clkRate ){
		BYTE funH=0x20 * order + 0x08 * cpol + 0x04 * cpha;   	// Initialize Order (MSB/LSB first) Clock Polarity (cpol) and Phase (cpha)
		if ((clkRate < 4) && (clkRate > 0)){					// Values from 0 to 3 possible. Default is 0.
			funH+=clkRate;										//	0 -> 1.8MHz; 1 -> 461KHz; 2 -> 115KHz; 3 -> 58KHz;
		}
		*poutbuf++ = 0xF0;										// Initialization function
		*poutbuf++ = funH;										// Function parameters
		poutbuf = outputBuffer;
		iprintf( "Configuring SPI channel...\r\n" );
		printBuffer( outputBuffer, 2);
		sendI2CMessage( outputBuffer, 2, bridgeAddress);
}



//-------------------------------------------------------------------------------------------------------
// sendSPImessage sends bufSize Bytes from the BufSPI buffer to the selected SPI Slaves (0x0 to 0xF possible)
//-------------------------------------------------------------------------------------------------------
void sendSPImessage ( BYTE BufSPI[], int bufSize, BYTE slaveSelect ){
		if (slaveSelect>0x0F){
			iprintf("Wrong SPI address");
		}
		else{
			*poutbuf++=slaveSelect;
			mergeBuffer(poutbuf, BufSPI, bufSize);
			poutbuf = outputBuffer;
			sendI2CMessage( outputBuffer, bufSize + 1 , bridgeAddress);
		}
}



//-------------------------------------------------------------------------------------------------------
// receiveMessage reads the bufSize Bytes from the Bridge buffer and writes them into inputBuffer
//-------------------------------------------------------------------------------------------------------
void receiveMessage ( BYTE inputBuffer[], int bufSize){
		I2CStat = I2CReadBuf(bridgeAddress, inputBuffer, bufSize);
		iprintf( "Reading bridge buffer...\r\n" );
		if( I2CStat == I2C_OK )
		{
			iprintf("Data Received: " );
			printBuffer(inputBuffer, bufSize);
			iprintf("Receive successfully\r\n" );
		}
		else
		   iprintf("Failed to read due to error: %d\r\n", I2CStat);
}



