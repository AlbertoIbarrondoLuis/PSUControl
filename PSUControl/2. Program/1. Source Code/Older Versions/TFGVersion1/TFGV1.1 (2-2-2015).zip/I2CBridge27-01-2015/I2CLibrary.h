/*
 * Library.h
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#ifndef I2CLIBRARY_H_
#define I2CLIBRARY_H_
#endif /* LIBRARY_H_ */

#include "predef.h"
#include <ctype.h>
#include <basictypes.h>					// BOOL & BYTE
#include <system.h>
#include <constants.h>
#include <ucos.h>
#include <ucosmcfc.h>
#include <serialirq.h>
#include <stdio.h>						// uint
#include <smarttrap.h>
#include <serialupdate.h>
#include "i2cmulti.h"            		//Used for Multi-Master I2C
#include <string.h>
#include <Pins.h>
#include <bsp.h>            			// MOD5213 board support package interface
#include <gdbstub.h>
#include <utils.h>          			// Include for usage of carrier board LEDs
#include <sim5213.h>        			// Access to MCF5213 register structures
#include <stdlib.h>
#include "GeneralLibrary.h"

//----------------------------------------Functions--------------------------------------------------//
void sendI2CMessage ( BYTE bufi2c[], int bufSize, BYTE destAddress);
void configureSPI( BOOL order, BOOL cpol, BOOL cpha, int clkRate );
void sendSPImessage ( BYTE BufSPI[], int bufSize, BYTE slaveSelect );
void receiveMessage (BYTE sendAddress[], int bufSize);


