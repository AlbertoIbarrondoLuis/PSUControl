/*
 * RDACcomplexLibrary.h
 *
 *  Created on: 02-feb-2015
 *      Author: Alberto
 */

#ifndef RDACCOMPLEXLIBRARY_H_
#define RDACCOMPLEXLIBRARY_H_


#endif /* RDACCOMPLEXLIBRARY_H_ */

#include "RDACCommandLibrary.h"
#include "I2CLibrary.h"

void setRDAC(int value, BYTE slaveSelect, BYTE I2CAdress);
void highImpRDAC(int slaveSelect, BYTE I2CAdress);
void getRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress);
void readCtrlRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress);
void resetRDAC(int slaveSelect, BYTE I2CAdress);
void shutdownRDAC(BOOL shutdownModeOn,int slaveSelect, BYTE I2CAdress);
void donothingRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress);
