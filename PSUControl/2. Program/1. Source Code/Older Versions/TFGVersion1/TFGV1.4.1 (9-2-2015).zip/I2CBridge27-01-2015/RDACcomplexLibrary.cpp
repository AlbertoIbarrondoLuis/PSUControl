/*
 * RDACcomplexLibrary.cpp
 *
 *  Created on: 02-feb-2015
 *      Author: Alberto
 */

#include "RDACComplexLibrary.h"
#include "I2CLibrary.h"

BOOL config = false;
BYTE outputBuffer[I2C_MAX_BUF_SIZE];			// Used to send every message
BYTE inputBuffer[I2C_MAX_BUF_SIZE];				// Used to receive every message
BYTE auxBuffer[I2C_MAX_BUF_SIZE];				// Used for auxiliary purposes

float Rpsu1 = 800;								// Different for each PSU

void setRDAC(int value, BYTE slaveSelect, BYTE I2CAdress){
	/*readCtrlRDAC(auxBuffer,slaveSelect,I2CAdress);
	config=((0x02 & auxBuffer[1])> 0);
	iprintf("auxBuffer[1] = %x\n", auxBuffer[1]);
	iprintf("Config = %d\n", config);
	iprintf("result = %d\n", 0x02 & auxBuffer[1]);
	if ( !config ){
		writeCtrl(outputBuffer, false, true, false);
		BYTE* poutBuf = outputBuffer;
		poutBuf+=2;
		donothing(poutBuf);
		sendSPImessage ( outputBuffer, 4, slaveSelect, I2CAdress);
		OSTimeDly( 1 );
		config=true;
	}
	float scaledValue = (1-((((float)volt/1.25)-1)*Rpsu1/20000))*1024;*/

	writeReg(outputBuffer, value );
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	iprintf("Configured value %d in slave %d\n\n", value, slaveSelect );
	/*donothingRDAC(auxBuffer, slaveSelect, I2CAdress);*/
}

void highImpRDAC(int slaveSelect, BYTE I2CAdress){
	highImp(outputBuffer);
	BYTE* poutBuf = outputBuffer;
	poutBuf+=2;
	donothing(poutBuf);
	sendSPImessage ( outputBuffer, 4, slaveSelect,I2CAdress);
	iprintf("High Impedance in slave %d\n\n", slaveSelect );
}

void getRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress){
	readReg(outputBuffer);
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	readBridgeBuffer( inputBuffer, 2 );
	mergeBuffer( ibuf, inputBuffer, 2 );

}

void resetRDAC(int slaveSelect, BYTE I2CAdress){
	reset(outputBuffer);
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	donothingRDAC( auxBuffer, slaveSelect, I2CAdress );
}

void shutdownRDAC(BOOL shutdownModeOn,int slaveSelect, BYTE I2CAdress){
	shutdown(outputBuffer, shutdownModeOn);
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
}

void readCtrlRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress){
	readCtrl(outputBuffer);
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	readBridgeBuffer( inputBuffer, 2 );
	/*if (!((inputBuffer[0] & 0xff) && (inputBuffer[1] & 0xfd))){
		mergeBuffer( ibuf, inputBuffer, 2 );
	}
	else{
		donothingRDAC( ibuf, slaveSelect, I2CAdress );
	}*/
}

void donothingRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress){
	donothing( outputBuffer );
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	readBridgeBuffer( inputBuffer, 2 );
	mergeBuffer( ibuf, inputBuffer, 2 );
}
