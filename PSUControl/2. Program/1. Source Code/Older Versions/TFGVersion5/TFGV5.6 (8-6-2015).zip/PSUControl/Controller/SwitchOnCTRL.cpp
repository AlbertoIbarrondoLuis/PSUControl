	/*
 * SwitchOnCTRL.cpp
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */


#include "Controller/Controller.h"

//==============================================VARIABLES==============================================//
// Data Lists
extern PSU_TYPE psuList[PSU_NUMBER];			// Power supply units' array list
extern BOOL psuSelectionList[PSU_NUMBER];		// Used for several functions where multiple psu selection is required.

// Switching ON
BOOL powerONProcess = false; 					// used to initialize the system.
int powerONticks=0; 							// delay counter when initializing the system.
BOOL psuSelectionListPending [PSU_NUMBER] = {0,0,0,0,0,0,0,0,0,0,0,0};		// bits in TRUE are PSUs pending to be switched on

// Testing
extern BOOL testMode_SwitchOnCTRL_Task_FLAG;
extern int testMode_psu_initializationTimer[PSU_NUMBER];


//=====================================================================================================//
//================================    PSUs SWITCH ON/OFF METHODS    ===================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// switchONPSUs - Manages the complete PSU switching-on process for the selected PSUs: Initializes
//				its RAM values, changes its RDAC Register values, tells the switchONPSUsTask to
//				begin the delayed switching-on process.
//-------------------------------------------------------------------------------------------------------
void switchONPSUsTask( BOOL psuSelection[PSU_NUMBER] ){
	powerONProcess=true;					// Beginning of the process

	initializeValuesPSUsSnIs();				// Load psuList values from RAM or set them to default

	updateVoltagePSUs( psuSelection );		// Sets the PSUs' potentiometers (RDACS) to the loaded/default values

	switchONPSUs( psuSelection );		// Task to initialize PSUs with certain delay (initializationTimer)

    powerONProcess=false;					// End of the process
}



//-------------------------------------------------------------------------------------------------------
// switchONPSUsTask - Task in charge of the PSUs' delayed switching-on process, connecting the relays
//					  when each PSU reaches its initializationTimer. When every PSU has been connected, the
//					  task is destroyed.
//-------------------------------------------------------------------------------------------------------
void switchONPSUs( void ){ memset(psuSelectionList, 1, PSU_NUMBER); switchONPSUs(psuSelectionList);}
void switchONPSUs( BOOL psuSelection[PSU_NUMBER] ){
	powerONticks = 0; memcpy(psuSelectionListPending, psuSelection, PSU_NUMBER);
	int psuNum; BOOL allConnected = false;
	if (testMode_SwitchOnCTRL_Task_FLAG){
		iprintf("powerONticks = %d  -  PSUs pending: ", powerONticks);
		printBuffer(psuSelectionListPending, PSU_NUMBER);iprintf("\n");
	}
	while(!allConnected){
		allConnected = true;
		for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
			if(psuSelectionListPending[psuNum]){
				if(psuList[psuNum].initializationTimer == powerONticks){
					psuList[psuNum].ReadyToConnect = true;
					connectPSU(psuNum);
					//adjustRdac (psuNum, psuList[psuNum].progValue);
					psuSelectionListPending[psuNum] = false;
					if(testMode_SwitchOnCTRL_Task_FLAG){
						testMode_psu_initializationTimer[psuNum]= powerONticks;
					}
				}
				else {
					allConnected = false;
				}
			}
		}

		if (testMode_SwitchOnCTRL_Task_FLAG){
			iprintf("powerONticks = %d  -  PSUs pending: ", powerONticks);
			printBuffer(psuSelectionListPending, PSU_NUMBER);iprintf("\n");
		}

		powerONticks++;
		OSTimeDly(TICKS_100MS);
	}
}

//-------------------------------------------------------------------------------------------------------
// switchOFFPSUs - Disconnects the selected PSUs' relays, updating its LED OUT, and sets their power to minimum
//-------------------------------------------------------------------------------------------------------
void switchOFFPSUs( void ){ memset(psuSelectionList, true, sizeof(psuSelectionList)); switchOFFPSUs(psuSelectionList);}
void switchOFFPSUs( BOOL psuSelection[PSU_NUMBER] ){
	int psuNum;
	for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
		if(psuSelection[psuNum]){
			psuList[psuNum].ReadyToConnect=false;
			disconnectRelay ( psuNum );
			psuList[psuNum].relayStatus=false;
			adjustRdac(psuNum, INITIAL_VOLTAGE);
			psuList[psuNum].psuStatus=false;
		}
	}
	// TODO: desactivar  led Out On. Comprobar el voltaje para asegurar que se ha desconectado
}



//-------------------------------------------------------------------------------------------------------
// connectPSU - Connects the selected PSU by switching its Relay and activates its LED OUT
//-------------------------------------------------------------------------------------------------------
void connectPSU ( int psuNum ){
	connectRelay ( psuNum );
	// TODO: activar LED OUT ON. quiz� esperar alguna medida de tensi�n para asegurar que funciona
	psuList[psuNum].psuStatus=true;
	psuList[psuNum].ReadyToConnect=false;
}


//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSUs' relays, updates its LED OUT, and sets its power to minimum
//-------------------------------------------------------------------------------------------------------
void disconnectPSU(int psuNum){
	psuList[psuNum].ReadyToConnect=false;
	disconnectRelay ( psuNum );
	psuList[psuNum].relayStatus=false;
	adjustRdac(psuNum, INITIAL_VOLTAGE);
	psuList[psuNum].psuStatus=false;
	// TODO: comprobar si se ha de desactivar  led Out On y si el voltaje se ha desconectado
}
