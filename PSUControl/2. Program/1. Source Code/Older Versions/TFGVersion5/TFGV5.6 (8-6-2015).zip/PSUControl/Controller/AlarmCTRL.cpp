/*
 * AlarmCTRL.cpp
 *
 *	RTOS task executed once every 100ms that checks the voltage & current of
 *	all the PSUs and triggers alarms if a limit is reached
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */

#include "Controller/Controller.h"


//===========================================VARIABLES=================================================//
// Data Lists
extern PSU_TYPE psuList[PSU_NUMBER];			// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];		// Supply & Internal voltages List

extern BOOL psuSelectionList[PSU_NUMBER];				// Used for various functions where multiple psu selection is required.
extern BOOL sniSelectionList[SnI_NUMBER];				// Used for various functions where multiple sni selection is required.
extern BOOL alarmSelectionList[ALARM_NUMBER];			// Used for various functions where multiple alarm selection is required.

// Timing
extern int alarmUpdatePeriodx50MS;

// Configuration
extern BOOL config_AlarmCTRLUpdate_SnI_FLAG;

// Testing
extern BOOL iddleMode_AlarmCTRL_Task_FLAG;

//=====================================================================================================//
//======================================    ALARM METHODS    ==========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// alarmTask - Independent process in charge of monitoring all the PSU alarms once every 100ms
//				and executing the programmed protocols once every second if an alarm is triggered.
//-------------------------------------------------------------------------------------------------------
void alarmTask (void *p){
	int nled = 0;
	BOOL ledFlag = true;
	while (1){
		OSTimeDly(alarmUpdatePeriodx50MS);   	// Critical, otherwise the lower tasks wont receive computing time.
		//OSSemPend( & alarmSem, 0);
		if(!iddleMode_AlarmCTRL_Task_FLAG){
			updateAlarms();
			nled++;
			if (nled>=5){Pins[28] = ledFlag;	// Uses LED 0 as output
						 ledFlag = !ledFlag;
						 nled= 0;
			}
		}
	}

}

//-------------------------------------------------------------------------------------------------------
// alarmCheck - Checks each alarm status for the selected PSU and executes the programmed protocols
//				if activated.
//-------------------------------------------------------------------------------------------------------
void alarmCheck (int Num, BOOL inf_sup, BOOL volt_corr, BOOL psu_sni){
	if (psu_sni == PSU_TYPE_LIST){		// Checking a PSU_TYPE from psuList
		if(psuList[Num].alarmWatch[_(inf_sup,volt_corr)]){				// If the selected alarm is being watched (INFERIOR/SUPERIOR, VOLTAGE/CURRENT)
																					// Refresh alarmLimitReached value
			if   (inf_sup==INFERIOR) {psuList[Num].alarmLimitReached[_(inf_sup,volt_corr)]=((volt_corr==VOLTAGE?psuList[Num].vOut:psuList[Num].cOut) <= psuList[Num].alarmLimitValues[_(inf_sup,volt_corr)]);}
			else/*inf_sup==SUPERIOR*/{psuList[Num].alarmLimitReached[_(inf_sup,volt_corr)]=((volt_corr==VOLTAGE?psuList[Num].vOut:psuList[Num].cOut) >= psuList[Num].alarmLimitValues[_(inf_sup,volt_corr)]);}
			if (psuList[Num].alarmLimitReached[_(inf_sup,volt_corr)]){			// If limit is exceeded
				psuList[Num].alarmCounters[_(inf_sup,volt_corr)]++;					// Increment Alarm Counter

				if (psuList[Num].alarmCounters[_(inf_sup,volt_corr)]>=psuList[Num].alarmLimitTimes[_(inf_sup,volt_corr)]){
																						//  Trigger on the alarm if counter reaches the time limit
					if (psuList[Num].alarmStatus[_(inf_sup,volt_corr)] == false ){			// If it's the first time the alarm is triggered, execute protocols
						psuList[Num].alarmStatus[_(inf_sup,volt_corr)] = true;
						int j;
						for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){									// Goes over each alarm protocol for the activated alarm
							if (psuList[Num].alarmProtocols[__(inf_sup,volt_corr, j)]){
								executeAlarmProtocol (Num, inf_sup,volt_corr, j, psu_sni);
							}
						}
					}
					psuList[Num].alarmCounters[_(inf_sup,volt_corr)]=psuList[Num].alarmLimitTimes[_(inf_sup,volt_corr)];
				}																		// Sets the counter to time limit (thus preventing it to increase further)
			}
			else{																	// If limit is not exceeded
				if (psuList[Num].alarmCounters[_(inf_sup,volt_corr)] > 0){			// And counter is higher than 0
					psuList[Num].alarmCounters[_(inf_sup,volt_corr)] -= 1;			// Decrease counter until it reaches 0

				}
				if (psuList[Num].alarmCounters[_(inf_sup,volt_corr)] == 0){			// And when it hits 0, shut off the alarm.
					psuList[Num].alarmStatus[_(inf_sup,volt_corr)] = false;
				}
			}
		}
		else{
			psuList[Num].alarmCounters[_(inf_sup,volt_corr)] = 0;
			psuList[Num].alarmStatus[_(inf_sup,volt_corr)] = false;
		}
	}

	else{			// psu_aux = CHECK_AUX    - Checking an SnI_TYPE from auxList
		if(sniList[Num].alarmWatch[_(inf_sup,volt_corr)]){				// If the selected alarm is being watched (INFERIOR/SUPERIOR, VOLTAGE/CURRENT)
																					// Refresh alarmLimitReached value
			if(inf_sup == INFERIOR){
				sniList[Num].alarmLimitReached[_(inf_sup,volt_corr)]=(sniList[Num].vOut <= sniList[Num].alarmLimitValues[_(inf_sup,volt_corr)]);
			}
			else{
				sniList[Num].alarmLimitReached[_(inf_sup,volt_corr)]=(sniList[Num].vOut >= sniList[Num].alarmLimitValues[_(inf_sup,volt_corr)]);
			}
			if (sniList[Num].alarmLimitReached[_(inf_sup,volt_corr)]){			// If limit is exceeded
				sniList[Num].alarmCounters[_(inf_sup,volt_corr)]++;					// Increment Alarm Counter

				if (sniList[Num].alarmCounters[_(inf_sup,volt_corr)]>=sniList[Num].alarmLimitTimes[_(inf_sup,volt_corr)]){
																						//  Trigger on the alarm if counter reaches the time limit
					if (sniList[Num].alarmStatus[_(inf_sup,volt_corr)] == false ){			// If it's the first time the alarm is triggered, execute protocols
						sniList[Num].alarmStatus[_(inf_sup,volt_corr)] = true;
						int j;
						for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){									// Goes over each alarm protocol for the activated alarm
							if (sniList[Num].alarmProtocols[__(inf_sup,volt_corr, j)]){
								executeAlarmProtocol (Num, inf_sup,volt_corr, j, psu_sni);
							}
						}
					}
					sniList[Num].alarmCounters[_(inf_sup,volt_corr)]=sniList[Num].alarmLimitTimes[_(inf_sup,volt_corr)];
				}																		// Sets the counter to time limit (thus preventing it to increase further)
			}
			else{																	// If limit is not exceeded
				if (sniList[Num].alarmCounters[_(inf_sup,volt_corr)] > 0){			// And counter is higher than 0
					sniList[Num].alarmCounters[_(inf_sup,volt_corr)] -= 1;			// Decrease counter until it reaches 0

				}
				if (sniList[Num].alarmCounters[_(inf_sup,volt_corr)] == 0){			// And when it hits 0, shut off the alarm.
					sniList[Num].alarmStatus[_(inf_sup,volt_corr)] = false;
				}
			}
		}
		else{
			sniList[Num].alarmCounters[_(inf_sup,volt_corr)] = 0;
			sniList[Num].alarmStatus[_(inf_sup,volt_corr)] = false;
		}
	}
}


//-------------------------------------------------------------------------------------------------------
// executeAlarmProtocol - Carries out a different protocol depending of the type of alarm
//						 (SUPERIOR/INFERIOR,VOLTAGE/CURRENT).
//-------------------------------------------------------------------------------------------------------
void executeAlarmProtocol (int Num, BOOL inf_sup, BOOL volt_corr, int protocolNum, int psu_sni){
	int k;
	switch (protocolNum){		// (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
	case PROTOCOL_SHUTDOWN:
		WORD shutdown;
		shutdown = psuList[Num].alarmProtocolShutdown[_(inf_sup, volt_corr)];
		for (k=0; k<12; k++){
			if (shutdown&0x1){
				disconnectPSU(Num);
			}
			shutdown = shutdown >>1;
		}
		break;
	case PROTOCOL_MODIFY_VOLTAGE:
			adjustRdac(Num, psuList[Num].alarmProtocolVoltage[_(inf_sup,volt_corr)]);
		break;
	case PROTOCOL_MESSAGE:

			iprintf(ALARM_MESSAGE);
			//TODO: Maybe add some other alarm output - left for future implementation
		break;
	}
}

//-------------------------------------------------------------------------------------------------------
// updateAlarms - Takes a sample of Voltage and Current for all the PSUs and updates
// 				  their alarm status, counters and flags by comparing the sample with
//				  the programmed limit
//-------------------------------------------------------------------------------------------------------
void updateAlarms (void){
	int psuNum;
	// Goes over each PSU in psuList
	for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
		// Check each alarm
		if (psuList[psuNum].psuStatus==ON){
			alarmCheck(psuNum, INFERIOR, VOLTAGE, PSU_TYPE_LIST);
			alarmCheck(psuNum, SUPERIOR, VOLTAGE, PSU_TYPE_LIST);
			alarmCheck(psuNum, INFERIOR, CURRENT, PSU_TYPE_LIST);
			alarmCheck(psuNum, SUPERIOR, CURRENT, PSU_TYPE_LIST);
		}
	}

	//Same procedure for auxList, controlled by AuxAlarmUpdatingFLAG (default switched off)
	if (config_AlarmCTRLUpdate_SnI_FLAG){
		for (psuNum=0; psuNum<SnI_NUMBER; psuNum++){
			alarmCheck(psuNum, INFERIOR, VOLTAGE, SnI_TYPE_LIST);
			alarmCheck(psuNum, SUPERIOR, VOLTAGE, SnI_TYPE_LIST);
		}
	}
}


//-------------------------------------------------------------------------------------------------------
// resetAlarms - disconnects the alarms of each PSU/SnI (defined by psu_sni) set as 1 on its correspondent
//					bit in list. The alarms to be disconnected are set on the bits of alarmType
//-------------------------------------------------------------------------------------------------------
void resetAlarms ( void ) {	memset(psuSelectionList, 1, sizeof(psuSelectionList)); // Resets All the alarms
							memset(alarmSelectionList, 1, sizeof(alarmSelectionList));
							memset(sniSelectionList, 1, sizeof(sniSelectionList));
							resetAlarms(psuSelectionList, alarmSelectionList, PSU_TYPE_LIST);
							resetAlarms(sniSelectionList, alarmSelectionList, SnI_TYPE_LIST);}
void resetAlarms ( BOOL Selection[] ,  BOOL alarmSelection[ALARM_NUMBER] , BOOL psu_sni){
	uint k; uint g;
	if (psu_sni==PSU_TYPE_LIST){
		for (k=0; k<PSU_NUMBER; k++){
			if ( Selection[k] ){
				for (g=0; g<ALARM_NUMBER; g++){
					if(alarmSelection[g]){
						psuList[k].alarmCounters[g] = 0;
						psuList[k].alarmStatus[g] = false;
						psuList[k].alarmLimitReached[g]=false;
					}
				}
			}
		}
	}
	else{ // psu_sni==SnI_TYPE_LIST
		for (k=0; k<SnI_NUMBER; k++){
			if ( Selection[k] ){
				for (g=0; g<ALARM_NUMBER-2; g++){
					if(alarmSelection[g]){
						sniList[k].alarmCounters[g] = 0;
						sniList[k].alarmStatus[g] = false;
						sniList[k].alarmLimitReached[g]=false;
					}
				}
			}
		}
		iprintf("]\n");
	}
}


//-------------------------------------------------------------------------------------------------------
// toggleAlarmsAll - connects all the alarms (alarmWatch = 1) of each PSU/SnI
//-------------------------------------------------------------------------------------------------------
void toggleAlarms (  BOOL almWatch  ) {	memset(psuSelectionList, 1, sizeof(psuSelectionList)); // Resets All the alarms
										memset(alarmSelectionList, 1, sizeof(alarmSelectionList));
										memset(sniSelectionList, 1, sizeof(sniSelectionList));
										toggleAlarms(psuSelectionList, alarmSelectionList, PSU_TYPE_LIST, almWatch);
										toggleAlarms(sniSelectionList, alarmSelectionList, SnI_TYPE_LIST, almWatch);}
void toggleAlarms ( BOOL Selection[] ,  BOOL alarmSelection[ALARM_NUMBER] , BOOL psu_sni, BOOL almWatch){
	uint k; uint g;
	if (psu_sni==PSU_TYPE_LIST){
		for (k=0; k<PSU_NUMBER; k++){
			if ( Selection[k] ){
				for (g=0; g<ALARM_NUMBER; g++){
					if(alarmSelection[g]){
						psuList[k].alarmWatch[g]=almWatch;
					}
				}
			}
		}
	}
	else{ // psu_sni==SnI_TYPE_LIST
		for (k=0; k<SnI_NUMBER; k++){
			if ( Selection[k] ){
				for (g=0; g<ALARM_NUMBER-2; g++){
					if(alarmSelection[g]){
						sniList[k].alarmWatch[g]=almWatch;
					}
				}
			}
		}
	}
}


//-------------------------------------------------------------------------------------------------------
// setAlarm - Sets both the value and the time for the desired alarm, turning it on (alarmWatch)
//-------------------------------------------------------------------------------------------------------
void setAlarm ( BOOL psu_sni, int num, BOOL volt_curr, BOOL inf_sup, float value, int time){
	if(psu_sni==PSU_TYPE_LIST){
		setalarmLimitValuesPSU(value, inf_sup, volt_curr, num);
		setalarmLimitTimesPSU(time, inf_sup, volt_curr, num);
		setalarmWatchPSU(true, inf_sup, volt_curr, num);
	}
	else{
		setalarmLimitValuesSnI(value, inf_sup, VOLTAGE, num);
		setalarmLimitTimesSnI(time, inf_sup, VOLTAGE, num);
		setalarmWatchSnI(true, inf_sup, volt_curr, num);
	}
}
