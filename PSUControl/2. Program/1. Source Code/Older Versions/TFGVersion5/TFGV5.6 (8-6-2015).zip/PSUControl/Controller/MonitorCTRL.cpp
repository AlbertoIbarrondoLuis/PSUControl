/*
 * MonitorCTRL.cpp
 *
 *	Continuous sampling of all the PSUs (and auxiliaries, when properly set). To do so, the RTOS task
 *	waits for the interrupt to post on monitorSem (an OS_SEM), and then goes over the next loop.
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */


#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List

//==============================================VARIABLES==============================================//
// Imported
extern OS_SEM monitorSem;					// Semaphore where PIT1 Posts and monitorTask Pends.
extern BOOL maxAGCReached;					// AGC boolean that determines if the maximum gain has been reached

// A2D Sampling
int lastMeasure = 0;
BOOL lastMeasureValid = false;
BYTE samplingFunction = FUNCTION_PSU_VOLTAGE;
int monitorNum = 0;

// Configuration Flags
extern BOOL config_MonitorCTRL_SnI_FLAG;	// Sets whether both Supply and Internal voltages are included in a2d routine loop or not

// Testing
extern BOOL seqMode_MonitorCTRL_Task_FLAG;
extern OS_SEM seqMode_MonitorCTRLTask_Sem;
extern BOOL testMode_MonitorCTRL_Measure_FLAG;
extern WORD testMode_Measure;

// Auxiliary
int a = 0;

//=====================================================================================================//
//======================================    MONITOR METHODS    ========================================//
//=====================================================================================================//
void monitorTask (void* p){
	int ledAux = 0;
	BOOL ledFlag = false;
	while(1){	// loop forever

		OSSemPend( & monitorSem , 0 );
		if (seqMode_MonitorCTRL_Task_FLAG){OSSemPend( & seqMode_MonitorCTRLTask_Sem , 0 );}

		lastMeasure = (testMode_MonitorCTRL_Measure_FLAG?testMode_Measure:(ReadA2DResult(0) >> 3));
		lastMeasureValid = ((lastMeasure>MINIMUM_LEVEL_ADC || maxAGCReached) &&(lastMeasure<MAXIMUM_LEVEL_ADC));
		if (lastMeasureValid){
			switch (samplingFunction){	//Store Value in the right object
				case FUNCTION_PSU_VOLTAGE:
					psuList[monitorNum].vOut= ADCCountsToVoltORCurr(lastMeasure, samplingFunction, monitorNum);
					break;
				case FUNCTION_PSU_CURRENT:
					psuList[monitorNum].cOut= ADCCountsToVoltORCurr(lastMeasure, samplingFunction, monitorNum);
					break;
				case FUNCTION_SnI_VOLTAGE:
					sniList[monitorNum].vOut= ADCCountsToVoltORCurr(lastMeasure, samplingFunction, monitorNum);
					break;
			}
			minAGC();	// Set AGC always to minimum upon next voltage sampling

			// Next PSU, and next samplingFunction (see defineConstants.cpp - MUX) if last PSU reached
			monitorNum++;
			if (config_MonitorCTRL_SnI_FLAG){
				if( ((samplingFunction<=FUNCTION_PSU_CURRENT) &&  (monitorNum>=PSU_NUMBER)) || (monitorNum>=SnI_NUMBER) ){
					monitorNum = 0;
					// Next sampling function (restart if last function reached, cyclic)
					samplingFunction = (samplingFunction>=FUNCTION_SnI_VOLTAGE?FUNCTION_PSU_VOLTAGE:samplingFunction+1);
				}
			}
			else{
				if (monitorNum >= PSU_NUMBER){
					monitorNum = 0;
					samplingFunction = !samplingFunction; 	// Toggle between FUNCTION_PSU_VOLTAGE (0) and FUNCTION_PSU_CURRENT(1)
				}										  	//  functions (see defineConstants.cpp - MUX)
			}
			setMUX( samplingFunction, (BYTE)monitorNum );	// Set muxes for next reading
		}
		else{
			if (lastMeasure!=0)	{scaleGainAGC(MIDSCALE_ADC/lastMeasure);}
			else				{scaleGainAGC(2);}
		}
//		printf("-LM=0x%x  Num=%d  Sampling =%d SCALEMUX=%.2f  SCALEAGC=%.2f   VALUE=%.2f\n", lastMeasure, Num, samplingFunction, getScaleFactorMUX(), getGainAGC(), ((float)lastMeasure) / (4095.0) * 3.3 *getScaleFactorMUX()/getGainAGC());
		ledAux++;
		if (ledAux>=500){
			ledAux =0;
			Pins[26]=ledFlag;
			ledFlag = !ledFlag;
		}
	}
}
