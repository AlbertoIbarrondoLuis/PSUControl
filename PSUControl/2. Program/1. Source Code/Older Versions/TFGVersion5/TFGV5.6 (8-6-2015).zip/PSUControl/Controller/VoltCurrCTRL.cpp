/*
 * VoltCurrCTRL.cpp
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */


#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List

// Scale Factor for ADC readings, accessible with _sf(samplingFunction, num)
float scaleFactorArray[38] = SCALE_FACTOR_ARRAY;

//=====================================================================================================//
//================================    VOLTAGE & CURRENT METHODS    ====================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// adjustRdac - changes the RDAC Register Value (thus modifying its output voltage)
// 					Checks for correct value updating
//-------------------------------------------------------------------------------------------------------
void adjustRdac (int psuNum, float Voltage){
	int desiredValue = voltToNum(Voltage, psuList[psuNum].rShunt);
	setValRDAC(desiredValue, psuList[psuNum].rdacAdr, psuList[psuNum].bridgeI2CAdr);
	int setValue = getValRDAC(psuList[psuNum].rdacAdr, psuList[psuNum].bridgeI2CAdr);
	if (desiredValue==setValue){
		psuList[psuNum].progValue = Voltage;
	}
	else{
		iprintf("ERROR - VoltCurrCTRL: Volt. value %d not properly configured on PSU %d. Value %d set instead\n", desiredValue, psuNum, setValue);
	}
}


//-------------------------------------------------------------------------------------------------------
// resetRdacs - Hardware rheostats' reset
//-------------------------------------------------------------------------------------------------------
void resetRdacs ( void ){
	Pins[21] = 1;
	OSTimeDly(TICKS_100MS);
	Pins[21] = 0;
}


//-------------------------------------------------------------------------------------------------------
// updateVoltagePSUs - Updates both RDAC values with their RAM configuration for the selected PSUs
//					  (marking its respective bit number as TRUE)
//-------------------------------------------------------------------------------------------------------
void updateVoltagePSUs( BOOL psuSelection[PSU_NUMBER] ){	// PSUs marked with his corresponding bit to 1 will be switched on.
	int psuNum;
	// ajustar fuentes
	for (psuNum=0;psuNum<PSU_NUMBER;psuNum++){
		if(psuSelection[psuNum]){
			if (psuList[psuNum].psuStatus) {
				adjustRdac (psuNum, psuList[psuNum].progValue);
			}
		}
 	}
	OSTimeDly(TICKS_100MS); // delay for regulator adjustment
}


//-------------------------------------------------------------------------------------------------------
// readVoltageValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						to voltage. Currently not in use, as this function is executed by PITR 0
//						(see TimerInt.cpp)
//-------------------------------------------------------------------------------------------------------
void readVoltageValue(int Num, BOOL psu_sni){
	float value = 0; DWORD pit_adc_counts;
	int samplingFunction = (psu_sni==PSU_TYPE_LIST?FUNCTION_PSU_VOLTAGE:FUNCTION_SnI_VOLTAGE);
	setMUX(samplingFunction, Num);
	pit_adc_counts = pitr_count_adc_sampling;
	while(pitr_count_adc_sampling==pit_adc_counts){
		//Wait until a small amount of time has passed (1 PIT1 period)
	}
	value = ADCCountsToVoltORCurr((ReadA2DResult(0) >> 3), samplingFunction, Num);
	if (psu_sni == PSU_TYPE_LIST){	psuList[Num].vOut = value;}
	else{							sniList[Num].vOut = value;}
}


//-------------------------------------------------------------------------------------------------------
// readCurrentValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						to current.Currently not in use, as this function is executed by PITR 0
//						(see TimerInt.cpp)
//-------------------------------------------------------------------------------------------------------
void readCurrentValue(int psuNum){
	float value = 0; DWORD pit_adc_counts;
	setMUX(FUNCTION_PSU_CURRENT, psuNum);
	pit_adc_counts = pitr_count_adc_sampling;
	while(pitr_count_adc_sampling==pit_adc_counts){
		//Wait until a small amount of time has passed (1 PIT1 period)
	}
	value = ADCCountsToVoltORCurr((ReadA2DResult(0) >> 3), FUNCTION_PSU_CURRENT, psuNum);
	psuList[psuNum].cOut = value;
}


//-------------------------------------------------------------------------------------------------------
// resetMeasuresAll - Sets all vOut and cOut of psuList and sniList to 0 (variables where ADC measures
//						are stored)
//-------------------------------------------------------------------------------------------------------
void resetMeasuresAll ( void ){
	int i;
	for (i=0; i<PSU_NUMBER; i++){psuList[i].vOut = 0;psuList[i].cOut = 0;}
	for (i=0; i<SnI_NUMBER; i++){sniList[i].vOut = 0;}
}


//-------------------------------------------------------------------------------------------------------
// VoltORCurrToADCCounts - Conversion from real value (voltage or current) to ADC 12-bit WORD value.
//							Dependent on the AGC gain.
//-------------------------------------------------------------------------------------------------------
WORD VoltORCurrToADCCounts ( float value, int samplingFunction, int Num ){
	return (WORD)(abs(round((value*getGainAGC()*(4095.0))/(scaleFactorArray[_sf(samplingFunction, Num)] * DEFAULT_SCALE_FACTOR*3.3))));
}


//-------------------------------------------------------------------------------------------------------
// ADCCountsToVoltORCurr - Conversion from ADC 12-bit WORD value to real value (voltage or current)
//							Dependent on the AGC gain.
//-------------------------------------------------------------------------------------------------------
float ADCCountsToVoltORCurr ( WORD ADCCounts, int samplingFunction, int Num ){
	return (((float)ADCCounts) * 3.3 * scaleFactorArray[_sf(samplingFunction, Num)] * DEFAULT_SCALE_FACTOR / (getGainAGC()* (4095.0)));
}
