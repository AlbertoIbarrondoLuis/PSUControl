/*
 * ConfigCTRL.cpp
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */

#include "Controller/Controller.h"
//extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
//extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List


//==============================================VARIABLES==============================================//

// Booleans
BOOL config_MonitorCTRL_SnI_FLAG = CONFIG_INIT_MONITORCTRL_SnI_FLAG;			// Supply & Internal voltages																		// included in a2d loop or not
BOOL config_AlarmCTRLUpdate_SnI_FLAG = CONFIG_INIT_ALARMCTRL_UPDATE_SnI_FLAG;	// Includes/excludes SnI voltage
																				// alarms when using updateAlarms(void)
// Ints
int alarmUpdatePeriodx50MS = CONFIG_INIT_ALARMCTRL_UPDATE_PERIOD_x50MS;

// Testing Booleans
BOOL iddleMode_AlarmCTRL_Task_FLAG = false;			// Stops Alarm Task, pending it on testMode_AlarmCTRLTask_Sem
BOOL seqMode_MonitorCTRL_Task_FLAG = false;		// Stops Monitor Task, pending it on seqMode_MonitorCTRLTask_Sem
BOOL testMode_MonitorCTRL_Measure_FLAG = false;		// Uses testMode_Measure instead of reading from ADC
BOOL testMode_SwitchOnCTRL_Task_FLAG = false; 		// Stores the PSUs waiting to be switched on in remainingPSUs[20]

// Testing Values
WORD testMode_Measure = 0;							// Used to simulate values. Recommended tu be used with VoltORCurrToADCCounts()
int testMode_psu_initializationTimer[PSU_NUMBER];	// Records the real initializaionTimer values for the PSUs in switchONTask()

// Semaphores
OS_SEM monitorSem;
OS_SEM seqMode_MonitorCTRLTask_Sem;



//=====================================================================================================//
//===================================    CONFIGURATION METHODS    =====================================//
//=====================================================================================================//

int allSemInit (void){
	return (OSSemInit(& monitorSem,0) && OSSemInit(& seqMode_MonitorCTRLTask_Sem,0));
}

// CONFIGURATION
void config_alarmUpdatePeriod_x50MS ( int newPeriodx50MS ){
	if (newPeriodx50MS<50){	alarmUpdatePeriodx50MS = newPeriodx50MS;}
	else{iprintf(" ERROR - CONFIG: Value for newPeriodMS (%d) (newPeriod<50)\n", newPeriodx50MS);}
}
void config_AlarmCTRLUpdate_SnI ( BOOL sniUpdateFLAG ){	config_AlarmCTRLUpdate_SnI_FLAG = sniUpdateFLAG;}
void config_MonitorCTRL_SnI 	( BOOL monitorSnI )	{	config_MonitorCTRL_SnI_FLAG = monitorSnI;}


// CONTROL Alarm & Monitor TASKS
void iddleMode_AlarmCTRL_Task ( BOOL iddleModeAlarmCTRLFLAG ){
	iddleMode_AlarmCTRL_Task_FLAG = iddleModeAlarmCTRLFLAG;
	Pins[28]=iddleModeAlarmCTRLFLAG;
//	iprintf("testMode_AlarmCTRL %s\n", (iddleModeAlarmCTRLFLAG?"ON":"OFF"));
}

void sequentialMode_MonitorCTRL_Task ( BOOL seqModeMonitorCTRLFLAG ){
	seqMode_MonitorCTRL_Task_FLAG = seqModeMonitorCTRLFLAG;
	OSSemPost(&seqMode_MonitorCTRLTask_Sem);
	OSTimeDly(1);		// Wait for MonitorTask to stop at testMode Semaphore
	Pins[26]=seqModeMonitorCTRLFLAG;
}

// TEST MODES
void testMode_MonitorCTRL_Measure ( BOOL testModeMonitorCTRLMeasureFLAG ){testMode_MonitorCTRL_Measure_FLAG = testModeMonitorCTRLMeasureFLAG;}
void testMode_set_Measure ( WORD testMeasure ){testMode_Measure = testMeasure;}
void testMode_SwitchOnCTRL_Task ( BOOL testModeSwitchOnCTRLTaskFLAG ){	testMode_SwitchOnCTRL_Task_FLAG = testModeSwitchOnCTRLTaskFLAG;}

