/*
 * StatusDISP.cpp
 *
 *  Created on: 27/05/2015
 *      Author: ALBERTO IBARRONDO
 */

#include "Display.h"

extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List

extern char categorySelectionDISP;

BYTE psuAlmStDisp[PSU_NUMBER][4][4];	// Alarm Status Display (v and c), filled with one of the Alarm messages below
BYTE psuValDisp[PSU_NUMBER][3][8];		// PSU values display, progVolt, vOut, cOut for each
BYTE psuStDisp[PSU_NUMBER][4];			// "ON " or "OFF"

BYTE sniAlmStDisp[SnI_NUMBER][2][4];	// Alarm Status Display for voltage, filled with one of the Alarm messages below
BYTE sniValDisp[SnI_NUMBER][3][8];		// SnI values display, nominalVoltage, vOut for each


// Alarm messages
static char alarmMessageConnected [4] = "Con";
static char alarmMessageLimReached [4] = "Lim";
static char alarmMessageTriggered [4] = "Trg";
static char alarmMessageDisconnected [4] = "Dis";

// Auxiliary
int k, j;

void processCommandStatus ( void ){
	// Empty, used just to print the system status
}

void statusDisplayDISP ( void ){
	refreshAlarmStatusDISP();
	refreshValuesDISP();
	iprintf( "\n\n\n\n\n\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("------------------------------- STATUS DISPLAY --------------------------------\r\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("_______________________________________________________________________________\r\n" );
	iprintf("||    1A-%s Vp=%sV   |    2A-%s Vp=%sV  |    3A-%s Vp=%sV  ||\r\n", psuStDisp[0], psuValDisp[0][0], psuStDisp[2], psuValDisp[2][0], psuStDisp[4], psuValDisp[4][0]);
	iprintf("||  vO=%s L-%s/U-%s | vO=%s L-%s/U-%s | vO=%s L-%s/U-%s ||\r\n", psuValDisp[0][1],psuAlmStDisp[0][0],psuAlmStDisp[0][1], psuValDisp[2][1],psuAlmStDisp[2][0],psuAlmStDisp[2][1], psuValDisp[4][1],psuAlmStDisp[4][0],psuAlmStDisp[4][1]);
	iprintf("||  cO=%s L-%s/U-%s | cO=%s L-%s/U-%s | cO=%s L-%s/U-%s ||\r\n", psuValDisp[0][2],psuAlmStDisp[0][2],psuAlmStDisp[0][3], psuValDisp[2][2],psuAlmStDisp[2][2],psuAlmStDisp[2][3], psuValDisp[4][2],psuAlmStDisp[4][2],psuAlmStDisp[4][3]);
	iprintf("_______________________________________________________________________________\r\n" );
	iprintf("||    1B-%s Vp=%sV   |    2B-%s Vp=%sV  |    3B-%s Vp=%sV  ||\r\n", psuStDisp[1], psuValDisp[1][0], psuStDisp[3], psuValDisp[3][0], psuStDisp[5], psuValDisp[5][0]);
	iprintf("||  vO=%s L-%s/U-%s | vO=%s L-%s/U-%s | vO=%s L-%s/U-%s ||\r\n", psuValDisp[1][1],psuAlmStDisp[1][0],psuAlmStDisp[1][1], psuValDisp[3][1],psuAlmStDisp[3][0],psuAlmStDisp[3][1], psuValDisp[5][1],psuAlmStDisp[5][0],psuAlmStDisp[5][1]);
	iprintf("||  cO=%s L-%s/U-%s | cO=%s L-%s/U-%s | cO=%s L-%s/U-%s ||\r\n", psuValDisp[1][2],psuAlmStDisp[1][2],psuAlmStDisp[1][3], psuValDisp[3][2],psuAlmStDisp[3][2],psuAlmStDisp[3][3], psuValDisp[5][2],psuAlmStDisp[5][2],psuAlmStDisp[5][3]);
	iprintf("_______________________________________________________________________________\r\n" );
	iprintf("_______________________________________________________________________________\r\n" );
	iprintf("||    4A-%s Vp=%sV   |    5A-%s Vp=%sV  |    6A-%s Vp=%sV  ||\r\n", psuStDisp[6], psuValDisp[6][0], psuStDisp[8], psuValDisp[8][0], psuStDisp[10], psuValDisp[10][0]);
	iprintf("||  vO=%s L-%s/U-%s | vO=%s L-%s/U-%s | vO=%s L-%s/U-%s ||\r\n", psuValDisp[6][1],psuAlmStDisp[6][0],psuAlmStDisp[6][1], psuValDisp[8][1],psuAlmStDisp[8][0],psuAlmStDisp[8][1], psuValDisp[10][1],psuAlmStDisp[10][0],psuAlmStDisp[10][1]);
	iprintf("||  cO=%s L-%s/U-%s | cO=%s L-%s/U-%s | cO=%s L-%s/U-%s ||\r\n", psuValDisp[6][2],psuAlmStDisp[6][2],psuAlmStDisp[6][3], psuValDisp[8][2],psuAlmStDisp[8][2],psuAlmStDisp[8][3], psuValDisp[10][2],psuAlmStDisp[10][2],psuAlmStDisp[10][3]);
	iprintf("_______________________________________________________________________________\r\n" );
	iprintf("||    4B-%s Vp=%sV   |    5B-%s Vp=%sV  |    6B-%s Vp=%sV  ||\r\n", psuStDisp[7], psuValDisp[7][0], psuStDisp[9], psuValDisp[9][0], psuStDisp[11], psuValDisp[11][0]);
	iprintf("||  vO=%s L-%s/U-%s | vO=%s L-%s/U-%s | vO=%s L-%s/U-%s ||\r\n", psuValDisp[7][1],psuAlmStDisp[7][0],psuAlmStDisp[7][1], psuValDisp[9][1],psuAlmStDisp[9][0],psuAlmStDisp[9][1], psuValDisp[11][1],psuAlmStDisp[11][0],psuAlmStDisp[11][1]);
	iprintf("||  cO=%s L-%s/U-%s | cO=%s L-%s/U-%s | cO=%s L-%s/U-%s ||\r\n", psuValDisp[7][2],psuAlmStDisp[7][2],psuAlmStDisp[7][3], psuValDisp[9][2],psuAlmStDisp[9][2],psuAlmStDisp[9][3], psuValDisp[11][2],psuAlmStDisp[11][2],psuAlmStDisp[11][3]);
	iprintf("_______________________________________________________________________________\r\n\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("_______________________________________________________________________________\r\n" );
	iprintf("||      SUP_42V_UNREG      |      SUP_35V_UNREG     |      SUP_16V_UNREG     ||\r\n");
	iprintf("||  vO=%s L-%s/U-%s | vO=%s L-%s/U-%s | vO=%s L-%s/U-%s ||\r\n", sniValDisp[0][1],sniAlmStDisp[0][0],sniAlmStDisp[0][1], sniValDisp[1][1],sniAlmStDisp[1][0],sniAlmStDisp[1][1], sniValDisp[2][1],sniAlmStDisp[2][0],sniAlmStDisp[2][1]);
	iprintf("||      SUP_32V_REG        |      SUP_16V_REG       |      SUP_12V_F_A       ||\r\n");
	iprintf("||  vO=%s L-%s/U-%s | vO=%s L-%s/U-%s | vO=%s L-%s/U-%s ||\r\n", sniValDisp[3][1],sniAlmStDisp[3][0],sniAlmStDisp[3][1], sniValDisp[4][1],sniAlmStDisp[4][0],sniAlmStDisp[4][1], sniValDisp[5][1],sniAlmStDisp[5][0],sniAlmStDisp[5][1]);
	iprintf("||      SUP_12V_F_B        |      SUP_12V_F_C       |      SUP_n16_REG       ||\r\n");
	iprintf("||  vO=%s L-%s/U-%s | vO=%s L-%s/U-%s | vO=%s L-%s/U-%s ||\r\n", sniValDisp[6][1],sniAlmStDisp[6][0],sniAlmStDisp[6][1], sniValDisp[7][1],sniAlmStDisp[7][0],sniAlmStDisp[7][1], sniValDisp[8][1],sniAlmStDisp[8][0],sniAlmStDisp[8][1]);
	iprintf("||      SUP_n20_UNREG      |      SUP_12V_F_D       |                        ||\r\n");
	iprintf("||  vO=%s L-%s/U-%s | vO=%s L-%s/U-%s |                        ||\r\n", sniValDisp[9][1],sniAlmStDisp[9][0],sniAlmStDisp[9][1], sniValDisp[10][1],sniAlmStDisp[10][0],sniAlmStDisp[10][1]);
	iprintf("_______________________________________________________________________________\r\n" );
	iprintf("||      INT_VCC_3V3        |      INT_VCC_12V       |      INT_VCC_n12V      ||\r\n");
	iprintf("||  vO=%s L-%s/U-%s | vO=%s L-%s/U-%s | vO=%s L-%s/U-%s ||\r\n", sniValDisp[11][1],sniAlmStDisp[11][0],sniAlmStDisp[11][1], sniValDisp[12][1],sniAlmStDisp[12][0],sniAlmStDisp[12][1], sniValDisp[13][1],sniAlmStDisp[13][0],sniAlmStDisp[13][1]);
	iprintf("_______________________________________________________________________________\r\n" );

}


void refreshAlarmStatusDISP ( void ){
	// PSU
	for (k=0; k<PSU_NUMBER; k++){
		for (j=0; j<4; j++){ // All alarms
			if (psuList[k].alarmWatch[j]){
				if (psuList[k].alarmCounters[j]>0){
					if(psuList[k].alarmStatus[j]){	mergeBuffer(psuAlmStDisp[k][j], (BYTE*)alarmMessageTriggered, 3);}	 	// Trg
					else{							mergeBuffer(psuAlmStDisp[k][j], (BYTE*)alarmMessageLimReached, 3);}}	// Lim
				else{								mergeBuffer(psuAlmStDisp[k][j], (BYTE*)alarmMessageConnected, 3);}} 	// Con
			else{									mergeBuffer(psuAlmStDisp[k][j], (BYTE*)alarmMessageDisconnected, 3);}	// Dis
		}
	}

	// SnI
	for (k=0; k<SnI_NUMBER; k++){
		// Inferior Voltage Alarm
		if (sniList[k].alarmWatch[0]){
			if (sniList[k].alarmCounters[0]>0){
				if(sniList[k].alarmStatus[0]){	mergeBuffer(sniAlmStDisp[k][0], (BYTE*)alarmMessageTriggered, 3);}	 	// Trg
				else{							mergeBuffer(sniAlmStDisp[k][0], (BYTE*)alarmMessageLimReached, 3);}}	// Lim
			else{								mergeBuffer(sniAlmStDisp[k][0], (BYTE*)alarmMessageConnected, 3);}} 	// Con
		else{									mergeBuffer(sniAlmStDisp[k][0], (BYTE*)alarmMessageDisconnected, 3);}	// Dis

		// Superior Voltage Alarm
		if (sniList[k].alarmWatch[1]){
			if (sniList[k].alarmCounters[1]>0){
				if(sniList[k].alarmStatus[1]){	mergeBuffer(sniAlmStDisp[k][1], (BYTE*)alarmMessageTriggered, 3);}	 	// Trg
				else{							mergeBuffer(sniAlmStDisp[k][1], (BYTE*)alarmMessageLimReached, 3);}}	// Lim
			else{								mergeBuffer(sniAlmStDisp[k][1], (BYTE*)alarmMessageConnected, 3);}} 	// Con
		else{									mergeBuffer(sniAlmStDisp[k][1], (BYTE*)alarmMessageDisconnected, 3);}	// Dis
	}
}

void refreshValuesDISP ( void ){

	// PSU
	for (k=0; k<PSU_NUMBER; k++){
		mergeBuffer(psuValDisp[k][0],(BYTE*) ftos(psuList[k].progValue, 3), 7);	fillWithBlank(psuValDisp[k][0],7); // progValue
		mergeBuffer(psuValDisp[k][1],(BYTE*) ftos(psuList[k].vOut, 3), 7);		fillWithBlank(psuValDisp[k][1],7); // vOut
		mergeBuffer(psuValDisp[k][2],(BYTE*) ftos(psuList[k].cOut, 3), 7);		fillWithBlank(psuValDisp[k][2],7); // cOut

		mergeBuffer(psuStDisp[k],(BYTE*) (psuList[k].psuStatus?"ON ":"OFF"), 3); // psuStatus
	}

	// SnI
	for (k=0; k<SnI_NUMBER; k++){
		mergeBuffer(sniValDisp[k][0],(BYTE*) ftos(sniList[k].nominalVoltage , 3), 7);	fillWithBlank(sniValDisp[k][0],7); 	// nominalVoltage
		mergeBuffer(sniValDisp[k][1],(BYTE*) ftos(sniList[k].vOut, 3), 7);				fillWithBlank(sniValDisp[k][1],7); 	// vOut
	}
}


