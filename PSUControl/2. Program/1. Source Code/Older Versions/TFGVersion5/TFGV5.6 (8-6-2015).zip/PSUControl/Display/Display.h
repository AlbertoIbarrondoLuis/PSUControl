/*
 * Display.h
 *
 *  Created on: 24/05/2015
 *      Author: ALBERTO IBARRONDO
 */

#ifndef DISPLAY_H_
#define DISPLAY_H_

#include "Headers.h"
#include "Controller/Controller.h"		// All the Controller Methods
#include "Libraries/Libraries.h"		// All the Libraries' Methods




//==========================================GENERAL===========================================//
void DisplayMain ( void );
void GeneralDisplayMenuDISP ( void );
void StatusDISP ( void );
void ProgramDISP ( void );
void FunctionDISP ( void );


//==========================================MODULES===========================================//

//------------------------------------ PROGRAMMING MENU --------------------------------------//
void processCommandProgram ( void );
void selectNumsDISP (BOOL psu_sni);
void selectAlarmsDISP (BOOL psu_sni);
void programProtocolsDISP ( BOOL psu_sni );

//------------------------------------- STATUS DISPLAY ---------------------------------------//
void processCommandStatus ( void );
void statusDisplayDISP ( void );
void refreshAlarmStatusDISP ( void );
void refreshValuesDISP ( void );

//------------------------------------- FUNCTION MENU ----------------------------------------//
void processCommandFunction ( void );


#endif /* DISPLAY_H_ */
