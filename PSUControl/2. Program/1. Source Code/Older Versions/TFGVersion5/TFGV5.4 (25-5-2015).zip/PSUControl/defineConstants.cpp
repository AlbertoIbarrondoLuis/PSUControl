/*
 * defineConstants.cpp
 *
 *  Created on: 13-feb-2015
 *   Author: Alberto Ibarrondo
 */


//________________________________________CONFIGURATION_________________________________________________//
#define CONFIG_INIT_MONITORCTRL_SnI_FLAG true		//Supply and Internal voltages included in a2d loop
#define CONFIG_INIT_ALARMCTRL_UPDATE_SnI_FLAG true	//Supply and Internal voltages included in alarm update
#define CONFIG_INIT_ALARMCTRL_UPDATE_PERIOD_x50MS   TICKS_100MS
													// N� of times the PITR 0 will count until alarm updating

#define MAXIMUM_LEVEL_ADC 0x0E00			// not used
#define MIDSCALE_ADC 0x0A80					// Objective for the second reading in A2D, configuring the AGC accordingly
#define MINIMUM_LEVEL_ADC 0x0700			// minimum A2D counts to label a measure as "valid". Otherwise, the AGC will go up


//___________________________________________VALUES_____________________________________________________//
#define I2C_FREQUENCY 0x19

#define SWITCH_ON_PRIO MAIN_PRIO-1			// Switching on task will have higher priority than main loop
#define ALARM_PRIO MAIN_PRIO-2				// Alarm task will have higher priority than main loop and Switch-on

#define RDAC_MAX_VALUE 1023					// Max & min values for RDAC Register
#define RDAC_MIN_VALUE 0
#define INITIAL_VOLTAGE 1.26				// Initial value for PSUs' Rdac (set to min to minimize power consumption)

#define PSU_NUMBER 12
#define SnI_NUMBER INT_VCC_n12V+1
#define ALL_PSUS_WORD 0xFFF					// For functions using WORD selectedPSUs as argument
#define ALL_SnIS_WORD 0x3FFF				// For functions using WORD selectedSnIs as argument
#define ALL_ALARMS_BYTE 0x0F				// For functions using BYTE alarmList as argument
#define TICKS_100MS TICKS_PER_SECOND/10
#define TASK_TIMES_PER_SECOND 10

#define OFF	false
#define ON	true


//_________________________________________ADDRESSES____________________________________________________//
#define MCF5213_I2C_ADDRESS 0x29				// Controller. Can be changed from 0x28 to 0x2F
#define EXPANDER_I2C_ADDRESS 0x39				// I2C Expander
#define FIRST_SLAVE_SPI_ADDRESS 0x1				// U202 - Upper slave SPI address (for PSUs with A on their names)
#define SECOND_SLAVE_SPI_ADDRESS 0x2			// U302 - Lower slave SPI address (for PSUs with B on their names)
#define AGC_SPI_ADDRESS 0x1

#define PSUs_I2C_ADDRESS_ARRAY	{0x2F, 0x2F, 0x2E, 0x2E, 0x2D, 0x2D, 0x2C, 0x2C, 0x2B, 0x2B, 0x2A, 0x2A}
#define AGC_I2C_ADDRESS 0x28


//_________________________________________ALARMS_______________________________________________________//
// ALARM ARRAYS ACCESS METHODS
#define _(a,b) a+2*b				// Arrays with 4 items. a=(INFERIOR/SUPERIOR); b=(VOLTAGE/CURRENT)
#define __(a,b,c) a+2*b+4*c			// Arrays with 8/12 items. a=(INFERIOR/SUPERIOR); b=(VOLTAGE/CURRENT);
									//		c=(PROTOCOL_SHUTDOWN/PROTOCOL_MODIFY_VOLTAGE/PROTOCOL_MESSAGE) for alarmProtocols.
// ALARM ARRAYS INDEXING
//inf_sup
#define INFERIOR 0					// First alarm array index bit (input "a" of the accessing methods)
#define SUPERIOR 1
//vol_curr
#define VOLTAGE 0					// Second alarm array index bit (input "b" of the accessing methods)
#define CURRENT 1

// Third alarm array index bit for alarmProtocols (input "c" of the accessing methods):
#define PROTOCOL_SHUTDOWN 0			// 	(0) Shut down certain PSUs
#define PROTOCOL_MODIFY_VOLTAGE 1	// 	(1) Modify Voltage
#define PROTOCOL_MESSAGE 2			// 	(2) Send Alarm Message
#define ALARM_PLOTOCOLS_NUM PROTOCOL_MESSAGE+1

#define ALARM_MESSAGE "ALARM in %s %d. %s %s limit reached\n", (psu_sni==PSU_TYPE_LIST?"PSU":"SnI"), Num, (type_volt_corr==0?"Voltage": "Current"), (limit_inf_sup==0?"Inferior": "Superior")


//______________________________________________PSUs&SnIs______________________________________________________//
// psu_sni
#define PSU_TYPE_LIST 1					// Used in functions: alarmCheck(), in resetAlarms()
#define SnI_TYPE_LIST 0


// PSU OUTPUTS
#define SF1_A 0
#define SF1_B 1
#define SF2_A 2
#define SF2_B 3
#define SF3_A 4
#define SF3_B 5
#define SF4_A 6
#define SF4_B 7
#define SF5_A 8
#define SF5_B 9
#define SF6_A 10
#define SF6_B 11

// SUPPLY VOLTAGES
#define SUP_42V_UNREG 0
#define SUP_35V_UNREG 1
#define SUP_16V_UNREG 2
#define SUP_32V_REG 3
#define SUP_16V_REG 4
#define SUP_12V_F_A 5
#define SUP_12V_F_B 6
#define SUP_12V_F_C 7
#define SUP_n16_REG 8
#define SUP_n20_UNREG 9
#define SUP_12V_F_D 10

//INTERNAL VOLTAGES
#define INT_VCC_3V3 11
#define INT_VCC_12V 12
#define INT_VCC_n12V 13

//SAMPLING FUNCTIONs
#define FUNCTION_PSU_VOLTAGE 0
#define FUNCTION_PSU_CURRENT 1
#define FUNCTION_SnI_VOLTAGE 2


//________________________________________________MUXES_______________________________________________________//
// MUXES
#define MUX_A 0
#define MUX_B 1
#define MUX_C 2
#define MUX_D 3
#define MUX_E 4

#define SCALE_FACTOR_ARRAY	{3, 3, 3, 3, 3, 3, 3, 3, 3, 3, -1.68, -1.68, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, 1.25, -1.25, -1.25, 5, 3, 1.68, 3, 3, 3.68/3, 3.68/3, 3.68/3, -1.68, -2, 3.68/3, 1, 1, -1}
#define _sf(samplingFunction, num) samplingFunction*12+num	// Accessing superior array with data from PSUs and SnIs
#define DEFAULT_SCALE_FACTOR 4.3*4

//_________________________________________DEFAULT PSU VALUES_______________________________________________//
#define DEFAULT_relayStatus_psu false						// Relay flag
#define DEFAULT_psuStatus_psu false							// PSU being used or not
#define DEFAULT_rdacValue_psu INITIAL_VOLTAGE				// RDACs' programmed voltage value
#define DEFAULT_bridgeI2CAdr_psu 0x2F						// PSU I2C Bridge address - not in use. Use instead PSUs_I2C_ADDRESS_ARRAY

#define DEFAULT_alarmLimitValues_psu_pos {13, 17, 0.3, 3}	// Inferior (0) and superior (1) voltage alarm LIMITS (magnitude);
#define DEFAULT_alarmLimitValues_psu_neg {13, 17, 0.3, 3}	//  and inferior (2) and superior (3) current alarm LIMITS.
#define DEFAULT_alarmLimitTimes_psu	{30, 30, 30, 30}		// Inferior (0) and superior (1) voltage alarm TIMES
															//  (Counter limits which trigger alarmStatus On/Off when reached);
															//  and inferior (2) and superior (3) current alarm TIMES.
#define DEFAULT_alarmProtocols_psu	{0,0,0,0,0,0,0,0,0,0,0,0}// Activate(TRUE) or ignore(FALSE) each of the protocols when the alarm pops up:
															//  (0-3) Shut down certain PSUs, (4-7) Modify this PSU's Voltage, (8-11) Send Alarm Message.
															//  For more info see PSU_TYPE.cpp
#define DEFAULT_alarmProtocolShutdown_psu {}				// PSU list to shutdown in alarm protocol Shutdown. Bits 0 to B shutdown
															//  PSUs 1 to 12 if set to TRUE.
#define DEFAULT_alarmProtocolVoltage_psu {15,14,20,6}		// New values for this PSU's voltage when executed this alarm's Modify Voltage Protocol .
#define DEFAULT_alarmCounters_psu {0, 0, 0, 0}				// Variables increasing on each scanning period if alarmLimitReached is ON(TRUE),
															//  until they reach alarmLimitTimes.
															//  They also serve for shutting down alarms when alarmLimitReached is OFF(FALSE).
#define DEFAULT_alarmStatus_psu {false,false,false,false}	// FALSE: alarm hasn't been triggered, not performing any alarm protocols.
															//  TRUE: alarm is ON, performing alarm protocols.
#define DEFAULT_alarmLimitReached_psu {false,false,false,false}	// FALSE: alarm hasn't reached the limit. If alarmStatus is ON, it will start
															//  decreasing the alarmCounter until alarmStatus is OFF(ntimes = alarmLimitTimes)
															//  TRUE: alarm has reached the limit, beginning to increase the alarmCounter
															//  until alarmStatus is ON (ntimes = alarmLimitTimes).

#define DEFAULT_alarmWatch_psu {false,false,false,false}	// FALSE: alarm is not configured, it will neither analyze the system nor trigger the alarmStatus ON.
															// TRUE: alarm is configured and working, will analyze the system, set the alarmStatus ON
															//  when a limit is reached, and execute the defined alarmProtocols
#define DEFAULT_rShunt_psu 820									// Internal resistor used for RDAC configuration

#define DEFAULT_vOut_psu 0									// ADC value of the output voltage
#define DEFAULT_cOut_psu 0									// ADC value of the output current

#define DEFAULT_initializationTimer_psu 10					// x100ms initial count for PSU switching-on


//____________________________________________________DEFAULT AUX VALUES_________________________________________________________//
#define DEFAULT_sniStatus_sni true							// SnI being used or not
#define DEFAULT_nominalVoltage_sni {42, 35, 16, 32, 16, 12, 12, 12, -16, -20, 12, 3.3, 12, -12}					// desired voltage value
#define SnI_INF_PERC_ALARM_VALUE 0.8						// Inferior voltage limit for auxiliary supplies' alarm (percentage)
#define SnI_SUP_PERC_ALARM_VALUE 1.2						// Superior voltage limit for auxiliary supplies' alarm (percentage)
															// 	Current limit values are not used
#define DEFAULT_alarmLimitTimes_sni	{100, 100, 100, 100}	// Inferior (0) and superior (1) voltage alarm TIMES
															//  (Counter limits which trigger alarmStatus On/Off when reached);
															//  and inferior (2) and superior (3) current alarm TIMES.
#define DEFAULT_alarmProtocols_sni  {0,0,0,0,0,0,0,0,0,0,0,0}// Activate(TRUE) or ignore(FALSE) each of the protocols when the alarm pops up:
															//  (0-3) Shut down certain PSUs, (4-7) Modify this PSU's Voltage, (8-11) Send Alarm Message.
															//  For more info see PSU_TYPE.cpp
#define DEFAULT_alarmProtocolShutdown_sni {}				// PSU list to shutdown in alarm protocol Shutdown. Bits 0 to B shutdown
															//  PSUs 1 to 12 if set to TRUE.
#define DEFAULT_alarmCounters_sni {0, 0, 0, 0}				// Variables increasing on each scanning period if alarmLimitReached is ON(TRUE),
															//  until they reach alarmLimitTimes.
															//  They also serve for shutting down alarms when alarmLimitReached is OFF(FALSE).
#define DEFAULT_alarmStatus_sni {false,false,false,false}	// FALSE: alarm hasn't been triggered, not performing any alarm protocols.
															//  TRUE: alarm is ON, performing alarm protocols.
#define DEFAULT_alarmLimitReached_sni {false,false,false,false}	// FALSE: alarm hasn't reached the limit. If alarmStatus is ON, it will start
															//  decreasing the alarmCounter until alarmStatus is OFF(ntimes = alarmLimitTimes)
															//  TRUE: alarm has reached the limit, beginning to increase the alarmCounter
															//  until alarmStatus is ON (ntimes = alarmLimitTimes).

#define DEFAULT_alarmWatch_sni {false,false,false,false}	// FALSE: alarm is not configured, it will neither analyze the system nor trigger the alarmStatus ON.
															// TRUE: alarm is configured and working, will analyze the system, set the alarmStatus ON
															//  when a limit is reached, and execute the defined alarmProtocols
#define DEFAULT_vOut_sni 0									// ADC value of the output voltage

