/*
 * Controller.h
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
 */

#ifndef CONTROLLER
#define CONTROLLER

#include "Headers.h"
#include "Libraries/Libraries.h"
#include "Libraries/I2C&SPILibrary.h"	// I2C&SPI Communication

//==========================================METHODS===========================================//

//-------------------------------VOLTAGE & CURRENT METHODS------------------------------------//
void adjustRdac (int psuNum, float Voltage);
void resetRdacs ( void );
void updateVoltagePSUs(WORD selectPSUs);
void readVoltageValue(int psuNum);
void readCurrentValue(int psuNum);
WORD VoltORCurrToADCCounts (float value, int psuNum, int samplingFunction);

//-------------------------------------ALARM METHODS------------------------------------------//
void alarmTask (void *p);
void alarmCheck (int psuNum, BOOL inf_sup, BOOL volt_corr, BOOL psu_aux);
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum, int psu_sni);
void updateAlarms (void);
void resetAlarms (WORD list, BYTE alarmType, BOOL psu_sni);
void resetAlarmsAll ( void );
void toggleAlarmsAll ( BOOL almWatch );

//-----------------------------------FLASH MEMORY METHODS-------------------------------------//
void loadFlashValuesPSUs (void);
void loadFlashValuesSNIs (void);
int saveInFlashValuesPSUsSNIs (void);
int initializeValuesPSUsSnIs(void);
void readFlashValuesPSU(int psuNum, PSU_TYPE *pData);
void createVERIFY_KEY(void);


//-----------------------------------SWITCH ON PSUs METHODS-----------------------------------//
void switchONPSUsTask(WORD switchONListPSUs);
void connectPSU(int psuNum);
void switchONPSUs(WORD selectedPSUs);
void disconnectPSU(int psuNum);
void switchOFFPSUs(WORD selectedPSUs);


//-------------------------------------DATA LISTS' METHODS-------------------------------------//
void defaultValuesPSU (int psuNum);
void printValuesPSU (int psuNum);
void defaultValuesSnI (int auxNum);
void printValuesSnI (int auxNum);
PSU_TYPE getPSU (int psuNum);
SnI_TYPE getSnI( int auxNum );
void setPSU (int psuNum, PSU_TYPE psu);
void setSnI( int auxNum, SnI_TYPE aux);

// setters for PSU_TYPE variables
void setrelayStatusPSU(BOOLEAN rlSt, int psuNum);
void setpsuStatusPSU(BOOLEAN psSt, int psuNum);
void setrdacValuePSU(float rdVal, int psuNum);
void setrbridgeI2CAdrPSU(BYTE brAddr, int psuNum);
void setrrdacAdrPSU(BYTE rdacAddr, int psuNum);
void setalarmLimitValuesPSU(float value, BOOLEAN inf_sup, BOOLEAN volt_curr, int psuNum);
void setalarmLimitTimesPSU(int time, BOOLEAN inf_sup, BOOLEAN volt_curr, int psuNum);
void setalalarmProtocolsPSU(BOOLEAN protocol_flag, BOOLEAN inf_sup, BOOLEAN volt_curr, BYTE protocol, int psuNum);
void setalarmProtocolShutdownPSU(WORD psus, BOOLEAN inf_sup, BOOLEAN volt_curr, int psuNum);
void setalarmProtocolVoltagePSU(float voltage, BOOLEAN inf_sup, BOOLEAN volt_curr, int psuNum);
void setalarmWatchPSU(BOOLEAN alarm_flag, BOOLEAN inf_sup, BOOLEAN volt_curr, int psuNum);
void setrShuntPSU(int rSh, int psuNum);

// setters for SnI_TYPE variables
void setsniStatusSnI(BOOLEAN snSt, int sniNum);
void setnominalVoltageSnI(float nomVal, int sniNum);
void setalarmLimitValuesSnI(float value, BOOLEAN inf_sup, BOOLEAN volt_corr, int sniNum);
void setalarmLimitTimesSnI(int time, BOOLEAN inf_sup, BOOLEAN volt_corr, int sniNum);
void setalalarmProtocolsSnI(BOOLEAN protocol_flag, BOOLEAN inf_sup, BOOLEAN volt_corr, BYTE protocol, int sniNum);
void setalarmProtocolShutdownSnI(WORD snis, BOOLEAN inf_sup, BOOLEAN volt_corr, int sniNum);
void setalarmWatchSnI(BOOLEAN alarm_flag, BOOLEAN inf_sup, BOOLEAN volt_corr, int sniNum);



//----------------------------------------MONITOR METHODS---------------------------------------//
void monitorTask (void* p);


//-------------------------------------CONFIGURATION METHODS------------------------------------//
int allSemInit (void);
void config_alarmUpdatePeriod_x50MS ( int newPeriodx50MS );
void config_AlarmCTRLUpdate_SnI ( BOOL sniUpdateFLAG );
void config_MonitorCTRL_SnI ( BOOL monitorSnI );
void testMode_AlarmCTRL_Task ( BOOL testModeAlarmCTRLFLAG );
void testMode_MonitorCTRL_Task ( BOOL testModeMonitorCTRLFLAG );
void testMode_MonitorCTRL_Measure ( BOOL testModeMonitorCTRLMeasureFLAG );
void testMode_SwitchOnCTRL_Task ( BOOL testModeSwitchOnCTRLTaskFLAG );
void set_testMode_Measure ( WORD testMeasure );

#endif /* CONTROLLER */


