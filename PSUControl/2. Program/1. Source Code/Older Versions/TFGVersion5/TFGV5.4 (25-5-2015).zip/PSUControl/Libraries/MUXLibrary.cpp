/*
 * MUXLibrary.cpp
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#include "MUXLibrary.h"

// AUXILIAR
#define EN_MUX_ABCDE 0x8
#define EN_MUX_ADC 0x8
#define SET_EXPANDER_BUS(mux, num) expanderBus[0]=(mux+EN_MUX_ADC)|((num+EN_MUX_ABCDE)<<4)

BYTE expanderBus[1] = {0};
BYTE resultI2C_MUX = 0;

// Scale
extern float scaleFactorArray[38];
float scaleFactor=0;

//-------------------------------------------------------------------------------------------------------
// setMuxes - Configures the Muxes for a PSU number (or other voltage generators) and the desired function:
//				(0) FUNCTION_PSU_VOLTAGE: Allows Voltage readings.
//				(1) FUNCTION_READ_CURRENT: Allows current Readings.
//				(2) FUNCTION_READ_SUPPLY: Allows Supply voltage readings (Regulating cards).
//				(3) FUNCTION_READ_INTERNAL: Allows internal voltage readings (Controller card).
//			  Returns a float with a scale value for the selected voltage
//-------------------------------------------------------------------------------------------------------

float setMUX(BYTE samplingFunction, BYTE Num){
	switch(samplingFunction){

		case FUNCTION_PSU_VOLTAGE:
			if (Num > SF4_B){Num-=8;
				if (Num > SF5_B){	SET_EXPANDER_BUS(MUX_E, Num);}
				else {				SET_EXPANDER_BUS(MUX_B, Num);}}
			else{					SET_EXPANDER_BUS(MUX_A, Num);}
			resultI2C_MUX = sendI2CMessage (expanderBus, 1, EXPANDER_I2C_ADDRESS);
			break;

		case FUNCTION_PSU_CURRENT:
			if (Num > SF4_B){Num-=4;
					SET_EXPANDER_BUS(MUX_B, Num);}
			else{	SET_EXPANDER_BUS(MUX_C, Num);}
			resultI2C_MUX = sendI2CMessage (expanderBus, 1, EXPANDER_I2C_ADDRESS);
			break;

		case FUNCTION_SnI_VOLTAGE:
			switch (Num){
				case SUP_n16_REG: case SUP_n20_UNREG: SET_EXPANDER_BUS(MUX_E, Num-8); break;
				case SUP_12V_F_D: expanderBus[0] = (5+EN_MUX_ADC); break;
				case INT_VCC_3V3: case INT_VCC_12V: SET_EXPANDER_BUS(MUX_B, Num-9); break;
				case INT_VCC_n12V: SET_EXPANDER_BUS(MUX_E, Num-9); break;
				default: SET_EXPANDER_BUS(MUX_D, Num); break;
			}
			resultI2C_MUX = sendI2CMessage (expanderBus, 1, EXPANDER_I2C_ADDRESS);
			break;

		default:
			iprintf(" ~ERROR MUX: Unsupported Function\n");
			break;
	}
	scaleFactor = scaleFactorArray[_sf(samplingFunction, Num)] * DEFAULT_SCALE_FACTOR;
	return scaleFactor;
}

float getScaleFactorMUX ( void ){
	return scaleFactor;
}

BYTE getI2CResultMUX ( void ){
	return resultI2C_MUX;
}
