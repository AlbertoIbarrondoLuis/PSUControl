/*
 * Test_Controller.cpp
 *
 *  Created on: 20/05/2015
 *      Author: ALBERTO IBARRONDO
 */


#include "Tests.h"


//==============================================VARIABLES==============================================//
//---------Imported from generalTEST.cpp
// Imported Arrays
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List

// Results
extern BYTE result1; extern BYTE result2; extern BYTE result3; extern BYTE result4; extern BYTE result5;
extern BYTE result6; extern BYTE result7; extern BYTE result8; extern BYTE result9; extern BYTE result10;
extern BYTE resultTotal;




//=====================================================================================================//
//================================    Controller Testing METHODS    ===================================//
//=====================================================================================================//



BOOL TEST_AlarmCTRL( void ){
	OSLockObj lock;//LOCK to avoid changes in vOut and cOut
	iprintf("\n\n\n\n===============TEST_AlarmCTRL===============\n");

	iprintf("\n\n\n\n1. Upper Voltage Alarm Triggering with no time. PSU 1 should be triggered, 4 shouldn't\n");
	iprintf("\n\n\n\n1. Upper Voltage Alarm Triggering with no time. PSU 1 should be triggered, 4 shouldn't\n");
	defaultValuesPSU(1);
	defaultValuesPSU(4);
	setalarmLimitTimesPSU(0, INFERIOR, VOLTAGE, 1);
	setalarmLimitTimesPSU(0, INFERIOR, VOLTAGE, 4);
	// forcing a value lower than 13 (default) for voltage
	psuList[1].vOut = 12;
	psuList[4].vOut = 14;
	alarmCheck(1,INFERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(4,INFERIOR,VOLTAGE,PSU_TYPE_LIST);
	iprintf(" alarmStatus (1) = %s (should be TRUE)\n", (getPSU(1).alarmStatus[_(INFERIOR,VOLTAGE)]?"TRUE":"FALSE"));
	iprintf(" alarmStatus (4) = %s (should be FALSE)\n", (getPSU(4).alarmStatus[_(INFERIOR,VOLTAGE)]?"TRUE":"FALSE"));
	result1 = getPSU(1).alarmStatus[_(INFERIOR,VOLTAGE)] == true;
	result2 = getPSU(4).alarmStatus[_(INFERIOR,VOLTAGE)] == false;
	printf("\n\n\n\n2. Loading Values and checking for data validity\n");
	getPSU(4).alarmProtocolShutdown[0] = 0;
	getPSU(5).alarmProtocolShutdown[0] = 2;
	loadFlashValuesPSUs();
//	printValuesPSU(5);
//	printValuesPSU(4);
	result2 = getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1);
	result3 = getPSU(5).alarmProtocolShutdown[0] == 0;
	iprintf(" Loaded alarmProtocolShutdown (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	iprintf(" Loaded alarmProtocolShutdown (5) = %d (should be %d)\n", getPSU(5).alarmProtocolShutdown[0], 0);
	iprintf("\n\n\n\n3. Initializing Values, printing PSUs 4 and 5, and checking for data validity\n");
	getPSU(4).alarmProtocolShutdown[0] = 0;
	getPSU(5).alarmProtocolShutdown[0] = 0;
	initializeValuesPSUsSnIs();
//	printValuesPSU(4);
//	printValuesPSU(5);
	result4 = getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1);
	result5 = getPSU(5).alarmProtocolShutdown[0] == demux4to16(5+1);
	iprintf(" Initialized alarmProtocolShutdown (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	iprintf(" Initialized alarmProtocolShutdown (5) = %d (should be %d)\n", getPSU(5).alarmProtocolShutdown[0], demux4to16(5+1));



	return true;
}


BOOL TEST_FlashMemCTRL( void ){
	// NOTE: all the printValues() methods are commented. In case of any error, toggle comment to analyze it.
	iprintf("\n\n\n\n===============TEST_FlashMemCTRL===============\n");

	//PSU
	TEST_FlashMemCTRL_PSU();

	//SnI
	TEST_FlashMemCTRL_SnI();

	//Results
	iprintf("\n TEST_FlashMemCTRL\n");
	iprintf("\n PART 1 - Setting default Values and saving values for PSUs\n");
	iprintf(" ~result1: %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Restore Saved Values for PSUs\n");
	iprintf(" ~result2: %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Empty values aren't corrupted for PSUs\n");
	iprintf(" ~result3: %s\n", (result3?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - Initializing Values, previous data ain't corrupted for PSUs\n");
	iprintf(" ~result4: %s\n", (result4?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - Initializing Values, empty values are correctly filled for PSUs\n");
	iprintf(" ~result5: %s\n", (result5?"PASSED":"NOT PASSED"));
	iprintf("\n PART 4 - Setting default Values and saving values for SnIs\n");
	iprintf(" ~result6: %s\n", (result6?"PASSED":"NOT PASSED"));
	iprintf("\n PART 5 - Restore Saved Values for SnIs\n");
	iprintf(" ~result7: %s\n", (result7?"PASSED":"NOT PASSED"));
	iprintf("\n PART 5 - Empty values aren't corrupted for SnIs\n");
	iprintf(" ~result8: %s\n", (result8?"PASSED":"NOT PASSED"));
	iprintf("\n PART 6 - Initializing Values, previous data ain't corrupted for SnIs\n");
	iprintf(" ~result9: %s\n", (result9?"PASSED":"NOT PASSED"));
	iprintf("\n PART 6 - Initializing Values, empty values are correctly filled for SnIs\n");
	iprintf(" ~result10: %s\n", (result10?"PASSED":"NOT PASSED"));
	resultTotal = (result1&&result2&&result3&&result4&&result5&&result6&&result7&&result8&&result9&&result10);
	iprintf("\n OVERALL RESULT: %s\n", (resultTotal?"PASSED":"NOT PASSED"));
	return resultTotal;
}


void TEST_FlashMemCTRL_PSU (void){
	iprintf("\n\n\n\n1. Setting default Values for PSUs 1 and 4, and saving values\n");
	defaultValuesPSU(1);
	defaultValuesPSU(4);
//	printValuesPSU(1);
//	printValuesPSU(4);
	getPSU(5).alarmProtocolShutdown[0] = 0;
	saveInFlashValuesPSUsSNIs();
	result1 = (getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1)) && (getPSU(1).alarmProtocolShutdown[0] == demux4to16(1+1));
	iprintf(" Saved alarmProtocolShutdown (1) = %d (should be %d)\n", getPSU(1).alarmProtocolShutdown[0], demux4to16(1+1));
	iprintf(" Saved alarmProtocolShutdown (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	printf("\n\n\n\n2. Loading Values and checking for data validity\n");
	getPSU(4).alarmProtocolShutdown[0] = 0;
	getPSU(5).alarmProtocolShutdown[0] = 2;
	loadFlashValuesPSUs();
//	printValuesPSU(5);
//	printValuesPSU(4);
	result2 = getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1);
	result3 = getPSU(5).alarmProtocolShutdown[0] == 0;
	iprintf(" Loaded alarmProtocolShutdown (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	iprintf(" Loaded alarmProtocolShutdown (5) = %d (should be %d)\n", getPSU(5).alarmProtocolShutdown[0], 0);
	iprintf("\n\n\n\n3. Initializing Values, printing PSUs 4 and 5, and checking for data validity\n");
	getPSU(4).alarmProtocolShutdown[0] = 0;
	getPSU(5).alarmProtocolShutdown[0] = 0;
	initializeValuesPSUsSnIs();
//	printValuesPSU(4);
//	printValuesPSU(5);
	result4 = getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1);
	result5 = getPSU(5).alarmProtocolShutdown[0] == demux4to16(5+1);
	iprintf(" Initialized alarmProtocolShutdown (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	iprintf(" Initialized alarmProtocolShutdown (5) = %d (should be %d)\n", getPSU(5).alarmProtocolShutdown[0], demux4to16(5+1));
}


void TEST_FlashMemCTRL_SnI(void){
	iprintf("\n\n\n\n4. Setting default Values for SnIs 4 and 13, and saving values\n");
	defaultValuesSnI(13);
	defaultValuesSnI(4);
	sniList[5].nominalVoltage = 0;
	saveInFlashValuesPSUsSNIs();
//	printValuesSnI(4);
//	printValuesSnI(5);
//	printValuesSnI(13);
	iprintf(" Saved InfVoltValue(4) = %s ", ftos(getSnI(4).alarmLimitValues[0]));iprintf("(should be < %s)\n", ftos(getSnI(4).nominalVoltage));
	iprintf(" Saved SupVoltValue(4) = %s ", ftos(getSnI(4).alarmLimitValues[1]));iprintf("(should be > %s)\n", ftos(getSnI(4).nominalVoltage));
	iprintf(" Saved InfVoltValue(13) = %s ", ftos(getSnI(13).alarmLimitValues[0]));iprintf("(should be < %s)\n", ftos(getSnI(13).nominalVoltage));
	iprintf(" Saved SupVoltValue(13) = %s ", ftos(getSnI(13).alarmLimitValues[1]));iprintf("(should be > %s)\n", ftos(getSnI(13).nominalVoltage));
	iprintf(" Saved nominalVoltage(5) = %s (should be 0)\n", ftos(getSnI(5).nominalVoltage));
	//Check Values
	result6 = ((getSnI(4).alarmLimitValues[0] < getSnI(4).nominalVoltage) && (getSnI(4).alarmLimitValues[1] > getSnI(4).nominalVoltage)) && ((getSnI(13).alarmLimitValues[0] < getSnI(13).nominalVoltage) && (getSnI(13).alarmLimitValues[1] > getSnI(13).nominalVoltage));
	//end Check Values
	iprintf("\n\n\n\n5. Loading Values and checking for data validity\n");
	getSnI(4).nominalVoltage = 0;
	getSnI(5).nominalVoltage = 2;
	loadFlashValuesSNIs();
//	printValuesSnI(4);
//	printValuesSnI(5);
	iprintf(" Loaded nominalVoltage(4) = %s (should be > 0)\n", ftos(getSnI(4).nominalVoltage));
	iprintf(" Loaded nominalVoltage(13) = %s (should be < 0)\n", ftos(getSnI(13).nominalVoltage));
	iprintf(" Loaded nominalVoltage(5) = %s (should be 0)\n", ftos(getSnI(5).nominalVoltage));
	//Check Values
	result7 = (getSnI(4).nominalVoltage != 0) && (getSnI(13).nominalVoltage != 0);
	result8 = getSnI(5).nominalVoltage == 0;
	//end Check Values
	printf("\n\n\n\n6. Initializing Values, printing SnIs 4 and 5, and checking for data validity\n");
	getSnI(4).nominalVoltage = 0;
	getSnI(5).nominalVoltage = 0;
	initializeValuesPSUsSnIs();
//	printValuesSnI(4);
//	printValuesSnI(5);
	iprintf(" Initialized nominalVoltage(4) = %s (should be > 0)\n", ftos(getSnI(4).nominalVoltage));
	iprintf(" Initialized nominalVoltage(13) = %s (should be < 0)\n", ftos(getSnI(13).nominalVoltage));
	iprintf(" Initialized nominalVoltage(5) = %s (should be > 0)\n", ftos(getSnI(5).nominalVoltage));
	//Check Values
	result9 = (getSnI(4).nominalVoltage > 0) && (getSnI(13).nominalVoltage < 0);
	result10 = (getSnI(5).nominalVoltage > 0 );
	//end Check Values
}



BOOL TEST_DataListsCTRL( void ){
	iprintf("\n\n\n\n===============TEST_DataListsCTRL===============\n");
	iprintf("\n\n\n\n1. Setting DEFAULT Values for PSUs 1, 4 (both positive) and 10 (negative)\n");
	defaultValuesPSU(1);
	defaultValuesPSU(4);
	defaultValuesPSU(11);
	printValuesPSU(1);
	printValuesPSU(4);
	printValuesPSU(11);
	//Check Values
	result1 = (getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1));
	result2 = (getPSU(1).alarmProtocolShutdown[0] == demux4to16(1+1));
	result3 = (getPSU(11).alarmProtocolShutdown[0] == demux4to16(11+1));
	//end Check Values
	iprintf(" Saved Value (1) = %d (should be %d)\n", getPSU(1).alarmProtocolShutdown[0], demux4to16(1+1));
	iprintf(" Saved Value (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	iprintf("\n\n\n\n2. Setting DEFAULT Values for SnIs 1 and 4\n");
	defaultValuesSnI(1);
	defaultValuesSnI(4);
	defaultValuesSnI(13);
	printValuesSnI(1);
	printValuesSnI(4);
	printValuesSnI(13);
	//Check Values
	result4 = ((getSnI(4).alarmLimitValues[0] < getSnI(4).nominalVoltage) && (getSnI(4).alarmLimitValues[1] > getSnI(4).nominalVoltage));
	result5 = ((getSnI(1).alarmLimitValues[0] < getSnI(1).nominalVoltage) && (getSnI(1).alarmLimitValues[1] > getSnI(1).nominalVoltage));
	result6 = ((getSnI(13).alarmLimitValues[0] < getSnI(13).nominalVoltage) && (getSnI(13).alarmLimitValues[1] > getSnI(13).nominalVoltage));
	// end Check Values
	iprintf("\n\n\n\n\n TEST_DataListsCTRL\n");
	iprintf("\n PART 1 - Setting default Values to PSUs\n");
	iprintf(" ~result1(PSU 4): %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf(" ~result2(PSU 1): %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf(" ~result3(PSU 11): %s\n", (result3?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Setting default Values to SnIs\n");
	iprintf(" ~result4(SnI 4): %s\n", (result4?"PASSED":"NOT PASSED"));
	iprintf(" ~result5(SnI 1): %s\n", (result5?"PASSED":"NOT PASSED"));
	iprintf(" ~result6(SnI 13): %s\n", (result6?"PASSED":"NOT PASSED"));
	result7 = (result1&&result2&&result3&&result4&&result5&&result6);
	iprintf("\n OVERALL RESULT: %s\n", (result6?"PASSED":"NOT PASSED"));
	return result6;
}
