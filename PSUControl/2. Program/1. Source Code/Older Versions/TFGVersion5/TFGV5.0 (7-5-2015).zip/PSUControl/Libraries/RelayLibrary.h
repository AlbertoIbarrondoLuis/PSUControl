/*
 * BusExpLibrary.h
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#ifndef BUSEXPLIBRARY_H_

#define BUSEXPLIBRARY_H_

#include "Headers.h"

#include "Libraries/I2C&SPILibrary.h"

void connectRelay ( int psuNum );
void disconnectRelay ( int psuNum );
void disconnectRelaySeveral ( WORD selectedPSUs );

#endif /* BUSEXPLIBRARY_H_ */
