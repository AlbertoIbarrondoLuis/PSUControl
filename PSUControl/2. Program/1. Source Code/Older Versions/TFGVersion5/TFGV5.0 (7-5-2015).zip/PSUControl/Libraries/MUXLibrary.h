/*
 * MUXLibrary.h
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#ifndef MUXLIBRARY_H_

#include "Headers.h"

#include "Libraries\I2C&SPILibrary.h"
#include "Libraries\ExpanderI2CLibrary.h"
#include "defineConstants.cpp"

#define MUXLIBRARY_H_

float setMUX(BYTE function, BYTE selectDev);
float getScaleFactorMUX ( void );
BYTE getI2CResultMUX ( void );

#endif /* MUXLIBRARY_H_ */
