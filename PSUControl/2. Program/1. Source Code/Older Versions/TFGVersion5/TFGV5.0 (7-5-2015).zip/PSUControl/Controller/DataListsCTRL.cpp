/*
 * 	AuxiliaryCTRL.cpp
 *
 *	Definition of psuList and auxList.
 *	Default Values and printing methods for both
 *	Getters & Setters for both
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
*/

#include "Controller/Controller.h"
PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
SnI_TYPE auxList[INT_VCC_n12V + 1];			// Supply & Internal voltages List


//=====================================================================================================//
//=================================    DATA LISTS' METHODS    =========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// defaultValuesPSU - Replaces the current PSU values in RAM by those predefined as DEFAULT in
//					file "defineConstants.cpp"
//-------------------------------------------------------------------------------------------------------
void defaultValuesPSU (int psuNum) {
	psuList[psuNum].relayStatus=DEFAULT_relayStatus;
	psuList[psuNum].psuStatus=DEFAULT_psuStatus;
	psuList[psuNum].rdacValue=DEFAULT_rdacValue;
	BYTE i2CtoSPIAddress[12]= PSUs_I2C_ADDRESS_ARRAY;
	psuList[psuNum].bridgeI2CAdr=i2CtoSPIAddress[psuNum];
	psuList[psuNum].rdacAdr=(psuNum&0x1?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
	float auxArray1[4]=DEFAULT_alarmLimitValues;
	memcpy(psuList[psuNum].alarmLimitValues, auxArray1, sizeof(psuList[psuNum].alarmLimitValues));
	int auxArray2[4]=DEFAULT_alarmLimitTimes;
	memcpy(psuList[psuNum].alarmLimitTimes, auxArray2, sizeof(psuList[psuNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_alarmProtocols;
	memcpy(psuList[psuNum].alarmProtocols, auxArray3, sizeof(psuList[psuNum].alarmProtocols));
	DWORD k = demux4to16(psuNum+1);
	int auxArray4[4]={k, k, k, k};
	memcpy(psuList[psuNum].alarmProtocolShutdown, auxArray4, sizeof(psuList[psuNum].alarmProtocolShutdown));
	float auxArray5[8]=DEFAULT_alarmProtocolVoltage;
	memcpy(psuList[psuNum].alarmProtocolVoltage, auxArray5, sizeof(psuList[psuNum].alarmProtocolVoltage));
	int auxArray6[4]=DEFAULT_alarmCounters;
	memcpy(psuList[psuNum].alarmCounters, auxArray6, sizeof(psuList[psuNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_alarmStatus;
	memcpy(psuList[psuNum].alarmStatus, auxArray7, sizeof(psuList[psuNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_alarmLimitReached;
	memcpy(psuList[psuNum].alarmLimitReached, auxArray8, sizeof(psuList[psuNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_alarmWatch;
	memcpy(psuList[psuNum].alarmWatch, auxArray9, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt = DEFAULT_rShunt;
	psuList[psuNum].vOut = DEFAULT_vOut;
	psuList[psuNum].cOut = DEFAULT_cOut;
}


//-------------------------------------------------------------------------------------------------------
// printValuesPSU - prints by stdio all the values in RAM from the selected PSU
//-------------------------------------------------------------------------------------------------------
void printValuesPSU (int psuNum) {
	iprintf("PSU-Number: %d\n", psuNum);
	iprintf("- relayStatus: %d\n",psuList[psuNum].relayStatus);
	iprintf("- psuStatus: %d\n",psuList[psuNum].psuStatus);
	iprintf("- rdacValue: %s\n",ftos(psuList[psuNum].rdacValue));
	iprintf("- bridgeI2CDir: 0x%x\n",psuList[psuNum].bridgeI2CAdr);
	iprintf("- rdacAdr: %d\n",psuList[psuNum].rdacAdr);
	iprintf("- alarmLimitValues: {%s, %s, %s, %s}\n",
			ftos(psuList[psuNum].alarmLimitValues[0]), ftos(psuList[psuNum].alarmLimitValues[1]),
			ftos(psuList[psuNum].alarmLimitValues[2]),ftos(psuList[psuNum].alarmLimitValues[3]));

	iprintf("- alarmLimitTimes: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitTimes[0], psuList[psuNum].alarmLimitTimes[1],
			psuList[psuNum].alarmLimitTimes[2],psuList[psuNum].alarmLimitTimes[3]);

	iprintf("- alarmProtocols: {%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d}\n",
			psuList[psuNum].alarmProtocols[0],psuList[psuNum].alarmProtocols[1],
			psuList[psuNum].alarmProtocols[2],psuList[psuNum].alarmProtocols[3],
			psuList[psuNum].alarmProtocols[4],psuList[psuNum].alarmProtocols[5],
			psuList[psuNum].alarmProtocols[6],psuList[psuNum].alarmProtocols[7],
			psuList[psuNum].alarmProtocols[8],psuList[psuNum].alarmProtocols[9],
			psuList[psuNum].alarmProtocols[10],psuList[psuNum].alarmProtocols[11]);
	iprintf("- alarmProtocolShutdown: {0x%x, 0x%x, 0x%x, 0x%x}\n",
			psuList[psuNum].alarmProtocolShutdown[0], psuList[psuNum].alarmProtocolShutdown[1],
			psuList[psuNum].alarmProtocolShutdown[2],psuList[psuNum].alarmProtocolShutdown[3]);
	iprintf("- alarmProtocolVoltage:{%s, %s, %s, %s, %s, %s, %s, %s}\n",
			ftos(psuList[psuNum].alarmProtocolVoltage[0]),ftos(psuList[psuNum].alarmProtocolVoltage[1]),
			ftos(psuList[psuNum].alarmProtocolVoltage[2]),ftos(psuList[psuNum].alarmProtocolVoltage[3]),
			ftos(psuList[psuNum].alarmProtocolVoltage[4]),ftos(psuList[psuNum].alarmProtocolVoltage[5]),
			ftos(psuList[psuNum].alarmProtocolVoltage[6]),ftos(psuList[psuNum].alarmProtocolVoltage[7]));
	iprintf("- alarmCounters: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmCounters[0], psuList[psuNum].alarmCounters[1],
			psuList[psuNum].alarmCounters[2],psuList[psuNum].alarmCounters[3]);
	iprintf("- alarmStatus: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmStatus[0], psuList[psuNum].alarmStatus[1],
			psuList[psuNum].alarmStatus[2],psuList[psuNum].alarmStatus[3]);
	iprintf("- alarmLimitReached: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitReached[0], psuList[psuNum].alarmLimitReached[1],
			psuList[psuNum].alarmLimitReached[2],psuList[psuNum].alarmLimitReached[3]);
	iprintf("- alarmWatch: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmWatch[0], psuList[psuNum].alarmWatch[1],
			psuList[psuNum].alarmWatch[2],psuList[psuNum].alarmWatch[3]);
	iprintf("- rShunt: %d\n",psuList[psuNum].rShunt);
	iprintf("- vOut: %d\n",psuList[psuNum].vOut);
	iprintf("- cOut: %d\n",psuList[psuNum].cOut);

}


//-------------------------------------------------------------------------------------------------------
// defaultValuesAUX - Replaces the current AUX values in RAM by those predefined as DEFAULT in
//					file "defineConstants.cpp"
//-------------------------------------------------------------------------------------------------------
void defaultValuesAUX (int auxNum) {
	auxList[auxNum].auxStatus=DEFAULT_auxStatus;
	float auxArray0[14]=DEFAULT_auxVoltage;
	auxList[auxNum].auxVoltage=auxArray0[auxNum];
	float auxArray1[4]= {auxList[auxNum].auxVoltage * AUXILIAR_INF_PERC_ALARM_VALUE, auxList[auxNum].auxVoltage * AUXILIAR_SUP_PERC_ALARM_VALUE, 0, 0 };
	memcpy(auxList[auxNum].alarmLimitValues, auxArray1, sizeof(auxList[auxNum].alarmLimitValues));
	int auxArray2[4]=DEFAULT_auxalarmLimitTimes;
	memcpy(auxList[auxNum].alarmLimitTimes, auxArray2, sizeof(auxList[auxNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_auxalarmProtocols;
	memcpy(auxList[auxNum].alarmProtocols, auxArray3, sizeof(auxList[auxNum].alarmProtocols));
	int auxArray4[4]={0, 0, 0, 0};
	memcpy(auxList[auxNum].alarmProtocolShutdown, auxArray4, sizeof(auxList[auxNum].alarmProtocolShutdown));
	int auxArray6[4]=DEFAULT_auxalarmCounters;
	memcpy(auxList[auxNum].alarmCounters, auxArray6, sizeof(auxList[auxNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_auxalarmStatus;
	memcpy(auxList[auxNum].alarmStatus, auxArray7, sizeof(auxList[auxNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_auxalarmLimitReached;
	memcpy(auxList[auxNum].alarmLimitReached, auxArray8, sizeof(auxList[auxNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_auxalarmWatch;
	memcpy(auxList[auxNum].alarmWatch, auxArray9, sizeof(auxList[auxNum].alarmWatch));
	auxList[auxNum].vOut = DEFAULT_vOut;
}

//-------------------------------------------------------------------------------------------------------
// printValuesAUX - prints by stdio all the values in RAM from the selected PSU
//-------------------------------------------------------------------------------------------------------
void printValuesAUX (int auxNum) {
	iprintf("AUX-Number: %d\n", auxNum);
	iprintf("- auxStatus: %d\n",auxList[auxNum].auxStatus);
	iprintf("- auxVoltage: %s\n",ftos(auxList[auxNum].auxVoltage));
	iprintf("- alarmLimitValues: {%s, %s, %s, %s}\n",
			ftos(auxList[auxNum].alarmLimitValues[0]), ftos(auxList[auxNum].alarmLimitValues[1]),
			ftos(auxList[auxNum].alarmLimitValues[2]),ftos(auxList[auxNum].alarmLimitValues[3]));

	iprintf("- alarmLimitTimes: {%d, %d, %d, %d}\n",
			auxList[auxNum].alarmLimitTimes[0], auxList[auxNum].alarmLimitTimes[1],
			auxList[auxNum].alarmLimitTimes[2],auxList[auxNum].alarmLimitTimes[3]);

	iprintf("- alarmProtocols: {%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d}\n",
			auxList[auxNum].alarmProtocols[0],auxList[auxNum].alarmProtocols[1],
			auxList[auxNum].alarmProtocols[2],auxList[auxNum].alarmProtocols[3],
			auxList[auxNum].alarmProtocols[4],auxList[auxNum].alarmProtocols[5],
			auxList[auxNum].alarmProtocols[6],auxList[auxNum].alarmProtocols[7],
			auxList[auxNum].alarmProtocols[8],auxList[auxNum].alarmProtocols[9],
			auxList[auxNum].alarmProtocols[10],auxList[auxNum].alarmProtocols[11]);
	iprintf("- alarmProtocolShutdown: {0x%x, 0x%x, 0x%x, 0x%x}\n",
			auxList[auxNum].alarmProtocolShutdown[0], auxList[auxNum].alarmProtocolShutdown[1],
			auxList[auxNum].alarmProtocolShutdown[2],auxList[auxNum].alarmProtocolShutdown[3]);
	iprintf("- alarmCounters: {%d, %d, %d, %d}\n",
			auxList[auxNum].alarmCounters[0], auxList[auxNum].alarmCounters[1],
			auxList[auxNum].alarmCounters[2],auxList[auxNum].alarmCounters[3]);
	iprintf("- alarmStatus: {%d, %d, %d, %d}\n",
			auxList[auxNum].alarmStatus[0], auxList[auxNum].alarmStatus[1],
			auxList[auxNum].alarmStatus[2],auxList[auxNum].alarmStatus[3]);
	iprintf("- alarmLimitReached: {%d, %d, %d, %d}\n",
			auxList[auxNum].alarmLimitReached[0], auxList[auxNum].alarmLimitReached[1],
			auxList[auxNum].alarmLimitReached[2],auxList[auxNum].alarmLimitReached[3]);
	iprintf("- alarmWatch: {%d, %d, %d, %d}\n",
			auxList[auxNum].alarmWatch[0], auxList[auxNum].alarmWatch[1],
			auxList[auxNum].alarmWatch[2],auxList[auxNum].alarmWatch[3]);
	iprintf("- vOut: %d\n",auxList[auxNum].vOut);

}
PSU_TYPE getPSU (int psuNum){
	return psuList[psuNum];
}

SnI_TYPE getAUX( int auxNum ){
	return auxList[auxNum];
}

void setPSU (int psuNum, PSU_TYPE psu){
	psuList[psuNum] = psu;
}

void setAUX( int auxNum, SnI_TYPE aux){
	auxList[auxNum] = aux;
}
