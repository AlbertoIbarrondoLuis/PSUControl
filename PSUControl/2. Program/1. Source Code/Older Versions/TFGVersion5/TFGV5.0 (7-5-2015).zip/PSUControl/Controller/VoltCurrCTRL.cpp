/*
 * VoltCurrCTRL.cpp
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */


#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE auxList [INT_VCC_n12V + 1];				// Supply & Internal voltages List


//=====================================================================================================//
//================================    VOLTAGE & CURRENT METHODS    ====================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// adjustRdac - changes the RDAC Register Value (thus modifying its output voltage)
// 					Checks for correct value updating
//-------------------------------------------------------------------------------------------------------
void adjustRdac (int psuNum, float Voltage){
	int desiredValue = voltToNum(Voltage, psuList[psuNum].rShunt);
	setValRDAC(desiredValue, psuList[psuNum].rdacAdr, psuList[psuNum].bridgeI2CAdr);
	int setValue = getValRDAC(psuList[psuNum].rdacAdr, psuList[psuNum].bridgeI2CAdr);
	if (desiredValue==setValue){
		psuList[psuNum].rdacValue = Voltage;
	}
	else{
		iprintf("ERROR: RDAC value %d not properly configured on PSU %d. Value %d set instead", desiredValue, psuNum, setValue);
	}
}


//-------------------------------------------------------------------------------------------------------
// resetRdacs - Hardware rheostats' reset
//-------------------------------------------------------------------------------------------------------
void resetRdacs ( void ){
	Pins[21] = 1;
	OSTimeDly(TICKS_100MS);
	Pins[21] = 0;
}


//-------------------------------------------------------------------------------------------------------
// updateVoltagePSUs - Updates both RDAC values with their RAM configuration for the selected PSUs
//					  (marking its respective bit number as TRUE)
//-------------------------------------------------------------------------------------------------------
void updateVoltagePSUs(WORD selectPSUs){	// PSUs marked with his corresponding bit to 1 will be switched on.
	int psuNum; int aux = selectPSUs;
	// ajustar fuentes
	for (psuNum=0;psuNum<PSU_NUMBER;psuNum++){
		if(aux & 0x0001){
			if (psuList[psuNum].psuStatus) {
				adjustRdac (psuNum, psuList[psuNum].rdacValue);
			}
		}
		aux=aux>>1;
 	}
	OSTimeDly(TICKS_100MS); // delay for regulator adjustment
}


//-------------------------------------------------------------------------------------------------------
// readVoltageValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						to voltage. Currently not in use, as this function is executed by PITR 0
//						(see TimerInt.cpp)
//-------------------------------------------------------------------------------------------------------
void readVoltageValue(int psuNum){
	float value = 0, scaleFactor = 0;
	scaleFactor = setMUX((BYTE) FUNCTION_READ_VOLTAGE, (BYTE)psuNum);
	value = ((float)(ReadA2DResult(0) >> 3) / (4095.0)) * 3.3 * scaleFactor*getGainAGC();
	psuList[psuNum].vOut = value;
}


//-------------------------------------------------------------------------------------------------------
// readCurrentValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						to current.Currently not in use, as this function is executed by PITR 0
//						(see TimerInt.cpp)
//-------------------------------------------------------------------------------------------------------
void readCurrentValue(int psuNum){
	float value = 0, scaleFactor = 0;
	scaleFactor = setMUX((BYTE)FUNCTION_READ_CURRENT, (BYTE)psuNum);
	value = ((float)(ReadA2DResult(0) >> 3) / (4095.0)) * 3.3 * scaleFactor * getGainAGC();
	psuList[psuNum].cOut = value;
}
