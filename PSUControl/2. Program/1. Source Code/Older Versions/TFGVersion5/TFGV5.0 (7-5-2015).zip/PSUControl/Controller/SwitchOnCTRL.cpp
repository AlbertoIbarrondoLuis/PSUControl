/*
 * SwitchOnCTRL.cpp
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */


#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE auxList [INT_VCC_n12V + 1];				// Supply & Internal voltages List


//==============================================VARIABLES==============================================//
BOOL powerONProcess = false; 	// used to initialize the system.
int powerONticks=0; 			// delay counter when initializing the system.
WORD switchONListPSUs = 0;		// bits in TRUE are PSUs pending to be switched on



//=====================================================================================================//
//================================    PSUs SWITCH ON/OFF METHODS    ===================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// switchONPSUs - Manages the complete PSU switching-on process for the selected PSUs: Initializes
//				its RAM values, changes its RDAC Register values, tells the switchONPSUsTask to
//				begin the delayed switching-on process.
//-------------------------------------------------------------------------------------------------------
void switchONPSUs(WORD selectedPSUs){
	powerONProcess=true;					// Starts switching on the psus. will be terminated by the switchONPSUsTask
	initializeValuesPSUsAUXs();				// Load psuList values from RAM or set them to default

    switchONPSUsTask( selectedPSUs );

    powerONProcess=false;					// End of the process
}



//-------------------------------------------------------------------------------------------------------
// switchONPSUsTask - Task in charge of the PSUs' delayed switching-on process, connecting the relays
//					  when each PSU reaches its initializationTimer. When every PSU has been connected, the
//					  task is destroyed.
//-------------------------------------------------------------------------------------------------------
void switchONPSUsTask(WORD switchONListPSUs){
		powerONticks = 0;
		while(switchONListPSUs){
			int psuNum=0;
			int aux=switchONListPSUs;
			for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
				if(aux & 0x0001){
					if(psuList[psuNum].initializationTimer <= powerONticks){
						switchONListPSUs-=(0x0001<<psuNum);
						psuList[psuNum].ReadyToConnect = true;
						connectPSU(psuNum);
						adjustRdac (psuNum, psuList[psuNum].rdacValue);
					}
				}
				aux=aux>>1;
			}
			powerONticks++;
			OSTimeDly(TICKS_100MS);
		}
}


//-------------------------------------------------------------------------------------------------------
// initializeValuesPSUsAUXs - Loads all PSU values from FLASH and checks for each VERIFY_KEY correction.
//						If corrupted, sets the PSU values to default. Also Initializes the values of
//						auxList to their defaults
//-------------------------------------------------------------------------------------------------------
int initializeValuesPSUsAUXs(void){
	 int saveParameters=FALSE;
	 int i=0;
	 PSU_TYPE *pData = (PSU_TYPE *) GetUserParameters();
	 PSU_TYPE *ppsuList = psuList;
	 for (i=0;i<PSU_NUMBER;i++){
	      if (pData->VerifyKey != VERIFY_KEY){ 			// Incorrect Data
	    	  defaultValuesPSU(i);
	    	  saveParameters=TRUE;							// Save values as soon as an invalid key is detected
          }else {											// Correct data
        	  // readFlashValuesPSU(i,pData); 				use in case memory copying didn't work (which currently does)
        	  memcpy (ppsuList, pData, sizeof(PSU_TYPE));
		  }
	      pData++; ppsuList++;							//Next PSU reading
	  }
     if (saveParameters){
    	 saveParameters = saveInFlashValuesPSU ();
     }

     for (i=0;i<=INT_VCC_n12V; i++){					// Initialize values of auxList to their defaults (auxiliar voltages)
    	 defaultValuesAUX(i);
     }
     return saveParameters;
}

//-------------------------------------------------------------------------------------------------------
// connectPSU - Connects the selected PSU by switching its Rel� and activates its LED OUT
//-------------------------------------------------------------------------------------------------------
void connectPSU(int psuNum){
	connectRelay ( psuNum );
	// TODO: activar LED OUT ON. quiz� esperar alguna medida de tensi�n para asegurar que funciona
	psuList[psuNum].psuStatus=true;
	psuList[psuNum].ReadyToConnect=false;
}


//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSU's relay, updating its LED OUT, and sets its power to minimum
//-------------------------------------------------------------------------------------------------------
void disconnectPSU(int psuNum){
	psuList[psuNum].ReadyToConnect=false;
	disconnectRelay ( psuNum );
	psuList[psuNum].relayStatus=false;
	adjustRdac(psuNum, INITIAL_VOLTAGE);
	psuList[psuNum].psuStatus=false;
	// TODO: comprobar si se ha de desactivar  led Out On y si el voltaje se ha desconectado
}

//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSUs' relays, updating its LED OUT, and sets their power to minimum
//-------------------------------------------------------------------------------------------------------
void switchOFFPSUs(WORD selectedPSUs){
	disconnectRelaySeveral ( selectedPSUs );
	int psuNum;
	for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
		if(selectedPSUs & 0x0001){
			psuList[psuNum].ReadyToConnect=false;
			disconnectRelay ( psuNum );
			psuList[psuNum].relayStatus=false;
			adjustRdac(psuNum, INITIAL_VOLTAGE);
			psuList[psuNum].psuStatus=false;
		}
		selectedPSUs=selectedPSUs>>1;
	}
	// TODO: desactivar  led Out On. Comprobar el voltaje para asegurar que se ha desconectado
}
