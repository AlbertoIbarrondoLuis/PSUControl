/*
 * MonitorCTRL.cpp
 *
 *	Continuous sampling of all the PSUs (and auxiliaries, when properly set). To do so, the RTOS task
 *	waits for the interrupt to post on monitorSem (an OS_SEM), and then goes over the next loop.
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */


#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE auxList [INT_VCC_n12V + 1];				// Supply & Internal voltages List

//==============================================VARIABLES==============================================//
// Imported
extern OS_SEM monitorSem;

// A2D Sampling
int lastMeasure = 0;
BOOL lastMeasureValid = false;
BYTE samplingFunction = FUNCTION_READ_VOLTAGE;

// Configuration Flags
BOOL readSupplyAuxFLAG = true;	// Sets whether both Supply and Internal voltages are included in a2d routine loop or not

// Auxiliary
int Num = 0;
int a = 0;
BOOL prevMeas = false;

//=====================================================================================================//
//======================================    MONITOR METHODS    ========================================//
//=====================================================================================================//
void monitorTask (void* p){
	while(1){	// loop forever
		a++;
		if(a>=1000){
			a= 0;

		lastMeasure = (ReadA2DResult(0) >> 3);
		lastMeasureValid = (lastMeasure>MINIMUM_LEVEL_ADC);

		if (lastMeasureValid){
			switch (samplingFunction){	//Store Value in the right object
				case FUNCTION_READ_VOLTAGE:
					psuList[Num].vOut= ((float)lastMeasure) / (4095.0) * 3.3 *getGainAGC()*getScaleFactorMUX();
					break;
				case FUNCTION_READ_CURRENT:
					psuList[Num].cOut= ((float)lastMeasure) / (4095.0) * 3.3 *getGainAGC()*getScaleFactorMUX();
					break;
				case FUNCTION_READ_SUPPLY_INTERNAL:	// TODO: left for revision
					auxList[Num].vOut= ((float)lastMeasure) / (4095.0) * 3.3 *getGainAGC()*getScaleFactorMUX();
					break;
			}
			minAGC();					// Set AGC always to minimum upon next voltage sampling

			// Next PSU, and next samplingFunction (see defineConstants.cpp - MUX) if last PSU reached
			Num++;
			if (readSupplyAuxFLAG){
				if( ((samplingFunction<=FUNCTION_READ_CURRENT) &&  (Num>=PSU_NUMBER)) || (Num>INT_VCC_n12V) ){
					Num = 0;
					// Next sampling function (restart if last function reached, cyclic)
					samplingFunction = (samplingFunction>=FUNCTION_READ_SUPPLY_INTERNAL?FUNCTION_READ_VOLTAGE:samplingFunction+1);
				}
			}
			else{
				if (Num >= PSU_NUMBER){
					Num = 0;
					samplingFunction = !samplingFunction; 	// Toggle between FUNCTION_READ_VOLTAGE (0) and FUNCTION_READ_CURRENT(1)
				}										  	//  functions (see defineConstants.cpp - MUX)
			}
			setMUX( samplingFunction, (BYTE)Num );	// Set muxes for next reading
			lastMeasureValid = false;
		}
		else{
			changeGainAGC(MIDSCALE_ADC/lastMeasure);
		}
		iprintf("Num = %d\n Sampling = %d\n SCALE = %s\n", Num, samplingFunction, ftos(getScaleFactorMUX()) );
		}
		OSSemPend( & monitorSem , 0 );
	}
}
