/*
 * AlarmCTRL.cpp
 *
 *	RTOS task executed once every 100ms that checks the voltage & current of
 *	all the PSUs and triggers alarms if a limit is reached
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */

#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List

//===========================================VARIABLES=================================================//
// Timing
extern int alarmUpdatePeriodx50MS;

// Configuration
extern BOOL config_AlarmCTRLUpdate_SnI_FLAG;

// Testing
extern BOOL testMode_AlarmCTRL_Task_FLAG;

//=====================================================================================================//
//======================================    ALARM METHODS    ==========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// alarmTask - Independent process in charge of monitoring all the PSU alarms once every 100ms
//				and executing the programmed protocols once every second if an alarm is triggered.
//-------------------------------------------------------------------------------------------------------
void alarmTask (void *p){
	int nled = 0;
	BOOL ledFlag = true;
	while (1){
		OSTimeDly(alarmUpdatePeriodx50MS);   	// Critical, otherwise the lower tasks wont receive computing time.
		//OSSemPend( & alarmSem, 0);
		if(!testMode_AlarmCTRL_Task_FLAG){
			updateAlarms();
			nled++;						// Uses LED 0 as output
			if (nled>=5){
				Pins[28] = ledFlag;
				ledFlag = !ledFlag;
				nled= 0;
			}
		}
	}

}

//-------------------------------------------------------------------------------------------------------
// alarmCheck - Checks each alarm status for the selected PSU and executes the programmed protocols
//				if activated.
//-------------------------------------------------------------------------------------------------------
void alarmCheck (int psuNum, BOOL inf_sup, BOOL volt_corr, BOOL psu_sni){
	if (psu_sni == PSU_TYPE_LIST){		// Checking a PSU_TYPE from psuList
		if(psuList[psuNum].alarmWatch[_(inf_sup,volt_corr)]){				// If the selected alarm is being watched (INFERIOR/SUPERIOR, VOLTAGE/CURRENT)
																					// Refresh alarmLimitReached value
			if   (inf_sup==INFERIOR) {psuList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]=((volt_corr==VOLTAGE?psuList[psuNum].vOut:psuList[psuNum].cOut) <= psuList[psuNum].alarmLimitValues[_(inf_sup,volt_corr)]);}
			else/*inf_sup==SUPERIOR*/{psuList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]=((volt_corr==VOLTAGE?psuList[psuNum].vOut:psuList[psuNum].cOut) >= psuList[psuNum].alarmLimitValues[_(inf_sup,volt_corr)]);}
			if (psuList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]){			// If limit is exceeded
				psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)]++;					// Increment Alarm Counter

				if (psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)]>=psuList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)]){
																						//  Trigger on the alarm if counter reaches the time limit
					if (psuList[psuNum].alarmStatus[_(inf_sup,volt_corr)] == false ){			// If it's the first time the alarm is triggered, execute protocols
						psuList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = true;
						int j;
						for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){									// Goes over each alarm protocol for the activated alarm
							if (psuList[psuNum].alarmProtocols[__(inf_sup,volt_corr, j)]){
								executeAlarmProtocol (psuNum, inf_sup,volt_corr, j, psu_sni);
							}
						}
					}
					psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)]=psuList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)];
				}																		// Sets the counter to time limit (thus preventing it to increase further)
			}
			else{																	// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)] > 0){			// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)] -= 1;			// Decrease counter until it reaches 0

				}
				if (psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)] == 0){			// And when it hits 0, shut off the alarm.
					psuList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = false;
				}
			}
		}
		else{
			psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)] = 0;
			psuList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = false;
		}
	}

	else{			// psu_aux = CHECK_AUX    - Checking an SnI_TYPE from auxList
		if(sniList[psuNum].alarmWatch[_(inf_sup,volt_corr)]){				// If the selected alarm is being watched (INFERIOR/SUPERIOR, VOLTAGE/CURRENT)
																					// Refresh alarmLimitReached value
			if(inf_sup == INFERIOR){
				sniList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]=(sniList[psuNum].vOut <= sniList[psuNum].alarmLimitValues[_(inf_sup,volt_corr)]);
			}
			else{
				sniList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]=(sniList[psuNum].vOut >= sniList[psuNum].alarmLimitValues[_(inf_sup,volt_corr)]);
			}
			if (sniList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]){			// If limit is exceeded
				sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)]++;					// Increment Alarm Counter

				if (sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)]>=sniList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)]){
																						//  Trigger on the alarm if counter reaches the time limit
					if (sniList[psuNum].alarmStatus[_(inf_sup,volt_corr)] == false ){			// If it's the first time the alarm is triggered, execute protocols
						sniList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = true;
						int j;
						for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){									// Goes over each alarm protocol for the activated alarm
							if (sniList[psuNum].alarmProtocols[__(inf_sup,volt_corr, j)]){
								executeAlarmProtocol (psuNum, inf_sup,volt_corr, j, psu_sni);
							}
						}
					}
					sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)]=sniList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)];
				}																		// Sets the counter to time limit (thus preventing it to increase further)
			}
			else{																	// If limit is not exceeded
				if (sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)] > 0){			// And counter is higher than 0
					sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)] -= 1;			// Decrease counter until it reaches 0

				}
				if (sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)] == 0){			// And when it hits 0, shut off the alarm.
					sniList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = false;
				}
			}
		}
		else{
			sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)] = 0;
			sniList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = false;
		}
	}
}


//-------------------------------------------------------------------------------------------------------
// executeAlarmProtocol - Carries out a different protocol depending of the type of alarm
//						 (SUPERIOR/INFERIOR,VOLTAGE/CURRENT).
//-------------------------------------------------------------------------------------------------------
void executeAlarmProtocol (int Num, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum, int psu_sni){
	int k;
	switch (protocolNum){		// (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
	case PROTOCOL_SHUTDOWN:
		WORD shutdown;
		shutdown = psuList[Num].alarmProtocolShutdown[_(limit_inf_sup, type_volt_corr)];
		for (k=0; k<12; k++){
			if (shutdown&0x1){
				disconnectPSU(Num);
			}
			shutdown = shutdown >>1;
		}
		break;
	case PROTOCOL_MODIFY_VOLTAGE:
			adjustRdac(Num, psuList[Num].alarmProtocolVoltage[_(limit_inf_sup,type_volt_corr)]);
		break;
	case PROTOCOL_MESSAGE:

			iprintf(ALARM_MESSAGE);
			//TODO: Maybe add some other alarm output - left for future implementation
		break;
	}
}

//-------------------------------------------------------------------------------------------------------
// updateAlarms - Takes a sample of Voltage and Current for all the PSUs and updates
// 				  their alarm status, counters and flags by comparing the sample with
//				  the programmed limit
//-------------------------------------------------------------------------------------------------------
void updateAlarms (void){
	int psuNum;
	// Goes over each PSU in psuList
	for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
		// Check each alarm
		if (psuList[psuNum].psuStatus==ON){
			alarmCheck(psuNum, INFERIOR, VOLTAGE, PSU_TYPE_LIST);
			alarmCheck(psuNum, SUPERIOR, VOLTAGE, PSU_TYPE_LIST);
			alarmCheck(psuNum, INFERIOR, CURRENT, PSU_TYPE_LIST);
			alarmCheck(psuNum, SUPERIOR, CURRENT, PSU_TYPE_LIST);
		}
	}

	//Same procedure for auxList, controlled by AuxAlarmUpdatingFLAG (default switched off)
	if (config_AlarmCTRLUpdate_SnI_FLAG){
		for (psuNum=0; psuNum<=INT_VCC_n12V; psuNum++){
			alarmCheck(psuNum, INFERIOR, VOLTAGE, SnI_TYPE_LIST);
			alarmCheck(psuNum, SUPERIOR, VOLTAGE, SnI_TYPE_LIST);
		}
	}
}


//-------------------------------------------------------------------------------------------------------
// resetAlarms - disconnects the alarms of each PSU/SnI (defined by psu_sni) set as 1 on its correspondent
//					bit in list. The alarms to be disconnected are set on the bits of alarmType
//-------------------------------------------------------------------------------------------------------
void resetAlarms (WORD list, BYTE alarmType, BOOL psu_sni){
	uint k; uint g;
	if (psu_sni==PSU_TYPE_LIST){
		for (k=0; k<PSU_NUMBER; k++){
			if (list&0x1){
				for (g=0; g<sizeof(psuList[k].alarmCounters); g++){
					if(alarmType&0x1){
						psuList[k].alarmCounters[g] = 0;
						psuList[k].alarmStatus[g] = false;
					}
					alarmType = alarmType >>1;
				}
			}
			list = list >>1;
		}
	}
	else{
		for (k=0; k<SnI_NUMBER; k++){
			if (list&0x1){
				for (g=0; g<sizeof(sniList[k].alarmCounters); g++){
					if(alarmType&0x1){
						sniList[k].alarmCounters[g] = 0;
						sniList[k].alarmStatus[g] = false;
					}
					alarmType = alarmType >>1;
				}
			}
			list = list >>1;
		}
	}
}

//-------------------------------------------------------------------------------------------------------
// resetAlarms - disconnects the alarms of each PSU/SnI (defined by psu_sni) set as 1 on its correspondent
//					bit in list. The alarms to be disconnected are set on the bits of alarmType
//-------------------------------------------------------------------------------------------------------
void resetAlarmsAll ( void ){
	uint i,j;
	for (j = 0; j<PSU_NUMBER;j++){
		for (i = 0; i<sizeof(psuList[j].alarmCounters); i++){
			psuList[j].alarmCounters[i]=0;
			psuList[j].alarmStatus[i]=0;
			psuList[j].alarmLimitReached[i]=0;
		}
	}
	for (j = 0; j<SnI_NUMBER;j++){
		for (i = 0; i<sizeof(sniList[j].alarmCounters)-2; i++){
			sniList[j].alarmCounters[i]=0;
			sniList[j].alarmStatus[i]=0;
			sniList[j].alarmLimitReached[i]=0;
		}
	}
}

//-------------------------------------------------------------------------------------------------------
// toggleAlarmsAll - connects all the alarms (alarmWatch = 1) of each PSU/SnI
//-------------------------------------------------------------------------------------------------------
void toggleAlarmsAll ( BOOL almWatch ){
	uint i,j;
	for (j = 0; j<PSU_NUMBER;j++){
		for (i = 0; i<sizeof(psuList[j].alarmCounters); i++){
			psuList[j].alarmWatch[i]=almWatch;
		}
	}
	for (j = 0; j<SnI_NUMBER;j++){
		for (i = 0; i<sizeof(sniList[j].alarmCounters)-2; i++){
			sniList[j].alarmWatch[i]=almWatch;
		}
	}
}


//-------------------------------------------------------------------------------------------------------
// setAlarm - Sets both the value and the time for the desired alarm, turning it on (alarmWatch)
//-------------------------------------------------------------------------------------------------------
void setAlarm ( BOOL psu_sni, int num, BOOL volt_curr, BOOL inf_sup, float value, int time){
	if(psu_sni==PSU_TYPE_LIST){
		setalarmLimitValuesPSU(value, inf_sup, volt_curr, num);
		setalarmLimitTimesPSU(time, inf_sup, volt_curr, num);
		setalarmWatchPSU(true, inf_sup, volt_curr, num);
	}
	else{
		setalarmLimitValuesSnI(value, inf_sup, VOLTAGE, num);
		setalarmLimitTimesSnI(time, inf_sup, VOLTAGE, num);
		setalarmWatchSnI(true, inf_sup, volt_curr, num);
	}
}
