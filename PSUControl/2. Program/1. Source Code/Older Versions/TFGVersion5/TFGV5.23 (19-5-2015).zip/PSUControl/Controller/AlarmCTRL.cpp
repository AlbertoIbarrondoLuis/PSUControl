/*
 * AlarmCTRL.cpp
 *
 *	RTOS task executed once every 100ms that checks the voltage & current of
 *	all the PSUs and triggers alarms if a limit is reached
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */

#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List

//===========================================VARIABLES=================================================//
BOOL AuxAlarmUpdatingFLAG = INIT_AUXILIARY_ALARMS; 	// Controls whether auxiliary voltages are checked
													// for updating their alarms or not at initialization


//=====================================================================================================//
//======================================    ALARM METHODS    ==========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// alarmTask - Independent process in charge of monitoring all the PSU alarms once every 100ms
//				and executing the programmed protocols once every second if an alarm is triggered.
//-------------------------------------------------------------------------------------------------------
void alarmTask (void *p){
	/* alarmUpdate is triggered on by PITR1 once every PITR_TIMES_TO_ALARM. Currently not in use
	if (alarmUpdate){
		alarmUpdate = false;
	}
	*/
	int nled = 0;
	BOOL ledFlag = true;
	while (1){
		OSTimeDly(TICKS_100MS);   	// Critical, otherwise the lower tasks wont receive computing time.
		updateAlarms();

		nled++;						// Uses LED 0 as output
			if (nled>=5){
				Pins[28] = ledFlag;
				ledFlag = !ledFlag;
				nled= 0;
			}
	}

}

//-------------------------------------------------------------------------------------------------------
// alarmCheck - Checks each alarm status for the selected PSU and executes the programmed protocols
//				if activated.
//-------------------------------------------------------------------------------------------------------
void alarmCheck (int psuNum, BOOL inf_sup, BOOL volt_corr, BOOL psu_aux){
	if (psu_aux == CHECK_PSU){		// Checking a PSU_TYPE from psuList
		if(psuList[psuNum].alarmWatch[_(inf_sup,volt_corr)]){				// If the selected alarm is being watched (INFERIOR/SUPERIOR, VOLTAGE/CURRENT)
																					// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(inf_sup,volt_corr)]);
			if (psuList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]){			// If limit is exceeded
				psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)]++;					// Increment Alarm Counter

				if (psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)]>=psuList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)]){
																						//  Trigger on the alarm if counter reaches the time limit
					if (psuList[psuNum].alarmStatus[_(inf_sup,volt_corr)] == false ){			// If it's the first time the alarm is triggered, execute protocols
						psuList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = true;
						int j;
						for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){									// Goes over each alarm protocol for the activated alarm
							if (psuList[psuNum].alarmProtocols[__(inf_sup,volt_corr, j)]){
								executeAlarmProtocol (psuNum, inf_sup,volt_corr, j);
							}
						}
					}
					psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)]=psuList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)];
				}																		// Sets the counter to time limit (thus preventing it to increase further)
			}
			else{																	// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)] > 0){			// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)] -= 1;			// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)] == 0){			// And when it hits 0, shut off the alarm.
						psuList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = false;
					}
				}
			}
		}
	}

	else{			// psu_aux = CHECK_AUX    - Checking an SnI_TYPE from auxList
		if(sniList[psuNum].alarmWatch[_(inf_sup,volt_corr)]){				// If the selected alarm is being watched (INFERIOR/SUPERIOR, VOLTAGE/CURRENT)
																					// Refresh alarmLimitReached value
			sniList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]=(sniList[psuNum].vOut <= sniList[psuNum].alarmLimitValues[_(inf_sup,volt_corr)]);
			if (sniList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]){			// If limit is exceeded
				sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)]++;					// Increment Alarm Counter

				if (sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)]>=sniList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)]){
																						//  Trigger on the alarm if counter reaches the time limit
					if (sniList[psuNum].alarmStatus[_(inf_sup,volt_corr)] == false ){			// If it's the first time the alarm is triggered, execute protocols
						sniList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = true;
						int j;
						for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){									// Goes over each alarm protocol for the activated alarm
							if (sniList[psuNum].alarmProtocols[__(inf_sup,volt_corr, j)]){
								executeAlarmProtocol (psuNum, inf_sup,volt_corr, j);
							}
						}
					}
					sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)]=sniList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)];
				}																		// Sets the counter to time limit (thus preventing it to increase further)
			}
			else{																	// If limit is not exceeded
				if (sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)] > 0){			// And counter is higher than 0
					sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)] -= 1;			// Decrease counter until it reaches 0
					if (sniList[psuNum].alarmCounters[_(inf_sup,volt_corr)] == 0){			// And when it hits 0, shut off the alarm.
						sniList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = false;
					}
				}
			}
		}
	}
}


//-------------------------------------------------------------------------------------------------------
// executeAlarmProtocol - Carries out a different protocol depending of the type of alarm
//						 (SUPERIOR/INFERIOR,VOLTAGE/CURRENT).
//-------------------------------------------------------------------------------------------------------
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum){
	int k;
	switch (protocolNum){		// (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
	case PROTOCOL_SHUTDOWN:
		WORD shutdown;
		shutdown = psuList[psuNum].alarmProtocolShutdown[_(limit_inf_sup, type_volt_corr)];
		for (k=0; k<12; k++){
			if (shutdown&0x1){
				disconnectPSU(psuNum);
			}
			shutdown = shutdown >>1;
		}
		break;
	case PROTOCOL_MODIFY_VOLTAGE:
			adjustRdac(psuNum, psuList[psuNum].alarmProtocolVoltage[_(limit_inf_sup,type_volt_corr)]);
		break;
	case PROTOCOL_MESSAGE:
			iprintf(ALARM_MESSAGE);
			//TODO: Maybe add some other alarm output - left for future implementation
		break;
	}
}

//-------------------------------------------------------------------------------------------------------
// updateAlarms - Takes a sample of Voltage and Current for all the PSUs and updates
// 				  their alarm status, counters and flags by comparing the sample with
//				  the programmed limit
//-------------------------------------------------------------------------------------------------------
void updateAlarms (void){
	int psuNum;
	// Goes over each PSU in psuList
	for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
		// Check each alarm
		alarmCheck(psuNum, INFERIOR, VOLTAGE, CHECK_PSU);
		alarmCheck(psuNum, SUPERIOR, VOLTAGE, CHECK_PSU);
		alarmCheck(psuNum, INFERIOR, CURRENT, CHECK_PSU);
		alarmCheck(psuNum, SUPERIOR, CURRENT, CHECK_PSU);

	}

	//Same procedure for auxList, controlled by AuxAlarmUpdatingFLAG (default switched off)
	if (AuxAlarmUpdatingFLAG){
		for (psuNum=0; psuNum<=INT_VCC_n12V; psuNum++){
			alarmCheck(psuNum, INFERIOR, VOLTAGE, CHECK_AUX);
			alarmCheck(psuNum, SUPERIOR, VOLTAGE, CHECK_AUX);
			alarmCheck(psuNum, INFERIOR, CURRENT, CHECK_AUX);
			alarmCheck(psuNum, SUPERIOR, CURRENT, CHECK_AUX);
		}
	}
}
