/*
 * Test_PSU.h
 *
 *  Created on: 10-mar-2015
 *      Author: Alberto
 */

#ifndef TEST_PSU_H_
#define TEST_PSU_H_

#include "Headers.h"
#include "Controller/Controller.h"		// All the Controller Methods

#endif /* TEST_PSU_H_ */


void TestMain ( void );
void GeneralMenu ( void );
void CommandMenu( void );
void processCommand( void );
void changeSlave( void );


//--------------------------------BATTERY TESTS-------------------------
BOOL BATTERY_TEST_I2C ( void );
BOOL BATTERY_TEST_RDAC ( void );
BOOL TEST_FlashMemCTRL_BATTERY( void );
BOOL TEST_DataListsCTRL_BATTERY ( void );
