	/*
 * SwitchOnCTRL.cpp
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */


#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
//extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List


//==============================================VARIABLES==============================================//
// Auxiliar
BOOL powerONProcess = false; 	// used to initialize the system.
int powerONticks=0; 			// delay counter when initializing the system.
WORD switchONListPSUs = 0;		// bits in TRUE are PSUs pending to be switched on

// Testing
extern BOOL testMode_SwitchOnCTRL_Task_FLAG;
extern WORD testMode_remainingPSUs[20];


//=====================================================================================================//
//================================    PSUs SWITCH ON/OFF METHODS    ===================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// switchONPSUs - Manages the complete PSU switching-on process for the selected PSUs: Initializes
//				its RAM values, changes its RDAC Register values, tells the switchONPSUsTask to
//				begin the delayed switching-on process.
//-------------------------------------------------------------------------------------------------------
void switchONPSUs(WORD selectedPSUs){
	powerONProcess=true;					// Beginning of the process

	initializeValuesPSUsSnIs();				// Load psuList values from RAM or set them to default

	updateVoltagePSUs( selectedPSUs );		// Sets the PSUs' potentiometers (RDACS) to the loaded/default values

	switchONPSUsTask( selectedPSUs );		// Task to initialize PSUs with certain delay (initializationTimer)

    powerONProcess=false;					// End of the process
}



//-------------------------------------------------------------------------------------------------------
// switchONPSUsTask - Task in charge of the PSUs' delayed switching-on process, connecting the relays
//					  when each PSU reaches its initializationTimer. When every PSU has been connected, the
//					  task is destroyed.
//-------------------------------------------------------------------------------------------------------
void switchONPSUsTask(WORD switchONListPSUs){
	powerONticks = 0;
	int psuNum;
	int aux=switchONListPSUs;
	while(switchONListPSUs){
		psuNum=0;
		aux=switchONListPSUs;
		for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
			if(aux & 0x0001){
				if(psuList[psuNum].initializationTimer <= powerONticks){
					switchONListPSUs-=(0x0001<<psuNum);
					psuList[psuNum].ReadyToConnect = true;
					connectPSU(psuNum);
					adjustRdac (psuNum, psuList[psuNum].progValue);
				}
			}
			aux=aux>>1;
		}

		if (testMode_SwitchOnCTRL_Task_FLAG){
			if (powerONticks<20){testMode_remainingPSUs[powerONticks] = switchONListPSUs;}
		}
		powerONticks++;
		OSTimeDly(TICKS_100MS);
	}
}

//-------------------------------------------------------------------------------------------------------
// connectPSU - Connects the selected PSU by switching its Rel� and activates its LED OUT
//-------------------------------------------------------------------------------------------------------
void connectPSU(int psuNum){
	connectRelay ( psuNum );
	// TODO: activar LED OUT ON. quiz� esperar alguna medida de tensi�n para asegurar que funciona
	psuList[psuNum].psuStatus=true;
	psuList[psuNum].ReadyToConnect=false;
}


//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSU's relay, updating its LED OUT, and sets its power to minimum
//-------------------------------------------------------------------------------------------------------
void disconnectPSU(int psuNum){
	psuList[psuNum].ReadyToConnect=false;
	disconnectRelay ( psuNum );
	psuList[psuNum].relayStatus=false;
	adjustRdac(psuNum, INITIAL_VOLTAGE);
	psuList[psuNum].psuStatus=false;
	// TODO: comprobar si se ha de desactivar  led Out On y si el voltaje se ha desconectado
}

//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSUs' relays, updating its LED OUT, and sets their power to minimum
//-------------------------------------------------------------------------------------------------------
void switchOFFPSUs(WORD selectedPSUs){
	disconnectRelaySeveral ( selectedPSUs );
	int psuNum;
	for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
		if(selectedPSUs & 0x0001){
			psuList[psuNum].ReadyToConnect=false;
			disconnectRelay ( psuNum );
			psuList[psuNum].relayStatus=false;
			adjustRdac(psuNum, INITIAL_VOLTAGE);
			psuList[psuNum].psuStatus=false;
		}
		selectedPSUs=selectedPSUs>>1;
	}
	// TODO: desactivar  led Out On. Comprobar el voltaje para asegurar que se ha desconectado
}
