/*
 * 	AuxiliaryCTRL.cpp
 *
 *	Definition of psuList and auxList.
 *	Default Values and printing methods for both
 *	Getters & Setters for both
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
*/

#include "Controller/Controller.h"
PSU_TYPE psuList[PSU_NUMBER];				// MAIN PSU ARRAY LIST
SnI_TYPE sniList[INT_VCC_n12V + 1];			// Supply & Internal voltages List


//=====================================================================================================//
//=================================    DATA LISTS' METHODS    =========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// defaultValuesPSU - Replaces the current PSU values in RAM by those predefined as DEFAULT in
//					file "defineConstants.cpp"
//-------------------------------------------------------------------------------------------------------
void defaultValuesPSU (int psuNum) {
	psuList[psuNum].relayStatus=DEFAULT_relayStatus_psu;
	psuList[psuNum].psuStatus=DEFAULT_psuStatus_psu;
	psuList[psuNum].progValue=DEFAULT_rdacValue_psu;
	BYTE i2CtoSPIAddress[12]= PSUs_I2C_ADDRESS_ARRAY;
	psuList[psuNum].bridgeI2CAdr=i2CtoSPIAddress[psuNum];
	psuList[psuNum].rdacAdr=(psuNum&0x1?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
	float auxArray0[4]=DEFAULT_alarmLimitValues_psu_pos;
	float auxArray1[4]=DEFAULT_alarmLimitValues_psu_neg;
	memcpy(psuList[psuNum].alarmLimitValues, (psuNum<=SF5_B?auxArray0:auxArray1), sizeof(psuList[psuNum].alarmLimitValues));
	int auxArray2[4]=DEFAULT_alarmLimitTimes_psu;
	memcpy(psuList[psuNum].alarmLimitTimes, auxArray2, sizeof(psuList[psuNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_alarmProtocols_psu;
	memcpy(psuList[psuNum].alarmProtocols, auxArray3, sizeof(psuList[psuNum].alarmProtocols));
	WORD k = demux4to16(psuNum+1);
	WORD auxArray4[4]={k, k, k, k};
	memcpy(psuList[psuNum].alarmProtocolShutdown, auxArray4, sizeof(psuList[psuNum].alarmProtocolShutdown));
	float auxArray5[4]=DEFAULT_alarmProtocolVoltage_psu;
	memcpy(psuList[psuNum].alarmProtocolVoltage, auxArray5, sizeof(psuList[psuNum].alarmProtocolVoltage));
	int auxArray6[4]=DEFAULT_alarmCounters_psu;
	memcpy(psuList[psuNum].alarmCounters, auxArray6, sizeof(psuList[psuNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_alarmStatus_psu;
	memcpy(psuList[psuNum].alarmStatus, auxArray7, sizeof(psuList[psuNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_alarmLimitReached_psu;
	memcpy(psuList[psuNum].alarmLimitReached, auxArray8, sizeof(psuList[psuNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_alarmWatch_psu;
	memcpy(psuList[psuNum].alarmWatch, auxArray9, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt = DEFAULT_rShunt_psu;
	psuList[psuNum].vOut = DEFAULT_vOut_psu;
	psuList[psuNum].cOut = DEFAULT_cOut_psu;
}


//-------------------------------------------------------------------------------------------------------
// printValuesPSU - prints by stdio all the values in RAM from the selected PSU
//-------------------------------------------------------------------------------------------------------
void printValuesPSU (int psuNum) {
	iprintf("\nPSU-NUMBER: %d\n", psuNum);
	iprintf("- relayStatus: %d\n",psuList[psuNum].relayStatus);
	iprintf("- psuStatus: %d\n",psuList[psuNum].psuStatus);
	iprintf("- rdacValue: %s\n",ftos(psuList[psuNum].progValue));
	iprintf("- bridgeI2CDir: 0x%x\n",psuList[psuNum].bridgeI2CAdr);
	iprintf("- rdacAdr: %d\n",psuList[psuNum].rdacAdr);
	iprintf("- alarmLimitValues:");printBuffer(psuList[psuNum].alarmLimitValues);
	iprintf("\n- alarmLimitTimes:");printBuffer(psuList[psuNum].alarmLimitTimes);
	iprintf("\n- alarmProtocols:");printBuffer(psuList[psuNum].alarmProtocols);
	iprintf("\n- alarmProtocolShutdown:");printBuffer(psuList[psuNum].alarmProtocolShutdown);
	iprintf("\n- alarmProtocolVoltage:");printBuffer(psuList[psuNum].alarmProtocolVoltage);
	iprintf("\n- alarmCounters:");printBuffer(psuList[psuNum].alarmCounters);
	iprintf("\n- alarmStatus:");printBuffer(psuList[psuNum].alarmStatus);
	iprintf("\n- alarmLimitReached:");printBuffer(psuList[psuNum].alarmLimitReached);
	iprintf("\n- alarmWatch:");printBuffer(psuList[psuNum].alarmWatch);
	iprintf("\n- rShunt: %d\n",psuList[psuNum].rShunt);
	iprintf("- vOut: %s\n",ftos(psuList[psuNum].vOut,4));
	iprintf("- cOut: %s\n",ftos(psuList[psuNum].cOut,4));

}


//-------------------------------------------------------------------------------------------------------
// defaultValuesSnI - Replaces the current SnI values in RAM by those predefined as DEFAULT in
//					file "defineConstants.cpp"
//-------------------------------------------------------------------------------------------------------
void defaultValuesSnI (int sniNum) {
	sniList[sniNum].sniStatus=DEFAULT_sniStatus_sni;
	float auxArray0[14]=DEFAULT_nominalVoltage_sni;
	sniList[sniNum].nominalVoltage=auxArray0[sniNum];
	sniList[sniNum].alarmLimitValues[0] = (sniList[sniNum].nominalVoltage>0?sniList[sniNum].nominalVoltage * SnI_INF_PERC_ALARM_VALUE:sniList[sniNum].nominalVoltage * SnI_SUP_PERC_ALARM_VALUE);
	sniList[sniNum].alarmLimitValues[1] = (sniList[sniNum].nominalVoltage>0?sniList[sniNum].nominalVoltage * SnI_SUP_PERC_ALARM_VALUE:sniList[sniNum].nominalVoltage * SnI_INF_PERC_ALARM_VALUE);
	sniList[sniNum].alarmLimitValues[2]	= 0;
	sniList[sniNum].alarmLimitValues[3]	= 0;
	int auxArray2[4]=DEFAULT_alarmLimitTimes_sni;
	memcpy(sniList[sniNum].alarmLimitTimes, auxArray2, sizeof(sniList[sniNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_alarmProtocols_sni;
	memcpy(sniList[sniNum].alarmProtocols, auxArray3, sizeof(sniList[sniNum].alarmProtocols));
	int auxArray4[4]=DEFAULT_alarmProtocolShutdown_sni;
	memcpy(sniList[sniNum].alarmProtocolShutdown, auxArray4, sizeof(sniList[sniNum].alarmProtocolShutdown));
	int auxArray6[4]=DEFAULT_alarmCounters_sni;
	memcpy(sniList[sniNum].alarmCounters, auxArray6, sizeof(sniList[sniNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_alarmStatus_sni;
	memcpy(sniList[sniNum].alarmStatus, auxArray7, sizeof(sniList[sniNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_alarmLimitReached_sni;
	memcpy(sniList[sniNum].alarmLimitReached, auxArray8, sizeof(sniList[sniNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_alarmWatch_sni;
	memcpy(sniList[sniNum].alarmWatch, auxArray9, sizeof(sniList[sniNum].alarmWatch));
	sniList[sniNum].vOut = DEFAULT_vOut_sni;
}


//-------------------------------------------------------------------------------------------------------
// printValuesAUX - prints by stdio all the values in RAM from the selected PSU
//-------------------------------------------------------------------------------------------------------
void printValuesSnI (int sniNum) {
	iprintf("SnI-Number: %d\n", sniNum);
	iprintf("- sniStatus: %d\n",sniList[sniNum].sniStatus);
	iprintf("- nominalVoltage: %s\n",ftos(sniList[sniNum].nominalVoltage));
	iprintf("- alarmLimitValues: ");printBuffer(sniList[sniNum].alarmLimitValues);
	iprintf("\n- alarmLimitTimes: ");printBuffer(sniList[sniNum].alarmLimitTimes);
	iprintf("\n- alarmProtocols: ");printBuffer(sniList[sniNum].alarmProtocols);
	iprintf("\n- alarmProtocolShutdown: ");printBuffer(sniList[sniNum].alarmProtocolShutdown);
	iprintf("\n- alarmCounters:  ");printBuffer(sniList[sniNum].alarmCounters);
	iprintf("\n- alarmStatus:  ");printBuffer(sniList[sniNum].alarmStatus);
	iprintf("\n- alarmLimitReached:  ");printBuffer(sniList[sniNum].alarmLimitReached);
	iprintf("\n- alarmWatch:  ");printBuffer(sniList[sniNum].alarmWatch);
	iprintf("\n- vOut: %s\n",ftos(sniList[sniNum].vOut,4));

}


//-------------------------------------------------------------------------------------------------------
// setters for PSU_TYPE variables
//-------------------------------------------------------------------------------------------------------
void setrelayStatusPSU(BOOLEAN rlSt, int psuNum){psuList[psuNum].relayStatus = rlSt;}
void setpsuStatusPSU(BOOLEAN psSt, int psuNum){psuList[psuNum].psuStatus = psSt;}
void setrdacValuePSU(float rdVal, int psuNum){psuList[psuNum].progValue = rdVal;}
void setrbridgeI2CAdrPSU(BYTE brAddr, int psuNum){psuList[psuNum].progValue = brAddr;}
void setrrdacAdrPSU(BYTE rdacAddr, int psuNum){psuList[psuNum].rdacAdr = rdacAddr;}
void setalarmLimitValuesPSU(float value, BOOLEAN inf_sup, BOOLEAN volt_corr, int psuNum){psuList[psuNum].alarmLimitValues[_(inf_sup, volt_corr)] = value;};
void setalarmLimitTimesPSU(int time, BOOLEAN inf_sup, BOOLEAN volt_corr, int psuNum){psuList[psuNum].alarmLimitTimes[_(inf_sup, volt_corr)] = time;};
void setalalarmProtocolsPSU(BOOLEAN protocol_flag, BOOLEAN inf_sup, BOOLEAN volt_corr, BYTE protocol, int psuNum){psuList[psuNum].alarmProtocols[__(inf_sup, volt_corr, protocol)] = protocol_flag;};
void setalarmProtocolShutdownPSU(WORD psus, BOOLEAN inf_sup, BOOLEAN volt_corr, int psuNum){psuList[psuNum].alarmProtocolShutdown[_(inf_sup, volt_corr)] = psus;};
void setalarmProtocolVoltagePSU(float voltage, BOOLEAN inf_sup, BOOLEAN volt_corr, int psuNum){psuList[psuNum].alarmProtocolVoltage[_(inf_sup, volt_corr)] = voltage;};
void setalarmWatchPSU(BOOLEAN alarm_flag, BOOLEAN inf_sup, BOOLEAN volt_corr, int psuNum){psuList[psuNum].alarmWatch[_(inf_sup, volt_corr)] = alarm_flag;};
void setrShuntPSU(int rSh, int psuNum){psuList[psuNum].rShunt = rSh;};



//-------------------------------------------------------------------------------------------------------
// setters for SnI_TYPE variables
//-------------------------------------------------------------------------------------------------------
void setsniStatusSnI(BOOLEAN snSt, int sniNum){sniList[sniNum].sniStatus = snSt;}
void setnominalVoltageSnI(float nomVal, int sniNum){sniList[sniNum].nominalVoltage = nomVal;}
void setalarmLimitValuesSnI(float value, BOOLEAN inf_sup, BOOLEAN volt_corr, int sniNum){sniList[sniNum].alarmLimitValues[_(inf_sup, volt_corr)] = value;};
void setalarmLimitTimesSnI(int time, BOOLEAN inf_sup, BOOLEAN volt_corr, int sniNum){sniList[sniNum].alarmLimitTimes[_(inf_sup, volt_corr)] = time;};
void setalalarmProtocolsSnI(BOOLEAN protocol_flag, BOOLEAN inf_sup, BOOLEAN volt_corr, BYTE protocol, int sniNum){sniList[sniNum].alarmProtocols[__(inf_sup, volt_corr, protocol)] = protocol_flag;};
void setalarmProtocolShutdownSnI(WORD snis, BOOLEAN inf_sup, BOOLEAN volt_corr, int sniNum){sniList[sniNum].alarmProtocolShutdown[_(inf_sup, volt_corr)] = snis;};
void setalarmWatchSnI(BOOLEAN alarm_flag, BOOLEAN inf_sup, BOOLEAN volt_corr, int sniNum){sniList[sniNum].alarmWatch[_(inf_sup, volt_corr)] = alarm_flag;};



//-------------------------------------------------------------------------------------------------------
// PSU_TYPE and SnI_TYPE getters
//-------------------------------------------------------------------------------------------------------
PSU_TYPE getPSU (int psuNum){return psuList[psuNum];}
SnI_TYPE getSnI( int sniNum ){return sniList[sniNum];}


//Object Setters - not in use
void setPSU (int psuNum, PSU_TYPE psu){	psuList[psuNum] = psu;}
void setSnI( int sniNum, SnI_TYPE sni){	sniList[sniNum] = sni;}
