/*
 * GeneralDISP.cpp
 *
 *  Created on: 21/05/2015
 *      Author: ALBERTO IBARRONDO
 */

#include "Display.h"

// Used for Keyboard
static char c;					// used for WAIT_FOR_KEYBOARD macro, and as auxiliary variable in certain functions
#define WAIT_FOR_KEYBOARD c = sgetchar(0);
char globalSelectionDISP='0';
char categorySelectionDISP='0';
#define EXIT 'e'


void DisplayMain ( void ){
	globalSelectionDISP='0';
	while (globalSelectionDISP!=EXIT){
		GeneralDisplayMenuDISP();
		categorySelectionDISP = '0';
		while (categorySelectionDISP!=EXIT){
			switch (globalSelectionDISP){
				case '1': StatusDISP(); processCommandProgram(); break;
				case '2': ProgramDISP(); processCommandStatus(); break;
				case '3': FunctionDISP(); processCommandFunction(); break;
				default:
					iprintf( "--------------------------------------------------------\r\n" );
					iprintf( "\nINVALID KEY -> %c\r\n", globalSelectionDISP);
					iprintf( " \r\nPRESS ANY KEY TO RETURN TO GENERAL MENU\r\n" );
					WAIT_FOR_KEYBOARD
					categorySelectionDISP=EXIT;
					break;
			}
		}
	}
}

void GeneralDisplayMenuDISP ( void ){
	iprintf( "\n\n\n\n\n\n");
	iprintf("========================================================\r\n" );
	iprintf("====================== GENERAL MENU ====================\r\n" );
	iprintf("========================================================\r\n" );
	iprintf(" (1) Status Display\r\n" );
	iprintf(" (2) Program Menu\r\n" );
	iprintf(" (3) Function Menu\r\n" );
	iprintf("--------------------------------------------------------\r\n" );
	iprintf("\r\nSelect menu number  \r\n" );
	globalSelectionDISP = sgetchar( 0 );
}


void StatusDISP ( void ){
	statusDisplayDISP();
	iprintf("\n (e) EXIT TO GENERAL MENU \r\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("\r\nEnter command \r\n" );
	categorySelectionDISP = sgetchar( 0 );
}

void ProgramDISP ( void ){
	iprintf( "\n\n\n\n\n\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("-------------------------------- PROGRAM MENU ---------------------------------\r\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("Power Supply Units (PSUs):\n" );
	iprintf(" (1) Switch ON/OFF\r\n" );
	iprintf(" (2) Change Output Voltage\r\n" );
	iprintf(" (3) Configure Alarms\r\n" );
	iprintf("Supply and Internal Voltages (SnIs):\n" );
	iprintf(" (4) Configure Alarms\n" );
	iprintf("\n (e) EXIT TO GENERAL MENU \r\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
		iprintf("\r\nEnter command \r\n" );
	categorySelectionDISP = sgetchar( 0 );
}

void FunctionDISP ( void ){
	iprintf( "\n\n\n\n\n\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("------------------------------- FUNCTION MENU ---------------------------------\r\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );

	iprintf("\n (e) EXIT TO GENERAL MENU \r\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("\r\nEnter command \r\n" );
	categorySelectionDISP = sgetchar( 0 );
}

