/*
 * ConfigCTRL.cpp
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */

#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List


//==============================================VARIABLES==============================================//
extern BOOL monitorSnIFLAG;					// Whether monitor Task is reading auxiliary voltages or
												//  just sticking in to PSUs' voltages
extern BOOL SnIAlarmUpdatingFLAG;

OS_SEM monitorSem;

BOOL samplingFLAG = true;

//=====================================================================================================//
//===================================    CONFIGURATION METHODS    =====================================//
//=====================================================================================================//

int monitorSemInit (void){
	return OSSemInit(& monitorSem,0);
}

void resetAlarmAuxiliaries (int Num, BOOL psu_sni){
	uint i;
	if (psu_sni == PSU_TYPE_LIST){
		for (i = 0; i<sizeof(psuList[Num].alarmCounters); i++){
			psuList[Num].alarmCounters[i]=0;
			psuList[Num].alarmStatus[i]=0;
			psuList[Num].alarmLimitReached[i]=0;
		}
	}
	else{
		for (i = 0; i<sizeof(sniList[Num].alarmCounters); i++){
			sniList[Num].alarmCounters[i]=0;
			sniList[Num].alarmStatus[i]=0;
			sniList[Num].alarmLimitReached[i]=0;
		}
	}
}

void toggleSampling ( BOOL samplFLAG ){
	samplingFLAG = samplFLAG;
}

void SnIAlarmUpdating ( BOOL sniUpdateFLAG ){
	SnIAlarmUpdatingFLAG = sniUpdateFLAG;
}

void toggleMonitorSnI ( BOOL monitorSnI ){
	monitorSnIFLAG = monitorSnI;
}
