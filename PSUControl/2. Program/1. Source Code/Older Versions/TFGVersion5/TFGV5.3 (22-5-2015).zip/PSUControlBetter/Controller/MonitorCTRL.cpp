/*
 * MonitorCTRL.cpp
 *
 *	Continuous sampling of all the PSUs (and auxiliaries, when properly set). To do so, the RTOS task
 *	waits for the interrupt to post on monitorSem (an OS_SEM), and then goes over the next loop.
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */


#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List

//==============================================VARIABLES==============================================//
// Imported
extern OS_SEM monitorSem;					// Semaphore where PIT1 Posts and monitorTask Pends.
extern BOOL maxAGCReached;					// AGC boolean that determines if the maximum gain has been reached

// A2D Sampling
int lastMeasure = 0;
BOOL lastMeasureValid = false;
BYTE samplingFunction = FUNCTION_READ_VOLTAGE;

// Configuration Flags
BOOL monitorSnIFLAG = true;	// Sets whether both Supply and Internal voltages are included in a2d routine loop or not

// Auxiliary
int Num = 0;
int a = 0;

BOOL prevMeas = false;

//=====================================================================================================//
//======================================    MONITOR METHODS    ========================================//
//=====================================================================================================//
void monitorTask (void* p){
	int ledAux = 0;
	BOOL ledFlag = false;
	while(1){	// loop forever
		OSSemPend( & monitorSem , 0 );
		lastMeasure = (ReadA2DResult(0) >> 3);
		lastMeasureValid = ((lastMeasure>MINIMUM_LEVEL_ADC) | maxAGCReached );

		if (lastMeasureValid){
			switch (samplingFunction){	//Store Value in the right object
				case FUNCTION_READ_VOLTAGE:
					psuList[Num].vOut= ((float)lastMeasure) / (4095.0) * 3.3 *getScaleFactorMUX()/getGainAGC();
					break;
				case FUNCTION_READ_CURRENT:
					psuList[Num].cOut= ((float)lastMeasure) / (4095.0) * 3.3 *getScaleFactorMUX()/getGainAGC();
					break;
				case FUNCTION_READ_SUPPLY_INTERNAL:
					sniList[Num].vOut= ((float)lastMeasure) / (4095.0) * 3.3 *getScaleFactorMUX()/getGainAGC();
					break;
			}
			minAGC();					// Set AGC always to minimum upon next voltage sampling

			// Next PSU, and next samplingFunction (see defineConstants.cpp - MUX) if last PSU reached
			Num++;
			if (monitorSnIFLAG){
				if( ((samplingFunction<=FUNCTION_READ_CURRENT) &&  (Num>=PSU_NUMBER)) || (Num>INT_VCC_n12V) ){
					Num = 0;
					// Next sampling function (restart if last function reached, cyclic)
					samplingFunction = (samplingFunction>=FUNCTION_READ_SUPPLY_INTERNAL?FUNCTION_READ_VOLTAGE:samplingFunction+1);
				}
			}
			else{
				if (Num >= PSU_NUMBER){
					Num = 0;
					samplingFunction = !samplingFunction; 	// Toggle between FUNCTION_READ_VOLTAGE (0) and FUNCTION_READ_CURRENT(1)
				}										  	//  functions (see defineConstants.cpp - MUX)
			}
			setMUX( samplingFunction, (BYTE)Num );	// Set muxes for next reading
		}
		else{
			changeGainAGC(MIDSCALE_ADC/lastMeasure);
		}
		//printf("-LM=0x%x  Num=%d  Sampling =%d SCALEMUX=%.2f  SCALEAGC=%.2f   VALUE=%.2f\n", lastMeasure, Num, samplingFunction, getScaleFactorMUX(), getGainAGC(), ((float)lastMeasure) / (4095.0) * 3.3 *getScaleFactorMUX()/getGainAGC());
		ledAux++;
		if (ledAux>=500){
			ledAux =0;
			Pins[27] = ledFlag;
			ledFlag = !ledFlag;
		}
	}
}
