/*
 * Test_Controller.cpp
 *
 *  Created on: 20/05/2015
 *      Author: ALBERTO IBARRONDO
 */


#include "Tests.h"


//==============================================VARIABLES==============================================//
//---------Imported from generalTEST.cpp
// Imported Arrays
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List

// Results
extern BYTE result1; extern BYTE result2; extern BYTE result3; extern BYTE result4; extern BYTE result5;
extern BYTE result6; extern BYTE result7; extern BYTE result8; extern BYTE result9; extern BYTE result10;
extern BYTE resultTotal;




//=====================================================================================================//
//================================    Controller Testing METHODS    ===================================//
//=====================================================================================================//


//-----------------------------------------------------------------------------------------------------//
//---------------------------------------   GLOBAL TESTS    -------------------------------------------//
//-----------------------------------------------------------------------------------------------------//

BOOL TEST_AlarmCTRL( void ){
	OSLockObj lock;//LOCK to avoid changes in vOut and cOut by monitorTask()
	iprintf("\n\n\n\n===============TEST_AlarmCTRL===============\n");

	//PSU
	TEST_AlarmCTRL_PSU1();
	TEST_AlarmCTRL_PSU2();
	TEST_AlarmCTRL_PSU3();
	TEST_AlarmCTRL_PSU4();

	//SnI
	TEST_AlarmCTRL_SnI1();
	TEST_AlarmCTRL_SnI2();
	TEST_AlarmCTRL_SnI3();

	//Results
	iprintf("\n TEST_AlarmCTRL\n");
	iprintf("\n PART 1 - PSU Inferior Voltage Alarm Triggered with no time\n");
	iprintf(" ~result1: %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf("\n PART 1 - PSU No false alarms \n");
	iprintf(" ~result2: %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - PSU Superior Voltage Alarm Triggering with 3 times. \n");
	iprintf(" ~result3: %s\n", (result3?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - PSU No false alarms\n");
	iprintf(" ~result4: %s\n", (result4?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - PSU Inferior Current Alarm Triggering with 2 times and Disconnection.\n");
	iprintf(" ~result5: %s\n", (result5?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - PSU No false alarms\n");
	iprintf(" ~result6: %s\n", (result6?"PASSED":"NOT PASSED"));
	iprintf("\n PART 4 - PSU Multiple Alarm Triggering for Upper Current\n");
	iprintf(" ~result7: %s\n", (result7?"PASSED":"NOT PASSED"));
	iprintf("\n PART 5 - SnI Inferior Voltage Alarm Triggering with no time. \n");
	iprintf(" ~result8: %s\n", (result8?"PASSED":"NOT PASSED"));
	iprintf("\n PART 6 - SnI Superior Voltage Alarm Triggering with 3/2 times. \n");
	iprintf(" ~result9: %s\n", (result9?"PASSED":"NOT PASSED"));
	iprintf("\n PART 4 - SnI Multiple Alarm Triggering for Upper Voltage\n");
	iprintf(" ~result10: %s\n", (result10?"PASSED":"NOT PASSED"));
	resultTotal = (result1&&result2&&result3&&result4&&result5&&result6&&result7&&result8&&result9&&result10);
	iprintf("\n OVERALL RESULT: %s\n", (resultTotal?"PASSED":"NOT PASSED"));
	return resultTotal;
}


BOOL TEST_FlashMemCTRL( void ){
	// NOTE: all the printValues() methods are commented. In case of any error, toggle comment to analyze it.
	iprintf("\n\n\n\n===============TEST_FlashMemCTRL===============\n");

	//PSU
	TEST_FlashMemCTRL_PSU();

	//SnI
	TEST_FlashMemCTRL_SnI();

	//Results
	iprintf("\n TEST_FlashMemCTRL\n");
	iprintf("\n PART 1 - Setting default Values and saving values for PSUs\n");
	iprintf(" ~result1: %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Restore Saved Values for PSUs\n");
	iprintf(" ~result2: %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Empty values aren't corrupted for PSUs\n");
	iprintf(" ~result3: %s\n", (result3?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - Initializing Values, previous data ain't corrupted for PSUs\n");
	iprintf(" ~result4: %s\n", (result4?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - Initializing Values, empty values are correctly filled for PSUs\n");
	iprintf(" ~result5: %s\n", (result5?"PASSED":"NOT PASSED"));
	iprintf("\n PART 4 - Setting default Values and saving values for SnIs\n");
	iprintf(" ~result6: %s\n", (result6?"PASSED":"NOT PASSED"));
	iprintf("\n PART 5 - Restore Saved Values for SnIs\n");
	iprintf(" ~result7: %s\n", (result7?"PASSED":"NOT PASSED"));
	iprintf("\n PART 5 - Empty values aren't corrupted for SnIs\n");
	iprintf(" ~result8: %s\n", (result8?"PASSED":"NOT PASSED"));
	iprintf("\n PART 6 - Initializing Values, previous data ain't corrupted for SnIs\n");
	iprintf(" ~result9: %s\n", (result9?"PASSED":"NOT PASSED"));
	iprintf("\n PART 6 - Initializing Values, empty values are correctly filled for SnIs\n");
	iprintf(" ~result10: %s\n", (result10?"PASSED":"NOT PASSED"));
	resultTotal = (result1&&result2&&result3&&result4&&result5&&result6&&result7&&result8&&result9&&result10);
	iprintf("\n OVERALL RESULT: %s\n", (resultTotal?"PASSED":"NOT PASSED"));
	return resultTotal;
}






BOOL TEST_DataListsCTRL( void ){
	iprintf("\n\n\n\n===============TEST_DataListsCTRL===============\n");
	iprintf("\n\n\n\n1. Setting DEFAULT Values for PSUs 1, 4 (both positive) and 10 (negative)\n");
	defaultValuesPSU(1);
	defaultValuesPSU(4);
	defaultValuesPSU(11);
	printValuesPSU(1);
	printValuesPSU(4);
	printValuesPSU(11);
	//Check Values
	result1 = (getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1));
	result2 = (getPSU(1).alarmProtocolShutdown[0] == demux4to16(1+1));
	result3 = (getPSU(11).alarmProtocolShutdown[0] == demux4to16(11+1));
	//end Check Values
	iprintf(" Saved Value (1) = %d (should be %d)\n", getPSU(1).alarmProtocolShutdown[0], demux4to16(1+1));
	iprintf(" Saved Value (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	iprintf("\n\n\n\n2. Setting DEFAULT Values for SnIs 1 and 4\n");
	defaultValuesSnI(1);
	defaultValuesSnI(4);
	defaultValuesSnI(13);
	printValuesSnI(1);
	printValuesSnI(4);
	printValuesSnI(13);
	//Check Values
	result4 = ((getSnI(4).alarmLimitValues[0] < getSnI(4).nominalVoltage) && (getSnI(4).alarmLimitValues[1] > getSnI(4).nominalVoltage));
	result5 = ((getSnI(1).alarmLimitValues[0] < getSnI(1).nominalVoltage) && (getSnI(1).alarmLimitValues[1] > getSnI(1).nominalVoltage));
	result6 = ((getSnI(13).alarmLimitValues[0] < getSnI(13).nominalVoltage) && (getSnI(13).alarmLimitValues[1] > getSnI(13).nominalVoltage));
	// end Check Values
	iprintf("\n\n\n\n\n TEST_DataListsCTRL\n");
	iprintf("\n PART 1 - Setting default Values to PSUs\n");
	iprintf(" ~result1(PSU 4): %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf(" ~result2(PSU 1): %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf(" ~result3(PSU 11): %s\n", (result3?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Setting default Values to SnIs\n");
	iprintf(" ~result4(SnI 4): %s\n", (result4?"PASSED":"NOT PASSED"));
	iprintf(" ~result5(SnI 1): %s\n", (result5?"PASSED":"NOT PASSED"));
	iprintf(" ~result6(SnI 13): %s\n", (result6?"PASSED":"NOT PASSED"));
	result7 = (result1&&result2&&result3&&result4&&result5&&result6);
	iprintf("\n OVERALL RESULT: %s\n", (result6?"PASSED":"NOT PASSED"));
	return result6;
}





//-----------------------------------------------------------------------------------------------------//
//-------------------------------------   PARTIAL TESTS    --------------------------------------------//
//-----------------------------------------------------------------------------------------------------//



void TEST_FlashMemCTRL_PSU (void){
	iprintf("\n\n\n\n1. Setting default Values for PSUs 1 and 4, and saving values\n");
	defaultValuesPSU(1);
	defaultValuesPSU(4);
//	printValuesPSU(1);
//	printValuesPSU(4);
	getPSU(5).alarmProtocolShutdown[0] = 0;
	saveInFlashValuesPSUsSNIs();
	result1 = (getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1)) && (getPSU(1).alarmProtocolShutdown[0] == demux4to16(1+1));
	iprintf(" Saved alarmProtocolShutdown (1) = %d (should be %d)\n", getPSU(1).alarmProtocolShutdown[0], demux4to16(1+1));
	iprintf(" Saved alarmProtocolShutdown (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	printf("\n\n\n\n2. Loading Values and checking for data validity\n");
	getPSU(4).alarmProtocolShutdown[0] = 0;
	getPSU(5).alarmProtocolShutdown[0] = 2;
	loadFlashValuesPSUs();
//	printValuesPSU(5);
//	printValuesPSU(4);
	result2 = getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1);
	result3 = getPSU(5).alarmProtocolShutdown[0] == 0;
	iprintf(" Loaded alarmProtocolShutdown (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	iprintf(" Loaded alarmProtocolShutdown (5) = %d (should be %d)\n", getPSU(5).alarmProtocolShutdown[0], 0);
	iprintf("\n\n\n\n3. Initializing Values, printing PSUs 4 and 5, and checking for data validity\n");
	getPSU(4).alarmProtocolShutdown[0] = 0;
	getPSU(5).alarmProtocolShutdown[0] = 0;
	initializeValuesPSUsSnIs();
//	printValuesPSU(4);
//	printValuesPSU(5);
	result4 = getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1);
	result5 = getPSU(5).alarmProtocolShutdown[0] == demux4to16(5+1);
	iprintf(" Initialized alarmProtocolShutdown (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	iprintf(" Initialized alarmProtocolShutdown (5) = %d (should be %d)\n", getPSU(5).alarmProtocolShutdown[0], demux4to16(5+1));
}


void TEST_FlashMemCTRL_SnI(void){
	iprintf("\n\n\n\n4. Setting default Values for SnIs 4 and 13, and saving values\n");
	defaultValuesSnI(13);
	defaultValuesSnI(4);
	sniList[5].nominalVoltage = 0;
	saveInFlashValuesPSUsSNIs();
//	printValuesSnI(4);
//	printValuesSnI(5);
//	printValuesSnI(13);
	iprintf(" Saved InfVoltValue(4) = %s ", ftos(getSnI(4).alarmLimitValues[0]));iprintf("(should be < %s)\n", ftos(getSnI(4).nominalVoltage));
	iprintf(" Saved SupVoltValue(4) = %s ", ftos(getSnI(4).alarmLimitValues[1]));iprintf("(should be > %s)\n", ftos(getSnI(4).nominalVoltage));
	iprintf(" Saved InfVoltValue(13) = %s ", ftos(getSnI(13).alarmLimitValues[0]));iprintf("(should be < %s)\n", ftos(getSnI(13).nominalVoltage));
	iprintf(" Saved SupVoltValue(13) = %s ", ftos(getSnI(13).alarmLimitValues[1]));iprintf("(should be > %s)\n", ftos(getSnI(13).nominalVoltage));
	iprintf(" Saved nominalVoltage(5) = %s (should be 0)\n", ftos(getSnI(5).nominalVoltage));
	//Check Values
	result6 = ((getSnI(4).alarmLimitValues[0] < getSnI(4).nominalVoltage) && (getSnI(4).alarmLimitValues[1] > getSnI(4).nominalVoltage)) && ((getSnI(13).alarmLimitValues[0] < getSnI(13).nominalVoltage) && (getSnI(13).alarmLimitValues[1] > getSnI(13).nominalVoltage));
	//end Check Values
	iprintf("\n\n\n\n5. Loading Values and checking for data validity\n");
	getSnI(4).nominalVoltage = 0;
	getSnI(5).nominalVoltage = 2;
	loadFlashValuesSNIs();
//	printValuesSnI(4);
//	printValuesSnI(5);
	iprintf(" Loaded nominalVoltage(4) = %s (should be > 0)\n", ftos(getSnI(4).nominalVoltage));
	iprintf(" Loaded nominalVoltage(13) = %s (should be < 0)\n", ftos(getSnI(13).nominalVoltage));
	iprintf(" Loaded nominalVoltage(5) = %s (should be 0)\n", ftos(getSnI(5).nominalVoltage));
	//Check Values
	result7 = (getSnI(4).nominalVoltage != 0) && (getSnI(13).nominalVoltage != 0);
	result8 = getSnI(5).nominalVoltage == 0;
	//end Check Values
	printf("\n\n\n\n6. Initializing Values, printing SnIs 4 and 5, and checking for data validity\n");
	getSnI(4).nominalVoltage = 0;
	getSnI(5).nominalVoltage = 0;
	initializeValuesPSUsSnIs();
//	printValuesSnI(4);
//	printValuesSnI(5);
	iprintf(" Initialized nominalVoltage(4) = %s (should be > 0)\n", ftos(getSnI(4).nominalVoltage));
	iprintf(" Initialized nominalVoltage(13) = %s (should be < 0)\n", ftos(getSnI(13).nominalVoltage));
	iprintf(" Initialized nominalVoltage(5) = %s (should be > 0)\n", ftos(getSnI(5).nominalVoltage));
	//Check Values
	result9 = (getSnI(4).nominalVoltage > 0) && (getSnI(13).nominalVoltage < 0);
	result10 = (getSnI(5).nominalVoltage > 0 );
	//end Check Values
}


void TEST_AlarmCTRL_PSU1( void ){
	iprintf("\n\n\n\n1. Inferior Voltage Alarm Triggering with no time. PSU 1 should be triggered, 4 shouldn't\n");
	defaultValuesPSU(1);
	defaultValuesPSU(4);
	setalarmLimitTimesPSU(0, INFERIOR, VOLTAGE, 1);
	setalarmLimitTimesPSU(0, INFERIOR, VOLTAGE, 4);
	setalarmWatchPSU(ON, INFERIOR, VOLTAGE, 1);
	setalarmWatchPSU(ON, INFERIOR, VOLTAGE, 4);
	// Simulating a value lower than 13 (default inferior limit) for voltage
	psuList[1].vOut = 12;
	psuList[4].vOut = 14;
	alarmCheck(1,INFERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(4,INFERIOR,VOLTAGE,PSU_TYPE_LIST);
	iprintf(" First comparison (v1 = 12, v4 =14, vLLim=13\n");
	iprintf(" alarmStatus (1) = %s (should be TRUE)(AC = %d)\n", (getPSU(1).alarmStatus[_(INFERIOR,VOLTAGE)]?"TRUE":"FALSE"), getPSU(1).alarmCounters[_(INFERIOR,VOLTAGE)]);
	iprintf(" alarmStatus (4) = %s (should be FALSE)(AC = %d)\n", (getPSU(4).alarmStatus[_(INFERIOR,VOLTAGE)]?"TRUE":"FALSE"), getPSU(4).alarmCounters[_(INFERIOR,VOLTAGE)]);
	result1 = getPSU(1).alarmStatus[_(INFERIOR,VOLTAGE)] == true;
	result2 = getPSU(4).alarmStatus[_(INFERIOR,VOLTAGE)] == false;
	// Simulating a value higher than 13 for voltage
	psuList[1].vOut = 14;
	alarmCheck(1,INFERIOR,VOLTAGE,PSU_TYPE_LIST);
	iprintf(" alarmStatus (1) = %s (should be FALSE)(AC = %d)\n", (getPSU(1).alarmStatus[_(INFERIOR,VOLTAGE)]?"TRUE":"FALSE"), getPSU(1).alarmCounters[_(INFERIOR,VOLTAGE)]);
	result1 &= getPSU(1).alarmStatus[_(INFERIOR,VOLTAGE)] == false;
	result2 &= getPSU(4).alarmStatus[_(INFERIOR,VOLTAGE)] == false;
	setalarmWatchPSU(OFF, INFERIOR, VOLTAGE, 1);
	setalarmWatchPSU(OFF, INFERIOR, VOLTAGE, 4);
}


void TEST_AlarmCTRL_PSU2( void ){
	iprintf("\n\n\n\n2. Superior Voltage Alarm Triggering with 3 times. PSU 1 should be triggered, 4 shouldn't\n");
	resetAlarms((demux4to16(1)|demux4to16(4)), ALL_ALARMS_BYTE, PSU_TYPE_LIST);
	setalarmLimitTimesPSU(3, SUPERIOR, VOLTAGE, 1);
	setalarmLimitTimesPSU(3, SUPERIOR, VOLTAGE, 4);
	setalarmWatchPSU(ON, SUPERIOR, VOLTAGE, 1);
	setalarmWatchPSU(ON, SUPERIOR, VOLTAGE, 4);
	// Simulating a value higher than 18 (default superior limit) for voltage
	psuList[1].vOut = 18;
	psuList[4].vOut = 15;
	alarmCheck(1,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	iprintf(" First comparison (v1 = 18, v4 =15, vULim=17\n");
	iprintf(" alarmStatus (1) = %s (should be FALSE)(AC = %d)\n", (getPSU(1).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getPSU(1).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	iprintf(" alarmStatus (4) = %s (should be FALSE)(AC = %d)\n", (getPSU(4).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getPSU(4).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	result3 = getPSU(1).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	result4 = getPSU(4).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	alarmCheck(1,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	result3 &= getPSU(1).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	result4 &= getPSU(4).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	alarmCheck(1,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	iprintf(" Third comparison (v1 = 18, v4 =15, vULim=17\n");
	iprintf(" alarmStatus (1) = %s (should be TRUE)(AC = %d)\n", (getPSU(1).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getPSU(1).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	iprintf(" alarmStatus (4) = %s (should be FALSE)(AC = %d)\n", (getPSU(4).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getPSU(4).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	result3 &= getPSU(1).alarmStatus[_(SUPERIOR,VOLTAGE)] == true;
	result4 &= getPSU(4).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	// Simulating a value lower than 18 for voltage
	alarmCheck(1,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	result3 &= getPSU(1).alarmCounters[_(SUPERIOR,VOLTAGE)] == getPSU(1).alarmLimitTimes[_(SUPERIOR,VOLTAGE)];
	psuList[1].vOut = 16;
	alarmCheck(1,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	iprintf(" Fourth comparison (v1 = 16, v4 =15, vULim=17\n");
	iprintf(" alarmStatus (1) = %s (should be TRUE)(AC = %d)\n", (getPSU(1).alarmStatus[_(INFERIOR,VOLTAGE)]?"TRUE":"FALSE"), getPSU(1).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	result3 &= getPSU(1).alarmStatus[_(SUPERIOR,VOLTAGE)] == true;
	result4 &= getPSU(4).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	alarmCheck(1,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(1,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	iprintf(" Sixth comparison (v1 = 16, v4 =15, vULim=17\n");
	iprintf(" alarmStatus (1) = %s (should be FALSE)(AC = %d)\n", (getPSU(1).alarmStatus[_(INFERIOR,VOLTAGE)]?"TRUE":"FALSE"), getPSU(1).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	result3 &= getPSU(1).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	result4 &= getPSU(4).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	setalarmWatchPSU(OFF, SUPERIOR, VOLTAGE, 1);
	setalarmWatchPSU(OFF, SUPERIOR, VOLTAGE, 4);
}


void TEST_AlarmCTRL_PSU3( void ){
	iprintf("\n\n\n\n3. Inferior Current Alarm Triggering with 2 times and Disconnection. PSU 1 should be triggered, 4 shouldn't\n");
	resetAlarms((demux4to16(1)|demux4to16(4)), ALL_ALARMS_BYTE, PSU_TYPE_LIST);
	setalarmLimitTimesPSU(3, INFERIOR, CURRENT, 1);
	setalarmLimitTimesPSU(3, INFERIOR, CURRENT, 4);
	setalarmWatchPSU(ON, INFERIOR, CURRENT, 1);
	setalarmWatchPSU(ON, INFERIOR, CURRENT, 4);
	// Simulating a value lower than 0.3 (default superior limit) for voltage
	psuList[1].cOut = 0.15;
	psuList[4].cOut = 0.7;
	alarmCheck(1,INFERIOR, CURRENT,PSU_TYPE_LIST);
	alarmCheck(4,INFERIOR, CURRENT,PSU_TYPE_LIST);
	iprintf(" First comparison (c1 = 0.15, c4 =0.7, cLLim=0.3\n");
	iprintf(" alarmStatus (1) = %s (should be FALSE)(AC = %d)\n", (getPSU(1).alarmStatus[_(INFERIOR, CURRENT)]?"TRUE":"FALSE"), getPSU(1).alarmCounters[_(INFERIOR, CURRENT)]);
	iprintf(" alarmStatus (4) = %s (should be FALSE)(AC = %d)\n", (getPSU(4).alarmStatus[_(INFERIOR, CURRENT)]?"TRUE":"FALSE"), getPSU(4).alarmCounters[_(INFERIOR, CURRENT)]);
	result5 = getPSU(1).alarmStatus[_(INFERIOR, CURRENT)] == false;
	result6 = getPSU(4).alarmStatus[_(INFERIOR, CURRENT)] == false;
	iprintf(" Second comparison (c1 = 0.15, c4 =0.7, cLLim=0.3\n");
	iprintf(" alarmStatus (1) = %s (should be TRUE)(AC = %d)\n", (getPSU(1).alarmStatus[_(INFERIOR, CURRENT)]?"TRUE":"FALSE"), getPSU(1).alarmCounters[_(INFERIOR, CURRENT)]);
	iprintf(" alarmStatus (4) = %s (should be FALSE)(AC = %d)\n", (getPSU(4).alarmStatus[_(INFERIOR, CURRENT)]?"TRUE":"FALSE"), getPSU(4).alarmCounters[_(INFERIOR, CURRENT)]);
	result5 &= getPSU(1).alarmStatus[_(INFERIOR, CURRENT)] == true;
	result6 &= getPSU(4).alarmStatus[_(INFERIOR, CURRENT)] == false;
	alarmCheck(1,INFERIOR, CURRENT,PSU_TYPE_LIST);
	result5 = getPSU(1).alarmCounters[_(INFERIOR, CURRENT)] == getPSU(1).alarmLimitTimes[_(INFERIOR, CURRENT)];
	setalarmWatchPSU(OFF, INFERIOR, CURRENT, 1);
	setalarmWatchPSU(OFF, INFERIOR, CURRENT, 4);
	alarmCheck(1,INFERIOR, CURRENT,PSU_TYPE_LIST);
	alarmCheck(4,INFERIOR, CURRENT,PSU_TYPE_LIST);
	iprintf(" Third comparison (c1 = 0.15, c4 =0.7, cLLim=0.3) - Disconnecting\n");
	iprintf(" alarmStatus (1) = %s (should be FALSE)(AC = %d)\n", (getPSU(1).alarmStatus[_(INFERIOR, CURRENT)]?"TRUE":"FALSE"), getPSU(1).alarmCounters[_(INFERIOR, CURRENT)]);
	iprintf(" alarmStatus (4) = %s (should be FALSE)(AC = %d)\n", (getPSU(4).alarmStatus[_(INFERIOR, CURRENT)]?"TRUE":"FALSE"), getPSU(4).alarmCounters[_(INFERIOR, CURRENT)]);
	result5 &= getPSU(1).alarmStatus[_(INFERIOR, CURRENT)] == false;
	result6 &= getPSU(4).alarmStatus[_(INFERIOR, CURRENT)] == false;
}


void TEST_AlarmCTRL_PSU4( void ){
	iprintf("\n\n\n\n4. Multiple Alarm Triggering for Upper Current with 2 times and Disconnection. All PSUs triggered. Using updateAlarms()\n");
	int i;
	resetAlarms(ALL_PSUS_WORD, ALL_ALARMS_BYTE, PSU_TYPE_LIST);
	for (i=0;i<PSU_NUMBER;i++){
		psuList[i].psuStatus=ON;
		psuList[i].cOut = i+3.5; // >3 (Default Upper Current Limit)
		psuList[i].vOut = i+17.5;// >17 (Default Upper Voltage Limit)
		psuList[i].alarmWatch[_(SUPERIOR, CURRENT)]=ON;	 // Should be triggered
		psuList[i].alarmWatch[_(INFERIOR, CURRENT)]=OFF;
		psuList[i].alarmWatch[_(INFERIOR, VOLTAGE)]=OFF;
		psuList[i].alarmWatch[_(SUPERIOR, VOLTAGE)]=OFF; //Shouldn't be triggered
		psuList[i].alarmLimitTimes[_(SUPERIOR, CURRENT)]=2;	 // Should be triggered
		psuList[i].alarmLimitTimes[_(INFERIOR, CURRENT)]=2;
		psuList[i].alarmLimitTimes[_(INFERIOR, VOLTAGE)]=2;
		psuList[i].alarmLimitTimes[_(SUPERIOR, VOLTAGE)]=2; //Shouldn't be triggered
	}
	updateAlarms();
	result7 = true;
	iprintf ("First time (all to 0): {");
	for (i=0;i<PSU_NUMBER;i++){
		result7 &= (psuList[i].alarmStatus[_(SUPERIOR, CURRENT)] == false) && (psuList[i].alarmCounters[_(SUPERIOR, CURRENT)]==1);
		result7 &= (psuList[i].alarmStatus[_(SUPERIOR, VOLTAGE)] == false) && (psuList[i].alarmCounters[_(SUPERIOR, VOLTAGE)]==0);
		iprintf (" %d,", psuList[i].alarmStatus[_(SUPERIOR, CURRENT)]);
	}
	iprintf ("}\n");
	iprintf ("Second time (all to 1): {");
	updateAlarms();
	for (i=0;i<PSU_NUMBER;i++){
		result7 &= (psuList[i].alarmStatus[_(SUPERIOR, CURRENT)] == true) && (psuList[i].alarmCounters[_(SUPERIOR, CURRENT)]==2);
		result7 &= (psuList[i].alarmStatus[_(SUPERIOR, VOLTAGE)] == false) && (psuList[i].alarmCounters[_(SUPERIOR, VOLTAGE)]==0);
		iprintf (" %d,", psuList[i].alarmStatus[_(SUPERIOR, CURRENT)]);
	}
	iprintf ("}\n");
	resetAlarms(ALL_PSUS_WORD, ALL_ALARMS_BYTE, PSU_TYPE_LIST);
}


void TEST_AlarmCTRL_SnI1( void ){
	iprintf("\n\n\n\n5. Inferior Voltage Alarm Triggering with no time. SnI 13 should be triggered, 4 shouldn't\n");
	defaultValuesSnI(13);
	defaultValuesSnI(4);
	setalarmLimitTimesSnI(0, INFERIOR, VOLTAGE, 13);
	setalarmLimitTimesSnI(0, INFERIOR, VOLTAGE, 4);
	setalarmWatchSnI(ON, INFERIOR, VOLTAGE, 13);
	setalarmWatchSnI(ON, INFERIOR, VOLTAGE, 4);
	// Simulating a value lower than -15 (default inferior limit for sni 13) for voltage
	sniList[13].vOut = -15;
	psuList[4].vOut = 16;
	alarmCheck(13,INFERIOR,VOLTAGE,SnI_TYPE_LIST);
	alarmCheck(4,INFERIOR,VOLTAGE,SnI_TYPE_LIST);
	iprintf(" First comparison (v13 = -15 (-14), v4 =16(16))\n");
	iprintf(" alarmStatus (13) = %s (should be TRUE)(AC = %d)\n", (getSnI(13).alarmStatus[_(INFERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(13).alarmCounters[_(INFERIOR,VOLTAGE)]);
	iprintf(" alarmStatus (4) = %s (should be FALSE)(AC = %d)\n", (getSnI(4).alarmStatus[_(INFERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(4).alarmCounters[_(INFERIOR,VOLTAGE)]);
	result8 = (getSnI(13).alarmStatus[_(INFERIOR,VOLTAGE)] == true) && (getSnI(4).alarmStatus[_(INFERIOR,VOLTAGE)] == false);
	// Simulating a value higher than -14 for voltage
	sniList[13].vOut = -12;
	alarmCheck(1,INFERIOR,VOLTAGE,SnI_TYPE_LIST);
	iprintf(" alarmStatus (13) = %s (should be FALSE)(AC = %d)\n", (getSnI(13).alarmStatus[_(INFERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(13).alarmCounters[_(INFERIOR,VOLTAGE)]);
	result8 &= getSnI(13).alarmStatus[_(INFERIOR,VOLTAGE)] == false;
	result8 &= getSnI(4).alarmStatus[_(INFERIOR,VOLTAGE)] == false;
	setalarmWatchSnI(OFF, INFERIOR, VOLTAGE, 13);
	setalarmWatchSnI(OFF, INFERIOR, VOLTAGE, 4);
}


void TEST_AlarmCTRL_SnI2( void ){
	iprintf("\n\n\n\n6. Superior Voltage Alarm Triggering with 3/2 times. Both should be triggered\n");
	resetAlarms((demux4to16(13)|demux4to16(4)), ALL_ALARMS_BYTE, SnI_TYPE_LIST);
	setalarmLimitTimesSnI(3, SUPERIOR, VOLTAGE, 13);
	setalarmLimitTimesSnI(2, SUPERIOR, VOLTAGE, 4);
	setalarmWatchSnI(ON, SUPERIOR, VOLTAGE, 13);
	setalarmWatchSnI(ON, SUPERIOR, VOLTAGE, 4);
	// Simulating a value higher than -10 (default superior limit) for voltage
	sniList[13].vOut = -5;
	sniList[4].vOut = 25;
	alarmCheck(13,SUPERIOR,VOLTAGE,SnI_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,SnI_TYPE_LIST);
	iprintf(" First comparison (v13 = -5(-10), v4 =25(18))\n");
	iprintf(" alarmStatus (1) = %s (should be FALSE)(AC = %d)\n", (getSnI(13).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(13).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	iprintf(" alarmStatus (4) = %s (should be FALSE)(AC = %d)\n", (getSnI(4).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(4).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	result9 = (getSnI(13).alarmStatus[_(SUPERIOR,VOLTAGE)] == false) && (getSnI(4).alarmStatus[_(SUPERIOR,VOLTAGE)] == false);
	alarmCheck(13,SUPERIOR,VOLTAGE,SnI_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,SnI_TYPE_LIST);
	result9 &= getSnI(13).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	result9 &= getSnI(4).alarmStatus[_(SUPERIOR,VOLTAGE)] == true;
	alarmCheck(13,SUPERIOR,VOLTAGE,SnI_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,SnI_TYPE_LIST);
	iprintf(" Third comparison (v13 = -5(-10), v4 =25(18))\n");
	iprintf(" alarmStatus (13) = %s (should be TRUE)(AC = %d)\n", (getSnI(13).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(13).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	iprintf(" alarmStatus (4) = %s (should be TRUE)(AC = %d)\n", (getSnI(4).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(4).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	result9 &= getSnI(13).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	result9 &= getSnI(4).alarmStatus[_(SUPERIOR,VOLTAGE)] == true;
	// Simulating a value lower than 18 for voltage
	alarmCheck(1,SUPERIOR,VOLTAGE,SnI_TYPE_LIST);
	result9 &= getSnI(1).alarmCounters[_(SUPERIOR,VOLTAGE)] == getSnI(1).alarmLimitTimes[_(SUPERIOR,VOLTAGE)];
	sniList[13].vOut = -12;
	setalarmWatchSnI(OFF, SUPERIOR, VOLTAGE, 4);
	alarmCheck(13,SUPERIOR,VOLTAGE,SnI_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,SnI_TYPE_LIST);
	iprintf(" Fourth comparison (v13 = -12(-10), v4 =25(18))\n");
	iprintf(" alarmStatus (13) = %s (should be TRUE)(AC = %d)\n", (getSnI(13).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(13).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	iprintf(" alarmStatus (4) = %s (should be FALSE)(AC = %d)\n", (getSnI(4).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(4).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	result9 &= getSnI(13).alarmStatus[_(SUPERIOR,VOLTAGE)] == true;
	result9 &= getSnI(4).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	alarmCheck(1,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(1,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	alarmCheck(4,SUPERIOR,VOLTAGE,PSU_TYPE_LIST);
	iprintf(" Sixth comparison (v13 = -12(-10), v4 =25(18))\n");
	iprintf(" alarmStatus (13) = %s (should be FALSE)(AC = %d)\n", (getSnI(13).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(13).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	iprintf(" alarmStatus (4) = %s (should be FALSE)(AC = %d)\n", (getSnI(4).alarmStatus[_(SUPERIOR,VOLTAGE)]?"TRUE":"FALSE"), getSnI(4).alarmCounters[_(SUPERIOR,VOLTAGE)]);
	result9 &= getSnI(13).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	result9 &= getSnI(4).alarmStatus[_(SUPERIOR,VOLTAGE)] == false;
	setalarmWatchSnI(OFF, SUPERIOR, VOLTAGE, 13);
	setalarmWatchSnI(OFF, SUPERIOR, VOLTAGE, 4);
}

void TEST_AlarmCTRL_SnI3( void ){
	iprintf("\n\n\n\n7. Multiple Alarm Triggering for Upper Voltage with 2 times and Disconnection. All SnIs triggered. Using updateAlarms()\n");
	int j;
	resetAlarms(ALL_PSUS_WORD, ALL_ALARMS_BYTE, SnI_TYPE_LIST);
	SnIAlarmUpdating(true);
	for (j=0;j<SnI_NUMBER;j++){
		sniList[j].vOut = sniList[j].alarmLimitValues[_(SUPERIOR, VOLTAGE)] + 2; //all superior limits exceeded
		sniList[j].alarmWatch[_(INFERIOR, VOLTAGE)]=ON;
		sniList[j].alarmWatch[_(SUPERIOR, VOLTAGE)]=ON; //Should be triggered
		sniList[j].alarmLimitTimes[_(INFERIOR, VOLTAGE)]=2;
		sniList[j].alarmLimitTimes[_(SUPERIOR, VOLTAGE)]=2; //Should be triggered
	}
	updateAlarms();
	result10 = true;
	iprintf ("First time (all to 0): {");
	for (j=0;j<SnI_NUMBER;j++){
		result10 &= (sniList[j].alarmStatus[_(INFERIOR, VOLTAGE)] == false) && (sniList[j].alarmCounters[_(INFERIOR, VOLTAGE)]==0);
		result10 &= (sniList[j].alarmStatus[_(SUPERIOR, VOLTAGE)] == false) && (sniList[j].alarmCounters[_(SUPERIOR, VOLTAGE)]==1);
		iprintf (" %d,", sniList[j].alarmStatus[_(SUPERIOR, VOLTAGE)]);
	}
	iprintf ("}\n");
	iprintf ("Second time (all to 1): {");
	updateAlarms();
	for (j=0;j<PSU_NUMBER;j++){
		result10 &= (sniList[j].alarmStatus[_(INFERIOR, VOLTAGE)] == false) && (sniList[j].alarmCounters[_(INFERIOR, VOLTAGE)]==0);
		result10 &= (sniList[j].alarmStatus[_(SUPERIOR, VOLTAGE)] == true) && (sniList[j].alarmCounters[_(SUPERIOR, VOLTAGE)]==2);
		iprintf (" %d,", sniList[j].alarmStatus[_(SUPERIOR, VOLTAGE)]);
	}
	iprintf ("}\n");
	resetAlarms(ALL_SnIS_WORD, ALL_ALARMS_BYTE, SnI_TYPE_LIST);
}
