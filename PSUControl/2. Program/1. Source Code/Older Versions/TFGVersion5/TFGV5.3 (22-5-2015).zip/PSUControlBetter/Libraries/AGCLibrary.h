/*
 * AGCLibrary.h
 *
 *  Created on: 17-abr-2015
 *      Author: Alberto
 */

#ifndef LIB_AGC
#define LIB_AGC

#include "Headers.h"
#include "Libraries/RDACLibrary.h"		// RDAC - Digital potentiometers

//----------------Configuration functions-------------------//
void minAGC( void );
void maxAGC( void );
void changeGainAGC( float num );

//------------------Conversion functions--------------------//
float numToGainAGC ( int rdacCount );
int gainToNumAGC ( float gain );

//---------------------Getter functions---------------------//
int getRdacCountAGC ( void );
float getGainAGC ( void );
BYTE getI2CResultAGC ( void );

#endif /* AGCLIBRARY_H_ */
