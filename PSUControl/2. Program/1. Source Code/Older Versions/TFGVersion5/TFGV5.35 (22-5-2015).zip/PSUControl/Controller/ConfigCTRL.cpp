/*
 * ConfigCTRL.cpp
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */

#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List


//==============================================VARIABLES==============================================//

// Booleans
BOOL config_MonitorCTRL_SnI_FLAG = CONFIG_INIT_MONITORCTRL_SnI_FLAG;	// Supply & Internal voltages
																		// included in a2d loop or not
BOOL config_AlarmCTRLUpdate_SnI_FLAG = CONFIG_INIT_ALARMCTRL_UPDATE_SnI_FLAG;// Includes/excludes SnI voltage
																		// alarms when using updateAlarms(void)
// Ints
int alarmUpdatePeriodx50MS = CONFIG_INIT_ALARMCTRL_UPDATE_PERIOD_x50MS;

// Testing Booleans
BOOL testMode_AlarmCTRL_Task_FLAG = false;	// Stops Alarm Task, pending it on testMode_AlarmCTRLTask_Sem
BOOL testMode_MonitorCTRL_Task_FLAG = false;// Stops Monitor Task, pending it on testMode_MonitorCTRLTask_Sem
BOOL testMode_MonitorCTRL_Measure_FLAG = false;// Uses testMode_Measure instead of reading from ADC
// Testing Values
WORD testMode_Measure = 0;

// Semaphores
OS_SEM monitorSem;
OS_SEM testMode_MonitorCTRLTask_Sem;



//=====================================================================================================//
//===================================    CONFIGURATION METHODS    =====================================//
//=====================================================================================================//

int allSemInit (void){
	return (OSSemInit(& monitorSem,0) && OSSemInit(& testMode_MonitorCTRLTask_Sem,0));
}



void config_alarmUpdatePeriod_x50MS ( int newPeriodx50MS ){
	if (newPeriodx50MS<50){
		alarmUpdatePeriodx50MS = newPeriodx50MS;
	}
	else{
		iprintf(" ERROR - CONFIG: Value for newPeriodMS (%d) (newPeriod<50)\n", newPeriodx50MS);
	}
}

void config_AlarmCTRLUpdate_SnI ( BOOL sniUpdateFLAG ){
	config_AlarmCTRLUpdate_SnI_FLAG = sniUpdateFLAG;
}

void config_MonitorCTRL_SnI ( BOOL monitorSnI ){
	config_MonitorCTRL_SnI_FLAG = monitorSnI;
}



void testMode_AlarmCTRL_Task ( BOOL testModeAlarmCTRLFLAG ){
	testMode_AlarmCTRL_Task_FLAG = testModeAlarmCTRLFLAG;
	Pins[28]=testModeAlarmCTRLFLAG;
//	iprintf("testMode_AlarmCTRL %s\n", (testModeAlarmCTRLFLAG?"ON":"OFF"));
}

void testMode_MonitorCTRL_Task ( BOOL testModeMonitorCTRLFLAG ){
	testMode_MonitorCTRL_Task_FLAG = testModeMonitorCTRLFLAG;
	Pins[26]=testModeMonitorCTRLFLAG;
	if (!testModeMonitorCTRLFLAG){
		OSSemPost(&testMode_MonitorCTRLTask_Sem);
	}
}

void testMode_MonitorCTRL_Measure ( WORD testMeasure ){

	testMode_MonitorCTRL_Measure_FLAG = testMeasure;
}

