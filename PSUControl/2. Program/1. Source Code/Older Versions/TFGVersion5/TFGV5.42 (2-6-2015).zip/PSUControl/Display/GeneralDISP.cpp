/*
 * GeneralDISP.cpp
 *
 *  Created on: 21/05/2015
 *      Author: ALBERTO IBARRONDO
 */

#include "Display.h"

// Used for Keyboard
static char c;					// used for WAIT_FOR_KEYBOARD macro, and as auxiliary variable in certain functions
#define WAIT_FOR_KEYBOARD c = sgetchar(0);
char globalSelectionDISP;
char categorySelectionDISP;
#define EXIT 'e'


void DisplayMain ( void ){
	GeneralDisplayMenuDISP();
	categorySelectionDISP = '0';
	while (categorySelectionDISP!=EXIT){
		switch (globalSelectionDISP){
			case '1': StatusDisplayDISP(); processCommandProgram(); break;
			case '2': ProgramMenuDISP(); processCommandStatus(); break;
			case '3': FunctionMenuDISP(); processCommandFunction(); break;
			default:
				iprintf( "--------------------------------------------------------\r\n" );
				iprintf( "\nINVALID NUMBER -> %c\r\n", globalSelectionDISP);
				iprintf( " \r\nPRESS ANY KEY TO EXIT\r\n" );
				WAIT_FOR_KEYBOARD
				categorySelectionDISP=EXIT;
				break;

		}
	}
}

void GeneralDisplayMenuDISP ( void ){
	iprintf( "\n\n\n\n\n\n========================================================\r\n" );
	iprintf( 			 "====================== GENERAL MENU ====================\r\n" );
	iprintf(			 "========================================================\r\n" );
	iprintf( 			 " (1) Status Display\r\n" );
	iprintf( 			 " (2) Program Menu\r\n" );
	iprintf( 			 " (3) Function Menu\r\n" );
	iprintf(			 "--------------------------------------------------------\r\n" );
	iprintf(			 "\r\nSelect menu number  \r\n" );
	globalSelectionDISP = sgetchar( 0 );
}


void StatusDisplayDISP ( void ){
	iprintf( "\n\n\n\n\n\n--------------------------------------------------------\r\n" );
	iprintf( 			 "---------------------- STATUS DISPLAY ------------------\r\n" );
	iprintf(			 "--------------------------------------------------------\r\n" );
	iprintf( 			 "\n (e) EXIT TO GENERAL MENU \r\n" );
	iprintf(   			 "--------------------------------------------------------\r\n" );
	iprintf( 			 "\r\nEnter command \r\n" );
	categorySelectionDISP = sgetchar( 0 );
}

void ProgramMenuDISP ( void ){
	iprintf( "\n\n\n\n\n\n--------------------------------------------------------\r\n" );
	iprintf( 			 "---------------------- PROGRAM MENU --------------------\r\n" );
	iprintf(			 "--------------------------------------------------------\r\n" );
	iprintf( 			 "Power Supply Units (PSUs):\n" );
	iprintf( 			 " (1) Switch ON/OFF\r\n" );
	iprintf( 			 " (2) Change Output Voltage\r\n" );
	iprintf( 			 " (3) Configure Alarms\r\n" );
	iprintf( 			 "Supply and Internal Voltages (SnIs):\n" );
	iprintf( 			 " (4) Configure Alarms\n" );
	iprintf( 			 "\n (e) EXIT TO GENERAL MENU \r\n" );
	iprintf(   			 "--------------------------------------------------------\r\n" );
	iprintf( 			 "\r\nEnter command \r\n" );
	categorySelectionDISP = sgetchar( 0 );
}

void FunctionMenuDISP ( void ){
	iprintf( "\n\n\n\n\n\n--------------------------------------------------------\r\n" );
	iprintf( 			 "---------------------- FUNCTION MENU -------------------\r\n" );
	iprintf(			 "--------------------------------------------------------\r\n" );
	iprintf( 			 "\n (e) EXIT TO GENERAL MENU \r\n" );
	iprintf(   			 "--------------------------------------------------------\r\n" );
	iprintf( 			 "\r\nEnter command \r\n" );
	categorySelectionDISP = sgetchar( 0 );
}

