/*
 * StatusDISP.cpp
 *
 *  Created on: 27/05/2015
 *      Author: ALBERTO IBARRONDO
 */

#include "Display.h"

extern char categorySelectionDISP;


void processCommandStatus ( void ){

}
