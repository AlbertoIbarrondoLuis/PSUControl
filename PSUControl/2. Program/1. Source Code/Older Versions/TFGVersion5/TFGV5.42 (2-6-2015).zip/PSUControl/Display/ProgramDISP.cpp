/*
 * ProgramDISP.cpp
 *
 *  Created on: 01/06/2015
 *      Author: ALBERTO IBARRONDO
 */

#include "Display.h"

extern PSU_TYPE psuList[PSU_NUMBER];
extern SnI_TYPE sniList[SnI_NUMBER];

extern char categorySelectionDISP;

BOOL selectedNums[SnI_NUMBER] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0};
BOOL selectedAlarms[4] = {0,0,0,0};
BOOL selectedProtocols[4] = {0,0,0,0};

void processCommandProgram ( void ){
	switch (categorySelectionDISP){
		case '1': // Switch ON/OFF PSUs
			selectNumsDISP(PSU_TYPE_LIST);
			break;
		case '2': // Change Output Voltage PSUs
			selectNumsDISP(PSU_TYPE_LIST);

			break;
		case '3': // Configure Alarms PSUs
			selectNumsDISP(PSU_TYPE_LIST);
			selectAlarmsDISP(PSU_TYPE_LIST);

			break;
		case '4': // Configure Alarms SnIs
			selectNumsDISP(SnI_TYPE_LIST);
			selectAlarmsDISP(SnI_TYPE_LIST);
			break;
	}
}


void selectNumsDISP (BOOL psu_sni){
	char selectingNumsAUX[1] = {'\0'};
	int hexValue=0;
	memset(selectedNums, 0, sizeof selectedNums);
	while (selectingNumsAUX[0]!=' '){
		iprintf( "\n\n\n\r\n\r\n=================== Select %s ====================\r\n", (psu_sni?"PSUs":"SnIs") );
		iprintf( 			   "Press the keys to toggle selected. # is selected, blank isn't.\n" );
		iprintf( 			   "Press SPACE KEY to continue, P to select all, O to unselect all\n" );
		if (psu_sni==PSU_TYPE_LIST){
			iprintf("   PSU OUTPUTS\n");
			iprintf(" (0)SF1_A + [%s] |  (1)SF1_B + [%s]\n", (selectedNums[0]?"#":" "), (selectedNums[1]?"#":" "));
			iprintf(" (2)SF2_A + [%s] |  (3)SF2_B + [%s]\n", (selectedNums[2]?"#":" "), (selectedNums[3]?"#":" "));
			iprintf(" (4)SF3_A + [%s] |  (5)SF3_B + [%s]\n", (selectedNums[4]?"#":" "), (selectedNums[5]?"#":" "));
			iprintf(" (6)SF4_A + [%s] |  (7)SF4_B + [%s]\n", (selectedNums[6]?"#":" "), (selectedNums[7]?"#":" "));
			iprintf(" (8)SF5_A + [%s] |  (9)SF5_B + [%s]\n", (selectedNums[8]?"#":" "), (selectedNums[9]?"#":" "));
			iprintf(" (A)SF6_A - [%s] |  (B)SF6_B - [%s]\n", (selectedNums[10]?"#":" "), (selectedNums[11]?"#":" "));
		}
		else{
			iprintf(" 	SUPPLY VOLTAGES\n");
			iprintf(" (0) SUP_42V_UNREG[%s]\n", (selectedNums[0]?"#":" "));
			iprintf(" (1) SUP_35V_UNREG[%s]\n", (selectedNums[1]?"#":" "));
			iprintf(" (2) SUP_16V_UNREG[%s]\n", (selectedNums[2]?"#":" "));
			iprintf(" (3) SUP_32V_REG[%s]\n", (selectedNums[3]?"#":" "));
			iprintf(" (4) SUP_16V_REG[%s]\n", (selectedNums[4]?"#":" "));
			iprintf(" (5) SUP_12V_F_A[%s]\n", (selectedNums[5]?"#":" "));
			iprintf(" (6) SUP_12V_F_B[%s]\n", (selectedNums[6]?"#":" "));
			iprintf(" (7) SUP_12V_F_C[%s]\n", (selectedNums[7]?"#":" "));
			iprintf(" (8) SUP_n16_REG[%s]\n", (selectedNums[8]?"#":" "));
			iprintf(" (9) SUP_n20_UNREG[%s]\n", (selectedNums[9]?"#":" "));
			iprintf(" (A) SUP_12V_F_D[%s]\n", (selectedNums[10]?"#":" "));

			iprintf(" INTERNAL VOLTAGES\n");
			iprintf(" (B) INT_VCC_3V3[%s]\n", (selectedNums[11]?"#":" "));
			iprintf(" (C) INT_VCC_12V[%s]\n", (selectedNums[12]?"#":" "));
			iprintf(" (D) INT_VCC_n12V[%s]\n", (selectedNums[13]?"#":" "));
		}
		selectingNumsAUX[0]=sgetchar(0);
		hexValue = Ascii2Hex(selectingNumsAUX, 1);
		if((hexValue!=0 || selectingNumsAUX[0]!='0') && hexValue<SnI_NUMBER){
			selectedNums[hexValue] = !selectedNums[hexValue];
		}
		if (selectingNumsAUX[0]=='p' || selectingNumsAUX[0]=='P'){
			memset(selectedNums, 1, sizeof selectedNums);
		}
		if (selectingNumsAUX[0]=='o' || selectingNumsAUX[0]=='O'){
			memset(selectedNums, 0, sizeof selectedNums);
		}
	}

	iprintf( "--------------------------------------------------------\r\n" );
	iprintf( "%s selected  \r\n", (psu_sni==PSU_TYPE_LIST?"PSUs":"SnIs"));
}

void selectAlarmsDISP (BOOL psu_sni){
	char selectingAlarmsAUX[1] = {'\0'};
	int hexValue=0;
	memset(selectedAlarms, 0, sizeof selectedAlarms);
	while (selectingAlarmsAUX[0]!=' '){
		iprintf( "\n\n\n\r\n\r\n=================== Configure Alarms ====================\r\n");
		iprintf( 			   "Press the keys to toggle selected. # is selected, blank isn't.\n" );
		iprintf( 			   "Press SPACE KEY to continue, P to select all, O to unselect all\n" );


			iprintf(" (0) Superior Voltage[%s]\n", (selectedAlarms[0]?"#":" "));
			iprintf(" (1) Inferior Voltage[%s]\n", (selectedAlarms[1]?"#":" "));
		if (psu_sni==PSU_TYPE_LIST){
			iprintf(" (2) Superior Current[%s]\n", (selectedAlarms[2]?"#":" "));
			iprintf(" (3) Inferior Current[%s]\n", (selectedAlarms[3]?"#":" "));
		}
		selectingAlarmsAUX[0]=sgetchar(0);
		hexValue = Ascii2Hex(selectingAlarmsAUX, 1);
		if((hexValue!=0 || selectingAlarmsAUX[0]!='0') && hexValue<SnI_NUMBER){
			selectedAlarms[hexValue] = !selectedAlarms[hexValue];
		}
		if (selectingAlarmsAUX[0]=='p' || selectingAlarmsAUX[0]=='P'){
			memset(selectedAlarms, 1, sizeof selectedAlarms);
		}
		if (selectingAlarmsAUX[0]=='o' || selectingAlarmsAUX[0]=='O'){
			memset(selectedAlarms, 0, sizeof selectedAlarms);
		}
	}

	iprintf( "--------------------------------------------------------\r\n" );
	iprintf( "\r\nAlarms selected  \r\n");
}


void setProtocolsDISP ( BOOL psu_sni ){
	char selectingProtocolsAUX[1] = {'\0'};
	int hexValue=0;
	memset(selectedProtocols, 0, sizeof selectedProtocols);
	while (selectingProtocolsAUX[0]!=' '){
		iprintf( "\n\n\n\r\n\r\n-------------------- Set Alarm Protocols -------------------\r\n");
		iprintf( 			   "Press the keys to toggle selected. # is selected, blank isn't.\n" );
		iprintf( 			   "Press SPACE KEY to continue, P to select all, O to unselect all\n" );
			iprintf(" (0) Shutdown PSUs [%s]\n", (selectedProtocols[0]?"#":" "));
			iprintf(" (1) Send Message [%s]\n", (selectedProtocols[1]?"#":" "));
		if (psu_sni==PSU_TYPE_LIST){
			iprintf(" (2) Modify Voltage[%s]\n", (selectedProtocols[2]?"#":" "));
		}
		selectingProtocolsAUX[0]=sgetchar(0);
		hexValue = Ascii2Hex(selectingProtocolsAUX, 1);
		if((hexValue!=0 || selectingProtocolsAUX[0]!='0') && hexValue<SnI_NUMBER){
			selectedProtocols[hexValue] = !selectedProtocols[hexValue];
		}
		if (selectingProtocolsAUX[0]=='p' || selectingProtocolsAUX[0]=='P'){
			memset(selectedProtocols, 1, sizeof selectedProtocols);
		}
		if (selectingProtocolsAUX[0]=='o' || selectingProtocolsAUX[0]=='O'){
			memset(selectedProtocols, 0, sizeof selectedProtocols);
		}
	}

	iprintf( "--------------------------------------------------------\r\n" );
	iprintf( "\r\nAlarm protocols set  \r\n");
}


void programAlarmLimitTimesDISP ( BOOL psu_sni ){
	char progmAlLimTimeAUX[3] = {'\0'};
	int num=0, i, j;
	iprintf( "\n\n\n\r\n\r\n---------------- Program Alarm Limit Time ----------------\r\n");
	iprintf(" Enter the time to be programmed (x100ms):  ");
	num = atoi(gets((char *)progmAlLimTimeAUX));iprintf("\r\n");
	if (num>100 || num <0){
		num = 0;
	}
	if(psu_sni==PSU_TYPE_LIST){
		for (i=0; i<PSU_NUMBER; i++){if(selectedNums[i]){
			for (j=0; j<4; j++){ if(selectedAlarms[j]){
				psuList[i].alarmLimitTimes[j] = num;
			}}
		}}
	}
	else{
		for (i=0; i<SnI_NUMBER; i++){if(selectedNums[i]){
			for (j=0; j<4; j++){ if(selectedAlarms[j]){
				sniList[i].alarmLimitTimes[j] = num;
			}}
		}}
	}
	iprintf( "--------------------------------------------------------\r\n" );
	iprintf( "\r\nAlarms programmed with alarmLimitTimes = %d\n", num);
}

void programAlarmLimitValuesDISP ( BOOL psu_sni ){
	char progmAlLimValiAUX[7] = {'\0'};
	float num=0; int i, j;
	iprintf( "\n\n\n\r\n\r\n-------------- Program Alarm Limit Value --------------\r\n");
	iprintf(" Enter the Value to be programmed (With 2 decimals top):  ");
	num = atof(gets((char *)progmAlLimValiAUX));iprintf("\r\n");
//	if (num>100 || num <0){	num = 0;}		// In case a certain interval is required. Not implemented
	if(psu_sni==PSU_TYPE_LIST){
		for (i=0; i<PSU_NUMBER; i++){if(selectedNums[i]){
			for (j=0; j<4; j++){ if(selectedAlarms[j]){
				psuList[i].alarmLimitValues[j] = num;
			}}
		}}
	}
	else{
		for (i=0; i<SnI_NUMBER; i++){if(selectedNums[i]){
			for (j=0; j<4; j++){ if(selectedAlarms[j]){
				sniList[i].alarmLimitValues[j] = num;
			}}
		}}
	}
	iprintf( "--------------------------------------------------------\r\n" );
	iprintf( "\r\nAlarms programmed with alarmLimitValues = %s\n", ftos(num));
}
