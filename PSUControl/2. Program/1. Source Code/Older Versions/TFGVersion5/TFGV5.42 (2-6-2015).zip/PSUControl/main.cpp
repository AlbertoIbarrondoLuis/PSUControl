
/******************************************************************************
 * 								MCF5213 12-PSU Controller
 *   General Purpose. Not with a specific use yet.
 *
 *   Author: Alberto Ibarrondo
 *
 *****************************************************************************/
float versionNo =5.42;

#include "headers.h"

#include "Libraries/AGCLibrary.h"		// AGC - Automatic Gain Control
#include "Libraries/GeneralLibrary.h"	// Functions with various general purposes
#include "Libraries/I2C&SPILibrary.h"	// I2C&SPI Communication
#include "Libraries/MUXLibrary.h"		// Multiplexers
#include "Libraries/RDACLibrary.h"		// RDAC - Digital potentiometers
#include "Libraries/RelayLibrary.h"		// Relay control

#include "Controller/Controller.h"		// All the Controller Methods
#include "Tests/Tests.h"				// All the testing Methods

//========================================DECLARATIONS===============================================//
//------------------------------------------Methods--------------------------------------------------//
extern "C" {
	void UserMain( void * pd);

	// This function sets up the 5213 interrupt controller
	void SetIntc(long func, int vector, int level, int prio);
}
void _init (void);

//-----------------------------------------Variables-------------------------------------------------//
const char * AppName="PSUControl";
static BYTE i2CtoSPIAddress[PSU_NUMBER]= PSUs_I2C_ADDRESS_ARRAY;	// Defined by 3 switches.

// Used to stop program waiting for user input
char m;
#define WAIT_FOR_KEYBOARD m=sgetchar(0);





//========================================USERMAIN===================================================//
void UserMain(void * pd) {
	_init();									// Defined below. Contains all the init & configuration issues.

//----------------------------------------Main Loop--------------------------------------------------//
	while (true) { //loop forever
		TestMain();
	}
}





//=====================================System Initializations========================================//
void _init (void){
	int i; DWORD res = 0;
	//-------------------------------------General System--------------------------------------------//
	SimpleUart(0,SystemBaud);assign_stdio(0);				// Serial port 0 for Data
	SimpleUart(1,SystemBaud);								// Serial port 1 for Debug
	EnableSmartTraps();
	#ifdef _DEBUG
		InitGDBStubNoBreak( 1, 115200 );
	#endif
	OSChangePrio(MAIN_PRIO);								//Other
	EnableSerialUpdate();

	iprintf("\n\n\n\n\n\n\n\nINITIALIZATION\n");
	putleds(8);
	iprintf("Version Number --> %s\n", ftos(versionNo, 3));
	createVERIFY_KEY();										// Using versionNo to update Flash DDBB

	//--------------------------------------I2C Bus Connection---------------------------------------//
	I2CInit(MCF5213_I2C_ADDRESS, I2C_FREQUENCY); 			// Initialize I2C with Predefined Address (0x20)
															// Set frequency division to 768 (66Mhz CF clock --> 88,25 Khz I2C bus)
	iprintf(" .Initialized I2C address for MCF5213: 0x%x\r\n",MCF5213_I2C_ADDRESS);
	iprintf("   -Set I2C Frequency division: %x (MCF internal CLK / 1280)\r\n",I2C_FREQUENCY);


	//-------------------------------------SPI Bus Connection----------------------------------------//

	toggleConsoleOutputI2CLib(OFF);
	toggleConsoleOutputRDACLib(OFF);

	for (i = 0; i<PSU_NUMBER; i++){
		res |=configureSPI( false, false, false, 2, i2CtoSPIAddress[i]);	// MSB first, CLK low when idle, data clocked
																	//  in on leading edge, frequency = 115KHz
	}
	if(res==I2C_OK){iprintf(" .SPI bus configured\r\n");}
	else{iprintf(" .SPI configuration ERROR - Coudn't be configured\r\n");}

	//-----------------------------------RDACs with minimum value------------------------------------//

	res = 0;
	for (i = 0; i<PSU_NUMBER; i++){
		setValRDAC(INITIAL_VOLTAGE, (i&0x1?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS), i2CtoSPIAddress[i]);
		res |= getI2CResultRDAC();
	}

	if(res==I2C_OK){iprintf(" .RDACs set to minimum value\r\n");}
	else{iprintf(" .RDAC setting ERROR - Coudn't be set to minimum value\r\n");}


	//-------------------------------------------GPIO------------------------------------------------//
	Pins[21].function( PIN21_GPIO ); // DMA Timer Input/Output 3 Pin set as GPIO
	iprintf(" .Pin 21 (TIN3) set as GPIO\r\n");

	//----------------------------------Analog to Digital Converter----------------------------------//

	Pins[13].function( PIN13_AN0 );// Configure the A2D pin n�13 as analog input
	EnableAD();
	setMUX(FUNCTION_PSU_VOLTAGE, SF1_A);					// Sets the initial MUX configuration to Voltage in first PSU
	minAGC();												// Initializes the AGC with minimum gain (fullscale)
	res = getI2CResultAGC() | getI2CResultMUX();
	if(res==I2C_OK){iprintf(" .ADC initialized\r\n");}
	else{iprintf(" .ADC initialization ERROR\r\n");}


	//--------------------------------------Button Interruption--------------------------------------//
	SetUpIRQ1();
	iprintf(" .Button Interruption Set\r\n");


	//---------------------------------------TimerInterruptions--------------------------------------//
	//SetUpPITR(0, 8294, 1); //Use PITR 0, Wait 8294 clocks, Divide by 2 from table 17-3, 2KHz - NOT IN USE, messes with RTOS Tasks. Best left unused
	SetUpPITR(1, 16588, 1); // Use PITR 1, Wait 16588 clocks, Divide by 2 from table 17-3, 1KHz - Interrupt in charge of A2D sampling
	iprintf(" .Timers initialized\r\n");

    //----------------------------------------- RTOS Tasks-------------------------------------------//
	OSSimpleTaskCreate( alarmTask, MAIN_PRIO - 1 );
	iprintf(" .alarmTask initialized\r\n");
	iprintf(" .MonitorSem %s\n", (allSemInit()==OS_NO_ERR?"Initialized CORRECTLY":"Initialization ERROR"));
	OSSimpleTaskCreate( monitorTask, MAIN_PRIO - 2 );
	iprintf(" .monitorTask initialized\r\n");



	iprintf("APPLICATION INITIALIZED\n\nPress one key to begin \n\n");
	WAIT_FOR_KEYBOARD
	putleds(0);
}

