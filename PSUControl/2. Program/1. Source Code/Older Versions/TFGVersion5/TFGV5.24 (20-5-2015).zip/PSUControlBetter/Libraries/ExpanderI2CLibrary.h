/*
 * ExpansorI2CLibrary.h
 *
 *  Created on: 08-abr-2015
 *      Author: Alberto
 */

#ifndef EXPANDERI2CLIBRARY_H_
#define EXPANDERI2CLIBRARY_H_

#include "Libraries\I2C&SPILibrary.h"
#include "defineConstants.cpp"

#endif /* EXPANDERI2CLIBRARY_H_ */

void writeToExpander (BYTE data, BYTE mask);
void resetExpander (void);
