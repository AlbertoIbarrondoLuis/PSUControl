/*
 * LibrariesTEST.cpp
 *
 *  Created on: 20/05/2015
 *      Author: ALBERTO IBARRONDO
 */


#include "Tests.h"


//==============================================VARIABLES==============================================//
// Used to stop program
#define WAIT_FOR_KEYBOARD c = sgetchar(0);
extern char c;


//---------Imported from generalTEST.cpp
// Auxiliary
extern BYTE test_slave_address;	// Set to FIRST_SLAVE_SPI_ADDRESS or SECOND_SLAVE_SPI_ADDRESS
extern BYTE test_bridge_address;					// Defined by 3 switches.
extern float Test_Rpsu;
BOOL sl_addr = false; BOOL i2c_addr = true; BOOL ctrl_allow = false;
// Results
extern BYTE result1; extern BYTE result2; extern BYTE result3; extern BYTE result4; extern BYTE result5;
// extern BYTE result6; extern BYTE result7; extern BYTE result8; extern BYTE result9; extern BYTE result10;
extern BYTE resultTotal;



//=====================================================================================================//
//================================    Libraries' Testing METHODS    ===================================//
//=====================================================================================================//


BOOL TEST_I2CSPILibrary ( void ){
	iprintf("\n\n\n\n===============TEST_I2C_ADDRESSING===============\n");
	iprintf(" 1.Change address manually in the I2CtoSPIBridge (Component U401) to 0x2F by setting the 3 switches to ZERO\n");
	iprintf("   Shutdown the PSU and disconnect the I2C bus cables, then connect them back and turn on the PSU\n");
	iprintf("  Press one key to begin test\n");
	WAIT_FOR_KEYBOARD
	iprintf(" Sending an I2C message to Address 0x2F\n");
	test_bridge_address = 0x2F;
	result1 = configureSPI( false, false, false, 2, test_bridge_address);
	result1 = (result1==0);
	iprintf(" \n\n 2.Change address manually in the I2CtoSPIBridge (Component U401) to 0x28 by setting the 3 switches to ONE\n");
	iprintf("    Shutdown the PSU and disconnect the I2C bus cables, then connect them back and turn on the PSU\n");
	iprintf("  Press one key to begin test\n");
	WAIT_FOR_KEYBOARD
	iprintf(" Sending an I2C message to Address 0x28\n");
	test_bridge_address = 0x28;
	result2 = configureSPI( false, false, false, 2, test_bridge_address);
	result2 = (result2==0);
	iprintf("\n TEST_I2C_ADDRESSING RESULTS:\n");
	iprintf("\n result1: %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf("\n result2: %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf("\n OVERALL RESULT: %s\n", ((result1&&result2)?"PASSED":"NOT PASSED"));
	resultTotal = result1&&result2;
	return resultTotal;
}

BOOL TEST_RDACLibrary( void ){
	iprintf("\n\n\n\n===============TEST_RDACLibrary===============\n");
	iprintf("\nSELECT THE RDAC TO BE TESTED\n");
	iprintf(" (1) UPPER RDAC, Component U202\n");
	iprintf(" (2) LOWER RDAC, Component U302\n");
	char rdac = sgetchar(0);
	sl_addr = (rdac=='1');
	test_slave_address = (sl_addr?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
	printf("\nSELECTED %s RDAC, Component %s\n", (rdac=='1'?"UPPER":"LOWER"), (rdac=='1'?"U202":"U302"));
	iprintf("Do you want to check the output voltage during the test? (y/n) \n");
	char v = sgetchar(0);
	BOOL check_volt = (v=='y' || v=='Y');
	iprintf("Output voltage %s be checked during the test\n", (check_volt?"WILL":"WON'T"));
	iprintf(" Press one key to begin test\n");
	WAIT_FOR_KEYBOARD
	iprintf("\n\n\n\n1. Reading RDAC Value\n");
	changeSlave();
	highImpRDAC(test_slave_address, test_bridge_address);
	changeSlave();
	int setvalue1 = getValRDAC(test_slave_address, test_bridge_address);
	result1 = (setvalue1!=0?true:false);
	if (check_volt){
		printf(" -> Output voltage should be near %.2f\n", numToVolt(setvalue1, Test_Rpsu));
		WAIT_FOR_KEYBOARD
	}

	int newvalue = (setvalue1>1000?800:900);// 900 = 5V;
	iprintf("\n\n\n\n2. Configuring RDAC Value and checking value updating\n");
	newvalue = scanFloatValue(Test_Rpsu);
	setValRDAC(newvalue, test_slave_address, test_bridge_address);
	int setvalue2 = getValRDAC(test_slave_address, test_bridge_address);
	result2 = (setvalue2==newvalue);
	if (check_volt){
		printf(" -> Output voltage should be near %.2f\n", numToVolt(setvalue2, Test_Rpsu));
		WAIT_FOR_KEYBOARD
	}

	iprintf("\n\n\n\n3. Configuring Control Register to allow RDAC Value to be updated and reading RDAC CTRL Register\n");
	setCtrlRDAC(0,1,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)
	result3 = getCtrlRDAC(test_slave_address, test_bridge_address);
	result3 = (result3==0x2);

	iprintf("\n\n\n\n4. Configuring Control Register to reject RDAC Value updates and reading RDAC CTRL Register\n");
	setCtrlRDAC(0,0,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)
	result4 = getCtrlRDAC(test_slave_address, test_bridge_address);
	result4 = (result4==0);

	iprintf("\n\n\n\n5. Resetting RDAC - Value is set to midscale - and reading RDAC Value\n");
	resetRDAC(test_slave_address, test_bridge_address);
	int setvalue5 = getValRDAC(test_slave_address, test_bridge_address);
	result5 = (setvalue5==0x200);
	if (check_volt){
		printf(" -> Output voltage should be near %.2f\n", numToVolt(setvalue5, Test_Rpsu));
		WAIT_FOR_KEYBOARD
	}

	iprintf("\n TEST_RDACLibrary RESULTS FOR %s RDAC\n", (rdac=='1'?"UPPER":"LOWER"));
	iprintf("\n PART 1 - Reading Rdac Value\n");
	iprintf(" ~result1: %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Changing Rdac Value\n");
	iprintf(" ~result2: %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - Allowing Rdac updating\n");
	iprintf(" ~result3: %s\n", (result3?"PASSED":"NOT PASSED"));
	iprintf("\n PART 4 - Rejecting Rdac updates\n");
	iprintf(" ~result4: %s\n", (result4?"PASSED":"NOT PASSED"));
	iprintf("\n PART 5 - Resetting Rdac\n");
	iprintf(" ~result5: %s\n", (result5?"PASSED":"NOT PASSED"));
	resultTotal = (result1&&result2&&result3&&result4&&result5);
	iprintf("\n OVERALL RESULT: %s\n", (resultTotal?"PASSED":"NOT PASSED"));
	return resultTotal;

}

