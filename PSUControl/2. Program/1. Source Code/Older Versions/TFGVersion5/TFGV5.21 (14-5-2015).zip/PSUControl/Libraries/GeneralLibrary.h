/*
 * GeneralLibrary.h
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */



#ifndef GENERALLIBRARY_H_

#include <stdlib.h>
#include "predef.h"
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <stdio.h>

#define GENERALLIBRARY_H_

void mergeBuffer(BYTE buf1[], BYTE buf2[], int size);
void printBuffer(float buf1[]);
void printBuffer(float buf1[], uint bufferSize);
void printBuffer(BYTE buf1[]);
void printBuffer(BYTE buf1[], uint bufferSize);
void printBuffer(int buf1[]);
void printBuffer(int buf1[], uint bufferSize);
void printBuffer(WORD buf1[]);
void printBuffer(WORD buf1[], uint bufferSize);
DWORD Ascii2Hex( char* buf, int num);

char* ftos (float f);
char* ftos (float f, int n);
char* ftos (float f, int n, char * stringingBufferTotal);
char* intToBuffer(char * buffer, int data);
void concChar(char* p, char* msg);
void itoa(int n, char s[]);
void reverse(char s[]);
DWORD demux4to16 (int a);
WORD hammWeight(WORD x);

// DEMUX METHOD
#define DEMUX(a) (0x1 << (a-1))

#endif /* GENERALLIBRARY_H_ */


