/*
 * Timerint.h
 *
 *  Created on: 15-abr-2015
 *      Author: Alberto
 */

#ifndef TIMERINT_H_
#define TIMERINT_H_

#include "Headers.h"
#include "Controller/Controller.h"
#include "Libraries/AGCLibrary.h"

//============================================GETTERS===================================================//
DWORD get_pitr_count_adc_sampling (void);
DWORD get_pitr_count_zero (void);

//======================================INTERRUPTION METHODS=============================================//
void SetUpPITR(int pitr_ch, WORD clock_interval, BYTE pcsr_pre /* See table 173 in the users manual for bits 8-11*/);
void SetUpIRQ1( void );

#endif /* TIMERINT_H_ */
