/*
 * Test_PSU.cpp
 *
 *  Created on: 10-mar-2015
 *      Author: Alberto
 */

#define WAIT_FOR_KEYBOARD c = sgetchar(0);
#define EXIT 'e'
#include "Test_PSU.h"

static char c;					// used for WAIT_FOR_KEYBOARD macro, and as auxiliary variable in certain functions
static char menuSelection;
static char testSelection;

BYTE destAddress = 0;							// For I2C Simple communication
BYTE buffer[I2C_MAX_BUF_SIZE];

BYTE test_slave_address = SECOND_SLAVE_SPI_ADDRESS;	// Set to FIRST_SLAVE_SPI_ADDRESS or SECOND_SLAVE_SPI_ADDRESS
BYTE test_bridge_address = 0x2F;					// Defined by 3 switches.
float Test_Rpsu = 825;
int newvalue;

BOOL sl_addr = false; BOOL i2c_addr = true; BOOL ctrl_allow = false;
BYTE result1; BYTE result2;
BYTE result3; BYTE result4;
BYTE result5; BYTE result6;
BYTE result7; BYTE result8;
BYTE result9; BYTE result10;
BYTE resultTotal;

void TestMain ( void ){
	GeneralMenu();
	menuSelection = sgetchar( 0 );
	testSelection = '0';
	while (testSelection!=EXIT){
		CommandMenu();
		testSelection = sgetchar( 0 );
		processCommand();
		iprintf("\n\n\n\n------------------------ TEST END ----------------------\n");
		WAIT_FOR_KEYBOARD
	}
}
void GeneralMenu ( void ){
	iprintf( "\n\n\n\n\n\n========================================================\r\n" );
	iprintf( "================== GENERAL TEST MENU ===================\r\n" );
	iprintf( "========================================================\r\n" );
	iprintf( " (1) I2C, SPI & RDAC Tests\r\n" );
	iprintf( " (2) Monitor Tests\r\n" );
	iprintf( " (3) Software Tests\r\n" );
	iprintf( "--------------------------------------------------------\r\n" );
	iprintf( "\r\nSelect menu number  \r\n" );
}

void CommandMenu( void ){
	switch (menuSelection){
	case '1':
		iprintf( "\n\n\n\r\n\r\n================= I2C&SPI&RDAC TEST MENU ==================\r\n" );
		iprintf( "I2C: 0x%x       SLAVE: %s, %d\n",  test_bridge_address, (sl_addr?"UPPER":"LOWER"), test_slave_address);
		iprintf( "\nADDRESSING OPTIONS\r\n" );
		iprintf( " (+) Toggle I2C Address destination (0x2F or 0x28)\r\n" );
		iprintf( " (-) Toggle SPI Selected slave (Upper/Lower)\r\n" );
		iprintf( "\nI2C&SPI CONFIG\r\n" );
		iprintf( " (q) Configure both I2C & SPI Channels\n");
		iprintf( " (w) Send I2C configurable message\n");
		iprintf( "\nRDAC FUNCTIONS (1 to 9)\r\n" );
		iprintf( " (1) Change RDAC Value\r\n" );
		iprintf( " (2) Read RDAC Value\r\n" );
		iprintf( " (3) Change RDAC Control Register (allow/reject updates)\r\n" );
		iprintf( " (4) Read RDAC Control Register\r\n" );
		iprintf( " (5) Reset RDAC\r\n" );
		iprintf( " (6) High Impedance on SDO for RDAC\r\n" );
		iprintf( " (7) Scaled (+1,-1) change of RDAC value\r\n" );
		iprintf( " (8) Program RDAC Value in 20TP-Mem\r\n" );
		iprintf( " (9) Read RDAC 20TP-Mem Value\r\n" );
		iprintf( "\nCOMPLETE TESTS\r\n" );
		iprintf( " (t) TEST_I2C_ADDRESSING\r\n" );
		iprintf( " (u) BATTERY_TEST_RDAC \r\n" );
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
	break;

	case '2':
		iprintf( "\n\n\n\r\n\r\n================== MONITORING TEST MENU ===================\r\n" );
		iprintf( "\nMONITORING\r\n" );
		iprintf( " (z) Voltage scan\r\n" );
		iprintf( " (x) Current scan\r\n" );
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
	break;

	case '3':
		iprintf( "\n\n\n\r\n\r\n=================== SOFTWARE TEST MENU ====================\r\n" );
		iprintf( "\nSOFTWARE TESTS\r\n" );
		iprintf( " (a) TEST_TIMER_INTERRUPTS\r\n" );
		iprintf( " (h) TEST_FlashMemCTRL_BATTERY \r\n" );
		iprintf( " (y) TEST_DataListsCTRL_BATTERY \r\n" );
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
	break;

	default:
		iprintf( "\nINVALID MENU NUMBER -> %c\r\n", menuSelection);
		iprintf( " \r\nPRESS ANY KEY TO EXIT\r\n" );
	break;
	}
	iprintf( "--------------------------------------------------------\r\n" );
	iprintf( "\r\nEnter command \r\n" );
}

void processCommand( void )
{
	switch ( menuSelection ){
	case '1':
		switch ( testSelection ){
			case 'q': case 'Q':
				iprintf("\n\n\n\n(q). Configure both I2C & SPI Channels\n");
				I2CInit(MCF5213_I2C_ADDRESS, I2C_FREQUENCY);
				configureSPI( false, false, false, 2, test_bridge_address);	// MSB first, CLK low when idle, data clocked
			break;
			case 'w': case 'W':
				iprintf("\n\n\n\n(w). Send I2C configurable message\n");
				I2CInit(MCF5213_I2C_ADDRESS, I2C_FREQUENCY);
				while( (destAddress < 0x07) || (destAddress > 0x78) )  //While address is invalid
				{
				   iprintf( "Enter valid 7-bit (2-digit hex) destination address for Master Transmit: ");
				   *buffer = 0x0000;
				   destAddress = (BYTE)atoi( gets((char*)buffer));
				   iprintf("\r\n");
				}
				iprintf("Buffer to TX (2B = 4 HEX characters): ");
				gets((char*)buffer);
				sendI2CMessage ( buffer, (strlen( (const char*)buffer ) )+1, destAddress);
			break;
			case '1': case '"':   // In case user just wants to press the '1/"' key
				// 900 = 5V
				iprintf("\n\n\n\n(1). Configuring RDAC Value\n");
				newvalue = scanFloatValue(Test_Rpsu);
				setValRDAC(newvalue, test_slave_address, test_bridge_address);
			break;

			case '2':
				iprintf("\n\n\n\n(2). Reading RDAC Value\n");
				changeSlave();
				highImpRDAC(test_slave_address, test_bridge_address);
				changeSlave();
				getValRDAC(test_slave_address, test_bridge_address);
			break;

			case '3':
				ctrl_allow = !ctrl_allow;
				if(ctrl_allow){
					iprintf("\n\n\n\n(3). Configuring control register to ALLOW RDAC Value to be updated\n");
					setCtrlRDAC(0,1,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (1)
				}
				else{
					iprintf("\n\n\n\n(3). Configuring control register to REJECT RDAC Value updates\n");
					setCtrlRDAC(0,0,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)
				}
			break;

			case '4':
				iprintf("\n\n\n\n(4). Reading RDAC Ctrl Value\n");
				changeSlave();
				highImpRDAC(test_slave_address, test_bridge_address);
				changeSlave();
				getCtrlRDAC(test_slave_address, test_bridge_address);
			break;

			case '5':
				iprintf("\n\n\n\n(5). Resetting RDAC to 0x200\n");
				resetRDAC(test_slave_address, test_bridge_address);
			break;

			case '6':
				iprintf("\n\n\n\n(6). Setting RDAC SDO in high impedance\n");
				highImpRDAC(test_slave_address, test_bridge_address);
			break;

			case '7':
				changeSlave();
				highImpRDAC(test_slave_address, test_bridge_address);
				changeSlave();
				newvalue = getValRDAC(test_slave_address, test_bridge_address);
				toggleConsoleOutputRDACLib(OFF);
				toggleConsoleOutputI2CLib(OFF);

				iprintf("newvalue = %d\n", newvalue);

				iprintf( "\n\n\n\n(7). Scaled change RDAC value\r\n Command list:\n" );
				iprintf( " (+) More Output Voltage\r\n" );
				iprintf( " (-) Less Output Voltage\r\n" );
				iprintf( " (e) Exit\r\n" );
				iprintf( "\r\nEnter command \r\n >" );
				testSelection =sgetchar (0);
				while ( testSelection != 'e' ){
					switch ( testSelection ){
						case '+':
							newvalue-=1;
							setValRDAC(newvalue, test_slave_address, test_bridge_address);
							printf( "Output Voltage +: %.2f (n=%d)\r\n", numToVolt(newvalue, Test_Rpsu), newvalue);
							break;

						case '-':
							newvalue+=1;
							setValRDAC(newvalue, test_slave_address, test_bridge_address);
							printf( "Output Voltage -: %.2f (n=%d)\r\n", numToVolt(newvalue, Test_Rpsu), newvalue);
							break;
						case 'e':
							break;
						default:
							iprintf( "INVALID COMMAND -> %c\r\n", testSelection);
							break;
					}
					iprintf("\n > ");
					testSelection =sgetchar (0);
				}
				iprintf("\n > Exiting Scaled change RDAC\n");
				toggleConsoleOutputRDACLib(ON);
				toggleConsoleOutputI2CLib(ON);
			break;

			case '8': case '(':
				iprintf( " (8) Program RDAC Value in 20TP-Mem\r\n" );
				c = 'n';
				while (c!='y'){
					newvalue = scanFloatValue(Test_Rpsu);
					iprintf( " Do you wish to program value 0x%x in slave %d with I2C = 0x%x ? (y/n)\r\n", newvalue, test_slave_address, test_bridge_address);
					c =sgetchar(0);
				}
				programMemRDAC(newvalue,test_slave_address, test_bridge_address );
			break;
			case '9': case ')':
				iprintf( " (9) Read RDAC 20TP-Mem Value\r\n" );
				readMemRDAC(test_slave_address, test_bridge_address );
			break;
			case '+':
				i2c_addr = !i2c_addr;
				test_bridge_address = (i2c_addr?0x2F:0x28);
				iprintf(" -> Destination I2C Address: 0x%x\n", test_bridge_address);

			break;
			case '-':
				changeSlave();
				iprintf(" -> Selected %s PSU (SPI dir: 0x%x)\n", (sl_addr?"UPPER":"LOWER"), test_slave_address );
			break;
			case 't': case 'T':
				BATTERY_TEST_I2C();
			break;
			case 'u': case 'U':
				BATTERY_TEST_RDAC();
			break;
			case 'e': case 'E':
				iprintf( "\nGOING BACK TO GENERAL MENU\n");
				testSelection = 'e';
			break;
			default:
				iprintf( "\nINVALID COMMAND -> %c\r\n", testSelection);
			break;
		}
	break;
	case '2':	// MONITOR TESTS
		switch ( testSelection ){
			case 'z': case 'Z':
				// TODO: TC_F_MONITORING_SCAN_VOLTAGE_SINGLE not yet defined
			break;
			case 'x': case 'X':
				// TODO: TC_F_MONITORING_SCAN_CURRENT_SINGLE not yet defined
			break;
			case 'e':
				iprintf( "\nGOING BACK TO GENERAL MENU\n");
			break;
			default:
				iprintf( "\nINVALID COMMAND -> %c\r\n", testSelection);
			break;
		}
	break;

	case '3':	// SOFTWARE TESTS
		switch ( testSelection ){
			case 'a': case 'A':
				iprintf("\n\n\n\n(a). TEST_TIMER_INTERRUPTS (press e to exit)\n");
				while (c!='e'){
					WAIT_FOR_KEYBOARD
					iprintf("Pitr count zero = %ldPitr count one = %ld\r\n", get_pitr_count_adc_sampling(), get_pitr_count_zero());
				}
			break;
			case 'y': case 'Y':
				TEST_DataListsCTRL_BATTERY();
			break;
			case 'h': case 'H':
				TEST_FlashMemCTRL_BATTERY();
			break;
			case 'e':
				iprintf( "\nGOING BACK TO GENERAL MENU\n");
			break;
			default:
				iprintf( "\nINVALID COMMAND -> %c\r\n", testSelection);
			break;
		}
	break;

	default:
		iprintf( "\nGOING BACK TO GENERAL MENU\n");
		testSelection = 'e';
	break;
	}

}

BOOL BATTERY_TEST_I2C ( void ){
	iprintf("\n\n\n\n===============TEST_I2C_ADDRESSING===============\n");
	iprintf(" 1.Change address manually in the I2CtoSPIBridge (Component U401) to 0x2F by setting the 3 switches to ZERO\n");
	iprintf("   Shutdown the PSU and disconnect the I2C bus cables, then connect them back and turn on the PSU\n");
	iprintf("  Press one key to begin test\n");
	WAIT_FOR_KEYBOARD
	iprintf(" Sending an I2C message to Address 0x2F\n");
	test_bridge_address = 0x2F;
	result1 = configureSPI( false, false, false, 2, test_bridge_address);
	result1 = (result1==0);
	iprintf(" \n\n 2.Change address manually in the I2CtoSPIBridge (Component U401) to 0x28 by setting the 3 switches to ONE\n");
	iprintf("    Shutdown the PSU and disconnect the I2C bus cables, then connect them back and turn on the PSU\n");
	iprintf("  Press one key to begin test\n");
	WAIT_FOR_KEYBOARD
	iprintf(" Sending an I2C message to Address 0x28\n");
	test_bridge_address = 0x28;
	result2 = configureSPI( false, false, false, 2, test_bridge_address);
	result2 = (result2==0);
	iprintf("\n TEST_I2C_ADDRESSING RESULTS:\n");
	iprintf("\n result1: %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf("\n result2: %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf("\n OVERALL RESULT: %s\n", ((result1&&result2)?"PASSED":"NOT PASSED"));
	resultTotal = result1&&result2;
	return resultTotal;
}

BOOL BATTERY_TEST_RDAC ( void ){
	iprintf("\n\n\n\n===============BATTERY_TEST_RDAC===============\n");
	iprintf("\nSELECT THE RDAC TO BE TESTED\n");
	iprintf(" (1) UPPER RDAC, Component U202\n");
	iprintf(" (2) LOWER RDAC, Component U302\n");
	char rdac = sgetchar(0);
	sl_addr = (rdac=='1');
	test_slave_address = (sl_addr?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
	printf("\nSELECTED %s RDAC, Component %s\n", (rdac=='1'?"UPPER":"LOWER"), (rdac=='1'?"U202":"U302"));
	iprintf("Do you want to check the output voltage during the test? (y/n) \n");
	char v = sgetchar(0);
	BOOL check_volt = (v=='y' || v=='Y');
	iprintf("Output voltage %s be checked during the test\n", (check_volt?"WILL":"WON'T"));
	iprintf(" Press one key to begin test\n");
	WAIT_FOR_KEYBOARD
	iprintf("\n\n\n\n1. Reading RDAC Value\n");
	changeSlave();
	highImpRDAC(test_slave_address, test_bridge_address);
	changeSlave();
	int setvalue1 = getValRDAC(test_slave_address, test_bridge_address);
	result1 = (setvalue1!=0?true:false);
	if (check_volt){
		printf(" -> Output voltage should be near %.2f\n", numToVolt(setvalue1, Test_Rpsu));
		WAIT_FOR_KEYBOARD
	}

	int newvalue = (setvalue1>1000?800:900);// 900 = 5V;
	iprintf("\n\n\n\n2. Configuring RDAC Value and checking value updating\n");
	newvalue = scanFloatValue(Test_Rpsu);
	setValRDAC(newvalue, test_slave_address, test_bridge_address);
	int setvalue2 = getValRDAC(test_slave_address, test_bridge_address);
	result2 = (setvalue2==newvalue);
	if (check_volt){
		printf(" -> Output voltage should be near %.2f\n", numToVolt(setvalue2, Test_Rpsu));
		WAIT_FOR_KEYBOARD
	}

	iprintf("\n\n\n\n3. Configuring Control Register to allow RDAC Value to be updated and reading RDAC CTRL Register\n");
	setCtrlRDAC(0,1,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)
	result3 = getCtrlRDAC(test_slave_address, test_bridge_address);
	result3 = (result3==0x2);

	iprintf("\n\n\n\n4. Configuring Control Register to reject RDAC Value updates and reading RDAC CTRL Register\n");
	setCtrlRDAC(0,0,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)
	result4 = getCtrlRDAC(test_slave_address, test_bridge_address);
	result4 = (result4==0);

	iprintf("\n\n\n\n5. Resetting RDAC - Value is set to midscale - and reading RDAC Value\n");
	resetRDAC(test_slave_address, test_bridge_address);
	int setvalue5 = getValRDAC(test_slave_address, test_bridge_address);
	result5 = (setvalue5==0x200);
	if (check_volt){
		printf(" -> Output voltage should be near %.2f\n", numToVolt(setvalue5, Test_Rpsu));
		WAIT_FOR_KEYBOARD
	}

	iprintf("\n BATTERY_TEST_RDAC RESULTS FOR %s RDAC\n", (rdac=='1'?"UPPER":"LOWER"));
	iprintf("\n PART 1 - Reading Rdac Value\n");
	iprintf(" ~result1: %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Changing Rdac Value\n");
	iprintf(" ~result2: %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - Allowing Rdac updating\n");
	iprintf(" ~result3: %s\n", (result3?"PASSED":"NOT PASSED"));
	iprintf("\n PART 4 - Rejecting Rdac updates\n");
	iprintf(" ~result4: %s\n", (result4?"PASSED":"NOT PASSED"));
	iprintf("\n PART 5 - Resetting Rdac\n");
	iprintf(" ~result5: %s\n", (result5?"PASSED":"NOT PASSED"));
	resultTotal = (result1&&result2&&result3&&result4&&result5);
	iprintf("\n OVERALL RESULT: %s\n", (resultTotal?"PASSED":"NOT PASSED"));
	return resultTotal;

}


BOOL TEST_FlashMemCTRL_BATTERY( void ){
	iprintf("\n\n\n\n===============BATTERY_TEST_FLASH_MEM===============\n");
	//PSU
	iprintf("\n\n\n\n1. Setting default Values for PSUs 1 and 4, and saving values\n");
	defaultValuesPSU(1);
	defaultValuesPSU(4);
	getPSU(5).alarmProtocolShutdown[0] = 0;
	saveInFlashValuesPSUsSNIs();
	printValuesPSU(4);
	result1 = (getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1)) && (getPSU(1).alarmProtocolShutdown[0] == demux4to16(1+1));
	iprintf(" Saved Value (1) = %d (should be %d)\n", getPSU(1).alarmProtocolShutdown[0], demux4to16(1+1));
	iprintf(" Saved Value (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	printf("\n\n\n\n2. Loading Values, printing PSUs 4 and 5, and checking for data validity\n");
	getPSU(4).alarmProtocolShutdown[0] = 0;
	getPSU(5).alarmProtocolShutdown[0] = 2;
	loadFlashValuesPSUs();
	printValuesPSU(4);
	result2 = getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1);
	printValuesPSU(5);
	result3 = getPSU(5).alarmProtocolShutdown[0] == 0;
	iprintf("\n\n\n\n3. Initializing Values, printing PSUs 4 and 5, and checking for data validity\n");
	getPSU(4).alarmProtocolShutdown[0] = 0;
	getPSU(5).alarmProtocolShutdown[0] = 0;
	initializeValuesPSUsSnIs();
	printValuesPSU(4);
	result4 = getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1);
	printValuesPSU(5);
	result5 = getPSU(5).alarmProtocolShutdown[0] == demux4to16(5+1);
	//SnI
	iprintf("\n\n\n\n4. Setting default Values for SnIs 4 and 13, and saving values\n");
	defaultValuesPSU(13);
	defaultValuesPSU(4);
	getSnI(5).nominalVoltage = 0;
	saveInFlashValuesPSUsSNIs();
	printValuesSnI(4);
	printValuesSnI(13);
	result6 = ((getSnI(4).alarmLimitValues[0] < getSnI(4).nominalVoltage) && (getSnI(4).alarmLimitValues[1] > getSnI(4).nominalVoltage)) && ((getSnI(13).alarmLimitValues[0] < getSnI(13).nominalVoltage) && (getSnI(13).alarmLimitValues[1] > getSnI(13).nominalVoltage));
	iprintf("\n\n\n\n5. Loading Values, printing SnIs 4 and 5, and checking for data validity\n");
	getSnI(4).nominalVoltage = 0;
	getSnI(5).nominalVoltage = 2;
	loadFlashValuesSNIs();
	printValuesSnI(4);
	result7 = getSnI(4).alarmProtocolShutdown[0] != 0;
	printValuesSnI(5);
	result8 = getSnI(5).alarmProtocolShutdown[0] == 0;
	printf("\n\n\n\n6. Initializing Values, printing SnIs 4 and 5, and checking for data validity\n");
	getSnI(4).nominalVoltage = 0;
	getSnI(5).nominalVoltage = 0;
	initializeValuesPSUsSnIs();
	printValuesSnI(4);
	result9 = (getSnI(4).nominalVoltage != 0 );
	printValuesSnI(5);
	result10 = (getSnI(5).nominalVoltage != 0 );

	iprintf("\n BATTERY_TEST_FLASH_MEM\n");
	iprintf("\n PART 1 - Setting default Values and saving values for PSUs\n");
	iprintf(" ~result1: %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Restore Saved Values for PSUs\n");
	iprintf(" ~result2: %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Empty values aren't corrupted for PSUs\n");
	iprintf(" ~result3: %s\n", (result3?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - Initializing Values, previous data ain't corrupted for PSUs\n");
	iprintf(" ~result4: %s\n", (result4?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - Initializing Values, empty values are correctly filled for PSUs\n");
	iprintf(" ~result5: %s\n", (result5?"PASSED":"NOT PASSED"));
	iprintf("\n PART 4 - Setting default Values and saving values for SnIs\n");
	iprintf(" ~result6: %s\n", (result6?"PASSED":"NOT PASSED"));
	iprintf("\n PART 5 - Restore Saved Values for SnIs\n");
	iprintf(" ~result7: %s\n", (result7?"PASSED":"NOT PASSED"));
	iprintf("\n PART 5 - Empty values aren't corrupted for SnIs\n");
	iprintf(" ~result8: %s\n", (result8?"PASSED":"NOT PASSED"));
	iprintf("\n PART 6 - Initializing Values, previous data ain't corrupted for SnIs\n");
	iprintf(" ~result9: %s\n", (result9?"PASSED":"NOT PASSED"));
	iprintf("\n PART 6 - Initializing Values, empty values are correctly filled for SnIs\n");
	iprintf(" ~result10: %s\n", (result10?"PASSED":"NOT PASSED"));
	resultTotal = (result1&&result2&&result3&&result4&&result5&&result6&&result7&&result8&&result9&&result10);
	iprintf("\n OVERALL RESULT: %s\n", (result6?"PASSED":"NOT PASSED"));
	return resultTotal;
}


BOOL TEST_DataListsCTRL_BATTERY( void ){
	iprintf("\n\n\n\n===============TEST_DataListsCTRL_BATTERY===============\n");
	iprintf("\n\n\n\n1. Setting DEFAULT Values for PSUs 1, 4 (both positive) and 10 (negative)\n");
	defaultValuesPSU(1);
	defaultValuesPSU(4);
	defaultValuesPSU(11);
	printValuesPSU(1);
	printValuesPSU(4);
	printValuesPSU(11);
	//Check Values
	result1 = (getPSU(4).alarmProtocolShutdown[0] == demux4to16(4+1));
	result2 = (getPSU(1).alarmProtocolShutdown[0] == demux4to16(1+1));
	result3 = (getPSU(11).alarmProtocolShutdown[0] == demux4to16(11+1));
	//end Check Values
	iprintf(" Saved Value (1) = %d (should be %d)\n", getPSU(1).alarmProtocolShutdown[0], demux4to16(1+1));
	iprintf(" Saved Value (4) = %d (should be %d)\n", getPSU(4).alarmProtocolShutdown[0], demux4to16(4+1));
	iprintf("\n\n\n\n2. Setting DEFAULT Values for SnIs 1 and 4\n");
	defaultValuesSnI(1);
	defaultValuesSnI(4);
	defaultValuesSnI(13);
	printValuesSnI(1);
	printValuesSnI(4);
	printValuesSnI(13);
	//Check Values
	result4 = ((getSnI(4).alarmLimitValues[0] < getSnI(4).nominalVoltage) && (getSnI(4).alarmLimitValues[1] > getSnI(4).nominalVoltage));
	result5 = ((getSnI(1).alarmLimitValues[0] < getSnI(1).nominalVoltage) && (getSnI(1).alarmLimitValues[1] > getSnI(1).nominalVoltage));
	result6 = ((getSnI(13).alarmLimitValues[0] < getSnI(13).nominalVoltage) && (getSnI(13).alarmLimitValues[1] > getSnI(13).nominalVoltage));
	// end Check Values
	iprintf("\n\n\n\n\n BATTERY_TEST_DataListsCTRL\n");
	iprintf("\n PART 1 - Setting default Values to PSUs\n");
	iprintf(" ~result1(PSU 4): %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf(" ~result2(PSU 1): %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf(" ~result3(PSU 11): %s\n", (result3?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Setting default Values to SnIs\n");
	iprintf(" ~result4(SnI 4): %s\n", (result4?"PASSED":"NOT PASSED"));
	iprintf(" ~result5(SnI 1): %s\n", (result5?"PASSED":"NOT PASSED"));
	iprintf(" ~result6(SnI 13): %s\n", (result6?"PASSED":"NOT PASSED"));
	result7 = (result1&&result2&&result3&&result4&&result5&&result6);
	iprintf("\n OVERALL RESULT: %s\n", (result6?"PASSED":"NOT PASSED"));
	return result6;
}


void changeSlave(void){
	sl_addr = !sl_addr;
	test_slave_address = (sl_addr?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
}
