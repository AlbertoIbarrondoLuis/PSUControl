/*
 * ConfigCTRL.cpp
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */

#include "Controller/Controller.h"
extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List


//==============================================VARIABLES==============================================//
extern BOOL readSupplyAuxFLAG;					// Whether monitor Task is reading auxiliary voltages or
												//  just sticking in to PSUs' voltages
OS_SEM monitorSem;

//=====================================================================================================//
//===================================    CONFIGURATION METHODS    =====================================//
//=====================================================================================================//

int monitorSemInit (void){
	return OSSemInit(& monitorSem,0);
}

