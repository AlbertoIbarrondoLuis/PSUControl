/*
 * 	AuxiliaryCTRL.cpp
 *
 *	Definition of psuList and auxList.
 *	Default Values and printing methods for both
 *	Getters & Setters for both
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
*/

#include "Controller/Controller.h"
PSU_TYPE psuList[PSU_NUMBER];				// MAIN PSU ARRAY LIST
SnI_TYPE sniList[INT_VCC_n12V + 1];			// Supply & Internal voltages List


//=====================================================================================================//
//=================================    DATA LISTS' METHODS    =========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// defaultValuesPSU - Replaces the current PSU values in RAM by those predefined as DEFAULT in
//					file "defineConstants.cpp"
//-------------------------------------------------------------------------------------------------------
void defaultValuesPSU (int psuNum) {
	psuList[psuNum].relayStatus=DEFAULT_relayStatus_psu;
	psuList[psuNum].psuStatus=DEFAULT_psuStatus_psu;
	psuList[psuNum].rdacValue=DEFAULT_rdacValue_psu;
	BYTE i2CtoSPIAddress[12]= PSUs_I2C_ADDRESS_ARRAY;
	psuList[psuNum].bridgeI2CAdr=i2CtoSPIAddress[psuNum];
	psuList[psuNum].rdacAdr=(psuNum&0x1?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
	float auxArray1[4]=DEFAULT_alarmLimitValues_psu;
	memcpy(psuList[psuNum].alarmLimitValues, auxArray1, sizeof(psuList[psuNum].alarmLimitValues));
	int auxArray2[4]=DEFAULT_alarmLimitTimes_psu;
	memcpy(psuList[psuNum].alarmLimitTimes, auxArray2, sizeof(psuList[psuNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_alarmProtocols_psu;
	memcpy(psuList[psuNum].alarmProtocols, auxArray3, sizeof(psuList[psuNum].alarmProtocols));
	WORD k = demux4to16(psuNum+1);
	WORD auxArray4[4]={k, k, k, k};
	memcpy(psuList[psuNum].alarmProtocolShutdown, auxArray4, sizeof(psuList[psuNum].alarmProtocolShutdown));
	float auxArray5[4]=DEFAULT_alarmProtocolVoltage_psu;
	memcpy(psuList[psuNum].alarmProtocolVoltage, auxArray5, sizeof(psuList[psuNum].alarmProtocolVoltage));
	int auxArray6[4]=DEFAULT_alarmCounters_psu;
	memcpy(psuList[psuNum].alarmCounters, auxArray6, sizeof(psuList[psuNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_alarmStatus_psu;
	memcpy(psuList[psuNum].alarmStatus, auxArray7, sizeof(psuList[psuNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_alarmLimitReached_psu;
	memcpy(psuList[psuNum].alarmLimitReached, auxArray8, sizeof(psuList[psuNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_alarmWatch_psu;
	memcpy(psuList[psuNum].alarmWatch, auxArray9, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt = DEFAULT_rShunt_psu;
	psuList[psuNum].vOut = DEFAULT_vOut_psu;
	psuList[psuNum].cOut = DEFAULT_cOut_psu;
}


//-------------------------------------------------------------------------------------------------------
// printValuesPSU - prints by stdio all the values in RAM from the selected PSU
//-------------------------------------------------------------------------------------------------------
void printValuesPSU (int psuNum) {
	iprintf("PSU-Number: %d\n", psuNum);
	iprintf("- relayStatus: %d\n",psuList[psuNum].relayStatus);
	iprintf("- psuStatus: %d\n",psuList[psuNum].psuStatus);
	iprintf("- rdacValue: %s\n",ftos(psuList[psuNum].rdacValue));
	iprintf("- bridgeI2CDir: 0x%x\n",psuList[psuNum].bridgeI2CAdr);
	iprintf("- rdacAdr: %d\n",psuList[psuNum].rdacAdr);
	iprintf("- alarmLimitValues: {%s, %s, %s, %s}\n",
			ftos(psuList[psuNum].alarmLimitValues[0]), ftos(psuList[psuNum].alarmLimitValues[1]),
			ftos(psuList[psuNum].alarmLimitValues[2]),ftos(psuList[psuNum].alarmLimitValues[3]));

	iprintf("- alarmLimitTimes: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitTimes[0], psuList[psuNum].alarmLimitTimes[1],
			psuList[psuNum].alarmLimitTimes[2],psuList[psuNum].alarmLimitTimes[3]);

	iprintf("- alarmProtocols: {%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d}\n",
			psuList[psuNum].alarmProtocols[0],psuList[psuNum].alarmProtocols[1],
			psuList[psuNum].alarmProtocols[2],psuList[psuNum].alarmProtocols[3],
			psuList[psuNum].alarmProtocols[4],psuList[psuNum].alarmProtocols[5],
			psuList[psuNum].alarmProtocols[6],psuList[psuNum].alarmProtocols[7],
			psuList[psuNum].alarmProtocols[8],psuList[psuNum].alarmProtocols[9],
			psuList[psuNum].alarmProtocols[10],psuList[psuNum].alarmProtocols[11]);
	iprintf("- alarmProtocolShutdown: {0x%x, 0x%x, 0x%x, 0x%x}\n",
			psuList[psuNum].alarmProtocolShutdown[0], psuList[psuNum].alarmProtocolShutdown[1],
			psuList[psuNum].alarmProtocolShutdown[2],psuList[psuNum].alarmProtocolShutdown[3]);
	iprintf("- alarmProtocolVoltage:{%s, %s, %s, %s}\n",
			ftos(psuList[psuNum].alarmProtocolVoltage[0]),ftos(psuList[psuNum].alarmProtocolVoltage[1]),
			ftos(psuList[psuNum].alarmProtocolVoltage[2]),ftos(psuList[psuNum].alarmProtocolVoltage[3]));
	iprintf("- alarmCounters: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmCounters[0], psuList[psuNum].alarmCounters[1],
			psuList[psuNum].alarmCounters[2],psuList[psuNum].alarmCounters[3]);
	iprintf("- alarmStatus: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmStatus[0], psuList[psuNum].alarmStatus[1],
			psuList[psuNum].alarmStatus[2],psuList[psuNum].alarmStatus[3]);
	iprintf("- alarmLimitReached: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitReached[0], psuList[psuNum].alarmLimitReached[1],
			psuList[psuNum].alarmLimitReached[2],psuList[psuNum].alarmLimitReached[3]);
	iprintf("- alarmWatch: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmWatch[0], psuList[psuNum].alarmWatch[1],
			psuList[psuNum].alarmWatch[2],psuList[psuNum].alarmWatch[3]);
	iprintf("- rShunt: %d\n",psuList[psuNum].rShunt);
	iprintf("- vOut: %d\n",psuList[psuNum].vOut);
	iprintf("- cOut: %d\n",psuList[psuNum].cOut);

}


//-------------------------------------------------------------------------------------------------------
// defaultValuesSnI - Replaces the current SnI values in RAM by those predefined as DEFAULT in
//					file "defineConstants.cpp"
//-------------------------------------------------------------------------------------------------------
void defaultValuesSnI (int sniNum) {
	sniList[sniNum].sniStatus=DEFAULT_sniStatus_sni;
	float auxArray0[14]=DEFAULT_nominalVoltage_sni;
	sniList[sniNum].nominalVoltage=auxArray0[sniNum];
	sniList[sniNum].alarmLimitValues[0] = (sniList[sniNum].nominalVoltage>0?sniList[sniNum].nominalVoltage * SnI_INF_PERC_ALARM_VALUE:sniList[sniNum].nominalVoltage * SnI_SUP_PERC_ALARM_VALUE);
	sniList[sniNum].alarmLimitValues[1] = (sniList[sniNum].nominalVoltage>0?sniList[sniNum].nominalVoltage * SnI_SUP_PERC_ALARM_VALUE:sniList[sniNum].nominalVoltage * SnI_INF_PERC_ALARM_VALUE);
	sniList[sniNum].alarmLimitValues[2]	= 0;
	sniList[sniNum].alarmLimitValues[3]	= 0;
	int auxArray2[4]=DEFAULT_alarmLimitTimes_sni;
	memcpy(sniList[sniNum].alarmLimitTimes, auxArray2, sizeof(sniList[sniNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_alarmProtocols_sni;
	memcpy(sniList[sniNum].alarmProtocols, auxArray3, sizeof(sniList[sniNum].alarmProtocols));
	int auxArray4[4]={0, 0, 0, 0};
	memcpy(sniList[sniNum].alarmProtocolShutdown, auxArray4, sizeof(sniList[sniNum].alarmProtocolShutdown));
	int auxArray6[4]=DEFAULT_alarmCounters_sni;
	memcpy(sniList[sniNum].alarmCounters, auxArray6, sizeof(sniList[sniNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_alarmStatus_sni;
	memcpy(sniList[sniNum].alarmStatus, auxArray7, sizeof(sniList[sniNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_alarmLimitReached_sni;
	memcpy(sniList[sniNum].alarmLimitReached, auxArray8, sizeof(sniList[sniNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_alarmWatch_sni;
	memcpy(sniList[sniNum].alarmWatch, auxArray9, sizeof(sniList[sniNum].alarmWatch));
	sniList[sniNum].vOut = DEFAULT_vOut_sni;
}

//-------------------------------------------------------------------------------------------------------
// printValuesAUX - prints by stdio all the values in RAM from the selected PSU
//-------------------------------------------------------------------------------------------------------
void printValuesSnI (int sniNum) {
	iprintf("AUX-Number: %d\n", sniNum);
	iprintf("- auxStatus: %d\n",sniList[sniNum].sniStatus);
	iprintf("- auxVoltage: %s\n",ftos(sniList[sniNum].nominalVoltage));
	iprintf("- alarmLimitValues: {%s, %s, %s, %s}\n",
			ftos(sniList[sniNum].alarmLimitValues[0]), ftos(sniList[sniNum].alarmLimitValues[1]),
			ftos(sniList[sniNum].alarmLimitValues[2]),ftos(sniList[sniNum].alarmLimitValues[3]));

	iprintf("- alarmLimitTimes: {%d, %d, %d, %d}\n",
			sniList[sniNum].alarmLimitTimes[0], sniList[sniNum].alarmLimitTimes[1],
			sniList[sniNum].alarmLimitTimes[2],sniList[sniNum].alarmLimitTimes[3]);

	iprintf("- alarmProtocols: {%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d}\n",
			sniList[sniNum].alarmProtocols[0],sniList[sniNum].alarmProtocols[1],
			sniList[sniNum].alarmProtocols[2],sniList[sniNum].alarmProtocols[3],
			sniList[sniNum].alarmProtocols[4],sniList[sniNum].alarmProtocols[5],
			sniList[sniNum].alarmProtocols[6],sniList[sniNum].alarmProtocols[7],
			sniList[sniNum].alarmProtocols[8],sniList[sniNum].alarmProtocols[9],
			sniList[sniNum].alarmProtocols[10],sniList[sniNum].alarmProtocols[11]);
	iprintf("- alarmProtocolShutdown: {0x%x, 0x%x, 0x%x, 0x%x}\n",
			sniList[sniNum].alarmProtocolShutdown[0], sniList[sniNum].alarmProtocolShutdown[1],
			sniList[sniNum].alarmProtocolShutdown[2],sniList[sniNum].alarmProtocolShutdown[3]);
	iprintf("- alarmCounters: {%d, %d, %d, %d}\n",
			sniList[sniNum].alarmCounters[0], sniList[sniNum].alarmCounters[1],
			sniList[sniNum].alarmCounters[2],sniList[sniNum].alarmCounters[3]);
	iprintf("- alarmStatus: {%d, %d, %d, %d}\n",
			sniList[sniNum].alarmStatus[0], sniList[sniNum].alarmStatus[1],
			sniList[sniNum].alarmStatus[2],sniList[sniNum].alarmStatus[3]);
	iprintf("- alarmLimitReached: {%d, %d, %d, %d}\n",
			sniList[sniNum].alarmLimitReached[0], sniList[sniNum].alarmLimitReached[1],
			sniList[sniNum].alarmLimitReached[2],sniList[sniNum].alarmLimitReached[3]);
	iprintf("- alarmWatch: {%d, %d, %d, %d}\n",
			sniList[sniNum].alarmWatch[0], sniList[sniNum].alarmWatch[1],
			sniList[sniNum].alarmWatch[2],sniList[sniNum].alarmWatch[3]);
	iprintf("- vOut: %d\n",sniList[sniNum].vOut);

}
PSU_TYPE getPSU (int psuNum){
	return psuList[psuNum];
}

SnI_TYPE getSnI( int sniNum ){
	return sniList[sniNum];
}

void setPSU (int psuNum, PSU_TYPE psu){
	psuList[psuNum] = psu;
}

void setSnI( int sniNum, SnI_TYPE sni){
	sniList[sniNum] = sni;
}
