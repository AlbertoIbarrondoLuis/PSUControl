/*
 * Controller.h
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
 */

#ifndef CONTROLLER_H_
#define CONTROLLER_H_

#include "Headers.h"

#include "defineConstants.cpp"
#include "Libraries/RDACLibrary.h"
#include "Libraries/MUXLibrary.h"
#include "Libraries/I2C&SPILibrary.h"
#include "Libraries/RelayLibrary.h"
#include "Interruption.h"




//==========================================METHODS===========================================//

//-------------------------------VOLTAGE & CURRENT METHODS------------------------------------//
void adjustRdac (int psuNum, float Voltage);
void resetRdacs ( void );
void updateVoltagePSUs(WORD selectPSUs);
void readVoltageValue(int psuNum);
void readCurrentValue(int psuNum);
void selectMuxPSU(int psuNum, int function);


//-------------------------------------ALARM METHODS------------------------------------------//
void alarmTask (void *p);
void alarmCheck (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr);
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum);
void updateAlarms (void);


//-----------------------------------FLASH MEMORY METHODS-------------------------------------//
void loadFlashValuesPSUs (void);
void loadFlashValuesSNIs (void);
int saveInFlashValuesPSUsSNIs (void);
void readFlashValuesPSU(int psuNum, PSU_TYPE *pData);
DWORD createVERIFY_KEY();


//-----------------------------------SWITCH ON PSUs METHODS-----------------------------------//
void switchONPSUsTask(WORD switchONListPSUs);
int initializeValuesPSUsSnIs(void);
void connectPSU(int psuNum);
void switchONPSUs(WORD selectedPSUs);
void disconnectPSU(int psuNum);
void switchOFFPSUs(WORD selectedPSUs);


//-------------------------------------DATA LISTS' METHODS-------------------------------------//
void defaultValuesPSU (int psuNum);
void printValuesPSU (int psuNum);
void defaultValuesSnI (int auxNum);
void printValuesSnI (int auxNum);
PSU_TYPE getPSU (int psuNum);
SnI_TYPE getSnI( int auxNum );
void setPSU (int psuNum, PSU_TYPE psu);
void setSnI( int auxNum, SnI_TYPE aux);


//----------------------------------------MONITOR METHODS---------------------------------------//
void monitorTask (void* p);


//-------------------------------------CONFIGURATION METHODS------------------------------------//
int monitorSemInit (void);


#endif /* CONTROLLER_H_ */


