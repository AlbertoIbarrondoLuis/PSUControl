/*
 * BusExpLibrary.cpp
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#include "Libraries/RelayLibrary.h"


//ODO: set the desired pins to gpio with command:
// Pins[30].function( PIN30_GPIO )
// Use table in PinIO APPNOTE for further inquiries

void connectRelay ( int psuNum ){
	// TODO: Select the desired GPIO PIN and set it to 1
}

void disconnectRelay ( int psuNum ){
	// TODO: Select the desired GPIO PIN and set it to 0
}

void disconnectRelaySeveral ( WORD selectedPSUs ){
	// TODO: Select the desired GPIO PINs and set them to 0
}
