/*
 * ExpansorI2CLibrary.cpp
 *
 *  Created on: 08-abr-2015
 *      Author: Alberto
 */

#include "Libraries\ExpanderI2CLibrary.h"

BYTE expanderBusBuffer[1] = {0};

void writeToExpander (BYTE data, BYTE mask){
	expanderBusBuffer[0] = ( expanderBusBuffer[0] & !mask ) | ( data & mask );
	sendI2CMessage (expanderBusBuffer, 1, EXPANDER_I2C_ADDRESS);
}

void resetExpander (void){
	expanderBusBuffer[0] = 0;
	sendI2CMessage (expanderBusBuffer, 1, EXPANDER_I2C_ADDRESS);
}
