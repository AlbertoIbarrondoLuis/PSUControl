/*
 * ExpansorI2CLibrary.h
 *
 *  Created on: 08-abr-2015
 *      Author: Alberto
 */

#ifndef EXPANSORI2CLIBRARY_H_
#define EXPANSORI2CLIBRARY_H_

#include "Libraries\I2C&SPILibrary.h"
#include "defineConstants.cpp"

#endif /* EXPANSORI2CLIBRARY_H_ */

void writeToExpander (BYTE data, BYTE mask);
void resetExpander (void);
