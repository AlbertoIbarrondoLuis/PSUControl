/*
 * PSULibrary.h
 *
 *  Created on: 04-feb-2015
 *      Author: Alberto
 */

#ifndef PSULIBRARY_H_

#include "PSU_TYPE.cpp"

#define PSULIBRARY_H_

void alarmCheck (int psuNum);
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum);
void adjustRdac (int psuNum, int slave, float Voltage);
void initializePSUs(int selectPSUs );
void refreshAlarmCounters_100ms (void);
void readVoltageValue(int psuNum);
void readCurrentValue(int psuNum);
void selectPSUMux( int psuNum, BOOL volt_curr);
void readFlashValuesPSU( int psuNum, PSU_TYPE *pData );
void defaultValuesPSU ( int psuNum );


#endif /* PSULIBRARY_H_ */


