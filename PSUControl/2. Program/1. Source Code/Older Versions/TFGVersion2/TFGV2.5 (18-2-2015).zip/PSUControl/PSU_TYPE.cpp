/*
 * PSU_TYPE.cpp
 *
 *  Created on: 18-feb-2015
 *      Author: Alberto
 */
#ifndef PSU_TYPE_FILE

#define PSU_TYPE_FILE
#include "basictypes.h"

typedef struct PSU_TYPE {
	BOOLEAN releStatus;					// Rel� flag
	BOOLEAN psuStatus;					// PSU being used or not

	float rdacValue;					// Programmed voltage
	BYTE bridgeI2CDir;					// PSU I2C Bridge direction

	float alarmLimitValues[4];			// inferior (0) and superior (1) voltage alarm limits; and inferior (2) and superior (3) current alarm limits.
	int alarmLimitTimes[4];				// inferior (0) and superior (1) voltage alarm times; and inferior (2) and superior (3) current alarm times.
	BOOL alarmProtocols[12];			// inferior (0) and superior (1) voltage alarm; and inferior (2) and superior (3) current alarm.
										// Third dimension is to activate(TRUE) or ignore(FALSE) the protocols when the alarm pops up: (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
										// Accessed with: __(Inf/sup, Vol/cur, Shutdown/Modify/sendMessage).
	WORD alarmProtocolShutdown[4];		// PSU list to shutdown in alarm protocol Shutdown (. bit 0 is for PSU 1, and so on.
	float alarmProtocolVoltage[8];		// New values for this PSU's voltage in case of alarm Protocol Modify Voltage.

	int alarmCounters[4];				// variables being increased on each scanning period if an alarm is ON, until they reach the alarmLimits
										// They also serve for shutting down alarms when not active for a period of time.

	BOOL alarmStatus[4];				// FALSE: alarm hasn't been triggered, not performing any alarm protocols. TRUE: alarm is ON, performing alarm protocols.
	BOOL alarmLimitReached[4];			// FALSE: alarm hasn't reached the limit. If alarmStatus was ON, it will start decreasing the alarmCounter until alarmStatus is OFF(ntimes = alarmLimitTimes). TRUE: alarm has reached the limit, beginning to increase the alarmCounter until alarmStatus is ON (ntimes = alarmLimitTimes).
	BOOL alarmWatch[4];					// FALSE: alarm is not configured, it will neither analyze the system nor trigger the alarmStatus ON.
										// TRUE: alarm is configured and working, will analyze the system, set the alarmStatus ON when a limit is reached, and execute the defined alarmProtocols

	int rShunt;							// Internal resistor used for RDAC configuration

	int divisorTension1;				// valor de la resistencia R1 del divisor a la entrada del CAD para lectura tension. R303 a R310 y R319 a R322
	int divisorTension2;				// valor de la resistencia R2 del divisor a la entrada del CAD para lectura tension. R311 a R311 y R323 a R326
	int rAdicPotDigital;				// valor de la resistencia R203
	int rDivisorPotDigital;				// valor de la resistencia R202

	int vOut;							// CAD value of the output voltage
	int cOut;							// CAD value of the output current

	// Initialization timing and boolean
	int temporizadoEncendido;  // x100 ms temporizado inicial de encendido de la fuente
	BOOL ReadyToConnect;	// indica si la fuente se ha cumplido la temporizacion para el encendido

	DWORD VerifyKey;		// llave de comprobaci�n de datos en memoria FLASH 0x48666050
};
#endif
