/*
 * PSULibrary.h
 *
 *  Created on: 04-feb-2015
 *      Author: Alberto
 */

#ifndef PSULIBRARY_H_
#define PSULIBRARY_H_


#endif /* PSULIBRARY_H_ */

void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum);
void adjustRDAC (int psuNum, float Voltage);
void readVoltageValue(int psuNum);
void readCurrentValue(int psuNum);
