/*
 * defineConstants.cpp
 *
 *  Created on: 13-feb-2015
 *      Author: Alberto
 */

#define PSU_NUMBER 12;			// TODO: cambiar los numeros 12 por PSU_NUMBER. Da error
