/*
 * PSU_TYPE.cpp
 *
 *  Created on: 18-feb-2015
 *      Author: Alberto
 */
#ifndef PSU_TYPE_FILE

#define PSU_TYPE_FILE
#include "basictypes.h"

typedef struct PSU_TYPE {


	//----------General Status----------//
	BOOLEAN releStatus;					// Rel� flag
	BOOLEAN psuStatus;					// PSU being used or not


	//------------Addressing------------//
	float rdacValue;					// Programmed voltage
	BYTE bridgeI2CAdr;					// PSU I2C Bridge address


	//-----------Alarm Arrays-----------//
	//First array index bit: INFERIOR(0)/SUPERIOR(1).
	//Second array index bit: VOLTAGE(0)/CURRENT(1).
	//Following array index bits: variable.
	//
	//Methods for array access:
	// _(a, b) --> Arrays with 4 items. a=(INFERIOR/SUPERIOR); b=(VOLTAGE/CURRENT)
	// _(a, b, c) --> Arrays with 8/12 items. a=(INFERIOR/SUPERIOR); b=(VOLTAGE/CURRENT)
	//		c=(PROTOCOL_SHUTDOWN/PROTOCOL_MODIFY_VOLTAGE/PROTOCOL_MESSAGE) for alarmProtocols.
	//		c=(FIRST_SLAVE/SECOND_SLAVE) for alarmProtocolVoltage.

	float alarmLimitValues[4];			// inferior (0) and superior (1) voltage alarm LIMITS (magnitude);
										// and inferior (2) and superior (3) current alarm LIMITS.

	int alarmLimitTimes[4];				// inferior (0) and superior (1) voltage alarm TIMES
										// (Counter limits which trigger alarmStatus On/Off when reached);
										// and inferior (2) and superior (3) current alarm TIMES.

	BOOL alarmProtocols[12];			// Activate(TRUE) or ignore(FALSE) each of the protocols when the alarm pops up:
										// c=(0) Shut down certain PSUs, (1) Modify this PSU's Voltage, (2) Send Alarm Message.

	DWORD alarmProtocolShutdown[4];		// PSU list to shutdown in alarm protocol Shutdown.
										// Bits 0 to B shutdown PSUs 1 to 12 if set to TRUE.

	float alarmProtocolVoltage[8];		// New values for this PSU's voltage when executed this alarm's Modify Voltage Protocol .

	int alarmCounters[4];				// Variables increasing on each scanning period if alarmLimitReached is ON(TRUE), until they reach alarmLimitTimes.
										// They also serve for shutting down alarms when alarmLimitReached is OFF(FALSE).

	BOOL alarmStatus[4];				// FALSE: alarm hasn't been triggered, not performing any alarm protocols.
										// TRUE: alarm is ON, performing alarm protocols.

	BOOL alarmLimitReached[4];			// FALSE: alarm hasn't reached the limit. If alarmStatus is ON, it will start
										// decreasing the alarmCounter until alarmStatus is OFF(ntimes = alarmLimitTimes)
										// TRUE: alarm has reached the limit, beginning to increase the alarmCounter
										// until alarmStatus is ON (ntimes = alarmLimitTimes).

	BOOL alarmWatch[4];					// FALSE: alarm is not configured, it will neither analyze the system nor trigger the alarmStatus ON.
										// TRUE: alarm is configured and working, will analyze the system, set the alarmStatus ON
										// when a limit is reached, and execute the defined alarmProtocols


	//----------Resistor Values---------//
	int rShunt;							// Internal resistor value used for RDAC configuration

	int divisorTension1;				// valor de la resistencia R1 del divisor a la entrada del CAD para lectura tension. R303 a R310 y R319 a R322
	int divisorTension2;				// valor de la resistencia R2 del divisor a la entrada del CAD para lectura tension. R311 a R311 y R323 a R326
	int rAdicPotDigital;				// valor de la resistencia R203
	int rDivisorPotDigital;				// valor de la resistencia R202


	//------------CAD values------------//
	int vOut;							// CAD value of the output voltage
	int cOut;							// CAD value of the output current

	// Initialization timing and boolean - Not currently in use
	int initializationTimer;  // x100 ms temporizado inicial de encendido de la fuente
	BOOL ReadyToConnect;	// indica si la fuente se ha cumplido la temporizacion para el encendido


	//-------------FLASH----------------//
	DWORD VerifyKey;					// Verification key for stored data in FLASH memory
};
#endif
