/*
 * PSULibrary.h
 *
 *  Created on: 04-feb-2015
 *      Author: Alberto
 */

#ifndef PSULIBRARY_H_

#include "PSU_TYPE.cpp"

#define PSULIBRARY_H_

void alarmTask (void *p );
void alarmCheck (int psuNum);
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum);
void adjustRdac (int psuNum, int slave, float Voltage);
void initializePSUs(DWORD selectPSUs );
void refreshAlarmCounters_100ms (void);
void readVoltageValue(int psuNum);
void readCurrentValue(int psuNum);
void selectMuxPSU( int psuNum, int function );
void readFlashValuesPSU( int psuNum, PSU_TYPE *pData );
void LoadFlashValuesPSU (void);
int initializeValuesPSUs(void);
void defaultValuesPSU ( int psuNum );
void printValuesPSU ( int psuNum );
int saveInFlashValuesPSU (void);
#endif /* PSULIBRARY_H_ */


