/*
 * PSULibrary.cpp
 *
 *  Created on: 04-feb-2015
 *      Author: Alberto
*/


#include "predef.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "RDACLibrary.h"
#include "I2CLibrary.h"
#include "PSULibrary.h"
#include "defineConstants.cpp"

// Variables
BOOL powerONProcess = true; 	// used to initialize the system only once.
int powerONticks=0; 			// delay counter when initialyzing the system.

char bufferMOD5270[80]; 		// buffer mensajes tx y rx con MOD5270 via UART

PSU_TYPE psuList[PSU_NUMBER];




void adjustRdac (int psuNum, int slave, float Voltage){
	//TODO: seleccionar SCL
	int desiredValue = voltToNum(Voltage, psuList[psuNum].rShunt);
	setRegRDAC(desiredValue, slave, psuList[psuNum].bridgeI2CAdr);
	int setValue = getRegRDAC( slave, psuList[psuNum].bridgeI2CAdr);
	if (desiredValue==setValue){
		psuList[psuNum].rdacValue = Voltage;
	}
	else{
		printf("ERROR: RDAC value %d not properly configured on PSU %d. Value %d set instead", desiredValue, psuNum, setValue);
	}
}

void readVoltageValue(int psuNum){
	float value = 0;
	selectMuxPSU( psuNum, VOLTAGE );
	//TODO: Check the voltage using ADC and convert it to float.
	psuList[psuNum].vOut = value;
}

void readCurrentValue(int psuNum){
	float value = 0;
	selectMuxPSU( psuNum, CURRENT );
	//TODO: Check the current using ADC and convert it to float.
	psuList[psuNum].cOut = value;
}

void selectMuxPSU( int psuNum, int function){
	// TODO: Change muxes to allow ADC to get the desired PSU measurement.
}

int initializeValuesPSUs(void){
	 int saveParameters=FALSE;
	 int i=0;
	 PSU_TYPE *pData = ( PSU_TYPE * ) GetUserParameters();
	 PSU_TYPE *ppsuList = psuList;
	 for (i=0;i<PSU_NUMBER;i++){
	      if ( pData->VerifyKey != VERIFY_KEY ){ 			// Incorrect Data
	    	  defaultValuesPSU(i);
	    	  saveParameters=TRUE;							// Value updating as soon as an invalid key is detected
          }else {											// Correct data
        	  // readFlashValuesPSU(i,pData); 					in case memory copying didn't work (which currently does)
        	  memcpy (ppsuList, pData, sizeof(PSU_TYPE));
		  }
	      pData++; ppsuList++;								//Next PSU reading
	  }
     if (saveParameters){
    	 saveParameters = saveInFlashValuesPSU ();
     }
     return saveParameters;
}

void initializePSUs(DWORD selectPSUs ){	// PSUs marked with his corresponding bit to 1 will be switched on.
	int psuNum; int aux = selectPSUs;
	// ajustar fuentes
	for (psuNum=0;psuNum<PSU_NUMBER;psuNum++){
		if(aux & 0x001){
			if (psuList[psuNum].psuStatus) {
				adjustRdac (psuNum, FIRST_SLAVE_DIR, psuList[psuNum].rdacValue);
				adjustRdac (psuNum, SECOND_SLAVE_DIR, psuList[psuNum].rdacValue);
			}
		}
		aux=aux>>1;
 	}
	OSTimeDly(TICKS_PER_SECOND/10); // retardo para ajuste de los reguladores
}



//ALARMS
void alarmTask ( void *p ){
	int generalCounter = 0;
	int psuNumAux = 0;
	while ( 1 )   // Loop forever
	   {	refreshAlarmCounters_100ms();
			generalCounter++;
			if ( generalCounter == TASK_TIMES_PER_SECOND ){				// Once every second
				generalCounter = 0;
				for (psuNumAux=0; psuNumAux<PSU_NUMBER; psuNumAux++){
					alarmCheck(psuNumAux);
				}
			}
			OSTimeDly( (int)(TICKS_PER_SECOND / TASK_TIMES_PER_SECOND) );   	// Critical, otherwise the lower tasks wont receive computing time.
	   }
}

void alarmCheck (int psuNum){
	int i;
	for (i=0; i<=3; i++){			// checks each alarm's status (Voltage/Current; Superior/Inferior)
		if(psuList[psuNum].alarmWatch[i] && psuList[psuNum].alarmStatus[i]){
			int j;
			for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){	// goes over each alarm protocol for the activated alarm
				if (psuList[psuNum].alarmProtocols[__(i&1,i&2, j)]){
					executeAlarmProtocol (psuNum, i&1, i&2, j);
				}
			}
		}
	}
}

void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum){
	int k;
	switch (protocolNum){		// (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
	case 0:
		WORD shutdown;
		shutdown = psuList[psuNum].alarmProtocolShutdown[_(limit_inf_sup, type_volt_corr)];
		for (k=0; k<12; k++){
			if (shutdown&1){
				// TODO: Apagar las fuentes de forma efectiva
				psuList[psuNum].releStatus = OFF;
				psuList[psuNum].psuStatus = OFF;
			}
			shutdown = shutdown >>1;
		}
		break;
	case 1:
			adjustRdac(psuNum, FIRST_SLAVE_DIR, psuList[psuNum].alarmProtocolVoltage[__(limit_inf_sup,type_volt_corr,FIRST_SLAVE)]);
			adjustRdac(psuNum, SECOND_SLAVE_DIR, psuList[psuNum].alarmProtocolVoltage[__(limit_inf_sup,type_volt_corr,SECOND_SLAVE)]);
		break;
	case 2:
			printf(ALARM_MESSAGE, psuNum, (type_volt_corr==0?"Voltage": "Current"), (limit_inf_sup==0?"Inferior": "Superior"));
			//Maybe add some other alarm output - left for future implementation
		break;
	}
}

void refreshAlarmCounters_100ms (void){
	int psuNum;
	for (psuNum=0; psuNum<12; psuNum++){
		readVoltageValue(psuNum);	// VOLTAGE READING

		if( psuList[psuNum].alarmWatch[_(INFERIOR,VOLTAGE)]){									// If INFERIOR VOLTAGE alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(INFERIOR,VOLTAGE)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(INFERIOR,VOLTAGE)]);
			if (psuList[psuNum].alarmLimitReached[_(INFERIOR,VOLTAGE)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]>=psuList[psuNum].alarmLimitTimes[_(INFERIOR,VOLTAGE)]){
					psuList[psuNum].alarmStatus[_(INFERIOR,VOLTAGE)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]=psuList[psuNum].alarmLimitTimes[_(INFERIOR,VOLTAGE)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(INFERIOR,VOLTAGE)] = false;
					}
				}
			}
		}

		if( psuList[psuNum].alarmWatch[_(SUPERIOR,VOLTAGE)]){									// If SUPERIOR VOLTAGE alarm is being watched
																										// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(SUPERIOR,VOLTAGE)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(SUPERIOR,VOLTAGE)]);
			if (psuList[psuNum].alarmLimitReached[_(SUPERIOR,VOLTAGE)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]>=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,VOLTAGE)]){
					psuList[psuNum].alarmStatus[_(SUPERIOR,VOLTAGE)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,VOLTAGE)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(SUPERIOR,VOLTAGE)] = false;
					}
				}
			}
		}


		readCurrentValue(psuNum);	//CURRENT READING

		if( psuList[psuNum].alarmWatch[_(INFERIOR,CURRENT)]){									// If INFERIOR CURRENT alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(INFERIOR,CURRENT)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(INFERIOR,CURRENT)]);
			if (psuList[psuNum].alarmLimitReached[_(INFERIOR,CURRENT)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]>=psuList[psuNum].alarmLimitTimes[_(INFERIOR,CURRENT)]){
					psuList[psuNum].alarmStatus[_(INFERIOR,CURRENT)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]=psuList[psuNum].alarmLimitTimes[_(INFERIOR,CURRENT)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(INFERIOR,CURRENT)] = false;
					}
				}
			}
		}
		if( psuList[psuNum].alarmWatch[_(SUPERIOR,CURRENT)]){									// If SUPERIOR CURRENT alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(SUPERIOR,CURRENT)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(SUPERIOR,CURRENT)]);
			if (psuList[psuNum].alarmLimitReached[_(SUPERIOR,CURRENT)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]>=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,CURRENT)]){
					psuList[psuNum].alarmStatus[_(SUPERIOR,CURRENT)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,CURRENT)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(SUPERIOR,CURRENT)] = false;
					}
				}
			}
		}
	}
}




//-------------------------------FLASH MEMORY-----------------------------------//
void LoadFlashValuesPSU (void){
	PSU_TYPE *pData = ( PSU_TYPE * ) GetUserParameters();
	memcpy (psuList, pData, sizeof(psuList));
	printf("Loaded values of psuList from Flash Mem\n");
}

int saveInFlashValuesPSU (void){
	int aux = SaveUserParameters( psuList, sizeof( psuList ) );
	printf("Saved values of psuList, for a total of %d Bytes in Flash Mem\n", aux);
	return aux;
}

void readFlashValuesPSU( int psuNum, PSU_TYPE *pData ){
	psuList[psuNum].releStatus=pData->releStatus;
	psuList[psuNum].psuStatus=pData->psuStatus;
	psuList[psuNum].rdacValue=pData->rdacValue;
	psuList[psuNum].bridgeI2CAdr=pData->bridgeI2CAdr;	// Probably required a different address for each psu
	memcpy(psuList[psuNum].alarmLimitValues, pData->alarmLimitValues, sizeof(psuList[psuNum].alarmLimitValues));
	memcpy(psuList[psuNum].alarmLimitTimes, pData->alarmLimitTimes, sizeof(psuList[psuNum].alarmLimitTimes));
	memcpy(psuList[psuNum].alarmProtocols, pData->alarmProtocols, sizeof(psuList[psuNum].alarmProtocols));
	memcpy(psuList[psuNum].alarmProtocolShutdown, pData->alarmProtocolShutdown, sizeof(psuList[psuNum].alarmProtocolShutdown));
	memcpy(psuList[psuNum].alarmProtocolVoltage, pData->alarmProtocolVoltage, sizeof(psuList[psuNum].alarmProtocolVoltage));
	memcpy(psuList[psuNum].alarmCounters, pData->alarmCounters, sizeof(psuList[psuNum].alarmCounters));
	memcpy(psuList[psuNum].alarmStatus, pData->alarmStatus, sizeof(psuList[psuNum].alarmStatus));
	memcpy(psuList[psuNum].alarmLimitReached, pData->alarmLimitReached, sizeof(psuList[psuNum].alarmLimitReached));
	memcpy(psuList[psuNum].alarmWatch, pData->alarmWatch, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt =  pData->rShunt;
	psuList[psuNum].divisorTension1 =  pData->divisorTension1;
	psuList[psuNum].divisorTension2 =  pData->divisorTension2;
	psuList[psuNum].rAdicPotDigital =  pData->rAdicPotDigital;
	psuList[psuNum].rDivisorPotDigital =  pData->rAdicPotDigital;
	psuList[psuNum].vOut =  pData->vOut;
	psuList[psuNum].cOut =  pData->cOut;
}

void defaultValuesPSU ( int psuNum ) {
	psuList[psuNum].releStatus=DEFAULT_releStatus;
	psuList[psuNum].psuStatus=DEFAULT_psuStatus;
	psuList[psuNum].rdacValue=DEFAULT_rdacValue;
	psuList[psuNum].bridgeI2CAdr=DEFAULT_bridgeI2CAdr;			// Probably required a different address for each psu
	float auxArray1[4]=DEFAULT_alarmLimitValues;
	memcpy(psuList[psuNum].alarmLimitValues, auxArray1, sizeof(psuList[psuNum].alarmLimitValues));
	int auxArray2[4]=DEFAULT_alarmLimitTimes;
	memcpy(psuList[psuNum].alarmLimitTimes, auxArray2, sizeof(psuList[psuNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_alarmProtocols;
	memcpy(psuList[psuNum].alarmProtocols, auxArray3, sizeof(psuList[psuNum].alarmProtocols));
	DWORD k = demux4to16(psuNum+1);
	int auxArray4[4]={k, k, k, k};
	memcpy(psuList[psuNum].alarmProtocolShutdown, auxArray4, sizeof(psuList[psuNum].alarmProtocolShutdown));
	float auxArray5[8]=DEFAULT_alarmProtocolVoltage;
	memcpy(psuList[psuNum].alarmProtocolVoltage, auxArray5, sizeof(psuList[psuNum].alarmProtocolVoltage));
	int auxArray6[4]=DEFAULT_alarmLimitTimes;
	memcpy(psuList[psuNum].alarmCounters, auxArray6, sizeof(psuList[psuNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_alarmStatus;
	memcpy(psuList[psuNum].alarmStatus, auxArray7, sizeof(psuList[psuNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_alarmLimitReached;
	memcpy(psuList[psuNum].alarmLimitReached, auxArray8, sizeof(psuList[psuNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_alarmWatch;
	memcpy(psuList[psuNum].alarmWatch, auxArray9, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt = DEFAULT_rShunt;
	psuList[psuNum].divisorTension1 = DEFAULT_divisorTension1;
	psuList[psuNum].divisorTension2 = DEFAULT_divisorTension2;
	psuList[psuNum].rAdicPotDigital = DEFAULT_rAdicPotDigital;
	psuList[psuNum].rDivisorPotDigital = DEFAULT_rDivisorPotDigital;
	psuList[psuNum].vOut = DEFAULT_vOut;
	psuList[psuNum].cOut = DEFAULT_cOut;
}

void printValuesPSU ( int psuNum ) {
	iprintf("PSU-Number: %d\n", psuNum);
	iprintf("- releStatus: %d\n",psuList[psuNum].releStatus);
	iprintf("- psuStatus: %d\n",psuList[psuNum].psuStatus);
	printf("- rdacValue: %.2f\n",psuList[psuNum].rdacValue);
	iprintf("- bridgeI2CDir: 0x%x\n",psuList[psuNum].bridgeI2CAdr);
	printf("- alarmLimitValues: {%.2f, %.2f, %.2f, %.2f}\n",
			psuList[psuNum].alarmLimitValues[0], psuList[psuNum].alarmLimitValues[1],
			psuList[psuNum].alarmLimitValues[2],psuList[psuNum].alarmLimitValues[3]);
	iprintf("- alarmLimitTimes: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitTimes[0], psuList[psuNum].alarmLimitTimes[1],
			psuList[psuNum].alarmLimitTimes[2],psuList[psuNum].alarmLimitTimes[3]);
	iprintf("- alarmProtocols: {%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d}\n",
			psuList[psuNum].alarmProtocols[0],psuList[psuNum].alarmProtocols[1],
			psuList[psuNum].alarmProtocols[2],psuList[psuNum].alarmProtocols[3],
			psuList[psuNum].alarmProtocols[4],psuList[psuNum].alarmProtocols[5],
			psuList[psuNum].alarmProtocols[6],psuList[psuNum].alarmProtocols[7],
			psuList[psuNum].alarmProtocols[8],psuList[psuNum].alarmProtocols[9],
			psuList[psuNum].alarmProtocols[10],psuList[psuNum].alarmProtocols[11]);
	iprintf("- alarmProtocolShutdown: {0x%x, 0x%x, 0x%x, 0x%x}\n",
			psuList[psuNum].alarmProtocolShutdown[0], psuList[psuNum].alarmProtocolShutdown[1],
			psuList[psuNum].alarmProtocolShutdown[2],psuList[psuNum].alarmProtocolShutdown[3]);
	printf("- alarmProtocolVoltage:{%.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f}\n",
			psuList[psuNum].alarmProtocolVoltage[0],psuList[psuNum].alarmProtocolVoltage[1],
			psuList[psuNum].alarmProtocolVoltage[2],psuList[psuNum].alarmProtocolVoltage[3],
			psuList[psuNum].alarmProtocolVoltage[4],psuList[psuNum].alarmProtocolVoltage[5],
			psuList[psuNum].alarmProtocolVoltage[6],psuList[psuNum].alarmProtocolVoltage[7]);
	iprintf("- alarmCounters: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmCounters[0], psuList[psuNum].alarmCounters[1],
			psuList[psuNum].alarmCounters[2],psuList[psuNum].alarmCounters[3]);
	iprintf("- alarmStatus: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmStatus[0], psuList[psuNum].alarmStatus[1],
			psuList[psuNum].alarmStatus[2],psuList[psuNum].alarmStatus[3]);
	iprintf("- alarmLimitReached: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitReached[0], psuList[psuNum].alarmLimitReached[1],
			psuList[psuNum].alarmLimitReached[2],psuList[psuNum].alarmLimitReached[3]);
	iprintf("- alarmWatch: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmWatch[0], psuList[psuNum].alarmWatch[1],
			psuList[psuNum].alarmWatch[2],psuList[psuNum].alarmWatch[3]);
	iprintf("- rShunt: %d\n",psuList[psuNum].rShunt);
	iprintf("- divisorTension1: %s %d\n",psuList[psuNum].divisorTension1);
	iprintf("- divisorTension2: %d\n",psuList[psuNum].divisorTension2);
	iprintf("- rAdicPotDigital: %d\n",psuList[psuNum].rAdicPotDigital);
	iprintf("- rDivisorPotDigital: %d\n",psuList[psuNum].rDivisorPotDigital);
	iprintf("- vOut: %d\n",psuList[psuNum].vOut);
	iprintf("- cOut: %d\n",psuList[psuNum].cOut);
}
//---------------------------------------Not Being Used---------------------------------//


// conecta el rel� de la fuente y activa led Out On. Modifica fuente[].fuenteOn

void connectPSU(int psuNum){
	BYTE mascara,dato;
	psuList[psuNum].psuStatus=true; // modificar var en RAM
	psuList[psuNum].ReadyToConnect=false; // para no volverla a encender
	//TODO: initialize reles
	/*
	if (numFuente<8){
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(1,0xFF,mascara);
	} else {
		numFuente=numFuente-8;
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(2,0xFF,mascara);
	}
	// activar LED OUT ON
	dato=0x80;
	mascara=!dato;
	EscribeEnDriver(2,dato,mascara);
	*/
}


void turnONPSUs(void){
	int i;
	for (i=0;i<12;i++){
		if (psuList[i].ReadyToConnect==true && psuList[i].psuStatus==false) {
			// la fuente esta apagada y lista para encender
			connectPSU(i);
		}
	}
}


// se encarga de preparar encendido retardado de las fuentes.Las enciende el monitor
void prepareTurnONPSUs( DWORD selectPSUs ){
	if (!powerONProcess){
		powerONticks=0;
		powerONProcess=true;
	}
		int i;
		for (i=0; i<PSU_NUMBER; i++){
			psuList[i].initializationTimer
		}

	}

	while (powerONticks<TICKS_PER_SECOND){
		powerONticks++;
		OSTimeDly(TICKS_PER_SECOND);
	}


}
/*


// desconecta el rel� de la fuente si necesario (configurable ante situacion alarma)
// envia mensaje alarma si necesario (configurable ante situacion alarma)
void DesconectarFuente(int numFuente){
	BYTE mascara,dato;
	extern BYTE driverA; // declarar la variable definida comunicaciones.cpp
	extern BYTE driverB; // declarar la variable definida comunicaciones.cpp

	if (numFuente<8){
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(1,0x00,mascara);
	} else {
		numFuente=numFuente-8;
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(2,0x00,mascara);
	}
	// comprobar si se ha de desactivar  led Out On
	if (driverA==0) {
		 if ((driverB & 0x0F)==0){
			 dato=0x80;
			 mascara=!dato;
			 EscribeEnDriver(2,0,mascara);
		 }
	}
}


// conecta el rel� de la fuente y activa led Out On. Modifica fuente[].fuenteOn
void ConectarFuente(int numFuente){
	BYTE mascara,dato;
	fuente[numFuente].fuenteOn=true; // modificar var en RAM
	fuente[numFuente].ReadyToConnect=false; // para no volverla a encender
	if (numFuente<8){
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(1,0xFF,mascara);
	} else {
		numFuente=numFuente-8;
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(2,0xFF,mascara);
	}
	// activar LED OUT ON
	dato=0x80;
	mascara=!dato;
	EscribeEnDriver(2,dato,mascara);
}
*/
