/*
 * GeneralLibrary.cpp
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#include "GeneralLibrary.h"
#include <string.h>

//-------------------------------------------------------------------------------------------------------
// mergeBuffer writes size bytes from buf2 to buf1
//-------------------------------------------------------------------------------------------------------
	void mergeBuffer(BYTE buf1[], BYTE buf2[], int size){
		BYTE* paux1 = buf1;
		BYTE* paux2 = buf2;
		for (int i = 0; i<size; i++){
			*paux1 = *paux2;
			paux2++; paux1++;
		}

	}

//-------------------------------------------------------------------------------------------------------
// printBuffer displays the contents of a buffer or array using iprintf
//-------------------------------------------------------------------------------------------------------
	void printBuffer(BYTE buf1[], uint bufferSize){
		iprintf(" |[");
		for (uint i = 0; i<bufferSize; i++){
			iprintf(", %x ", buf1[i]);
		}
		iprintf("]| ");
	}

//-------------------------------------------------------------------------------------------------------
// Ascii2Byte converts the first two ASCII chars of a string to a single hex value
//-------------------------------------------------------------------------------------------------------
	BYTE Ascii2Byte( char* buf ){
	   char conv[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
	   BYTE temp = 0;
	   for( int i = 0; i<16; i++)
		  if ( toupper(buf[1]) == conv[i] )
			 temp = i;
	   for( int i = 0; i<16; i++)
		  if ( toupper(buf[0]) == conv[i] )
			 temp |= i<<4;
	   return temp;
	}


//-------------------------------------------------------------------------------------------------------
// intToBuffer - adds an int value (previously converted to string) to a buffer, with a # sign as separator
//-------------------------------------------------------------------------------------------------------
	char *  intToBuffer(char * buffer, int data){
		char buf2[10];
		char *f=buf2;
		strcat(buffer,"#");
		itoa(data,f);
		strcat(buffer,f);
		return buffer;
	}


//-------------------------------------------------------------------------------------------------------
// itoa - convert n to characters in s
//-------------------------------------------------------------------------------------------------------
	void itoa(int n, char s[]){
	     int i, sign;
	     if ((sign = n) < 0)  // record sign
	         n = -n;          // make n positive
	     i = 0;
	     do {       // generate digits in reverse order
	         s[i++] = n % 10 + '0';   // get next digit
	     } while ((n /= 10) > 0);     // delete it
	     if (sign < 0)
	         s[i++] = '-';
	     s[i] = '\0';
	     reverse(s);
	}


//-------------------------------------------------------------------------------------------------------
// reverse:  reverse string s in place
//-------------------------------------------------------------------------------------------------------
	void reverse(char s[]){
	     int i, j;
	     char c;
	     for (i = 0, j = strlen(s)-1; i<j; i++, j--) {
	         c = s[i];
	         s[i] = s[j];
	         s[j] = c;
	     }
	}


//-------------------------------------------------------------------------------------------------------
// reverse:  reverse string s in place
//-------------------------------------------------------------------------------------------------------
	DWORD demux4to16 (int a){
		DWORD r = 0;
		if (a<0){
			r = (0x1 << a);
		}
		return r;
	}
