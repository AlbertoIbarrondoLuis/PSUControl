/*
 * PSULibrary.cpp
 *
 *  Created on: 04-feb-2015
 *      Author: Alberto
*/


#include "predef.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "RDACLibrary.h"
#include "I2CLibrary.h"
#include "PSULibrary.h"
#include "defineConstants.cpp"

// Variables
BOOL powerONProcess = true; 	// indica si estamos en proceso de encendido
char bufferMOD5270[80]; 		// buffer mensajes tx y rx con MOD5270 via UART
int decimasDesdeArranque=0; 	// decdimas de segundo desde que se ordena arranque para encendido retardado

PSU_TYPE psuList[PSU_NUMBER];


void alarmCheck (int psuNum){
	int i;
	for (i=0; i<=3; i++){			// checks each alarm's status (Voltage/Current; Superior/Inferior)
		if(psuList[psuNum].alarmWatch[i] && psuList[psuNum].alarmStatus[i]){
			int j;
			for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){	// goes over each alarm protocol for the activated alarm
				if (psuList[psuNum].alarmProtocols[__(i&1,i&2, j)]){
					executeAlarmProtocol (psuNum, i&1, i&2, j);
				}
			}
		}
	}

}

void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum){
	int k;
	switch (protocolNum){		// (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
	case 0:
		WORD shutdown;
		shutdown = psuList[psuNum].alarmProtocolShutdown[_(limit_inf_sup, type_volt_corr)];
		for (k=0; k<12; k++){
			if (shutdown&1){
				// TODO: Apagar las fuentes de forma efectiva
				psuList[psuNum].releStatus = OFF;
				psuList[psuNum].psuStatus = OFF;
			}
			shutdown = shutdown >>1;
		}
		break;
	case 1:
			adjustRdac(psuNum, FIRST_SLAVE_DIR, psuList[psuNum].alarmProtocolVoltage[__(limit_inf_sup,type_volt_corr,FIRST_SLAVE)]);
			adjustRdac(psuNum, SECOND_SLAVE_DIR, psuList[psuNum].alarmProtocolVoltage[__(limit_inf_sup,type_volt_corr,SECOND_SLAVE)]);
		break;
	case 2:
			printf(ALARM_MESSAGE, psuNum, (type_volt_corr==0?"Voltage": "Current"), (limit_inf_sup==0?"Inferior": "Superior"));
			//Maybe add some other alarm output - left for future implementation
		break;
	}
}

void adjustRdac (int psuNum, int slave, float Voltage){
	int desiredValue = voltToNum(Voltage, psuList[psuNum].rShunt);
	setRegRDAC(desiredValue, slave, psuList[psuNum].bridgeI2CDir);
	int setValue = getRegRDAC( slave, psuList[psuNum].bridgeI2CDir);
	if (desiredValue==setValue){
		psuList[psuNum].rdacValue = Voltage;
	}
	else{
		printf("ERROR: RDAC value %d not properly configured on PSU %d. Value %d set instead", desiredValue, psuNum, setValue);
	}
}

void initializePSUs(int selectPSUs ){	// PSUs marked with his corresponding bit to 1 will be switched on.
	int psuNum; int aux = selectPSUs;
	// ajustar fuentes
	for (psuNum=0;psuNum<PSU_NUMBER;psuNum++){
		if(aux & 0x001){
			if (psuList[psuNum].psuStatus) {
				adjustRdac (psuNum, FIRST_SLAVE_DIR, psuList[psuNum].rdacValue);
				adjustRdac (psuNum, SECOND_SLAVE_DIR,psuList[psuNum].rdacValue);
			}
		}
		aux=aux>>1;
 	}
	OSTimeDly(TICKS_PER_SECOND); // retardo para ajuste de los reguladores
}

void refreshAlarmCounters_100ms (void){
	int psuNum;
	for (psuNum=0; psuNum<12; psuNum++){
		readVoltageValue(psuNum);	// VOLTAGE READING

		if( psuList[psuNum].alarmWatch[_(INFERIOR,VOLTAGE)]){									// If INFERIOR VOLTAGE alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(INFERIOR,VOLTAGE)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(INFERIOR,VOLTAGE)]);
			if (psuList[psuNum].alarmLimitReached[_(INFERIOR,VOLTAGE)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]>=psuList[psuNum].alarmLimitTimes[_(INFERIOR,VOLTAGE)]){
					psuList[psuNum].alarmStatus[_(INFERIOR,VOLTAGE)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]=psuList[psuNum].alarmLimitTimes[_(INFERIOR,VOLTAGE)];
				}																				// Sets the counter to limit value
			}
			else{																			// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(INFERIOR,VOLTAGE)] = false;
					}
				}
			}
		}

		if( psuList[psuNum].alarmWatch[_(SUPERIOR,VOLTAGE)]){									// If SUPERIOR VOLTAGE alarm is being watched
																										// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(SUPERIOR,VOLTAGE)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(SUPERIOR,VOLTAGE)]);
			if (psuList[psuNum].alarmLimitReached[_(SUPERIOR,VOLTAGE)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]>=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,VOLTAGE)]){
					psuList[psuNum].alarmStatus[_(SUPERIOR,VOLTAGE)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,VOLTAGE)];
				}																				// Sets the counter to limit value
			}
			else{																			// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(SUPERIOR,VOLTAGE)] = false;
					}
				}
			}
		}


		readCurrentValue(psuNum);	//CURRENT READING

		if( psuList[psuNum].alarmWatch[_(INFERIOR,CURRENT)]){									// If INFERIOR CURRENT alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(INFERIOR,CURRENT)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(INFERIOR,CURRENT)]);
			if (psuList[psuNum].alarmLimitReached[_(INFERIOR,CURRENT)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]>=psuList[psuNum].alarmLimitTimes[_(INFERIOR,CURRENT)]){
					psuList[psuNum].alarmStatus[_(INFERIOR,CURRENT)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]=psuList[psuNum].alarmLimitTimes[_(INFERIOR,CURRENT)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(INFERIOR,CURRENT)] = false;
					}
				}
			}
		}
		if( psuList[psuNum].alarmWatch[_(SUPERIOR,CURRENT)]){									// If SUPERIOR CURRENT alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(SUPERIOR,CURRENT)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(SUPERIOR,CURRENT)]);
			if (psuList[psuNum].alarmLimitReached[_(SUPERIOR,CURRENT)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]>=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,CURRENT)]){
					psuList[psuNum].alarmStatus[_(SUPERIOR,CURRENT)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,CURRENT)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(SUPERIOR,CURRENT)] = false;
					}
				}
			}
		}
	}
}

void readVoltageValue(int psuNum){
	float value = 0;
	selectPSUMux( psuNum, VOLTAGE );
	//TODO: Check the voltage using ADC and convert it to float.
	psuList[psuNum].vOut = value;
}

void readCurrentValue(int psuNum){
	float value = 0;
	selectPSUMux( psuNum, CURRENT );
	//TODO: Check the current using ADC and convert it to float.
	psuList[psuNum].cOut = value;
}

void selectPSUMux( int psuNum, BOOL volt_curr){
	// TODO: Change muxes to allow ADC to get the desired PSU measurement.
}

int initializeValuesPSU(void){
	 int saveParameters=FALSE;
	 int i=0;
	 PSU_TYPE *pData = ( PSU_TYPE * ) GetUserParameters();
	 PSU_TYPE *ppsuList = psuList;
	 for (i=0;i<PSU_NUMBER;i++){
	      if ( pData->VerifyKey != VERIFY_KEY ){ 			// Incorrect Data
	    	  defaultValuesPSU(i);
	    	  saveParameters=TRUE;						// Toggle comment to allow value updating as soon as an invalid key is detected
          }else {											// Correct data
        	  // readFlashValuesPSU(i,pData); 					in case memory copying didn't work (which currently does)
        	  memcpy (ppsuList, pData, sizeof(PSU_TYPE));
		  }
	      pData++; ppsuList++;								//Next PSU reading
	  }
     if (saveParameters){
    	 saveParameters = saveInFlashValuesPSU ();
     }
     return saveParameters;
}

void LoadFlashValuesPSU (void){
	PSU_TYPE *pData = ( PSU_TYPE * ) GetUserParameters();
	memcpy (psuList, pData, sizeof(psuList));
	printf("Loaded values of psuList from Flash Mem\n");
}

int saveInFlashValuesPSU (void){
	int aux = SaveUserParameters( psuList, sizeof( psuList ) );
	printf("Saved values of psuList, for a total of %d Bytes in Flash Mem\n", aux);
	return aux;
}

void readFlashValuesPSU( int psuNum, PSU_TYPE *pData ){
	psuList[psuNum].releStatus=pData->releStatus;
	psuList[psuNum].psuStatus=pData->psuStatus;
	psuList[psuNum].rdacValue=pData->rdacValue;
	psuList[psuNum].bridgeI2CDir=pData->bridgeI2CDir;	// Probably required a different address for each psu
	memcpy(psuList[psuNum].alarmLimitValues, pData->alarmLimitValues, sizeof(psuList[psuNum].alarmLimitValues));
	memcpy(psuList[psuNum].alarmLimitTimes, pData->alarmLimitTimes, sizeof(psuList[psuNum].alarmLimitTimes));
	memcpy(psuList[psuNum].alarmProtocols, pData->alarmProtocols, sizeof(psuList[psuNum].alarmProtocols));
	memcpy(psuList[psuNum].alarmProtocolShutdown, pData->alarmProtocolShutdown, sizeof(psuList[psuNum].alarmProtocolShutdown));
	memcpy(psuList[psuNum].alarmProtocolVoltage, pData->alarmProtocolVoltage, sizeof(psuList[psuNum].alarmProtocolVoltage));
	memcpy(psuList[psuNum].alarmCounters, pData->alarmCounters, sizeof(psuList[psuNum].alarmCounters));
	memcpy(psuList[psuNum].alarmStatus, pData->alarmStatus, sizeof(psuList[psuNum].alarmStatus));
	memcpy(psuList[psuNum].alarmLimitReached, pData->alarmLimitReached, sizeof(psuList[psuNum].alarmLimitReached));
	memcpy(psuList[psuNum].alarmWatch, pData->alarmWatch, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt =  pData->rShunt;
	psuList[psuNum].divisorTension1 =  pData->divisorTension1;
	psuList[psuNum].divisorTension2 =  pData->divisorTension2;
	psuList[psuNum].rAdicPotDigital =  pData->rAdicPotDigital;
	psuList[psuNum].rDivisorPotDigital =  pData->rAdicPotDigital;
	psuList[psuNum].vOut =  pData->vOut;
	psuList[psuNum].cOut =  pData->cOut;
}

void defaultValuesPSU ( int psuNum ) {
	psuList[psuNum].releStatus=DEFAULT_releStatus;
	psuList[psuNum].psuStatus=DEFAULT_psuStatus;
	psuList[psuNum].rdacValue=DEFAULT_rdacValue;
	psuList[psuNum].bridgeI2CDir=DEFAULT_bridgeI2CDir;			// Probably required a different address for each psu
	float auxArray1[4]=DEFAULT_alarmLimitValues;
	memcpy(psuList[psuNum].alarmLimitValues, auxArray1, sizeof(psuList[psuNum].alarmLimitValues));
	int auxArray2[4]=DEFAULT_alarmLimitTimes;
	memcpy(psuList[psuNum].alarmLimitTimes, auxArray2, sizeof(psuList[psuNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_alarmProtocols;
	memcpy(psuList[psuNum].alarmProtocols, auxArray3, sizeof(psuList[psuNum].alarmProtocols));
	DWORD k = demux4to16(psuNum+1);
	int auxArray4[4]={k, k, k, k};
	memcpy(psuList[psuNum].alarmProtocolShutdown, auxArray4, sizeof(psuList[psuNum].alarmProtocolShutdown));
	float auxArray5[8]=DEFAULT_alarmProtocolVoltage;
	memcpy(psuList[psuNum].alarmProtocolVoltage, auxArray5, sizeof(psuList[psuNum].alarmProtocolVoltage));
	int auxArray6[4]=DEFAULT_alarmLimitTimes;
	memcpy(psuList[psuNum].alarmCounters, auxArray6, sizeof(psuList[psuNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_alarmStatus;
	memcpy(psuList[psuNum].alarmStatus, auxArray7, sizeof(psuList[psuNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_alarmLimitReached;
	memcpy(psuList[psuNum].alarmLimitReached, auxArray8, sizeof(psuList[psuNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_alarmWatch;
	memcpy(psuList[psuNum].alarmWatch, auxArray9, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt = DEFAULT_rShunt;
	psuList[psuNum].divisorTension1 = DEFAULT_divisorTension1;
	psuList[psuNum].divisorTension2 = DEFAULT_divisorTension2;
	psuList[psuNum].rAdicPotDigital = DEFAULT_rAdicPotDigital;
	psuList[psuNum].rDivisorPotDigital = DEFAULT_rDivisorPotDigital;
	psuList[psuNum].vOut = DEFAULT_vOut;
	psuList[psuNum].cOut = DEFAULT_cOut;
}

void printValuesPSU ( int psuNum ) {
	iprintf("PSU-Number: %d\n", psuNum);
	iprintf("- releStatus: %d\n",psuList[psuNum].releStatus);
	iprintf("- psuStatus: %d\n",psuList[psuNum].psuStatus);
	printf("- rdacValue: %.2f\n",psuList[psuNum].rdacValue);
	iprintf("- bridgeI2CDir: 0x%x\n",psuList[psuNum].bridgeI2CDir);
	printf("- alarmLimitValues: {%.2f, %.2f, %.2f, %.2f}\n",
			psuList[psuNum].alarmLimitValues[0], psuList[psuNum].alarmLimitValues[1],
			psuList[psuNum].alarmLimitValues[2],psuList[psuNum].alarmLimitValues[3]);
	iprintf("- alarmLimitTimes: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitTimes[0], psuList[psuNum].alarmLimitTimes[1],
			psuList[psuNum].alarmLimitTimes[2],psuList[psuNum].alarmLimitTimes[3]);
	iprintf("- alarmProtocols: {%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d}\n",
			psuList[psuNum].alarmProtocols[0],psuList[psuNum].alarmProtocols[1],
			psuList[psuNum].alarmProtocols[2],psuList[psuNum].alarmProtocols[3],
			psuList[psuNum].alarmProtocols[4],psuList[psuNum].alarmProtocols[5],
			psuList[psuNum].alarmProtocols[6],psuList[psuNum].alarmProtocols[7],
			psuList[psuNum].alarmProtocols[8],psuList[psuNum].alarmProtocols[9],
			psuList[psuNum].alarmProtocols[10],psuList[psuNum].alarmProtocols[11]);
	iprintf("- alarmProtocolShutdown: {0x%x, 0x%x, 0x%x, 0x%x}\n",
			psuList[psuNum].alarmProtocolShutdown[0], psuList[psuNum].alarmProtocolShutdown[1],
			psuList[psuNum].alarmProtocolShutdown[2],psuList[psuNum].alarmProtocolShutdown[3]);
	printf("- alarmProtocolVoltage:{%.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f}\n",
			psuList[psuNum].alarmProtocolVoltage[0],psuList[psuNum].alarmProtocolVoltage[1],
			psuList[psuNum].alarmProtocolVoltage[2],psuList[psuNum].alarmProtocolVoltage[3],
			psuList[psuNum].alarmProtocolVoltage[4],psuList[psuNum].alarmProtocolVoltage[5],
			psuList[psuNum].alarmProtocolVoltage[6],psuList[psuNum].alarmProtocolVoltage[7]);
	iprintf("- alarmCounters: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmCounters[0], psuList[psuNum].alarmCounters[1],
			psuList[psuNum].alarmCounters[2],psuList[psuNum].alarmCounters[3]);
	iprintf("- alarmStatus: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmStatus[0], psuList[psuNum].alarmStatus[1],
			psuList[psuNum].alarmStatus[2],psuList[psuNum].alarmStatus[3]);
	iprintf("- alarmLimitReached: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitReached[0], psuList[psuNum].alarmLimitReached[1],
			psuList[psuNum].alarmLimitReached[2],psuList[psuNum].alarmLimitReached[3]);
	iprintf("- alarmWatch: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmWatch[0], psuList[psuNum].alarmWatch[1],
			psuList[psuNum].alarmWatch[2],psuList[psuNum].alarmWatch[3]);
	iprintf("- rShunt: %d\n",psuList[psuNum].rShunt);
	iprintf("- divisorTension1: %d\n",psuList[psuNum].divisorTension1);
	iprintf("- divisorTension2: %d\n",psuList[psuNum].divisorTension2);
	iprintf("- rAdicPotDigital: %d\n",psuList[psuNum].rAdicPotDigital);
	iprintf("- rDivisorPotDigital: %d\n",psuList[psuNum].rDivisorPotDigital);
	iprintf("- vOut: %d\n",psuList[psuNum].vOut);
	iprintf("- cOut: %d\n",psuList[psuNum].cOut);
}
//---------------------------------------Not Being Used---------------------------------//


// conecta el rel� de la fuente y activa led Out On. Modifica fuente[].fuenteOn

void ConectarFuente(int psuNum){
	BYTE mascara,dato;
	psuList[psuNum].psuStatus=true; // modificar var en RAM
	psuList[psuNum].ReadyToConnect=false; // para no volverla a encender
	//TODO: initialize reles
	/*
	if (numFuente<8){
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(1,0xFF,mascara);
	} else {
		numFuente=numFuente-8;
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(2,0xFF,mascara);
	}
	// activar LED OUT ON
	dato=0x80;
	mascara=!dato;
	EscribeEnDriver(2,dato,mascara);
	*/
}


void turnONPSUs(void){
	int i;
	for (i=0;i<12;i++){
		if (psuList[i].ReadyToConnect==true && psuList[i].psuStatus==false) {
			// la fuente esta apagada y lista para encender
			ConectarFuente(i);
		}
	}
}


// control y monitorizacion de la fuente retorna 0 si OK y si no retorna numFuente con alarma
int MonitoryControl(int numFuente){
	int i;
	turnONPSUs(); // comprobar si hay que encender alguna fuente
	for (i=0;i<12;i++){
		if (psuList[i].psuStatus) {
			/*
			MonitorTension(i);
			MonitorCorriente(i);*/
		}
	}
	return 0;
}

//TODO: lector CAD usando el codigo del ejemplo


/*



#define VERIFY_KEY (0x48666051)  // NV Settings key code







// realiza lectura de tensi�n y gestiona alarmas
void MonitorTension(int numFuente){
	LeerTensionFuente(numFuente); // lectura tension
	if (fuente[numFuente].vigilarVolts) { // se ha de supervisar el voltaje
		if (TensionEnLimites(numFuente)){ // fuente en limites
			if (fuente[numFuente].segsSinAlarmaVolts<=0 && fuente[numFuente].alarmaVolts) { // cancelar condicion alarma
				fuente[numFuente].segsAlarmaVolts=0; // restablecer contador
				fuente[numFuente].alarmaVolts=false;
				fuente[numFuente].alarma=false;
			}
		} else { //fuente fuera de l�mites
			if (fuente[numFuente].segsAlarmaVolts>=fuente[numFuente].filtroAlarmaVolts) { //disparar condicion alarma
				fuente[numFuente].segsSinAlarmaVolts=fuente[numFuente].filtroSinAlarmaVolts; // restablecer contador
				fuente[numFuente].alarmaVolts=true;
				fuente[numFuente].alarma=true;
				TrataAlarma(numFuente);
			}
		}
	}
	if (fuente[numFuente].autorregVolts) RegulacionVolts(numFuente);
}


// realiza lectura de corriente y gestiona alarmas
void MonitorCorriente(int numFuente){
	LeerCorrienteFuente(numFuente); // lectura corriente
	if (fuente[numFuente].vigilarCurrent) { // se ha de supervisar el corriente
		if (TensionEnLimites(numFuente)){ // fuente en limites
			if (fuente[numFuente].segsSinAlarmaCurr<=0 && fuente[numFuente].alarmaCurrent) { // cancelar condicion alarma
				fuente[numFuente].segsAlarmaCurr=0; // restablecer contador
				fuente[numFuente].alarmaCurrent=false;
				fuente[numFuente].alarma=false;
			}
		} else { //fuente fuera de l�mites
			if (fuente[numFuente].segsAlarmaCurr>=fuente[numFuente].filtroAlarmaCurrent) { //disparar condicion alarma
				fuente[numFuente].segsSinAlarmaCurr=fuente[numFuente].filtroSinAlarmaCurr; // restablecer contador
				fuente[numFuente].alarmaCurrent=true;
				fuente[numFuente].alarma=true;
				TrataAlarma(numFuente);
			}
		}
	}
}

// pendiente de definir comportamiento
void RegulacionVolts(int numFuente){


}
// interrumpe cada segundo. Actualiza los temporizadores de alarma en tensi�n
BOOL ActualizaTemporizadoresAlarmaTension(void){
	int i;
	for (i=0;i<12;i++){
		if(!fuente[i].TransicionEn_TensionEnLimites){ // nos fiamos del estado por estar estable
			if(fuente[i].tensionEnLimites){ // fuente ok t_odo el tiempo
				if(fuente[i].segsSinAlarmaVolts>0) fuente[i].segsSinAlarmaVolts--; // decrementar timer anulacion alarma
			} else {
				if(fuente[i].segsAlarmaVolts<fuente[i].filtroAlarmaVolts) fuente[i].segsAlarmaVolts++; // incrementar timer anulacion alarma
			}
		} else { // situacion inestable
			fuente[i].TransicionEn_TensionEnLimites=false; // limpiar flag de transici�n
			// si estabamos descontando timer para liberar alarma volver a reiniciar
			if(fuente[i].alarmaVolts){
				fuente[i].segsSinAlarmaVolts=fuente[i].filtroSinAlarmaVolts; // restablecer contador
			} else{
				fuente[i].segsAlarmaVolts=0; // como no se mantuvo cte alarma se reinicia contador
			}
		}
	}
	return true;
}

// interrumpe cada segundo. Actualiza los temporizadores de alarma en corriente
BOOL ActualizaTemporizadoresAlarmaCurrent(void){
	int i;
	for (i=0;i<12;i++){
		if(!fuente[i].TransicionEn_CurrEnLimites){ // nos fiamos del estado por estar estable
			if(fuente[i].currentEnLimites){ // fuente ok t_odo el tiempo
				if(fuente[i].segsSinAlarmaCurr>0) fuente[i].segsSinAlarmaCurr--; // decrementar timer anulacion alarma
			} else {
				if(fuente[i].segsAlarmaCurr<fuente[i].filtroAlarmaCurrent) fuente[i].segsAlarmaCurr++; // incrementar timer anulacion alarma
			}
		} else { // situacion inestable
			fuente[i].TransicionEn_CurrEnLimites=false; // limpiar flag de transici�n
			// si estabamos descontando timer para liberar alarma volver a reiniciar
			if(fuente[i].alarmaCurrent){
				fuente[i].segsSinAlarmaCurr=fuente[i].filtroSinAlarmaCurr; // restablecer contador
			} else {
				fuente[i].segsAlarmaCurr=0; // cmo no se mantuvo cte alarma se reinicia contador
			}
		}
	}
	return true;
}

// se encarga de preparar encendido retardado de las fuentes.Las enciende el monitor
void ActualizaPreparadoEncendido(void){
	int i;
	if (enProcesoEncendidoFuentes){
		decimasDesdeArranque++;
		if(decimasDesdeArranque <= encendidoFuente[11][0]){ // todavia en proceso de encendido
			enProcesoEncendidoFuentes=true;
			// preparar encendido de las fuentes con esta temporizacion
			for (i=0 ; i<12 ; i++){
				if (decimasDesdeArranque >= fuente[i].temporizadoEncendido) fuente[i].ReadyToConnect=true; //preparada var para que monitro haga el encendido
			}
		} else {
			enProcesoEncendidoFuentes=false; // se termin� de encender la ultima fuente
		}
	}
}

// rutina de atenci�n de alarmas en fuentes
// desconecta la fuente. Envia alarma y desconecta fuentes dependientes
void TrataAlarma(int numFuente){
	int i;
	if (fuente[numFuente].desconSiAlarmCurr && fuente[numFuente].alarmaCurrent){
		DesconectarFuente(numFuente); // desconectar fuente con alarma
		if (fuente[numFuente].enviarAlarmas) EnviaAlarma(numFuente);
	}
	if (fuente[numFuente].desconSiAlarmVolts && fuente[numFuente].alarmaVolts){
		DesconectarFuente(numFuente); // desconectar fuente con alarma
		if (fuente[numFuente].enviarAlarmas) EnviaAlarma(numFuente);
	}

	// desconectar el resto de las fuentes
	for (i=0;i<12;i++){
		if (fuente[i].apagarSiAlarmaEnOtraFuente) DesconectarFuente(numFuente);
	}
}


// desconecta el rel� de la fuente si necesario (configurable ante situacion alarma)
// envia mensaje alarma si necesario (configurable ante situacion alarma)
void DesconectarFuente(int numFuente){
	BYTE mascara,dato;
	extern BYTE driverA; // declarar la variable definida comunicaciones.cpp
	extern BYTE driverB; // declarar la variable definida comunicaciones.cpp

	if (numFuente<8){
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(1,0x00,mascara);
	} else {
		numFuente=numFuente-8;
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(2,0x00,mascara);
	}
	// comprobar si se ha de desactivar  led Out On
	if (driverA==0) {
		 if ((driverB & 0x0F)==0){
			 dato=0x80;
			 mascara=!dato;
			 EscribeEnDriver(2,0,mascara);
		 }
	}
}


// conecta el rel� de la fuente y activa led Out On. Modifica fuente[].fuenteOn
void ConectarFuente(int numFuente){
	BYTE mascara,dato;
	fuente[numFuente].fuenteOn=true; // modificar var en RAM
	fuente[numFuente].ReadyToConnect=false; // para no volverla a encender
	if (numFuente<8){
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(1,0xFF,mascara);
	} else {
		numFuente=numFuente-8;
		dato=DemuxTresOcho(numFuente);
		mascara=!dato;
		EscribeEnDriver(2,0xFF,mascara);
	}
	// activar LED OUT ON
	dato=0x80;
	mascara=!dato;
	EscribeEnDriver(2,dato,mascara);
}

// actualizar con los nuevos campos!!!
//lee los datos de una fuente de flash y los mete en RAM
void LeeFuente(int i,tipo *pFuente){
		//fuente[i]=*pFuente; // esta instrucci�n deber�a sustituir las siguientes
		  fuente[i].potInicial=pFuente->potInicial; // m�ximo 256
		  fuente[i].fuenteOnInicio = pFuente->fuenteOnInicio;
		  fuente[i].maxCurrent=pFuente->maxCurrent;
		  fuente[i].minCurrent=pFuente->minCurrent;
		//  fuente[i].FiltroAlarmaCurrent=pFuente->FiltroAlarmaCurrent;
		//  fuente[i].FiltroSinAlarmaCurrent=pFuente->FiltroSinAlarmaCurrent;
		//  fuente[i].segsAlarmaCurrent=pFuente->segsSinAlarmaCurrent;
		//  fuente[i].segsSinAlarmaCurrent=pFuente->segsSinAlarmaCurrent;
		  fuente[i].TransicionEn_CurrEnLimites=pFuente->TransicionEn_CurrEnLimites;
		  fuente[i].currentEnLimites=pFuente->currentEnLimites;
		  fuente[i].alarmaCurrent =pFuente->alarmaCurrent;
		//  fuente[i].vigilarCurrent=pFuente->FiltroSinAlarmaCurrent;
		  fuente[i].maxVolts=pFuente->maxVolts;
		  fuente[i].minVolts=pFuente->minVolts;
		  //fuente[i].segsAlarmaVolts=pFuente->segsAlarmaVolts;
		  fuente[i].alarmaVolts =pFuente->alarmaVolts;
		  fuente[i].enviarAlarmas = pFuente->enviarAlarmas;
		  fuente[i].maxPot=pFuente->maxPot;
		  fuente[i].minPot=pFuente->minPot;
		  fuente[i].autorregVolts = pFuente->autorregVolts;
		  fuente[i].apagarSiAlarmaEnOtraFuente =pFuente->apagarSiAlarmaEnOtraFuente;
		  fuente[i].rShunt=pFuente->rShunt;
		  fuente[i].divisorTension1=pFuente->divisorTension1;
		  fuente[i].divisorTension2=pFuente->divisorTension2;
		  fuente[i].rAdicPotDigital=pFuente->rAdicPotDigital;
		  fuente[i].rDivisorPotDigital=pFuente->rDivisorPotDigital;
		    // variables
		  fuente[i].alarma = pFuente->alarma;
		  fuente[i].vout=pFuente->vout;
		  fuente[i].current=pFuente->current;
		  fuente[i]. pot=pFuente->pot;
		  fuente[i].fuenteOn= pFuente->fuenteOn;
		  fuente[i].voutMedia=pFuente->voutMedia;
		  fuente[i].currentMedia=pFuente->currentMedia;
		  fuente[i].VerifyKey =pFuente->VerifyKey;
}


// lee la BBDD de flash de todas las fuentes y verifica que no este corrompida.
// Si lo esta inicializa con datos por defecto para la fuente da�ada (alarma y apagada)
// y graba los datos de todas las fuentes en flash. Retorna true si ha habido error en la BBDD
int LeerParametrosFuente(void){
	 BOOL grabar=FALSE;
	 BYTE i=0;
	 tipo *pData = ( tipo * ) GetUserParameters();
	 //iprintf("Verify key = 0x%lX\r\n", pData->VerifyKey);
	 for (i=0;i<12;i++){
	      if ( pData->VerifyKey != VERIFY_KEY ){ // datos incorrectos
	    	  //iprintf("La clave de verificaci�n de la fuente %d no es v�lida\r\n",i);
	    	  InicializaParametrosFuente(i);
			  grabar=TRUE;
          }else { //datos correctos
			LeeFuente(i,pData);
		  }
	      pData++; //apuntar al siguiente registro
	  }
     if (grabar){
    	// iprintf("Grabando nueva Flash\r\n");
    	 SaveUserParameters( &fuente, sizeof( fuente ) );
     }
 return grabar;
}

// Env�a la informaci�n de la fuente por el puerto de serie
void EnviaInfoDeFuente(int numFuente){
	char buf[80]="Parametros de la fuente: ";
	char buf2[10]; //para meter dato
	char *f=buf2; // puntero que apunta a dato
	AnadeEnteroAMensaje(buf,numFuente); // a�adir numero de fuente
	AnadeEnteroAMensaje(buf,fuente[numFuente].potInicial);
	AnadeEnteroAMensaje(buf,fuente[numFuente].fuenteOnInicio);
	AnadeEnteroAMensaje(buf,fuente[numFuente].maxCurrent);
	AnadeEnteroAMensaje(buf,fuente[numFuente].minCurrent);
	AnadeEnteroAMensaje(buf,fuente[numFuente].filtroAlarmaCurrent);
	AnadeEnteroAMensaje(buf,fuente[numFuente].segsAlarmaCurr);
	AnadeEnteroAMensaje(buf,fuente[numFuente].segsSinAlarmaCurr);
	AnadeEnteroAMensaje(buf,fuente[numFuente].TransicionEn_CurrEnLimites);
	AnadeEnteroAMensaje(buf,fuente[numFuente].currentEnLimites);
	AnadeEnteroAMensaje(buf,fuente[numFuente].alarmaCurrent);
	AnadeEnteroAMensaje(buf,fuente[numFuente].vigilarCurrent);
	AnadeEnteroAMensaje(buf,fuente[numFuente].desconSiAlarmCurr);
	AnadeEnteroAMensaje(buf,fuente[numFuente].maxVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].minVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].filtroAlarmaVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].filtroSinAlarmaVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].segsAlarmaVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].segsSinAlarmaVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].TransicionEn_TensionEnLimites);
	AnadeEnteroAMensaje(buf,fuente[numFuente].tensionEnLimites);
	AnadeEnteroAMensaje(buf,fuente[numFuente].alarmaVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].vigilarVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].desconSiAlarmVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].enviarAlarmas);
	AnadeEnteroAMensaje(buf,fuente[numFuente].ackAlarma);
	AnadeEnteroAMensaje(buf,fuente[numFuente].maxPot);
	AnadeEnteroAMensaje(buf,fuente[numFuente].minPot);
	AnadeEnteroAMensaje(buf,fuente[numFuente].autorregVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].segsAutorregVolts);
	AnadeEnteroAMensaje(buf,fuente[numFuente].apagarSiAlarmaEnOtraFuente);
	AnadeEnteroAMensaje(buf,fuente[numFuente].rShunt);
	AnadeEnteroAMensaje(buf,fuente[numFuente].divisorTension1);
	AnadeEnteroAMensaje(buf,fuente[numFuente].divisorTension2);
	AnadeEnteroAMensaje(buf,fuente[numFuente].rAdicPotDigital);
	AnadeEnteroAMensaje(buf,fuente[numFuente].rDivisorPotDigital);
	AnadeEnteroAMensaje(buf,fuente[numFuente].temporizadoEncendido);
	AnadeEnteroAMensaje(buf,fuente[numFuente].ReadyToConnect);
	AnadeEnteroAMensaje(buf,fuente[numFuente].alarma);
	AnadeEnteroAMensaje(buf,fuente[numFuente].vout);
	AnadeEnteroAMensaje(buf,fuente[numFuente].current);
	AnadeEnteroAMensaje(buf,fuente[numFuente].pot);
	AnadeEnteroAMensaje(buf,fuente[numFuente].fuenteOn);
	AnadeEnteroAMensaje(buf,fuente[numFuente].fuenteDesactivada);
	AnadeEnteroAMensaje(buf,fuente[numFuente].voutMedia);
	AnadeEnteroAMensaje(buf,fuente[numFuente].currentMedia);
	AnadeStringAMensaje(buf,"#");
	f=buf;
	//EnvioUart(f); // activar cuando esten activas las comunicaciones

}



// extrae campo del mensaje recibido del MOD5270 y retorna puntero a mensaje en la nueva posicion
char * ExtraeCampoAMensaje(char * mensaje){
return mensaje;
}



// ajusta el potenci�metro de la tension de salida
void AjustarPotenciometroVout(int numFuente,int valor){
	SeleccionaSCL(numFuente); // seleccionar SCL1,2,3 seg�n fuente...
	EscribeEnPotDig(SeleccionaAddressPotDig(numFuente),valor); // modifica valor pot
	fuente[numFuente].pot=valor; // actualizar RAM

}

//  Comprueba que la tensi�n esta dentro de los l�mites y actualiza valor vout y tension en l�mites  en ram
BOOL TensionEnLimites(int numFuente){
	BOOL enLimites=true;
	float volts = ( (float)fuente[numFuente].vout / (4095.0)) * 3.3;
	volts=volts*fuente[numFuente].divisorTension2/(fuente[numFuente].divisorTension1+fuente[numFuente].divisorTension2);
	if (volts>fuente[numFuente].maxVolts || volts<fuente[numFuente].minVolts) enLimites=false;
	if(fuente[numFuente].tensionEnLimites!=enLimites){ // es estado que tenia antes no coincide con el actual
		fuente[numFuente].TransicionEn_TensionEnLimites=true; // detectada transicion
		fuente[numFuente].tensionEnLimites=enLimites; // actualizar al nuevo estado
	}
	return enLimites;
}



// actualiza en Ram el valor de la tensi�n(cuentas cad)
void LeerTensionFuente(int numFuente){
	int cuentas;
	SeleccionLecturaTension(numFuente); // prepara los muxes para lectura de tensi�n.
	cuentas=LecturaCAD();
	fuente[numFuente].vout=cuentas;
}


// actualiza en Ram el valor de la corriente(cuentas cad)
void LeerCorrienteFuente(int numFuente){
	int cuentas;
	SeleccionLecturaCorriente(numFuente); // prepara los muxes para lectura de tensi�n.
	cuentas=LecturaCAD();
	fuente[numFuente].current=cuentas;
}

// rutina llamada por monitor. Enciende las fuentes pendientes
void EncenderFuentes(void){
	int i;
	for (i=0;i<12;i++){
		if (fuente[i].ReadyToConnect==true && fuente[i].fuenteOn==false) {
			// la fuente esta apagada y lista para encender
			ConectarFuente(i);
		}
	}
}
*/
