/*
 * RDACLibrary.cpp
 *
 *  Created on: 02-feb-2015
 *      Author: Alberto Ibarrondo
 */



#include "RDACLibrary.h"




BOOL readBuffer = true;							// Controls I2C Buffer reading when using doNothingRDAC
BOOL regWriteEnable = false;					// TRUE if RDAC Register can be updated, FALSE if RDAC Register is protected


BYTE outputBuffer[I2C_MAX_BUF_SIZE];			// Used to send every message
BYTE inputBuffer[I2C_MAX_BUF_SIZE];				// Used to receive every message






//=============================================RDAC METHODS=============================================//

//-------------------------------------------------------------------------------------------------------
// setCtrlRDAC - Stores the given flags into the RDAC Control Register
//		.	calibrationDisable: Sets RDAC into Calibration (0-Default) or Normal (1) performance mode`.
//		.	regWriteEnable: Protects (0-default) or allows (1) RDAC Register update.
//		.	programEnable: Protects (0-default) or allows (1) 20TP Memory writing.
//-------------------------------------------------------------------------------------------------------
void setCtrlRDAC(BOOL calibrationDisable, BOOL regWriteEnable, BOOL programEnable, BYTE slaveSelect, BYTE I2CAdress){
	writeCtrlCOM(outputBuffer, calibrationDisable, regWriteEnable, programEnable);
	BYTE result = sendSPImessage (outputBuffer, 2, slaveSelect, I2CAdress);
	if (result==I2C_OK){
		regWriteEnable = true;
		iprintf("Configured Ctrl Reg %x in slave %d\n\n", outputBuffer[1], slaveSelect);
	}
	else{
		iprintf("ERROR: Couldn't configure Ctrl Reg in slave %d\n\n", slaveSelect);
	}
}



//-------------------------------------------------------------------------------------------------------
// getCtrlRDAC - Returns a BYTE with the RDAC Control Register last 3 bits
//		.	0x04: Sets RDAC into Calibration (0-Default) or Normal (1) performance mode`.
//		.	0x02: Protects (0-default) or allows (1) RDAC Register update.
//		.	0x01: Protects (0-default) or allows (1) 20TP Memory writing.
//-------------------------------------------------------------------------------------------------------
BYTE getCtrlRDAC(int slaveSelect, BYTE I2CAdress){
	readCtrlCOM(outputBuffer);
	sendSPImessage (outputBuffer, 2, slaveSelect, I2CAdress);
	donothingRDAC(inputBuffer, slaveSelect, I2CAdress);
	regWriteEnable = (BOOL)(inputBuffer[1]&0x02);
	void printCtrlRDAC (BYTE inputBuffer[]);		// Prints by console the contents of Ctrl Register
	return inputBuffer[1]&0x7;
}



//-------------------------------------------------------------------------------------------------------
// setRegRDAC - Sets a new value to the RDAC Register (modifying its impedance). Value must be between 0
//				and 0x3FF.
//-------------------------------------------------------------------------------------------------------
void setRegRDAC(int value, BYTE slaveSelect, BYTE I2CAdress){
	getCtrlRDAC(slaveSelect,I2CAdress);
	if (!regWriteEnable){
		setCtrlRDAC(0,1,0, slaveSelect, I2CAdress);
	}
	writeRegCOM(outputBuffer, value);
	sendSPImessage (outputBuffer, 2, slaveSelect, I2CAdress);
	iprintf("Configured value %d (0x%x) in slave n�%d\n\n", value, slaveSelect);
}



//-------------------------------------------------------------------------------------------------------
// getRegRDAC - reads the RDAC Register, containing the impedance value.
//-------------------------------------------------------------------------------------------------------
int getRegRDAC(int slaveSelect, BYTE I2CAdress){
	readRegCOM(outputBuffer);
	sendSPImessage (outputBuffer, 2, slaveSelect, I2CAdress);
	donothingRDAC(inputBuffer, slaveSelect, I2CAdress);
	printRegRDAC (inputBuffer);			// Prints by console the received value
	return inputBuffer[0]*0x100+inputBuffer[1];
}



//-------------------------------------------------------------------------------------------------------
// highImpRDAC - Sets SDO (MISO pin) in high impedance. Must be used after every command not to interfere
//				 with other slaves.
//-------------------------------------------------------------------------------------------------------
void highImpRDAC(int slaveSelect, BYTE I2CAdress){
	highImpCOM(outputBuffer);
	sendSPImessage (outputBuffer, 2, slaveSelect,I2CAdress);
	donothingRDAC(inputBuffer, slaveSelect, I2CAdress);
	iprintf("High Impedance in slave %d\n\n", slaveSelect);
}



//-------------------------------------------------------------------------------------------------------
// resetRDAC - Sets Ctrl Register to Default and impedance value to midscale (0x201)
//-------------------------------------------------------------------------------------------------------
void resetRDAC(int slaveSelect, BYTE I2CAdress){
	resetCOM(outputBuffer);
	sendSPImessage (outputBuffer, 2, slaveSelect, I2CAdress);
	donothingRDAC(inputBuffer, slaveSelect, I2CAdress);
}



//-------------------------------------------------------------------------------------------------------
// shutdownRDAC - sets the device into Open Circuit. Doesn't always work
//-------------------------------------------------------------------------------------------------------
void shutdownRDAC(BOOL shutdownModeOn,int slaveSelect, BYTE I2CAdress){
	shutdownCOM(outputBuffer, shutdownModeOn);
	sendSPImessage (outputBuffer, 2, slaveSelect, I2CAdress);
	donothingRDAC(inputBuffer, slaveSelect, I2CAdress);
}



//-------------------------------------------------------------------------------------------------------
// doNothingRDAC - empty command. Used to read a response from the I2C Bridge
//-------------------------------------------------------------------------------------------------------
void donothingRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress){
	doNothingCOM(outputBuffer);
	sendSPImessage (outputBuffer, 2, slaveSelect, I2CAdress);
	if(readBuffer){
		readBridgeBuffer(ibuf, 2);
	}
}







//============================================PRINT METHODS===========================================//
void printCtrlRDAC (BYTE ibuf[]){
	printf("20TP programming -> %s\n", (((ibuf[1]&0x01)>0)?"Enabled": "Disabled(default)"));
	printf("Register programming -> %s\n", (((ibuf[1]&0x02)>0)?"Enabled": "Disabled(default)"));
	printf("Resistor mode -> %s\n", (((ibuf[1]&0x04)>0)?"Normal": "Performance(default)"));
}
void printRegRDAC (BYTE ibuf[]){
	printf("Resistor Value: %d (0x%x in hex)\n", (ibuf[0]*0x100 + ibuf[1]), (ibuf[0]*0x100 + ibuf[1]));
}

int voltToNum (float volt, float Rpsu){
	return (int)((1-((((float)volt/1.25)-1)*Rpsu/20000))*1024);
}

float numToVolt (int num, float Rpsu){
	return 1.25*(1+20000*(1-num/1023)/Rpsu);
}




//============================================BUFFER METHODS===========================================//
// All the messages are stored in the given buffer's first 2 Bytes.


//-------------------------------------------------------------------------------------------------------
// donothing - empty command. Used to advance in reading
//-------------------------------------------------------------------------------------------------------
void doNothingCOM(BYTE* buffer){
	BYTE donothing[2] = {0x00, 0x00};
	mergeBuffer(buffer, donothing, 2);
}


//-------------------------------------------------------------------------------------------------------
// writeReg - command to write a value to the RDAC register. From 0x000 to 0x3FF (0 to 1023).
//-------------------------------------------------------------------------------------------------------
void writeRegCOM(BYTE* buffer, int value){
	if (value >0x3FF){
		value=0x200;
	}
	BYTE writeValue[2] = {0x04+((value & 0x300)>>8), (value & 0x0FF)};
	mergeBuffer(buffer, writeValue, 2);
}


//-------------------------------------------------------------------------------------------------------
// readReg - command to send the RDAC register (containing the resistance value) to the Bridge Buffer
//-------------------------------------------------------------------------------------------------------
void readRegCOM(BYTE* buffer){
	BYTE readValue[2] = {0x08, 0x00};
	mergeBuffer(buffer, readValue, 2);
}


//-------------------------------------------------------------------------------------------------------
// reset -  command to restart the RDAC with a value of 0x200 (midscale)
//-------------------------------------------------------------------------------------------------------
void resetCOM(BYTE* buffer){
	BYTE reset[2] = {0x10, 0x00};
	mergeBuffer(buffer, reset, 2);
}


//-------------------------------------------------------------------------------------------------------
// writeCtrl - command to set each bit of the Control register
//-------------------------------------------------------------------------------------------------------
void writeCtrlCOM(BYTE* buffer, BOOL calibrationDisable, BOOL regWriteEnable, BOOL programEnable ){
	BYTE writeCtrl[2] = {0x18, 0x04*calibrationDisable+ 0x02*regWriteEnable + 0x01*programEnable};
	mergeBuffer(buffer, writeCtrl, 2);
}


//-------------------------------------------------------------------------------------------------------
// readCtrl - command to send the Control register to the Bridge Buffer
//-------------------------------------------------------------------------------------------------------
void readCtrlCOM(BYTE* buffer){
	BYTE readCtrl[2] = {0x1C, 0x00};
	mergeBuffer(buffer, readCtrl, 2);
}


//-------------------------------------------------------------------------------------------------------
// shutdown - command to set the RDAC in open circuit
//-------------------------------------------------------------------------------------------------------
void shutdownCOM(BYTE* buffer, BOOL shutdownModeOn){
	BYTE shutdown[2] = {0x20, 0x00 + 0x01*shutdownModeOn};
	mergeBuffer(buffer, shutdown, 2);
}


//-------------------------------------------------------------------------------------------------------
// highImp - command to set SDO pin in high impedance for minimum power dissipation
//-------------------------------------------------------------------------------------------------------
void highImpCOM(BYTE* buffer){
	BYTE highImp[2] = {0x80, 0x01};
	mergeBuffer(buffer, highImp, 2);
}
