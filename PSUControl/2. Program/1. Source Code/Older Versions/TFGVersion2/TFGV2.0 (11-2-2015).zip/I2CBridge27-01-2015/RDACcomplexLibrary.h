/*
 * RDACcomplexLibrary.h
 *
 *  Created on: 02-feb-2015
 *      Author: Alberto
 */

#ifndef RDACCOMPLEXLIBRARY_H_
#define RDACCOMPLEXLIBRARY_H_


#endif /* RDACCOMPLEXLIBRARY_H_ */

#include "RDACCommandLibrary.h"
#include "I2CLibrary.h"

//------------------------------------COMMAND METHODS-------------------------------------//
void setCtrlRDAC(BOOL calibrationDisable, BOOL regWriteEnable, BOOL programEnable, BYTE slaveSelect, BYTE I2CAdress);
void getCtrlRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress);
void setRegRDAC(int value, BYTE slaveSelect, BYTE I2CAdress);
void getRegRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress);
void highImpRDAC(int slaveSelect, BYTE I2CAdress);
void resetRDAC(int slaveSelect, BYTE I2CAdress);
void shutdownRDAC(BOOL shutdownModeOn,int slaveSelect, BYTE I2CAdress);
void donothingRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress);


//------------------------------------AUXILIAR METHODS------------------------------------//
void printCtrlRDAC (BYTE ibuf[]);
void printRegRDAC (BYTE ibuf[]);
