/*
 * RDACcomplexLibrary.cpp
 *
 *  Created on: 02-feb-2015
 *      Author: Alberto
 */

#include "RDACComplexLibrary.h"
#include "I2CLibrary.h"

BOOL readBuffer = true;							// Controls I2C Buffer reading when using doNothingRDAC
BOOL config = false;
BYTE outputBuffer[I2C_MAX_BUF_SIZE];			// Used to send every message
BYTE inputBuffer[I2C_MAX_BUF_SIZE];				// Used to receive every message
BYTE auxBuffer[I2C_MAX_BUF_SIZE];				// Used for auxiliary purposes

float Rpsu1 = 800;								// Different for each PSU



//---------------------------------------COMMAND METHODS---------------------------------------------//
void setCtrlRDAC(BOOL calibrationDisable, BOOL regWriteEnable, BOOL programEnable, BYTE slaveSelect, BYTE I2CAdress){
	writeCtrlCOM(outputBuffer, calibrationDisable, regWriteEnable, programEnable);
	sendSPImessage (outputBuffer, 2, slaveSelect, I2CAdress);
	iprintf("Configured Ctrl Reg %x in slave %d\n\n", outputBuffer[1], slaveSelect );
}

void getCtrlRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress){
	readCtrlCOM(outputBuffer);
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	donothingRDAC( ibuf, slaveSelect, I2CAdress );
}

void setRegRDAC(int value, BYTE slaveSelect, BYTE I2CAdress){
	/*readCtrlRDAC(auxBuffer,slaveSelect,I2CAdress);
	config=((0x02 & auxBuffer[1])> 0);
	iprintf("auxBuffer[1] = %x\n", auxBuffer[1]);
	iprintf("Config = %d\n", config);
	iprintf("result = %d\n", 0x02 & auxBuffer[1]);
	if ( !config ){
		writeCtrl(outputBuffer, false, true, false);
		BYTE* poutBuf = outputBuffer;
		poutBuf+=2;
		donothing(poutBuf);
		sendSPImessage ( outputBuffer, 4, slaveSelect, I2CAdress);
		OSTimeDly( 1 );
		config=true;
	}
	float scaledValue = (1-((((float)volt/1.25)-1)*Rpsu1/20000))*1024;
	printf("\n\nVolts in float: %f  ", volt);
	printf("scaledValue in integer: %d\n", (int)scaledValue);
	int value = (int)scaledValue;*/

	writeRegCOM(outputBuffer, value );
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	iprintf("Configured value %d in slave %d\n\n", value, slaveSelect );
	/*donothingRDAC(auxBuffer, slaveSelect, I2CAdress);*/
}

void getRegRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress){
	readRegCOM(outputBuffer);
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	donothingRDAC( ibuf, slaveSelect, I2CAdress );
}

void highImpRDAC(int slaveSelect, BYTE I2CAdress){
	highImpCOM(outputBuffer);
	sendSPImessage ( outputBuffer, 2, slaveSelect,I2CAdress);
	donothingRDAC(auxBuffer, slaveSelect, I2CAdress);
	iprintf("High Impedance in slave %d\n\n", slaveSelect );
}

void resetRDAC(int slaveSelect, BYTE I2CAdress){
	resetCOM(outputBuffer);
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	donothingRDAC( auxBuffer, slaveSelect, I2CAdress );
}

void shutdownRDAC(BOOL shutdownModeOn,int slaveSelect, BYTE I2CAdress){
	shutdownCOM(outputBuffer, shutdownModeOn);
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	donothingRDAC( auxBuffer, slaveSelect, I2CAdress);
}

void donothingRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress){
	doNothingCOM( outputBuffer );
	sendSPImessage ( outputBuffer, 2, slaveSelect, I2CAdress);
	if(readBuffer){
		readBridgeBuffer( inputBuffer, 2 );
		mergeBuffer( ibuf, inputBuffer, 2);
	}
}




//---------------------------------------AUXILIAR METHODS---------------------------------------------//
void printCtrlRDAC (BYTE ibuf[]){
	printf("20TP programming -> %s\n", (((ibuf[1]&0x01)>0)?"Enabled": "Disabled(default)"));
	printf("Register programming -> %s\n", (((ibuf[1]&0x02)>0)?"Enabled": "Disabled(default)"));
	printf("Resistor mode -> %s\n", (((ibuf[1]&0x04)>0)?"Normal": "Performance(default)"));
}
void printRegRDAC (BYTE ibuf[]){
	printf("Resistor Value: %d (0x%x in hex)\n", (ibuf[0]*0x100 + ibuf[1]), (ibuf[0]*0x100 + ibuf[1]));
}
