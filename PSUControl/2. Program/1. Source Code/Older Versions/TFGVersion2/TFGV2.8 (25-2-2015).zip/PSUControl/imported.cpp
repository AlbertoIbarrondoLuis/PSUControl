/*
 * imported.cpp
 *
 *  Created on: 25-feb-2015
 *   Author: Alberto Ibarrondo
 */
#include <i2cmaster.h>
#include "basictypes.h"
#include "imported.h"
#include "predef.h"
#include <stdio.h>
#include <ctype.h>
#include <basictypes.h>
#include <serialirq.h>
#include <system.h>
#include <constants.h>
#include <ucos.h>
#include <smarttrap.h>
#include <serialupdate.h>
#include <pins.h>
#include <qspi.h>
#include <serial.h>
#include <string.h>
#include <a2d.h>
#include <..\MOD5213\system\sim5213.h>
#include <cfinter.h>

BYTE driverA=0; // valor inicial bus U314
BYTE driverB=0; // valor inicial bus U315
BYTE transceptorBus=0; // valor inicial bus U313

// escribe en transceptores de bus. Actualiza la variable en ram necesaria para mantener estado estable
// address = direccion del transceptor. Dato=valor a escribir, variable=valor del bus en ram,mascara=mascara escritura
void EscribeEnTransceptorBus(BYTE address, BYTE dato, BYTE mascara,BYTE * variable){
	PBYTE p=(BYTE *)dato;
	BYTE temp = *variable;
	temp = temp & mascara; //ajustar la nueva var en ram
	temp = temp | dato; //ajustar la nueva var en ram
	*variable = temp; // el contenido apuntado por variable = contenido de temp
	I2CSendBuf(address, p, (strlen( (const char*)dato ) )+1);
}


// selecciona que SCL se ha de activar en funcion de la fuente
void SeleccionaSCL(int numFuente){
    int scl;
    BYTE dato, mascara;
    PBYTE p=(BYTE *)transceptorBus;
	if (numFuente<12) scl=3;
	if (numFuente<8) scl=2;
	if (numFuente<4) scl=1;
	mascara=0x70; // modificar solo p4,p5,p6
	switch(scl){
    	case 1:
    		dato=0x16;
    		break;
    	case 2:
    		dato=0x32;
    	    break;
    	default:
    		dato=0x64;
    	    break;
    }
	EscribeEnTransceptorBus(addressTransBus, dato,mascara,p);
}

// determina la direcci�n del potenci�metro digital
BYTE SeleccionaAddressPotDig(int numFuente){
	BYTE address;
	if (numFuente==0 ||numFuente==4||numFuente==8) address=potDigA;
	if (numFuente==1 ||numFuente==5||numFuente==9) address=potDigB;
	if (numFuente==2 ||numFuente==6||numFuente==10) address=potDigC;
	if (numFuente==3 ||numFuente==7||numFuente==11) address=potDigD;
	return address;
}

// escribe dato en driver U314(numDriver=1) o U315(numDriver=2)
// actualiza variable en RAM para mantener estado
void EscribeEnDriver(int numDriver,BYTE dato, BYTE mascara){
   BYTE address;
   PBYTE p=(BYTE *)dato;
   if (numDriver == 1){
	   address = addressAddressDriverA;
	   driverA = driverA & mascara;
	   driverA = driverA | dato;
	   dato = driverA;
   } else {
	  address=addressAddressDriverB;
	   driverB = driverB & mascara;
	   driverB = driverB | dato;
	   dato = driverA;
   }
   I2CSendBuf(address, p, (strlen( (const char*)dato ) )+1);

}

// pone en los transceptores de bus los valores iniciales
// ning�n SCL , ning�n STROBE, ning�n rel� de fuente ni led on
void  InicializarBusesControladora(void){
	PBYTE p=(BYTE *)transceptorBus;
	EscribeEnTransceptorBus(addressTransBus, *p,0xFF,p);
	p=(BYTE *)driverA;
	EscribeEnTransceptorBus(addressAddressDriverA, *p,0xFF,p);
	p=(BYTE *)driverB;
	EscribeEnTransceptorBus(addressAddressDriverB, *p,0xFF,p);
}



