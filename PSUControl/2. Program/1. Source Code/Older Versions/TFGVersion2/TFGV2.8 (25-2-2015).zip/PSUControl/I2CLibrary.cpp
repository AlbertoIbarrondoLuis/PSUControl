/*
 * I2CLibrary.cpp
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#include "i2CLibrary.h"


//---------------------------------------Variables---------------------------------------------------//
BYTE I2CStat;
BYTE bridgeAddress = 0x2F; // 0x28 to 0x2F possible. 3 last bits are configurable with switches

BYTE sendBuffer[I2C_MAX_BUF_SIZE];   	// User created I2C output buffer
BYTE* pSendBuf = sendBuffer;         	// Pointer to user I2C output buffer
BYTE receiveBuffer[I2C_MAX_BUF_SIZE];   	// User created I2C output buffer
BYTE* pRecBuf = receiveBuffer;         	// Pointer to user I2C output buffer

//-------------------------------------------------------------------------------------------------------
// sendI2CMessage sends the bufSize Bytes from bufi2c to the bridgeAddress through I2C including a null at the end
//-------------------------------------------------------------------------------------------------------
BYTE sendI2CMessage ( BYTE outputBuffer[], int bufSize, BYTE I2CAdress){
		iprintf( "I2C msg (0x%x) -> ", I2CAdress );
		printBuffer(outputBuffer, bufSize);
		I2CStat = I2CSendBuf(I2CAdress, outputBuffer, bufSize);// Send the buffer size plus one to include the null character
		if( I2CStat == I2C_OK )
		   iprintf( " -> I2C OK\n" );
		else
		   iprintf( " -> I2C ERROR: Failed to send to address %x due to error: %d\r\n\r\n", I2CAdress ,I2CStat);
		return I2CStat;
}



//-------------------------------------------------------------------------------------------------------
// configureSPI sends 2 bytes using outputBuffer to configure the SPI channel using the bridge.
// Initialize Order (MSB/LSB first) Clock Polarity (cpol) and Phase (cpha)
// Values from 0 to 3 possible. Default is 0.
//	0 -> 1.8MHz; 1 -> 461KHz; 2 -> 115KHz; 3 -> 58KHz;
//-------------------------------------------------------------------------------------------------------
void configureSPI( BOOL order, BOOL cpol, BOOL cpha, int clkRate, BYTE I2CAdress){
		BYTE configureSPI[2] = {0xF0, 0x20 * order + 0x08 * cpol + 0x04 * cpha+ (((clkRate < 4) && (clkRate > 0))?clkRate:0)};
		sendI2CMessage( configureSPI, 2, I2CAdress);
		iprintf( " .Configured SPI channel:\r\n" );
		iprintf( "   -   Byte order: %s\n", (order?"LSB of data transmitted first": "MSB of data transmitted first"));
		iprintf( "   -   Clock polarity: %s\n", (order?"SPI Clock HIGH when idle": "SPI Clock HIGH when idle"));
		iprintf( "   -   Clock Phase: %s\n", (order?"Data clocked in on trailing edge": "Data clocked in on leading edge"));

}



//-------------------------------------------------------------------------------------------------------
// sendSPImessage sends bufSize Bytes from the BufSPI buffer to the selected SPI Slaves (0x0 to 0xF possible)
//-------------------------------------------------------------------------------------------------------
BYTE sendSPImessage ( BYTE outputBuffer[], int bufSize, BYTE slaveSelect, BYTE I2CAdress){
		if (slaveSelect>0x0F){
			iprintf("SPI ERROR: Wrong SPI address");
			return 0xff;	// Not important, just a value different from any I2C Result
		}
		else{
			*pSendBuf++=slaveSelect;
			mergeBuffer(pSendBuf, outputBuffer, bufSize);
			pSendBuf = sendBuffer;
			iprintf("SPI msg (Sl:%d) --> ", slaveSelect);
			BYTE I2CcomResult = sendI2CMessage( sendBuffer, bufSize + 1 , I2CAdress);
			OSTimeDly( 1 );
			return I2CcomResult;
		}
}



//-------------------------------------------------------------------------------------------------------
// receiveMessage reads the bufSize Bytes from the Bridge buffer and writes them into inputBuffer
//-------------------------------------------------------------------------------------------------------
void readBridgeBuffer ( BYTE inputBuffer[], int bufSize){
		iprintf( "Reading bridge buffer\n" );
		I2CStat = I2CReadBuf(bridgeAddress, inputBuffer, bufSize);
		if( I2CStat == I2C_OK )
		{
			iprintf("Data Received -> " );
			printBuffer(inputBuffer, bufSize);
			iprintf(" -> I2C OK\r\n" );
		}
		else
		   iprintf("I2C ERROR: Failed to read due to error: %d\r\n", I2CStat);
}



