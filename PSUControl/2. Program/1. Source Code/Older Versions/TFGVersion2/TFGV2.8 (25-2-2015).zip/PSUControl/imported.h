/*
 * comunicaciones.h
 *
 *  Created on: Oct 25, 2012
 *      Author: Aco
 */

#ifndef COMUNICACIONES_H_
#define COMUNICACIONES_H_




#define FINMENSAJE '#'
#define addressTransBus 0x3E //
#define addressAddressDriverA 0x3C //
#define addressAddressDriverB 0x3D //
#define potDigA 0x18
#define potDigB 0x4C
#define potDigC 0x1A
#define potDigD 0x4E


//  declaracion de funciones
void ThreadRecepcionUart(void * pdata);
void TrataMensajeUart(void);
void ThreadRecepcionUart(void);
void EnvioUart(char *mesaje);
void TrataMensajeUart(void);
void InicializaUart(void);
BOOL EnviaI2C(BYTE address,BYTE *buffer);
void EscribeEnTransceptorBus(BYTE address, BYTE dato, BYTE mascara,BYTE * variable);
void EscribeEnDriver(int numDriver,BYTE dato, BYTE mascara);
void SeleccionaSCL(int numFuente);
BYTE SeleccionaAddressPotDig(int numFuente);
void SeleccionaMuxPrevioTension(int numFuente);
void SeleccionaMuxFinalTension(int numFuente);
void SeleccionaMuxPrevioCorriente(int numFuente);
void SeleccionaMuxFinalCorriente(int numFuente);
void SeleccionLecturaTension(int numFuente);
void SeleccionLecturaCorriente(int numFuente);
void InicializarBusesControladora(void);
void initializeADC(void);
int LecturaCAD(void);
BYTE DemuxTresOcho(int numero);
void EnviaAlarma(int numFuente);
void IniciarTimer(void);
void InterrupcionCien_ms();
void Interrupcion_Un_Segundo();
void EscribeEnPotDig(BYTE address,BYTE valor);


extern BOOL MENSAJE_MOD5270_SEM;
extern "C" {
void SetIntc(long func, int vector, int level, int prio);
}

#endif /* COMUNICACIONES_H_ */
