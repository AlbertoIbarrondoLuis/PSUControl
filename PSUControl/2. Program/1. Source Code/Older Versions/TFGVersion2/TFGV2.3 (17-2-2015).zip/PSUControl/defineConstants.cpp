/*
 * defineConstants.cpp
 *
 *  Created on: 13-feb-2015
 *      Author: Alberto
 */

#define PSU_NUMBER 12
#define ALL_PSUS_INIT 0xFFF


#define OFF	false
#define ON	true

#define INFERIOR 0					// First Coordinate
#define SUPERIOR 1

#define VOLTAGE 0					// Second Coordinate
#define CURRENT 1

#define FIRST_SLAVE 0
#define SECOND_SLAVE 1
#define FIRST_SLAVE_DIR 0
#define SECOND_SLAVE_DIR 2

#define _(a,b) a+2*b
#define __(a,b,c) a+2*b+4*c;

#define PROTOCOL_SHUTDOWN 0			//(0) Shut down certain PSUs
#define PROTOCOL_MODIFY_VOLTAGE 1	//(1) Modify Voltage
#define PROTOCOL_MESSAGE 2			//(2) Send Alarm Message

#define ALARM_PLOTOCOLS_NUM 3

#define ALARM_MESSAGE "ALARM in PSU n� %d. %s %s limit reached"
















//_________________________________________DEFAULT VALUES_______________________________________________//
#define DEFAULT_releStatus false							// Rel� flag
#define DEFAULT_psuStatus false								// PSU being used or not

#define DEFAULT_rdacValue 15								// Programmed voltage
#define DEFAULT_bridgeI2CDir 0xF							// PSU I2C Bridge direction

#define DEFAULT_alarmLimitValues 	{{13, 17}, {0.3, 3}}	// inferior (0,0) and superior (1,0) voltage alarm limits; and inferior (0,1) and superior (1,1) current alarm limits.

#define DEFAULT_alarmLimitTimes		{{100, 100}, {100, 100}}// inferior (0,0) and superior (1,0) voltage alarm times; and inferior (0,1) and superior (1,1) current alarm times.
#define DEFAULT_alarmProtocols		{{{1,1,1},{1,1,1}},{{1,1,1}, {1,1,1}}};		// inferior (0,0) and superior (1,0) voltage alarm; and inferior (0,1) and superior (1,1) current alarm.
										// Third dimension is to activate(TRUE) or ignore(FALSE) the protocols when the alarm pops up: (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
#define DEFAULT_alarmProtocolShutdown[2][2];	// PSU list to shutdown in alarm protocol Shutdown (. bit 0 is for PSU 1, and so on.
#define DEFAULT_alarmProtocolVoltage[2][2][2];	// New values for this PSU's voltage in case of alarm Protocol Modify Voltage.

#define DEFAULT_alarmCounters[4];				// variables being increased on each scanning period if an alarm is ON, until they reach the alarmLimits
										// They also serve for shutting down alarms when not active for a period of time.

#define DEFAULT_alarmStatus[4];				// FALSE: alarm hasn't been triggered, not performing any alarm protocols. TRUE: alarm is ON, performing alarm protocols.
#define DEFAULT_alarmLimitReached[4];			// FALSE: alarm hasn't reached the limit. If alarmStatus was ON, it will start decreasing the alarmCounter until alarmStatus is OFF(ntimes = alarmLimitTimes). TRUE: alarm has reached the limit, beginning to increase the alarmCounter until alarmStatus is ON (ntimes = alarmLimitTimes).
#define DEFAULT_alarmWatch[4];					// FALSE: alarm is not configured, it will neither analyze the system nor trigger the alarmStatus ON.
										// TRUE: alarm is configured and working, will analyze the system, set the alarmStatus ON when a limit is reached, and execute the defined alarmProtocols

#define DEFAULT_rShunt;							// Internal resistor used for RDAC configuration

#define DEFAULT_divisorTension1;				// valor de la resistencia R1 del divisor a la entrada del CAD para lectura tension. R303 a R310 y R319 a R322
#define DEFAULT_divisorTension2;				// valor de la resistencia R2 del divisor a la entrada del CAD para lectura tension. R311 a R311 y R323 a R326
#define DEFAULT_rAdicPotDigital;				// valor de la resistencia R203
#define DEFAULT_rDivisorPotDigital;				// valor de la resistencia R202

#define DEFAULT_vOut;							// CAD value of the output voltage
#define DEFAULT_cOut;							// CAD value of the output current

