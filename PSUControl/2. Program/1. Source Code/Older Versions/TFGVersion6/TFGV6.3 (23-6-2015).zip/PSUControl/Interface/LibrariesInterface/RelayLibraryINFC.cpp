/*
 * RelayLibraryINFC.cpp
 *
 *  Created on: 23-jun-2015
 *      Author: Alberto
 */

#include "Interface/LibrariesInterface/LibrariesINFC.h"	// Interface for Libraries' Methods

//==============================================VARIABLES==============================================//
// Keyboard
#define EXIT 'e'
#define WAIT_FOR_KEYBOARD funcChar = sgetchar(0);
extern char funcChar;				// used for WAIT_FOR_KEYBOARD macro, and as auxiliary variable in certain functions
extern char functionSelectionINFC;
extern BYTE bufferINFC[I2C_MAX_BUF_SIZE];

// Relays


// Values
extern int psuNumINFC;


//=====================================================================================================//
//================================   RELAY LIBRARY INTERFACE   ========================================//
//=====================================================================================================//

void RelayFunctionsDISP ( void ) {
	functionSelectionINFC = '0';
	while ( functionSelectionINFC!=EXIT ){
		ERASE_CONSOLE
		iprintf("=============================== RELAY LIBRARY =================================\r\n" );
		iprintf(" (1) Connect PSU Relay\n");
		iprintf(" (2) Disconnect PSU Relay\n");
		iprintf(" (3) Relays' Status\n");
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
		iprintf("-------------------------------------------------------------------------------\r\n" );
		iprintf( "\r\nEnter command: " );
		functionSelectionINFC = sgetchar(0);iprintf("%c\n", functionSelectionINFC);
		iprintf("\n-------------------------------------------------------------------------------\r\n" );
		switch ( functionSelectionINFC ){
			case '1':	connectRelay_Relay_INFC();		break;
			case '2':	disconnectRelay_Relay_INFC();	break;
			case '3':	relayStatus_Relay_INFC();		break;
			case EXIT: iprintf("Exiting to FUNCTION MENU\n");  break;
			default:
				iprintf( "\nINVALID KEY -> %c\r\n", functionSelectionINFC);
				iprintf( " \r\nPRESS ANY KEY TO RETURN TO CONFIG FUNCTION\r\n" );
				break;
		}
		WAIT_FOR_KEYBOARD
	}
}

void connectRelay_Relay_INFC ( void ) {
	iprintf("\n\n\n\n(1). Connect Relay\n");
	psuNumINFC = selectPSUNumINFC();
	connectPSU( psuNumINFC );
	iprintf("Relay connected for PSU %d\n", psuNumINFC);
}

void disconnectRelay_Relay_INFC ( void ) {
	iprintf("\n\n\n\n(2). Disconnect Relay\n");
	psuNumINFC = selectPSUNumINFC();
	disconnectPSU( psuNumINFC );
	iprintf("Relay disconnected for PSU %d\n", psuNumINFC);
}

void relayStatus_Relay_INFC ( void ){
	iprintf("\n\n\n\n(3). Relay Status\n");
	for (int i=0; i<PSU_NUMBER; i++){
		iprintf("%d: %s\n", i, (getRelayStatus(i)?"CONNECTED":"DISCONNECTED"));
	}
}
