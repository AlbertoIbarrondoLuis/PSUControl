/*
 * GeneralFunctionsINFC.cpp
 *
 *  Created on: 22-jun-2015
 *      Author: Alberto
 */


#include "Interface/LibrariesInterface/LibrariesINFC.h"	// Interface for Libraries' Methods

//==============================================VARIABLES==============================================//
// I2C&SPI, RDAC
extern BYTE bufferINFC[I2C_MAX_BUF_SIZE];

// Values
extern int psuNumINFC;


//=====================================================================================================//
//==============================   GENERAL FUNCTIONS INTERFACE   ======================================//
//=====================================================================================================//

int selectPSUNumINFC ( void ){
	int psuNum;
	iprintf( " Select PSU number (0 to 11): " );
	*bufferINFC = 0x0000;
	psuNum=atoi(gets((char*)bufferINFC));iprintf("\r\n");
	while ((psuNumINFC<0) || (psuNumINFC>=PSU_NUMBER)){
		iprintf( " Invalid number. Select a number from 0 to 11: " );
		psuNum=atoi(gets((char*)bufferINFC));iprintf("\r\n");
	}
	return psuNum;
}
