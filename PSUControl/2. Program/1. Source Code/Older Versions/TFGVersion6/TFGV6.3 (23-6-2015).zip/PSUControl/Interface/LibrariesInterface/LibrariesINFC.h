/*
 * FunctionsINFC.h
 *
 *  Created on: 22-jun-2015
 *      Author: Alberto
 */

#ifndef FUNCTIONSINFC_H_
#define FUNCTIONSINFC_H_

#include "Headers.h"
#include "Libraries/Libraries.h"		// All the Libraries' Methods
#include "Controller/Controller.h"		// All the Controller Methods

//-------------------------------------- AGC Library ------------------------------------------//
// Main
void AGCLibraryINFC ( void );
// Functions
void setAGCMinimum_AGC_INFC ( void );
void setAGCMaximum_AGC_INFC ( void );
void scaleAGCGain_AGC_INFC ( void );
void setAGCGain_AGC_INFC ( void );
void countsToGain_AGC_INFC ( void );
void gainToCounts_AGC_INFC ( void );
void getAGCStatus_AGC_INFC ( void );


//------------------------------------ General Library ----------------------------------------//
int selectPSUNumINFC ( void );


//------------------------------------ I2CnSPI Library ----------------------------------------//
// Main
void I2CnSPILibraryINFC( void );
// Functions
void configChannels_I2CSPI_INFC( void );
void sendI2CMessage_I2CnSPI_INFC( void );
void changeI2CAddress_I2CnSPI_INFC( void );
void toggleSPIAddress_I2CnSPI_INFC( void );
void setAddressesPSU_I2CnSPI_INFC( void );

//--------------------------------------- MUX Library ------------------------------------------//
// Main
void MUXLibraryINFC ( void );
// Functions
void setMuxes_MUX_INFC ( void );
void readPSUVoltage_MUX_INFC ( void );
void readPSUCurrent_MUX_INFC ( void );
void readSnIVoltage_MUX_INFC ( void );



//------------------------------------- RDAC Library ------------------------------------------//
// Main
void RDACLibraryINFC( void );
// Functions
void setRDACValue_RDAC_INFC ( void );
void readRDACValue_RDAC_INFC ( void );
void toggleRDACCtrl_RDAC_INFC ( void );
void getRDACCtrl_RDAC_INFC ( void );
void resetRDAC_RDAC_INFC ( void );
void higImpSDO_RDAC_INFC ( void );
void scaleSetRDACValue_RDAC_INFC ( void );
void programMemRDAC_RDAC_INFC ( void );
void readMemRDAC_RDAC_INFC ( void );
void voltsToCounts_RDAC_INFC ( void );
void countsToVolts_RDAC_INFC ( void );


//-------------------------------------- Relay Library -----------------------------------------//
// Main
void RelayFunctionsDISP ( void );
// Functions
void connectRelay_Relay_INFC ( void );
void disconnectRelay_Relay_INFC ( void );
void relayStatus_Relay_INFC ( void );


#endif /* FUNCTIONSINFC_H_ */
