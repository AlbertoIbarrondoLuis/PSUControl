/*
 * AGCLibrary.cpp
 *
 *  Created on: 17-abr-2015
 *      Author: Alberto
 */

#include "AGCLibrary.h"

float gainAGC = 1.1;			float auxGainAGC;
int rdacCountAGC = 0;			int auxRdacCountAGC;

BYTE resultI2C_AGC = 0;
BOOL maxAGCReached = false;		BOOL auxMaxAGCReached;
BOOL minAGCReached = false;		BOOL auxMinAGCReached;

void minAGC( void ){
	auxRdacCountAGC = RDAC_MIN_VALUE;
	setValRDAC(auxRdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
	resultI2C_AGC = getI2CResultRDAC();
	if(resultI2C_AGC==I2C_OK){
		rdacCountAGC = auxRdacCountAGC;
		gainAGC = countsToGainAGC ( rdacCountAGC );
		maxAGCReached = false;
		minAGCReached = true;
	}
	else{
		// ERROR
	}
}

void maxAGC( void ){
	auxRdacCountAGC = RDAC_MAX_VALUE;
	setValRDAC(auxRdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
	resultI2C_AGC = getI2CResultRDAC();
	if(resultI2C_AGC==I2C_OK){
		rdacCountAGC = auxRdacCountAGC;
		gainAGC = countsToGainAGC ( rdacCountAGC );
		maxAGCReached = true;
		minAGCReached = false;
	}
	else{
		// ERROR
	}
}

void setGainAGC( float num ){
	auxRdacCountAGC = gainToCountsAGC(num);
	if (auxRdacCountAGC > RDAC_MAX_VALUE){auxRdacCountAGC = RDAC_MAX_VALUE;	auxMaxAGCReached=true;}else{auxMaxAGCReached = false;}
	if (auxRdacCountAGC < RDAC_MIN_VALUE){auxRdacCountAGC = RDAC_MIN_VALUE;	auxMinAGCReached=true;}else{auxMinAGCReached = false;}
	setValRDAC(auxRdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
	resultI2C_AGC = getI2CResultRDAC();
	if(resultI2C_AGC==I2C_OK){
		rdacCountAGC = auxRdacCountAGC;
		gainAGC = countsToGainAGC(auxRdacCountAGC);
		maxAGCReached = auxMaxAGCReached;
		minAGCReached = auxMinAGCReached;
	}
	else{
		// ERROR
	}

}

void scaleGainAGC( float num ){
	auxGainAGC = gainAGC * num;
	auxRdacCountAGC = gainToCountsAGC(num);
	if (auxRdacCountAGC > RDAC_MAX_VALUE){auxRdacCountAGC = RDAC_MAX_VALUE;	auxMaxAGCReached=true;}else{auxMaxAGCReached = false;}
	if (auxRdacCountAGC < RDAC_MIN_VALUE){auxRdacCountAGC = RDAC_MIN_VALUE;	auxMinAGCReached=true;}else{auxMinAGCReached = false;}
	setValRDAC(auxRdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
	resultI2C_AGC = getI2CResultRDAC();
	if(resultI2C_AGC==I2C_OK){
		rdacCountAGC = auxRdacCountAGC;
		gainAGC = countsToGainAGC(auxRdacCountAGC);
		maxAGCReached = auxMaxAGCReached;
		minAGCReached = auxMinAGCReached;
	}
	else{
		// ERROR
	}

}

float countsToGainAGC ( int rdacCount ){
	auxGainAGC =  1 + (((float)rdacCount + 1)/1024)*100;
	return auxGainAGC;
}

int gainToCountsAGC (float gain){
	auxRdacCountAGC = (int)((((gain-1)/100)*1024)+1);
	return auxRdacCountAGC;
}

int getCountsAGC ( void ){
	return rdacCountAGC;
}

float getGainAGC ( void ){
	return gainAGC;
}

float readGainAGC ( void ){
	rdacCountAGC = getValRDAC(AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
	gainAGC = countsToGainAGC(rdacCountAGC);
	return gainAGC;
}

BYTE getI2CResultAGC ( void ){
	return resultI2C_AGC;
}
