/*
 * MUXLibrary.cpp
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#include "MUXLibrary.h"

// AUXILIAR
#define EN_MUX_ABCDE 0x8
#define EN_MUX_ADC 0x8
#define SET_EXPANDER_BUS(mux, num) expanderBus[0]=(mux+EN_MUX_ADC)|((num+EN_MUX_ABCDE)<<4)

BYTE expanderBus[1] = {0};
BYTE resultI2C_MUX = 0;

// Scale
extern float scaleFactorArray[38];
float scaleFactor=0;

// Muxes
#define MUX_ABCDE 0
#define MUX_ADC 1

//-------------------------------------------------------------------------------------------------------
// initMUX - Initializes all the Pins used for Mux control
//-------------------------------------------------------------------------------------------------------
void initMUX ( void ){
	// MUX_ABCDE
	Pins[15].function(PIN15_GPIO); //A0_MUX_ABCDE
	Pins[16].function(PIN16_GPIO); //A1_MUX_ABCDE
	Pins[17].function(PIN17_GPIO); //A2_MUX_ABCDE
	Pins[18].function(PIN18_GPIO); //EN_MUX_ABCDE
	// MUX_ADC
	Pins[28].function(PIN28_GPIO); //A0_MUX_ADC
	Pins[33].function(PIN33_GPIO); //A1_MUX_ADC
	Pins[34].function(PIN34_GPIO); //A2_MUX_ADC
	Pins[35].function(PIN35_GPIO); //EN_MUX_ADC
}

//-------------------------------------------------------------------------------------------------------
// setMUX - Configures the Muxes for a PSU number (or other voltage generators) and the desired function:
//				(0) FUNCTION_PSU_VOLTAGE: Allows Voltage readings.
//				(1) FUNCTION_READ_CURRENT: Allows current Readings.
//				(2) FUNCTION_READ_SUPPLY: Allows Supply voltage readings (Regulating cards).
//				(3) FUNCTION_READ_INTERNAL: Allows internal voltage readings (Controller card).
//			  Returns a float with a scale value for the selected voltage
//-------------------------------------------------------------------------------------------------------
float setMUX(BYTE samplingFunction, BYTE Num){
	scaleFactor = scaleFactorArray[_sf(samplingFunction, Num)] * DEFAULT_SCALE_FACTOR;
	switch(samplingFunction){

		case FUNCTION_PSU_VOLTAGE:
			if (Num > SF4_B){
				if (Num > SF5_B){	setPinsMUX(Num-8, MUX_E);}
				else {				setPinsMUX(Num-8, MUX_B);}}
			else{					setPinsMUX(Num, MUX_A);}
			break;

		case FUNCTION_PSU_CURRENT:
			if (Num>SF4_B){ setPinsMUX(Num-4, MUX_B);}
			else{			setPinsMUX(Num, MUX_C);}
			break;

		case FUNCTION_SnI_VOLTAGE:
			switch (Num){
				case SUP_n16_REG: case SUP_n20_UNREG: 	setPinsMUX(Num-8, MUX_E); break;
				case SUP_12V_F_D: 						setPinsMUX(0, 5); break;
				case INT_VCC_3V3: case INT_VCC_12V: 	setPinsMUX(Num-9, MUX_B); break;
				case INT_VCC_n12V: 						setPinsMUX(Num-9, MUX_E); break;
				default: 								setPinsMUX(Num, MUX_D); break;
			}
			break;
		default:
			iprintf(" ~ERROR MUX: Unsupported Function\n");
			break;
	}
	return scaleFactor;
}


//-------------------------------------------------------------------------------------------------------
// setPinsMUX - Sets all the GPIO pins for a selected number and mux
//-------------------------------------------------------------------------------------------------------
void setPinsMUX ( BYTE Num, BYTE Mux){

		Pins[15] = Num & 0x1; //A0_MUX_ABCDE
		Pins[16] = Num & 0x2; //A1_MUX_ABCDE
		Pins[17] = Num & 0x4; //A2_MUX_ABCDE
		Pins[18] = 1; //EN_MUX_ABCDE

		Pins[28] = Mux & 0x1; //A0_MUX_ADC
		Pins[33] = Mux & 0x2; //A1_MUX_ADC
		Pins[34] = Mux & 0x4; //A2_MUX_ADC
		Pins[35] = 1; //EN_MUX_ADC
}



float getScaleFactorMUX ( void ){
	return scaleFactor;
}

BYTE getI2CResultMUX ( void ){
	return resultI2C_MUX;
}
