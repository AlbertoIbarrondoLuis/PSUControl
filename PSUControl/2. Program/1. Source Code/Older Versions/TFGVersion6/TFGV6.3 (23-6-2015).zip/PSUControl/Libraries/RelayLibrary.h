/*
 * BusExpLibrary.h
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#ifndef LIB_RELAY

#define LIB_RELAY

#include "Headers.h"
#include "Libraries/I2C&SPILibrary.h"	// I2C&SPI Communication

void connectRelay ( int psuNum );
void disconnectRelay ( int psuNum );
void disconnectRelaySeveral ( WORD selectedPSUs );
BOOL getRelayStatus ( int psuNum );

#endif /* BUSEXPLIBRARY_H_ */
