/*
 * Interface.h
 *
 *	Console methods to program the system, display its status and configuration and use all the
 *	Library methods
 *
 *  Created on: 24/05/2015
 *      Author: ALBERTO IBARRONDO
 */

#ifndef DISPLAY_H_
#define DISPLAY_H_

#include "Headers.h"
#include "Controller/Controller.h"				// All the Controller Methods
#include "Libraries/Libraries.h"				// All the Libraries' Methods
#include "Tests/Tests.h"						// Testing
#include "Interface/LibrariesInterface/LibrariesINFC.h"	// Interface for Libraries' Methods


//==========================================GENERAL===========================================//
void InferfaceMain ( void ); 		// Call to access all the code via terminal. Can be exited
void InterfaceMenuINFC ( void );



//==========================================MODULES===========================================//

//------------------------------------ PROGRAMMING MENU --------------------------------------//
// Program Menu
void ProgramINFC ( void );
void processCommandProgramINFC ( void );
void alarmProgramMenuINFC ( BOOL psu_sni );
// Selectors
void selectNumsINFC ( BOOL psu_sni );
void selectAlarmsINFC ( BOOL psu_sni );
void selectProtocolsINFC ( BOOL psu_sni );
void selectShutdownINFC ( BOOL psu_sni );
// Programming methods
void switchOnOffINFC ( void );
void changeOutputVoltageINFC ( void );
void programInitializationTimerINFC ( void );
void programAlarmLimitTimesINFC ( BOOL psu_sni );
void programAlarmLimitValuesINFC ( BOOL psu_sni );
void programAlarmWatchINFC ( BOOL psu_sni );
void programAlarmProtocolsINFC ( BOOL psu_sni );
void programAlarmProtocolShutdownINFC(BOOL psu_sni);
void programAlarmProtocolModVoltINFC ( void );

//------------------------------------ DISPLAY MENU ------------------------------------------//
// Display Menu
void DisplayINFC ( void );
void processCommandDisplayINFC ( void );
// Status
void statusDisplayINFC ( void );
void refreshAlarmStatusINFC ( void );
void refreshValuesINFC ( void );
// Configuration
void configDisplayINFC ( BOOL psu_sni );
void refreshAlarmConfigINFC ( BOOL psu_sni );
void refreshValuesConfigINFC ( BOOL psu_sni );


//------------------------------------- FUNCTION MENU ----------------------------------------//
// Function Menu
void FunctionINFC ( void );
void processCommandFunctionINFC ( void );
// Libraries' Methods
void I2CnSPILibraryINFC( void );
void RDACLibraryINFC( void );
void AGCLibraryINFC ( void );
void RelayFunctionsDISP ( void );
void MUXLibraryINFC ( void );



//-------------------------------------- CONFIG MENU -----------------------------------------//
// Config Menu
void ConfigINFC ( void );
void processCommandConfigINFC ( void );
// Config Methods
void AlmPeriodConfigINFC ( void );
void snisConfigINFC( void );
void simulationINFC ( void );
void toggleRDACOutputINFC ( void );
void toggleI2CnSPIOutputINFC ( void );

#endif /* DISPLAY_H_ */
