/*
 * RelayLibrary.h
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#ifndef LIB_RELAY

#define LIB_RELAY

#include "Headers.h"
#include "Libraries/I2C&SPILibrary.h"	// I2C&SPI Communication

void connectRelay ( int psuNum );
void disconnectRelay ( int psuNum );
void connectSeveralRelay ( WORD selectedPSUs );
void disconnectSeveralRelay ( WORD selectedPSUs );
BOOL getStatusRelay ( int psuNum );
BYTE getI2CResultRelay ( void );

#endif /* LIB_RELAY */
