/*
 * I2CLibrary.h
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#ifndef LIB_I2CSPI
#define LIB_I2CSPI

#include "Headers.h"
#include "Libraries/GeneralLibrary.h"	// Functions with various general purposes

//----------------------------------------Functions--------------------------------------------------//
BYTE sendI2CMessage ( BYTE outputBuffer[], int bufSize, BYTE I2CAdress );
BYTE configureSPI( BOOL order, BOOL cpol, BOOL cpha, int clkRate, BYTE I2CAdress );
BYTE sendSPImessage ( BYTE outputBuffer[], int bufSize, BYTE slaveSelect, BYTE BridgeI2CAdress );
BYTE readBridgeBuffer ( BYTE inputBuffer[], int bufSize, BYTE I2CAdress);
void errorDetails( BYTE I2CStat );

#endif /* LIBRARY_H_ */

