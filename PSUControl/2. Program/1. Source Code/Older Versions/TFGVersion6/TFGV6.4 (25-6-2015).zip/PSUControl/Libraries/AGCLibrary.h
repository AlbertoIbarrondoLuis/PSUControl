/*
 * AGCLibrary.h
 *
 *  Created on: 17-abr-2015
 *      Author: Alberto
 */

#ifndef LIB_AGC
#define LIB_AGC

#include "Headers.h"
#include "Libraries/RDACLibrary.h"		// RDAC - Digital potentiometers

//----------------Configuration functions-------------------//
void minAGC( void );
void maxAGC( void );
void setGainAGC( float num );
void scaleGainAGC( float num );

//------------------Conversion functions--------------------//
float countsToGainAGC ( int rdacCount );
int gainToCountsAGC ( float gain );

//---------------------Getter functions---------------------//
int getCountsAGC ( void );
float getGainAGC ( void );
float readValuesAGC ( void );
BYTE getI2CResultAGC ( void );

#endif /* AGCLIBRARY_H_ */
