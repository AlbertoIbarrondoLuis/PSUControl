/*
 * Test_PSU.h
 *
 *  Created on: 10-mar-2015
 *      Author: Alberto
 */

#ifndef TEST_PSU_H_
#define TEST_PSU_H_

#include "Headers.h"
#include "Controller/Controller.h"		// All the Controller Methods
#include "Interface/Interface.h"		// Status display, Program and function menus

#endif /* TEST_PSU_H_ */

//==========================================MODULES===========================================//

//----------------------------------------- General ------------------------------------------//
void TestMain ( void );
void TestMenu ( void );
void PSUControlTEST ( void );



//--------------------------------Libraries' TEST methods-------------------------------------//
// Menu
void LibrariesTEST ( void );
// Tests
BOOL TEST_I2CSPILibrary ( void );
BOOL TEST_RDACLibrary ( void );
BOOL TEST_AGCLibrary( void );
BOOL TEST_MUXLibrary ( void );
BOOL TEST_RelayLibrary ( void );

//--------------------------------Controller TEST methods-------------------------------------//
// Menu
void ControllerTEST ( void );
// Global Tests
void TEST_Timer_Interruption ( void );
BOOL TEST_AlarmCTRL( void );
BOOL TEST_DataListsCTRL ( void );
BOOL TEST_FlashMemCTRL( void );
BOOL TEST_MonitorCTRL( void );
BOOL TEST_SwitchOnCTRL( void );
BOOL TEST_VoltCurrCTRL( void );

// Partial Tests
void TEST_AlarmCTRL_PSU1(void);
void TEST_AlarmCTRL_PSU2(void);
void TEST_AlarmCTRL_PSU3(void);
void TEST_AlarmCTRL_PSU4(void);
void TEST_AlarmCTRL_SnI1(void);
void TEST_AlarmCTRL_SnI2(void);
void TEST_AlarmCTRL_SnI3(void);
void TEST_FlashMemCTRL_PSU (void);
void TEST_FlashMemCTRL_SnI(void);
void TEST_MonitorCTRL_HIGHVALUES( void );
void TEST_MonitorCTRL_NOMINALVALUES( void );
