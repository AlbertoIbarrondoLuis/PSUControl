/*
 * SwitchOnCTRL.cpp
 *
 *	Relay connection & disconnection, delayed switch on process (based on initializationTimer) and
 *	programmed voltage update. It also sets PSUs into low voltage when disconnected, minimizing
 *	power consumption
 *
 *  Created on: 07-may-2015
 *      Author: Alberto
 */


#include "Controller/Controller.h"

//==============================================VARIABLES==============================================//
// Data Lists
extern PSU_TYPE psuList[PSU_NUMBER];			// Power supply units' array list
extern BOOL psuSelectionList[PSU_NUMBER];		// Used for several functions where multiple psu selection is required.

// Switching ON
BOOL powerONProcess = false; 					// used to initialize the system.
int powerONticks=0; 							// delay counter when initializing the system.
BOOL psuSelectionListPending [PSU_NUMBER] = {0,0,0,0,0,0,0,0,0,0,0,0};		// bits in TRUE are PSUs pending to be switched on

// Testing
extern BOOL testMode_SwitchOnCTRL_Task_FLAG;
extern int testMode_psu_initializationTimer[PSU_NUMBER];

// Led Out
BOOL ledOUT = OFF;

// Button
extern BOOL buttonAction;
BOOL buttonStatusFLAG = ledOUT;					// System is ON/OFF
BOOL psuBUTTONSelectionList[PSU_NUMBER];		// Stores the PSUs with status ON as TRUE in its corresponding
												// bit, and as FALSE with status OFF
// Auxiliary
int but_psuNum;

//=====================================================================================================//
//================================    PSUs SWITCH ON/OFF METHODS    ===================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// switchONPSUsTask - Manages the complete PSU switching-on process for the selected PSUs: Initializes
//				its RAM values, updates its RDAC Register values, tells the switchONPSUsTask to
//				begin the delayed switching-on process.
// 		#INPUT: +None: all the PSUs selected
//				+BOOL psuSelection[PSU_NUMBER] - boolean array where ONES are PSUs being switched on
// 		#OUTPUT: None
//		>E.G.:	switchONPSUs(selectedNums); - used in switchOnOffINFC ();
//-------------------------------------------------------------------------------------------------------
void switchONPSUs( void ){ memset(psuSelectionList, 1, PSU_NUMBER); switchONPSUs(psuSelectionList);}
void switchONPSUs( BOOL psuSelection[PSU_NUMBER] ){
	powerONProcess=true;					// Beginning of the process

	initializeValuesPSUsSnIs();				// Load psuList values from RAM or set them to default

	updateVoltagePSUs( psuSelection );		// Sets the PSUs' potentiometers (RDACS) to the loaded/default values

	switchONPSUsTask( psuSelection );		// Task to initialize PSUs with certain delay (initializationTimer)

    powerONProcess=false;					// End of the process
}



//-------------------------------------------------------------------------------------------------------
// switchONPSUsTask - Task in charge of the PSUs' delayed switching-on process, connecting the relays
//					  when each PSU reaches its initializationTimer. The task is endedWhen every PSU has
//					  been connected.
// 		#INPUT: +BOOL psuSelection[PSU_NUMBER] - boolean array where ONES are PSUs being switched on
// 		#OUTPUT: None
//		>E.G.:	switchONPSUsTask( psuSelection ); - used in switchONPSUs();
//-------------------------------------------------------------------------------------------------------
void switchONPSUsTask( BOOL psuSelection[PSU_NUMBER] ){
	powerONticks = 0; memcpy(psuSelectionListPending, psuSelection, PSU_NUMBER);
	int psuNum; BOOL allConnected = false, ledON = false;
	if (testMode_SwitchOnCTRL_Task_FLAG){
		iprintf("powerONticks = %d  -  PSUs pending: ", powerONticks);
		printBuffer(psuSelectionListPending, PSU_NUMBER);iprintf("\n");
	}
	while(!allConnected){
		allConnected = true;
		for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
			if(psuSelectionListPending[psuNum]){
				if(psuList[psuNum].initializationTimer == powerONticks){
					psuList[psuNum].ReadyToConnect = true;
					connectPSU(psuNum);
					psuSelectionListPending[psuNum] = false;
					if(testMode_SwitchOnCTRL_Task_FLAG){ // status storage if testMode ON
						testMode_psu_initializationTimer[psuNum]= powerONticks;
					}
				}
				else {
					allConnected = false;
				}
			}
			if(psuList[psuNum].psuStatus){ledON=true;}
		}

		if (testMode_SwitchOnCTRL_Task_FLAG){ // console output if testMode ON
			iprintf("powerONticks = %d  -  PSUs pending: ", powerONticks);
			printBuffer(psuSelectionListPending, PSU_NUMBER);iprintf("\n");
		}

		powerONticks++;
		OSTimeDly(TICKS_100MS);
	}
	ledOUT = ledON; LED_OUT_ON = ledOUT;
}

//-------------------------------------------------------------------------------------------------------
// switchOFFPSUs - Disconnects the selected PSUs' relays, sets their power to minimum, and updates LED OUT
// 		#INPUT: +None: all the PSUs selected
//				+BOOL psuSelection[PSU_NUMBER] - boolean array where ONES are PSUs being switched off
// 		#OUTPUT: None
//		>E.G.:	switchOFFPSUs(psuONSelectionList); - used in Interruption.cpp;
//-------------------------------------------------------------------------------------------------------
void switchOFFPSUs( void ){ memset(psuSelectionList, true, sizeof(psuSelectionList)); switchOFFPSUs(psuSelectionList);}
void switchOFFPSUs( BOOL psuSelection[PSU_NUMBER] ){
	int psuNum; BOOL ledOFF = true;
	for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
		if(psuSelection[psuNum]){
			disconnectRelay ( psuNum );
			adjustRdac(psuNum, INITIAL_VOLTAGE);
		}
		if (psuList[psuNum].psuStatus==ON){ledOFF = false;}
	}
	ledOUT=!ledOFF; LED_OUT_ON=ledOUT;
}



//-------------------------------------------------------------------------------------------------------
// connectPSU - Connects the selected PSU by switching its Relay and activates its LED OUT
// 		#INPUT: int psuNum - number of PSU (0 to 11) whose Relay will be connected
// 		#OUTPUT: None
//		>E.G.:	connectPSU(int psuNum); - used in switchONPSUsTask();
//-------------------------------------------------------------------------------------------------------
void connectPSU ( int psuNum ){
	connectRelay ( psuNum );
	psuList[psuNum].psuStatus=true;
	psuList[psuNum].ReadyToConnect=false;
}


//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSU's relay
// 		#INPUT: int psuNum - number of PSU (0 to 11) whose Relay will be disconnected
// 		#OUTPUT: None
//		>E.G.:	disconnectPSU(int psuNum); - used in switchOFFPSUs();
//-------------------------------------------------------------------------------------------------------
void disconnectPSU(int psuNum){
	disconnectRelay ( psuNum );
	psuList[psuNum].psuStatus=false;
	psuList[psuNum].ReadyToConnect=false;
}



//==============================================BUTTON=================================================//
//-------------------------------------------------------------------------------------------------------
// buttonTask - Switches ON/OFF the PSUs when an IRQ1 is triggered (setting buttonAction = true)
// 		#INPUT:	None
// 		#OUTPUT: None
//		>E.G.: config_alarmUpdatePeriod_x50MS ( 20 );
//-------------------------------------------------------------------------------------------------------
void buttonTask ( void ){
	if (buttonAction){
		if(buttonStatusFLAG==ON){
			for (but_psuNum=0; but_psuNum<PSU_NUMBER; but_psuNum++){
				psuBUTTONSelectionList[but_psuNum] = (getPSU(but_psuNum).psuStatus == ON);
			}
			switchOFFPSUs(psuBUTTONSelectionList);// Turns OFF all the PSUs what were ON (psuStatus == ON).
			iddleMode_AlarmCTRL_Task(ON);
			buttonStatusFLAG = OFF;
		}
		else{ // buttonStatusFLAG==OFF
			switchONPSUs(psuBUTTONSelectionList); // Turns ON all the PSUs what were turned off when button was pressed the first time.
			iddleMode_AlarmCTRL_Task(OFF);
			buttonStatusFLAG = ON;
		}
		buttonAction = false;
	}
}
