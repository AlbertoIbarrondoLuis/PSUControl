/*
 * Test_PSU.h
 *
 *  Created on: 10-mar-2015
 *      Author: Alberto
 */

#ifndef TEST_PSU_H_
#define TEST_PSU_H_

#include "Headers.h"
#include "Controller/Controller.h"		// All the Controller Methods
#include "Interface/Interface.h"		// Status display, Program and function menus

#endif /* TEST_PSU_H_ */

//==========================================MODULES===========================================//

//-------------------------------VOLTAGE & CURRENT METHODS------------------------------------//
void TestMain ( void );
void GeneralMenu ( void );
void CommandMenu( void );
void processCommand( void );
void changeSlave( void );


//--------------------------------Libraries' TEST methods-------------------------------------//
BOOL TEST_I2CSPILibrary ( void );
BOOL TEST_RDACLibrary ( void );
BOOL TEST_AGCLibrary( void );


//--------------------------------Controller TEST methods-------------------------------------//

//Global
BOOL TEST_AlarmCTRL( void );
BOOL TEST_DataListsCTRL ( void );
BOOL TEST_FlashMemCTRL( void );
BOOL TEST_MonitorCTRL( void );
BOOL TEST_SwitchOnCTRL( void );
BOOL TEST_VoltCurrCTRL( void );

//Partial
void TEST_AlarmCTRL_PSU1(void);
void TEST_AlarmCTRL_PSU2(void);
void TEST_AlarmCTRL_PSU3(void);
void TEST_AlarmCTRL_PSU4(void);
void TEST_AlarmCTRL_SnI1(void);
void TEST_AlarmCTRL_SnI2(void);
void TEST_AlarmCTRL_SnI3(void);
void TEST_FlashMemCTRL_PSU (void);
void TEST_FlashMemCTRL_SnI(void);
void TEST_MonitorCTRL_HIGHVALUES( void );
void TEST_MonitorCTRL_NOMINALVALUES( void );
