/*
 * AGCLibrary.cpp
 *
 *  Created on: 17-abr-2015
 *      Author: Alberto
 */

#include "AGCLibrary.h"

float gainAGC = 1.1;
int rdacCountAGC = 0;
BYTE resultI2C_AGC = 0;
BOOL maxAGCReached = false;
BOOL minAGCReached = false;

void minAGC( void ){
	rdacCountAGC = RDAC_MIN_VALUE;
	countsToGainAGC ( rdacCountAGC );
	setValRDAC(rdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
	resultI2C_AGC = getI2CResultRDAC();
	maxAGCReached = false;
}

void maxAGC( void ){
	rdacCountAGC = RDAC_MAX_VALUE;
	countsToGainAGC ( rdacCountAGC );
	setValRDAC(rdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
	resultI2C_AGC = getI2CResultRDAC();
	maxAGCReached = true;
}

void setGainAGC( float num ){
	gainAGC = num;
	gainToCountsAGC(gainAGC);
	if (rdacCountAGC > RDAC_MAX_VALUE){
		rdacCountAGC = RDAC_MAX_VALUE;
		countsToGainAGC(rdacCountAGC);
		maxAGCReached = true;
	}
	else{
		maxAGCReached = false;
	}
	setValRDAC(rdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
	resultI2C_AGC = getI2CResultRDAC();
}

void scaleGainAGC( float num ){
	gainAGC = gainAGC * num;
	gainToCountsAGC(gainAGC);
	if (rdacCountAGC > RDAC_MAX_VALUE){
		rdacCountAGC = RDAC_MAX_VALUE;
		countsToGainAGC(rdacCountAGC);
		maxAGCReached = true;
	}
	else{
		maxAGCReached = false;
	}
	setValRDAC(rdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
	resultI2C_AGC = getI2CResultRDAC();
}

float countsToGainAGC ( int rdacCount ){
	gainAGC = 1 + (((float)rdacCount + 1)/1024)*100;
	return gainAGC;
}

int gainToCountsAGC (float gain){
	rdacCountAGC = (int)((((gain-1)/100)*1024)+1);
	return rdacCountAGC;
}

int getCountsAGC ( void ){
	return rdacCountAGC;
}

float getGainAGC ( void ){
	return gainAGC;
}

BYTE getI2CResultAGC ( void ){
	return resultI2C_AGC;
}
