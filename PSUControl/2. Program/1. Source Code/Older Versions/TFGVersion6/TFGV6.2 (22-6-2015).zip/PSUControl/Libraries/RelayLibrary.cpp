/*
 * BusExpLibrary.cpp
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#include "Libraries/RelayLibrary.h"

//==============================================VARIABLES==============================================//
// Data Lists
extern PSU_TYPE psuList[PSU_NUMBER];			// Power supply units' array list

// I2C Bus Expander
BYTE expanderBusBuffer[1] = {0};
BYTE mask, data;

// Relays
#define CONNECTED 0x1
#define DISCONNECTED 0x0


//=====================================================================================================//
//======================================    RELAY METHODS    ==========================================//
//=====================================================================================================//

void initRelay ( void ){
	Pins[22].function( PIN22_GPIO ); // Relay SF1_A (0)
	Pins[23].function( PIN23_GPIO ); // Relay SF1_B (1)
	Pins[24].function( PIN24_GPIO ); // Relay SF2_A (2)
	Pins[25].function( PIN25_GPIO ); // Relay SF2_B (3)
	Pins[26].function( PIN26_GPIO ); // Relay SF3_A (4)
	Pins[27].function( PIN27_GPIO ); // Relay SF3_B (5)
}

void connectRelay ( int psuNum ){
	if (psuNum > SF3_B){
		mask = 1<<(psuNum - 6); // SF4_A -> 0
		expanderBusBuffer[0] = ( expanderBusBuffer[0] & !mask ) | ( CONNECTED & mask );
		sendI2CMessage (expanderBusBuffer, 1, EXPANDER_I2C_ADDRESS);
	}
	else{
		Pins[psuNum+22]=CONNECTED;
	}
	psuList[psuNum].relayStatus=true;
}

void disconnectRelay ( int psuNum ){
	if (psuNum > SF3_B){
		mask = 1<<(psuNum - 6); // SF4_A -> 0
		expanderBusBuffer[0] = ( expanderBusBuffer[0] & !mask ) | ( DISCONNECTED & mask );
		sendI2CMessage (expanderBusBuffer, 1, EXPANDER_I2C_ADDRESS);
	}
	else{
		Pins[psuNum+22]=DISCONNECTED;
	}
	psuList[psuNum].relayStatus=false;
}

void disconnectRelaySeveral ( WORD selectedPSUs ){
	// TODO: Select the desired GPIO PINs and set them to 0
}

BOOL getRelayStatus ( int psuNum ){
	return true;
}
