/*
 * FunctionDISP.cpp
 *
 *  Created on: 23/06/2015
 *      Author: ALBERTO IBARRONDO
 */

#include "Interface.h"
#include "Libraries/Libraries.h"


//==============================================VARIABLES==============================================//
// Imported
extern BOOL maxAGCReached;

// Keyboard
extern char categorySelectionINFC;
#define EXIT 'e'
char functionSelectionINFC ='\0';
char auxSelectionINFC = '\0';
static char funcChar;					// used for WAIT_FOR_KEYBOARD macro, and as auxiliary variable in certain functions
#define WAIT_FOR_KEYBOARD funcChar = sgetchar(0);

// I2C&SPI, RDAC
#define CHANGE_SLAVE slaveSPIAddressINFC=(psuNumINFC&0x1?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
BYTE bufferINFC[I2C_MAX_BUF_SIZE];
BYTE slaveSPIAddressINFC = SECOND_SLAVE_SPI_ADDRESS;	// Set to FIRST_SLAVE_SPI_ADDRESS or SECOND_SLAVE_SPI_ADDRESS
BYTE i2cAddressINFC = 0x2F;								// Defined by 3 switches for RDACs. 0x28 to 0x2F
extern BYTE bridgeI2CAddressList[PSU_NUMBER];

// Values
float floatValue=0;
int psuNumINFC;
int newvalueINFC;
BOOL ctrl_allowINFC = false;

// Pause Tasks
extern BOOL idleMode_Alarm;
extern BOOL seqMode_Monitor;

//=====================================================================================================//
//======================================   FUNCTION MENU   ============================================//
//=====================================================================================================//

void FunctionINFC ( void ){
	// Setting alarm and monitor Tasks into Pause status
	if (!idleMode_Alarm)	{ iddleMode_AlarmCTRL_Task (true);		}
	if (!seqMode_Monitor)	{ sequentialMode_MonitorCTRL_Task(true);}

	ERASE_CONSOLE
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("------------------------------- FUNCTION MENU ---------------------------------\r\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf(" (1) I2C&SPILibrary - Communications\n");
	iprintf(" (2) RDACLibrary - Digital Rheostats\n");
	iprintf(" (3) AGCLibrary - Automatic Gain Control\n");
	iprintf(" (4) RelayLibrary - Relays\n");
	iprintf(" (5) VoltCurrCTRL - Voltage and Current measuring\n");
	iprintf("\n (e) EXIT TO GENERAL MENU \r\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("\r\nEnter command \r\n" );
	categorySelectionINFC = sgetchar( 0 );
	processCommandFunctionINFC();
}


void processCommandFunctionINFC ( void ){
	switch (categorySelectionINFC){
		case '1': I2CSPIFunctionsINFC(); break;
		case '2': RDACFunctionsDISP(); break;
		case '3': AGCFunctionsDISP(); break;
		case '4': RelayFunctionsDISP(); break;
		case '5': VoltCurrFunctionsDISP(); break;
		case EXIT:
			iprintf("Exiting to INTERFACE MENU\n");
			// Setting alarm and monitor Tasks into previous status
			iddleMode_AlarmCTRL_Task (idleMode_Alarm);
			sequentialMode_MonitorCTRL_Task(seqMode_Monitor);
			break;
		default:
			iprintf("invalid command -> %c\n", categorySelectionINFC);
			break;
	}
	WAIT_FOR_KEYBOARD
}



/////////////////////////////////////////////////////////////// NOT IMPLEMENTED YET
void AGCFunctionsDISP ( void ){
	functionSelectionINFC = '0';
	while ( functionSelectionINFC!=EXIT ){
		iprintf("AGC Library\n");
		iprintf(" (1) Minimum AGC Gain\n");
		iprintf(" (2) Maximum AGC Gain\n");
		iprintf(" (3) Scale AGC Gain\n");
		iprintf(" (4) Set AGC Gain\n");
		iprintf(" (5) Convert Gain to RDAC Counts\n");
		iprintf(" (6) Convert RDAC Counts to Gain \n");
		iprintf(" (7) Get Current Gain and Counts\n");
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
		iprintf( "--------------------------------------------------------\r\n" );
		iprintf( "\r\nEnter command \r\n" );
		functionSelectionINFC = sgetchar(0);

		switch ( functionSelectionINFC ){
			case '1':
			iprintf("1. Setting AGC gain to Minimum\n");
			minAGC();
			iprintf("",getGainAGC(), maxAGCReached);
			break;

			case '2':
			iprintf("2. Setting AGC gain to maximum\n");
			maxAGC();
			iprintf("",getGainAGC(), maxAGCReached);
			break;
			case '3':
			iprintf("3. Scaling AGC gain\n");
			iprintf("Current AGC gain: %d\n", getGainAGC());
			iprintf("Scale factor: \n");
			*bufferINFC = 0x00000000;
			floatValue=atof(gets((char*)bufferINFC));iprintf("\r\n");
			iprintf("Final AGC gain: %d\n", getGainAGC());
			break;

			case '4':
			iprintf("4. Set AGC gain\n");
			iprintf("Current AGC gain: %d\n", getGainAGC());
			iprintf("New Vaule: \n");
			*bufferINFC = 0x00000000;
			floatValue=atof(gets((char*)bufferINFC));iprintf("\r\n");
			iprintf("Final AGC gain: %d\n", getGainAGC());
			break;

			case '5':
			iprintf("5. Conversion: Counts to Gain\n");
			iprintf("Counts: ");
			*bufferINFC = 0x00000000;
			floatValue=atof(gets((char*)bufferINFC));iprintf("\r\n");
			// COUNTS TO GAIN
			iprintf("Converted gain: %d\n", getGainAGC());
			break;

			case '6':
			iprintf("6. Conversion: Gain to Counts\n");
			iprintf("Gain: ");
			floatValue=atof(gets((char*)bufferINFC));iprintf("\r\n");
			iprintf("Converted Counts: %d\n", getCountsAGC());
			break;

			case '7':
			iprintf("7. Get values\n");
			iprintf("AGC gain: %d\n", getGainAGC());
			iprintf("AGC Counts: %d\n", getCountsAGC());
			break;

			case EXIT: iprintf(" Going back to general menu\n"); break;
			default: iprintf("Invalid Command\n");break;
		}
		iprintf("-------Function END-------");
	}
}

void RelayFunctionsDISP ( void ) {
	functionSelectionINFC = '0';
	while ( functionSelectionINFC!=EXIT ){
		iprintf("Relay Library\n");
		iprintf(" (1) Connect PSU Relay\n");
		iprintf(" (2) Disconnect PSU Relay\n");
		iprintf(" (3) Relays' Status\n");
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
		iprintf( "--------------------------------------------------------\r\n" );
		iprintf( "\r\nEnter command \r\n" );
		functionSelectionINFC = sgetchar(0);
		switch ( functionSelectionINFC ){
			case '1':
			iprintf("1. Connect Relay\n");
			selectPSUNumINFC();
			connectPSU( psuNumINFC );
			iprintf("Relay connected for PSU %d\n", psuNumINFC);
			break;

			case '2': iprintf("3. Disconnect Relay\n");
			selectPSUNumINFC();
			disconnectPSU( psuNumINFC );
			iprintf("Relay disconnected for PSU %d\n", psuNumINFC);
			break;

			case '3':
			iprintf("3. Relay Status\n");
			for (int i=0; i<PSU_NUMBER; i++){
				iprintf("%d: %s\n", i, (getRelayStatus(i)?"CONNECTED":"DISCONNECTED"));
			}
			break;

			case EXIT: iprintf(" Going back to general menu\n"); break;
			default: iprintf("Invalid Command\n"); break;
		}
		iprintf("-------Function END-------");
	}
}

void VoltCurrFunctionsDISP ( void ){
	functionSelectionINFC = '0';
	while ( functionSelectionINFC!=EXIT ){
		iprintf("Voltage & Current Controller\n");
		iprintf(" (1) Change Voltage to a PSU\n");
		iprintf(" (2) Read PSU voltage\n");
		iprintf(" (3) Read PSU current\n");
		iprintf(" (4) Read SnI voltage\n");
		iprintf(" (5) Convert Volts to RDAC Counts\n");
		iprintf(" (6) Convert RDAC Counts to Volts \n");
		iprintf(" (7) Get Current Gain and Counts\n");
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
		iprintf( "--------------------------------------------------------\r\n" );
		iprintf( "\r\nEnter command \r\n" );
		functionSelectionINFC = sgetchar(0);

		switch ( functionSelectionINFC ){
			case '1': //adjustRDAC();
				break;
		}
	}
}

