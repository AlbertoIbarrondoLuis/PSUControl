/*
 * MUXLibrary.h
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#ifndef LIB_MUX

#include "Headers.h"
#include "Libraries/I2C&SPILibrary.h"	// I2C&SPI Communication

#define LIB_MUX

void initMUX ( void );
float setMUX(BYTE samplingFunction, BYTE Num);
void setPinsMUX ( BYTE Num, BOOL abcde_adc);
float getScaleFactorMUX ( void );
BYTE getI2CResultMUX ( void );

#endif /* MUXLIBRARY_H_ */
