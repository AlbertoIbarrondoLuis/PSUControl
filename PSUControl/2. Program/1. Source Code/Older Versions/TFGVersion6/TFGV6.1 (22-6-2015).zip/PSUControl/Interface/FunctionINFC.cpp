/*
 * FunctionDISP.cpp
 *
 *  Created on: 23/06/2015
 *      Author: ALBERTO IBARRONDO
 */

#include "Interface.h"
#include "Libraries/Libraries.h"


//==============================================VARIABLES==============================================//
// Imported
extern BOOL maxAGCReached;

// Keyboard
extern char categorySelectionINFC;
#define EXIT 'e'
char functionSelectionINFC ='\0';
char auxSelectionINFC = '\0';

// I2C&SPI, RDAC
#define CHANGE_SLAVE slaveSPIAddressINFC=(psuNumINFC&0x1?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
BYTE bufferINFC[I2C_MAX_BUF_SIZE];
BYTE slaveSPIAddressINFC = SECOND_SLAVE_SPI_ADDRESS;	// Set to FIRST_SLAVE_SPI_ADDRESS or SECOND_SLAVE_SPI_ADDRESS
BYTE i2cAddressINFC = 0x2F;								// Defined by 3 switches for RDACs. 0x28 to 0x2F
extern BYTE bridgeI2CAddressList[PSU_NUMBER];

// Values
float floatValue=0;
int psuNumINFC;
int newvalueINFC;
BOOL ctrl_allowINFC = false;


//=====================================================================================================//
//======================================   FUNCTION MENU   ============================================//
//=====================================================================================================//

void FunctionINFC ( void ){
	iprintf( "\n\n\n\n\n\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("------------------------------- FUNCTION MENU ---------------------------------\r\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf(" (1) I2C&SPILibrary - Communications\n");
	iprintf(" (2) RDACLibrary - Digital Rheostats\n");
	iprintf(" (3) AGCLibrary - Automatic Gain Control\n");
	iprintf(" (4) RelayLibrary - Relays\n");
	iprintf(" (5) VoltCurrCTRL - Voltage and Current measuring\n");
	iprintf("\n (e) EXIT TO GENERAL MENU \r\n" );
	iprintf("-------------------------------------------------------------------------------\r\n" );
	iprintf("\r\nEnter command \r\n" );
	categorySelectionINFC = sgetchar( 0 );
	processCommandFunctionINFC();
}


void processCommandFunctionINFC ( void ){
	switch (categorySelectionINFC){
		case '1': I2CSPIFunctionsINFC(); break;
		case '2': RDACFunctionsDISP(); break;
		case '3': AGCFunctionsDISP(); break;
		case '4': RelayFunctionsDISP(); break;
		case '5': VoltCurrFunctionsDISP(); break;
		case EXIT: iprintf(" Going back to general menu\n");break;
		default: iprintf("Invalid Command\n");break;
	}
}

void I2CSPIFunctionsINFC( void ){
	functionSelectionINFC = '0';
	while ( functionSelectionINFC!=EXIT ){
		iprintf( "\n\n\n\r\n\r\n====================== I2C&SPI FUNCTIONS =======================\r\n" );
		iprintf( "I2C: 0x%x       SLAVE: %s, %d\n",  i2cAddressINFC, (slaveSPIAddressINFC==SECOND_SLAVE_SPI_ADDRESS?"UPPER":"LOWER"), slaveSPIAddressINFC);
		iprintf( "\nADDRESSING OPTIONS\r\n" );
		iprintf( " (+) Change I2C Address destination manually (0x2F to 0x28 for RDACs)\r\n" );
		iprintf( " (-) Toggle SPI Selected slave (Upper/Lower)\r\n" );
		iprintf( " (*) Set I2C & SPI addresses for a certain PSU\r\n" );
		iprintf( "\nI2C&SPI FUNCTIONS\r\n" );
		iprintf( " (1) Configure both I2C & SPI Channels\n");
		iprintf( " (2) Send I2C configurable message\n");
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
		iprintf( "--------------------------------------------------------\r\n" );
		iprintf( "\r\nEnter command \r\n" );
		functionSelectionINFC = sgetchar(0);
		switch ( functionSelectionINFC ){
			case '1':
				iprintf("\n\n\n\n(1). Configure both I2C & SPI Channels\n");
				I2CInit(MCF5213_I2C_ADDRESS, I2C_FREQUENCY);
				configureSPI( false, false, false, 2, i2cAddressINFC);	// MSB first, CLK low when idle, data clocked
			break;
			case '2':
				iprintf("\n\n\n\n(2). Send I2C configurable message\n");
				I2CInit(MCF5213_I2C_ADDRESS, I2C_FREQUENCY);
				iprintf("Buffer to TX (2B = 4 HEX characters): ");
				gets((char*)bufferINFC);
				sendI2CMessage ( bufferINFC, (strlen( (const char*)bufferINFC ) )+1, i2cAddressINFC);
			break;
			case '+':
				iprintf( "(+). Change I2C Address destination manually (0x2F to 0x28 for RDACs)\r\n" );
				while( (i2cAddressINFC < 0x07) || (i2cAddressINFC > 0x78) )  //While address is invalid
				{
				   iprintf( "Enter valid 7-bit (2-digit hex) destination address for Master Transmit: ");
				   *bufferINFC = 0x0000;
				   i2cAddressINFC = (BYTE)atoi( gets((char*)bufferINFC));
				   iprintf("\r\n");
				}
				iprintf(" -> Destination I2C Address: 0x%x\n", i2cAddressINFC);
			break;
			case '-':
				iprintf( "(-). Toggle SPI Selected slave (Upper/Lower)\r\n" );
				slaveSPIAddressINFC=(slaveSPIAddressINFC==SECOND_SLAVE_SPI_ADDRESS?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
				iprintf(" -> Selected %s PSU (SPI dir: 0x%x)\n", (slaveSPIAddressINFC==SECOND_SLAVE_SPI_ADDRESS?"UPPER":"LOWER"), slaveSPIAddressINFC );
			break;
			case '*':
				iprintf( "(*). Set I2C & SPI addresses for a certain PSU\r\n" );
				selectPSUNumINFC();
				i2cAddressINFC = bridgeI2CAddressList[psuNumINFC];
				slaveSPIAddressINFC=(psuNumINFC&0x1?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
				iprintf(" -> Selected PSU: %d\n", psuNumINFC);
				iprintf(" -> Destination I2C Address: 0x%x\n", i2cAddressINFC);
				iprintf(" -> Selected %s PSU (SPI dir: 0x%x)\n", (slaveSPIAddressINFC==SECOND_SLAVE_SPI_ADDRESS?"UPPER":"LOWER"), slaveSPIAddressINFC );
			break;
			case EXIT: iprintf( "\nGOING BACK TO FUNCTION MENU\n");					break;
			default:iprintf( "\nINVALID COMMAND -> %c\r\n", functionSelectionINFC);	break;
		}
		iprintf("--------------------------------------------------------\r\n");
	}
}

void RDACFunctionsDISP( void ){
	functionSelectionINFC = '0';
	while ( functionSelectionINFC!=EXIT ){
		iprintf( "\n\n\n\r\n\r\n====================== RDAC FUNCTIONS =======================\r\n" );
		iprintf( "I2C: 0x%x       SLAVE: %s, %d\n",  i2cAddressINFC, (slaveSPIAddressINFC==SECOND_SLAVE_SPI_ADDRESS?"UPPER":"LOWER"), slaveSPIAddressINFC);
		iprintf( "\nADDRESSING OPTIONS\r\n" );
		iprintf( " (+) Change I2C Address destination manually (0x2F to 0x28 for RDACs)\r\n" );
		iprintf( " (-) Toggle SPI Selected slave (Upper/Lower)\r\n" );
		iprintf( " (*) Set I2C & SPI addresses for a certain PSU\r\n" );
		iprintf( "\nRDAC FUNCTIONS (1 to 9)\r\n" );
		iprintf( " (1) Change RDAC Value\r\n" );
		iprintf( " (2) Read RDAC Value\r\n" );
		iprintf( " (3) Change RDAC Control Register (allow/reject updates)\r\n" );
		iprintf( " (4) Read RDAC Control Register\r\n" );
		iprintf( " (5) Reset RDAC\r\n" );
		iprintf( " (6) High Impedance on SDO for RDAC\r\n" );
		iprintf( " (7) Scaled (+1,-1) change of RDAC value\r\n" );
		iprintf( " (8) Program RDAC Value in 20TP-Mem\r\n" );
		iprintf( " (9) Read RDAC 20TP-Mem Value\r\n" );
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
		iprintf( "--------------------------------------------------------\r\n" );
		iprintf( "\r\nEnter command \r\n" );
		functionSelectionINFC = sgetchar(0);
		switch ( functionSelectionINFC ){
			case '1': case '"':
				iprintf("\n\n\n\n(1). Configuring RDAC Value\n");
				newvalueINFC = scanFloatValue(800);
				setValRDAC(newvalueINFC, slaveSPIAddressINFC, i2cAddressINFC);
			break;

			case '2':
				iprintf("\n\n\n\n(2). Reading RDAC Value\n");
				CHANGE_SLAVE
				highImpRDAC(slaveSPIAddressINFC, i2cAddressINFC);
				CHANGE_SLAVE
				getValRDAC(slaveSPIAddressINFC, i2cAddressINFC);
			break;

			case '3':
				ctrl_allowINFC = !ctrl_allowINFC;
				if(ctrl_allowINFC){
					iprintf("\n\n\n\n(3). Configuring control register to ALLOW RDAC Value to be updated\n");
					setCtrlRDAC(0,1,0, slaveSPIAddressINFC, i2cAddressINFC);	// Second bit controls RDAC update permission (1)
				}
				else{
					iprintf("\n\n\n\n(3). Configuring control register to REJECT RDAC Value updates\n");
					setCtrlRDAC(0,0,0, slaveSPIAddressINFC, i2cAddressINFC);	// Second bit controls RDAC update permission (0)
				}
			break;

			case '4':
				iprintf("\n\n\n\n(4). Reading RDAC Ctrl Value\n");
				CHANGE_SLAVE
				highImpRDAC(slaveSPIAddressINFC, i2cAddressINFC);
				CHANGE_SLAVE
				getCtrlRDAC(slaveSPIAddressINFC, i2cAddressINFC);
			break;

			case '5':
				iprintf("\n\n\n\n(5). Resetting RDAC to 0x200\n");
				resetRDAC(slaveSPIAddressINFC, i2cAddressINFC);
			break;

			case '6':
				iprintf("\n\n\n\n(6). Setting RDAC SDO in high impedance\n");
				highImpRDAC(slaveSPIAddressINFC, i2cAddressINFC);
			break;

			case '7':
				CHANGE_SLAVE
				highImpRDAC(slaveSPIAddressINFC, i2cAddressINFC);
				CHANGE_SLAVE
				newvalueINFC = getValRDAC(slaveSPIAddressINFC, i2cAddressINFC);
				toggleConsoleOutputRDACLib(OFF);
				toggleConsoleOutputI2CLib(OFF);

				iprintf("newvalue = %d\n", newvalueINFC);

				iprintf( "\n\n\n\n(7). Scaled change RDAC value\r\n Command list:\n" );
				iprintf( " (+) More Output Voltage\r\n" );
				iprintf( " (-) Less Output Voltage\r\n" );
				iprintf( " (e) Exit\r\n" );
				iprintf( "\r\nEnter command \r\n >" );
				auxSelectionINFC =sgetchar (0);
				while ( auxSelectionINFC != EXIT ){
					switch ( auxSelectionINFC ){
						case '+':
							newvalueINFC-=1;
							setValRDAC(newvalueINFC, slaveSPIAddressINFC, i2cAddressINFC);
							printf( "Output Voltage +: %.2f (n=%d)\r\n", numToVolt(newvalueINFC, 820), newvalueINFC);
							break;

						case '-':
							newvalueINFC+=1;
							setValRDAC(newvalueINFC, slaveSPIAddressINFC, i2cAddressINFC);
							printf( "Output Voltage -: %.2f (n=%d)\r\n", numToVolt(newvalueINFC, 820), newvalueINFC);
							break;
						case 'e':break;
						default:iprintf( "INVALID COMMAND -> %c\r\n", auxSelectionINFC);break;
					}
					iprintf("\n > ");
					auxSelectionINFC =sgetchar (0);
				}
				iprintf("\n > Exiting Scaled change RDAC\n");
				toggleConsoleOutputRDACLib(ON);
				toggleConsoleOutputI2CLib(ON);
			break;

			case '8': case '(':
				iprintf( " (8) Program RDAC Value in 20TP-Mem\r\n" );
				auxSelectionINFC = 'n';
				while (auxSelectionINFC!='y'){
					newvalueINFC = scanFloatValue(820);
					iprintf( " Do you wish to program value 0x%x in slave %d with I2C = 0x%x ? (y/n)\r\n", newvalueINFC, slaveSPIAddressINFC, i2cAddressINFC);
					auxSelectionINFC =sgetchar(0);
				}
				programMemRDAC(newvalueINFC,slaveSPIAddressINFC, i2cAddressINFC );
			break;
			case '9': case ')':
				iprintf( " (9) Read RDAC 20TP-Mem Value\r\n" );
				readMemRDAC(slaveSPIAddressINFC, i2cAddressINFC );
			break;

			case '+':
				iprintf( "(+). Change I2C Address destination manually (0x2F to 0x28 for RDACs)\r\n" );
				while( (i2cAddressINFC < 0x07) || (i2cAddressINFC > 0x78) )  //While address is invalid
				{
				   iprintf( "Enter valid 7-bit (2-digit hex) destination address for Master Transmit: ");
				   *bufferINFC = 0x0000;
				   i2cAddressINFC = (BYTE)atoi( gets((char*)bufferINFC));
				   iprintf("\r\n");
				}
				iprintf(" -> Destination I2C Address: 0x%x\n", i2cAddressINFC);
			break;
			case '-':
				iprintf( "(-). Toggle SPI Selected slave (Upper/Lower)\r\n" );
				slaveSPIAddressINFC=(slaveSPIAddressINFC==SECOND_SLAVE_SPI_ADDRESS?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
				iprintf(" -> Selected %s PSU (SPI dir: 0x%x)\n", (slaveSPIAddressINFC==SECOND_SLAVE_SPI_ADDRESS?"UPPER":"LOWER"), slaveSPIAddressINFC );
			break;
			case '*':
				iprintf( "(*). Set I2C & SPI addresses for a certain PSU\r\n" );
				selectPSUNumINFC();
				i2cAddressINFC = bridgeI2CAddressList[psuNumINFC];
				iprintf(" -> Selected PSU: %d\n", psuNumINFC);
				iprintf(" -> Destination I2C Address: 0x%x\n", i2cAddressINFC);
				iprintf(" -> Selected %s PSU (SPI dir: 0x%x)\n", (slaveSPIAddressINFC==SECOND_SLAVE_SPI_ADDRESS?"UPPER":"LOWER"), slaveSPIAddressINFC );
			break;
			case EXIT: iprintf( "\nGOING BACK TO GENERAL MENU\n");					break;
			default:iprintf( "\nINVALID COMMAND -> %c\r\n", functionSelectionINFC);	break;
		}
		iprintf("--------------------------------------------------------\r\n");
	}
}



/////////////////////////////////////////////////////////////// NOT IMPLEMENTED YET
void AGCFunctionsDISP ( void ){
	functionSelectionINFC = '0';
	while ( functionSelectionINFC!=EXIT ){
		iprintf("AGC Library\n");
		iprintf(" (1) Minimum AGC Gain\n");
		iprintf(" (2) Maximum AGC Gain\n");
		iprintf(" (3) Scale AGC Gain\n");
		iprintf(" (4) Set AGC Gain\n");
		iprintf(" (5) Convert Gain to RDAC Counts\n");
		iprintf(" (6) Convert RDAC Counts to Gain \n");
		iprintf(" (7) Get Current Gain and Counts\n");
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
		iprintf( "--------------------------------------------------------\r\n" );
		iprintf( "\r\nEnter command \r\n" );
		functionSelectionINFC = sgetchar(0);

		switch ( functionSelectionINFC ){
			case '1':
			iprintf("1. Setting AGC gain to Minimum\n");
			minAGC();
			iprintf("",getGainAGC(), maxAGCReached);
			break;

			case '2':
			iprintf("2. Setting AGC gain to maximum\n");
			maxAGC();
			iprintf("",getGainAGC(), maxAGCReached);
			break;
			case '3':
			iprintf("3. Scaling AGC gain\n");
			iprintf("Current AGC gain: %d\n", getGainAGC());
			iprintf("Scale factor: \n");
			*bufferINFC = 0x00000000;
			floatValue=atof(gets((char*)bufferINFC));iprintf("\r\n");
			iprintf("Final AGC gain: %d\n", getGainAGC());
			break;

			case '4':
			iprintf("4. Set AGC gain\n");
			iprintf("Current AGC gain: %d\n", getGainAGC());
			iprintf("New Vaule: \n");
			*bufferINFC = 0x00000000;
			floatValue=atof(gets((char*)bufferINFC));iprintf("\r\n");
			iprintf("Final AGC gain: %d\n", getGainAGC());
			break;

			case '5':
			iprintf("5. Conversion: Counts to Gain\n");
			iprintf("Counts: ");
			*bufferINFC = 0x00000000;
			floatValue=atof(gets((char*)bufferINFC));iprintf("\r\n");
			// COUNTS TO GAIN
			iprintf("Converted gain: %d\n", getGainAGC());
			break;

			case '6':
			iprintf("6. Conversion: Gain to Counts\n");
			iprintf("Gain: ");
			atof;
			iprintf("Converted Counts: %d\n", getCountsAGC());
			break;

			case '7':
			iprintf("7. Get values\n");
			iprintf("AGC gain: %d\n", getGainAGC());
			iprintf("AGC Counts: %d\n", getCountsAGC());
			break;

			case EXIT: iprintf(" Going back to general menu\n"); break;
			default: iprintf("Invalid Command\n");break;
		}
		iprintf("-------Function END-------");
	}
}

void RelayFunctionsDISP ( void ) {
	functionSelectionINFC = '0';
	while ( functionSelectionINFC!=EXIT ){
		iprintf("Relay Library\n");
		iprintf(" (1) Connect PSU Relay\n");
		iprintf(" (2) Disconnect PSU Relay\n");
		iprintf(" (3) Relays' Status\n");
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
		iprintf( "--------------------------------------------------------\r\n" );
		iprintf( "\r\nEnter command \r\n" );
		functionSelectionINFC = sgetchar(0);
		switch ( functionSelectionINFC ){
			case '1':
			iprintf("1. Connect Relay\n");
			selectPSUNumINFC();
			connectPSU( psuNumINFC );
			iprintf("Relay connected for PSU %d\n", psuNumINFC);
			break;

			case '2': iprintf("3. Disconnect Relay\n");
			selectPSUNumINFC();
			disconnectPSU( psuNumINFC );
			iprintf("Relay disconnected for PSU %d\n", psuNumINFC);
			break;

			case '3':
			iprintf("3. Relay Status\n");
			for (int i=0; i<PSU_NUMBER; i++){
				iprintf("%d: %s\n", i, (getRelayStatus(i)?"CONNECTED":"DISCONNECTED"));
			}
			break;

			case EXIT: iprintf(" Going back to general menu\n"); break;
			default: iprintf("Invalid Command\n"); break;
		}
		iprintf("-------Function END-------");
	}
}

void VoltCurrFunctionsDISP ( void ){
	functionSelectionINFC = '0';
	while ( functionSelectionINFC!=EXIT ){
		iprintf("Voltage & Current Controller\n");
		iprintf(" (1) Change Voltage to a PSU\n");
		iprintf(" (2) Read PSU voltage\n");
		iprintf(" (3) Read PSU current\n");
		iprintf(" (4) Read SnI voltage\n");
		iprintf(" (5) Convert Volts to RDAC Counts\n");
		iprintf(" (6) Convert RDAC Counts to Volts \n");
		iprintf(" (7) Get Current Gain and Counts\n");
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
		iprintf( "--------------------------------------------------------\r\n" );
		iprintf( "\r\nEnter command \r\n" );
		functionSelectionINFC = sgetchar(0);

		switch ( functionSelectionINFC ){
			case '1': //adjustRDAC();
				break;
		}
	}
}


void selectPSUNumINFC ( void ){
	iprintf( " Select PSU number (0 to 11): " );
	*bufferINFC = 0x0000;
	psuNumINFC=atoi(gets((char*)bufferINFC));iprintf("\r\n");
	if ((psuNumINFC<0) || (psuNumINFC>=PSU_NUMBER)){
		iprintf( " Invalid number. Selecting 0 instead\n " );psuNumINFC=0;
	}
}
