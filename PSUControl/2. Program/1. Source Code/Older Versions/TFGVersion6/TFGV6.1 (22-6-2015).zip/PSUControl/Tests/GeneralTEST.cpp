/*
 * Test_PSU.cpp
 *
 *  Created on: 10-mar-2015
 *      Author: Alberto
 */




#include "Tests.h"



//==============================================VARIABLES==============================================//

// Used for Keyboard
static char c;					// used for WAIT_FOR_KEYBOARD macro, and as auxiliary variable in certain functions
#define WAIT_FOR_KEYBOARD c = sgetchar(0);
static char menuSelection;
static char testSelection;
#define EXIT 'e'

// Imported Arrays
//extern PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
//extern SnI_TYPE sniList [INT_VCC_n12V + 1];				// Supply & Internal voltages List

// Auxiliary
BYTE destAddress = 0;							// For I2C Simple communication
BYTE buffer[I2C_MAX_BUF_SIZE];
BYTE test_slave_address = SECOND_SLAVE_SPI_ADDRESS;	// Set to FIRST_SLAVE_SPI_ADDRESS or SECOND_SLAVE_SPI_ADDRESS
BYTE test_bridge_address = 0x2F;					// Defined by 3 switches.
float Test_Rpsu = 825;
int newvalue;
BOOL sl_addr = false; BOOL i2c_addr = true; BOOL ctrl_allow = false;

// Results
BYTE result1; BYTE result2;BYTE result3; BYTE result4;BYTE result5;
BYTE result6; BYTE result7; BYTE result8;BYTE result9; BYTE result10;
BYTE resultTotal;



//=====================================================================================================//
//==================================    General Testing METHODS    ====================================//
//=====================================================================================================//

void TestMain ( void ){
	menuSelection = '0';
	while (menuSelection!=EXIT){
		GeneralMenu();
		menuSelection = sgetchar( 0 );
		testSelection = '0';
		while (testSelection!=EXIT){
			CommandMenu();
			testSelection = sgetchar( 0 );
			processCommand();
			iprintf("\n\n\n\n------------------------ TEST END ----------------------\n");
			WAIT_FOR_KEYBOARD
		}
	}
}


void GeneralMenu ( void ){
	iprintf( "\n\n\n\n\n\n========================================================\r\n" );
	iprintf( "====================== TEST MENU =======================\r\n" );
	iprintf( "========================================================\r\n" );
	iprintf( " (1) I2C, SPI & RDAC Tests\r\n" );
	iprintf( " (2) Monitor Tests\r\n" );
	iprintf( " (3) Software Tests\r\n" );
	iprintf( "\n (e) EXIT TO INTERFACE MENU \r\n" );
	iprintf( "--------------------------------------------------------\r\n" );
	iprintf( "\r\nSelect menu number  \r\n" );
}


void CommandMenu( void ){
	switch (menuSelection){
	case '1':
		iprintf( "\n\n\n\r\n\r\n================= I2C&SPI&RDAC TEST MENU ==================\r\n" );
		iprintf( "I2C: 0x%x       SLAVE: %s, %d\n",  test_bridge_address, (sl_addr?"UPPER":"LOWER"), test_slave_address);
		iprintf( "\nADDRESSING OPTIONS\r\n" );
		iprintf( " (+) Toggle I2C Address destination (0x2F or 0x28)\r\n" );
		iprintf( " (-) Toggle SPI Selected slave (Upper/Lower)\r\n" );
		iprintf( "\nRDAC FUNCTIONS (1 to 9)\r\n" );
		iprintf( " (1) Change RDAC Value\r\n" );
		iprintf( " (2) Read RDAC Value\r\n" );
		iprintf( " (3) Change RDAC Control Register (allow/reject updates)\r\n" );
		iprintf( " (4) Read RDAC Control Register\r\n" );
		iprintf( " (5) Reset RDAC\r\n" );
		iprintf( " (6) High Impedance on SDO for RDAC\r\n" );
		iprintf( " (7) Scaled (+1,-1) change of RDAC value\r\n" );
		iprintf( " (8) Program RDAC Value in 20TP-Mem\r\n" );
		iprintf( " (9) Read RDAC 20TP-Mem Value\r\n" );
		iprintf( "\nCOMPLETE TESTS\r\n" );
		iprintf( " (t) TEST_I2C_ADDRESSING\r\n" );
		iprintf( " (u) BATTERY_TEST_RDAC \r\n" );
		iprintf( "\n (e) EXIT TO TEST MENU \r\n" );
	break;

	case '2':
		iprintf( "\n\n\n\r\n\r\n================== MONITORING TEST MENU ===================\r\n" );
		iprintf( "\nMONITORING\r\n" );
		iprintf( " (z) Voltage scan\r\n" );
		iprintf( " (x) Current scan\r\n" );
		iprintf( " (s) TEST_AGCLibrary\r\n" );
		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
	break;

	case '3':
		iprintf( "\n\n\n\r\n\r\n=================== SOFTWARE TEST MENU ====================\r\n" );
		iprintf( "\nSOFTWARE TESTS\r\n" );
		iprintf( " (a) TEST_TIMER_INTERRUPTS\r\n" );
		iprintf( " (g) TEST_AlarmCTRL \r\n" );
		iprintf( " (y) TEST_DataListsCTRL \r\n" );
		iprintf( " (h) TEST_FlashMemCTRL \r\n" );
		iprintf( " (s) TEST_MonitorCTRL \r\n" );
		iprintf( " (d) TEST_SwitchOnCTRL \r\n" );
		iprintf( " (f) TEST_VoltCurrCTRL \r\n" );

		iprintf( "\n (e) EXIT TO GENERAL MENU \r\n" );
	break;

	default:
		iprintf( "\nINVALID MENU NUMBER -> %c\r\n", menuSelection);
		iprintf( " \r\nPRESS ANY KEY TO EXIT\r\n" );
	break;
	}
	iprintf( "--------------------------------------------------------\r\n" );
	iprintf( "\r\nEnter command \r\n" );
}

void processCommand( void )
{
	switch ( menuSelection ){
	case '1':
		switch ( testSelection ){
			case 'q': case 'Q':
				iprintf("\n\n\n\n(q). Configure both I2C & SPI Channels\n");
				I2CInit(MCF5213_I2C_ADDRESS, I2C_FREQUENCY);
				configureSPI( false, false, false, 2, test_bridge_address);	// MSB first, CLK low when idle, data clocked
			break;
			case 'w': case 'W':
				iprintf("\n\n\n\n(w). Send I2C configurable message\n");
				I2CInit(MCF5213_I2C_ADDRESS, I2C_FREQUENCY);
				while( (destAddress < 0x07) || (destAddress > 0x78) )  //While address is invalid
				{
				   iprintf( "Enter valid 7-bit (2-digit hex) destination address for Master Transmit: ");
				   *buffer = 0x0000;
				   destAddress = (BYTE)atoi( gets((char*)buffer));
				   iprintf("\r\n");
				}
				iprintf("Buffer to TX (2B = 4 HEX characters): ");
				gets((char*)buffer);
				sendI2CMessage ( buffer, (strlen( (const char*)buffer ) )+1, destAddress);
			break;
			case '1': case '"':   // In case user just wants to press the '1/"' key
				// 900 = 5V
				iprintf("\n\n\n\n(1). Configuring RDAC Value\n");
				newvalue = scanFloatValue(Test_Rpsu);
				setValRDAC(newvalue, test_slave_address, test_bridge_address);
			break;

			case '2':
				iprintf("\n\n\n\n(2). Reading RDAC Value\n");
				changeSlave();
				highImpRDAC(test_slave_address, test_bridge_address);
				changeSlave();
				getValRDAC(test_slave_address, test_bridge_address);
			break;

			case '3':
				ctrl_allow = !ctrl_allow;
				if(ctrl_allow){
					iprintf("\n\n\n\n(3). Configuring control register to ALLOW RDAC Value to be updated\n");
					setCtrlRDAC(0,1,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (1)
				}
				else{
					iprintf("\n\n\n\n(3). Configuring control register to REJECT RDAC Value updates\n");
					setCtrlRDAC(0,0,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)
				}
			break;

			case '4':
				iprintf("\n\n\n\n(4). Reading RDAC Ctrl Value\n");
				changeSlave();
				highImpRDAC(test_slave_address, test_bridge_address);
				changeSlave();
				getCtrlRDAC(test_slave_address, test_bridge_address);
			break;

			case '5':
				iprintf("\n\n\n\n(5). Resetting RDAC to 0x200\n");
				resetRDAC(test_slave_address, test_bridge_address);
			break;

			case '6':
				iprintf("\n\n\n\n(6). Setting RDAC SDO in high impedance\n");
				highImpRDAC(test_slave_address, test_bridge_address);
			break;

			case '7':
				changeSlave();
				highImpRDAC(test_slave_address, test_bridge_address);
				changeSlave();
				newvalue = getValRDAC(test_slave_address, test_bridge_address);
				toggleConsoleOutputRDACLib(OFF);
				toggleConsoleOutputI2CLib(OFF);

				iprintf("newvalue = %d\n", newvalue);

				iprintf( "\n\n\n\n(7). Scaled change RDAC value\r\n Command list:\n" );
				iprintf( " (+) More Output Voltage\r\n" );
				iprintf( " (-) Less Output Voltage\r\n" );
				iprintf( " (e) Exit\r\n" );
				iprintf( "\r\nEnter command \r\n >" );
				testSelection =sgetchar (0);
				while ( testSelection != 'e' ){
					switch ( testSelection ){
						case '+':
							newvalue-=1;
							setValRDAC(newvalue, test_slave_address, test_bridge_address);
							printf( "Output Voltage +: %.2f (n=%d)\r\n", numToVolt(newvalue, Test_Rpsu), newvalue);
							break;

						case '-':
							newvalue+=1;
							setValRDAC(newvalue, test_slave_address, test_bridge_address);
							printf( "Output Voltage -: %.2f (n=%d)\r\n", numToVolt(newvalue, Test_Rpsu), newvalue);
							break;
						case 'e':
							break;
						default:
							iprintf( "INVALID COMMAND -> %c\r\n", testSelection);
							break;
					}
					iprintf("\n > ");
					testSelection =sgetchar (0);
				}
				iprintf("\n > Exiting Scaled change RDAC\n");
				toggleConsoleOutputRDACLib(ON);
				toggleConsoleOutputI2CLib(ON);
			break;

			case '8': case '(':
				iprintf( " (8) Program RDAC Value in 20TP-Mem\r\n" );
				c = 'n';
				while (c!='y'){
					newvalue = scanFloatValue(Test_Rpsu);
					iprintf( " Do you wish to program value 0x%x in slave %d with I2C = 0x%x ? (y/n)\r\n", newvalue, test_slave_address, test_bridge_address);
					c =sgetchar(0);
				}
				programMemRDAC(newvalue,test_slave_address, test_bridge_address );
			break;
			case '9': case ')':
				iprintf( " (9) Read RDAC 20TP-Mem Value\r\n" );
				readMemRDAC(test_slave_address, test_bridge_address );
			break;
			case '+':
				i2c_addr = !i2c_addr;
				test_bridge_address = (i2c_addr?0x2F:0x28);
				iprintf(" -> Destination I2C Address: 0x%x\n", test_bridge_address);

			break;
			case '-':
				changeSlave();
				iprintf(" -> Selected %s PSU (SPI dir: 0x%x)\n", (sl_addr?"UPPER":"LOWER"), test_slave_address );
			break;
			case 't': case 'T':
				TEST_I2CSPILibrary();
			break;
			case 'u': case 'U':
				TEST_RDACLibrary();
			break;
			case EXIT: iprintf( "\nGOING BACK TO GENERAL MENU\n");
				testSelection = 'e';
			break;
			default:iprintf( "\nINVALID COMMAND -> %c\r\n", testSelection);	break;
		}
	break;
	case '2':	// MONITOR TESTS
		switch ( testSelection ){
			case 'z': case 'Z':
				// TODO: TC_F_MONITORING_SCAN_VOLTAGE_SINGLE not yet defined
			break;
			case 'x': case 'X':
				// TODO: TC_F_MONITORING_SCAN_CURRENT_SINGLE not yet defined
			break;
			case 's': case 'S':
				TEST_AGCLibrary();
			break;
			case 'e':
				iprintf( "\nGOING BACK TO GENERAL MENU\n");
			break;
			default:
				iprintf( "\nINVALID COMMAND -> %c\r\n", testSelection);
			break;
		}
	break;

	case '3':	// SOFTWARE TESTS
		switch ( testSelection ){
			case 'a': case 'A':
				iprintf("\n\n\n\n(a). TEST_TIMER_INTERRUPTS (press e to exit)\n");
				while (c!='e'){
					WAIT_FOR_KEYBOARD
					iprintf("Pitr count zero = %ld Pitr count one = %ld\r\n", pitr_count_adc_sampling, pitr_count_zero);
				}
			break;
			case 'g': case 'G':
				TEST_AlarmCTRL();
			break;
			case 'f': case 'F':
				TEST_VoltCurrCTRL();
			break;
			case 's': case 'S':
				TEST_MonitorCTRL();
			break;
			case 'd': case 'D':
				TEST_SwitchOnCTRL();
			break;
			case 'y': case 'Y':
				TEST_DataListsCTRL();
			break;
			case 'h': case 'H':
				TEST_FlashMemCTRL();
			break;
			case 'e':
				iprintf( "\nGOING BACK TO GENERAL MENU\n");
			break;
			default:
				iprintf( "\nINVALID COMMAND -> %c\r\n", testSelection);
			break;
		}
	break;

	default:
		iprintf( "\nGOING BACK TO GENERAL MENU\n");
		testSelection = 'e';
	break;
	}

}





void changeSlave(void){
	sl_addr = !sl_addr;
	test_slave_address = (sl_addr?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
}
