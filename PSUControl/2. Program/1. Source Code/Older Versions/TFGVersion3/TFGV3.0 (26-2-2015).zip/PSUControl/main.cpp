
/******************************************************************************
 * 								MCF5213 PSU Monitor&Config
 *   General Purpose. Not with a specific use yet.
 *
 *   Author: Alberto Ibarrondo
 *
 *****************************************************************************/
float versionNo =3.0;

#include <basictypes.h>							// BOOL & BYTE
#include <a2d.h>								// Analog to digital converter
#include "GeneralLibrary.h"						// Functions with various general purposes
#include "I2CLibrary.h"							// I2C&SPI Communication
#include "RDACLibrary.h"						// RDAC configuration
#include "PSULibrary.h"							// Heaviest program
#include "defineConstants.cpp"					// Default Values and other Defines


//====================================INICIALIZACIONES===============================================//
extern "C" { void UserMain( void * pd); }
void _init (void);

//---------------------------------------Constants---------------------------------------------------//
const char * AppName="PSUControl";
int freqDiv = 0x19;
BYTE nburnAddress = 0x29;						// Can be changed from 0x28 to 0x2F
BYTE i2CtoSPIAddress = 0x2F;					// Defined by 3 switches.
BYTE bufc[I2C_MAX_BUF_SIZE];
BYTE* pbufc = bufc + 2;



//========================================USERMAIN===================================================//
void UserMain(void * pd) {
	_init();									// Defined below. Contains all the configuration issues.
    char c = sgetchar( 0 );						// Frequently used to stop program until input is received

//--------------------------------------Main Loop----------------------------------------------------//
    while (1) {
    	LoadFlashValuesPSU ();
    	printValuesPSU(1);
    	printValuesPSU(4);
		iprintf("\n\n\n\n----------------PROGRAM END----------------\n");c = sgetchar( 0 );

    }
}




void _init (void){

	//-------------------------------------General System--------------------------------------------//
	SimpleUart(0,SystemBaud);assign_stdio(0);				// Serial port 0 for Data
	SimpleUart(1,SystemBaud);								// Serial port 1 for Debug
	#ifdef _DEBUG
		InitGDBStubNoBreak( 1, 115200 );
	#endif

	OSChangePrio(MAIN_PRIO);								//Other
	EnableSerialUpdate();
	#ifndef _DEBUG
	EnableSmartTraps();
	#endif

	iprintf("\n\n\n\n\n\n\n\nAplication initializing");
	putleds((int)versionNo);

	//--------------------------------------I2C Bus Connection---------------------------------------//
	I2CInit(nburnAddress, freqDiv); 						// Initialize I2C with Predefined Address (0x20)
															// Set frequency division to 1280 (66Mhz CF clock --> 25 Khz I2C bus)
															// which is half of the default freqDiv (0x15 = 640)
	iprintf("\r\n .Initialized I2C address for MCF5213: 0x%x\r\n",nburnAddress);
	iprintf(" .Set I2C Frequency division: %x (MCF internal CLK / 1280)\r\n",freqDiv);


	//-------------------------------------SPI Bus Connection----------------------------------------//
	configureSPI( false, false, false, 2, i2CtoSPIAddress);	// MSB first, CLK low when idle, data clocked
															//  in on leading edge, frequency = 115KHz

	//----------------------------------Analog to Digital Converter----------------------------------//
	Pins[11].function( PIN11_AN2 );							// Configure the A2D pins as analog inputs
	Pins[12].function( PIN12_AN1 );
	Pins[13].function( PIN13_AN0 );
	Pins[14].function( PIN14_AN3 );
	Pins[15].function( PIN15_AN7 );
	Pins[16].function( PIN16_AN6 );
	Pins[17].function( PIN17_AN5 );
	Pins[18].function( PIN18_AN4 );

	EnableAD();
	iprintf(" .ADC initialized\r\n",freqDiv);

	iprintf("Application initialized\n\nPRESS ONE KEY TO BEGIN \n\n");


    //------------------------------------ RTOS Tasks------------------------------------------------//
    // TODO: convertirlo a aplicaci�n noRTOS con interrupciones. Opcional.
    OSSimpleTaskCreate( alarmTask, MAIN_PRIO - 2 );
    OSSimpleTaskCreate( switchONPSUsTask, MAIN_PRIO - 1 );
}

