/*
 * Test_PSU.cpp
 *
 *  Created on: 10-mar-2015
 *      Author: Alberto
 */

#define WAIT_FOR_KEYBOARD c = sgetchar(0);

#include "Test_PSU.h"
#include "I2CLibrary.h"

char c;
BYTE test_slave_address = SECOND_SLAVE_ADDRESS;	// Set to FIRST_SLAVE_ADDRESS or SECOND_SLAVE_ADDRESS
BYTE test_bridge_address = 0x2F;					// Defined by 3 switches.
BOOL sl_addr = false; BOOL i2c_addr = true; BOOL ctrl_allow = false;
BYTE result1; BYTE result2;

void displayCommandMenu( void ){
   iprintf( "\r\n\r\n----------------------- MAIN MENU ----------------------\r\n" );
   printf( "I2C: 0x%x       SLAVE: %s, %d\n",  test_bridge_address, (sl_addr?"UPPER":"LOWER"), test_slave_address);
   iprintf( "\nI2C&SPI CONFIG\r\n" );
   iprintf( " (q) Configure SPI Channel\n");
   iprintf( "\nRDAC FUNCTIONS (1 to 9)\r\n" );
   iprintf( " (1) Change RDAC Value\r\n" );
   iprintf( " (2) Read RDAC Value\r\n" );
   iprintf( " (3) Change RDAC Control Register (allow/reject updates)\r\n" );
   iprintf( " (4) Read RDAC Control Register\r\n" );
   iprintf( " (5) Reset RDAC\r\n" );
   iprintf( " (6) High Impedance on SDO for RDAC\r\n" );
   iprintf( "\nADDRESSING OPTIONS\r\n" );
   iprintf( " (a) I2C Address destination (0x2F or 0x28)\r\n" );
   iprintf( " (b) Selected slave (SPI Address)\r\n" );
   iprintf( "\nCOMPLETE TESTS\r\n" );
   iprintf( " (t) TEST_I2CtoSPI_test_bridge_address\r\n" );
   iprintf( " (u) TEST_RDAC_ONE \r\n" );
   iprintf( "--------------------------------------------------------\r\n" );
   iprintf( "\r\nEnter command \r\n" );
}

void processCommand( char ch )
{


	int newvalue = 840;
  	switch ( ch )
   {
		case 'q': case 'Q':
			iprintf("\n\n\n\n(q). Configuring SPI Channel (used as I2C message)\n", newvalue);
			configureSPI( false, false, false, 2, test_bridge_address);	// MSB first, CLK low when idle, data clocked
			break;
		case '1': case '"':   // In case user just wants to press the '1/"' key
			// 900 = 5V
			iprintf("\n\n\n\n(1). Configuring RDAC Value to %d\n", newvalue);
			setRegRDAC(newvalue, test_slave_address, test_bridge_address);
			break;

		case '2':
			iprintf("\n\n\n\n(2). Reading RDAC Value\n");
			changeSlave();
			highImpRDAC(test_slave_address, test_bridge_address);
			changeSlave();
			getRegRDAC(test_slave_address, test_bridge_address);
			break;

		case '3':
			ctrl_allow = !ctrl_allow;
			if(ctrl_allow){
				iprintf("\n\n\n\n(3). Configuring control register to ALLOW RDAC Value to be updated\n");
				setCtrlRDAC(0,1,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (1)
			}
			else{
				iprintf("\n\n\n\n(3). Configuring control register to REJECT RDAC Value updates\n");
				setCtrlRDAC(0,0,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)
			}
			break;

		case '4':
			iprintf("\n\n\n\n(4). Reading RDAC Ctrl Value\n");
			changeSlave();
			highImpRDAC(test_slave_address, test_bridge_address);
			changeSlave();
			getCtrlRDAC(test_slave_address, test_bridge_address);
			break;

		case '5':
			iprintf("\n\n\n\n(5). Resetting RDAC to 0x200\n");
			resetRDAC(test_slave_address, test_bridge_address);
			break;

		case '6':
			iprintf("\n\n\n\n(6). Setting RDAC SDO in high impedance\n");
			highImpRDAC(test_slave_address, test_bridge_address);
			break;

		case 'a': case 'A':
			i2c_addr = !i2c_addr;
			iprintf(" -> Destination I2C Address: \n", test_bridge_address);
			test_bridge_address = (i2c_addr?0x2F:0x28);

			break;
		case 'b': case 'B':
			changeSlave();
			iprintf(" -> Selected %s PSU (SPI dir: 0x%x)\n", (sl_addr?"UPPER":"LOWER"), test_slave_address );
			break;

		case 't': case 'T':
			// TEST_I2CtoSPI_test_bridge_address
			iprintf("\n\n\n\nTEST_I2CtoSPI_test_bridge_address\n");
			iprintf(" Change address manually in the I2CtoSPIBridge to 0x2F\n");
			WAIT_FOR_KEYBOARD
			iprintf(" Sending  to Address 0x2F\n");
			test_bridge_address = 0x2F;
			result1 = configureSPI( false, false, false, 2, test_bridge_address);
			iprintf(" Change address manually in the I2CtoSPIBridge to 0x28(invert all the switches)\n");
			WAIT_FOR_KEYBOARD
			iprintf(" Sending  to Address 0x28\n");
			test_bridge_address = 0x28;
			result2 = configureSPI( false, false, false, 2, test_bridge_address);
			WAIT_FOR_KEYBOARD
			iprintf("\n TEST RESULTS:\n");
			iprintf("\n result1: %s\n", ((result1==0)?"PASSED":"NOT PASSED"));
			iprintf("\n result1: %s\n", ((result2==0)?"PASSED":"NOT PASSED"));
			WAIT_FOR_KEYBOARD
			break;

		case 'u': case 'U':
			//TEST_RDAC_ONE
			highImpRDAC(FIRST_SLAVE_ADDRESS, test_bridge_address);
			highImpRDAC(SECOND_SLAVE_ADDRESS, test_bridge_address);
			iprintf("\n\n\n\nTEST_RDAC_ONE\n");
			iprintf("\nSELECTED SLAVE: %s\n", (sl_addr?"UPPER":"LOWER"));

			iprintf("\n\n\n\n1. Reading RDAC Value\n");
			WAIT_FOR_KEYBOARD
			getRegRDAC(test_slave_address, test_bridge_address);

			iprintf("\n\n\n\n2. Configuring Control Register to allow RDAC Value to be updated\n");
			WAIT_FOR_KEYBOARD
			setCtrlRDAC(0,1,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (1)

			newvalue = 900;
			// 900 = 5V
			iprintf("\n\n\n\n3. Configuring RDAC Value to %d and reading value\n", newvalue);
			WAIT_FOR_KEYBOARD
			setRegRDAC(newvalue, test_slave_address, test_bridge_address);
			getRegRDAC(test_slave_address, test_bridge_address);

			iprintf("\n\n\n\n4. Reading RDAC CTRL Register\n");
			WAIT_FOR_KEYBOARD
			getCtrlRDAC(test_slave_address, test_bridge_address);

			iprintf("\n\n\n\n5. Reading RDAC Value\n");
			WAIT_FOR_KEYBOARD
			getRegRDAC(test_slave_address, test_bridge_address);

			iprintf("\n\n\n\n5. Configuring Control Register in 1st to reject RDAC Value updates\n");
			WAIT_FOR_KEYBOARD
			setCtrlRDAC(0,0,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)

			iprintf("\n\n\n\n6. Reading CTRL Register & RDAC Value\n");
			WAIT_FOR_KEYBOARD
			getCtrlRDAC(test_slave_address, test_bridge_address);
			getRegRDAC(test_slave_address, test_bridge_address);

			newvalue = 400;
			iprintf("\n\n\n\n7. Unsuccessfully configuring RDAC Value to %d\n", newvalue);
			WAIT_FOR_KEYBOARD
			setRegRDAC(newvalue, test_slave_address, test_bridge_address);
			getRegRDAC(test_slave_address, test_bridge_address);

			iprintf("\n\n\n\n8. Resetting RDAC - Value is set to midscale\n");
			WAIT_FOR_KEYBOARD
			resetRDAC(test_slave_address, test_bridge_address);

			iprintf("\n\n\n\n9. Reading RDAC Value\n");
			WAIT_FOR_KEYBOARD
			getRegRDAC(test_slave_address, test_bridge_address);
			break;
      default:
         iprintf( "Invalid command\r\n" );
         break;
   }
}

void changeSlave(void){
	sl_addr = !sl_addr;
	test_slave_address = (sl_addr?FIRST_SLAVE_ADDRESS:SECOND_SLAVE_ADDRESS);
}
