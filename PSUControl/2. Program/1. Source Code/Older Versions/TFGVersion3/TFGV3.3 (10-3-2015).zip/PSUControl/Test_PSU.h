/*
 * Test_PSU.h
 *
 *  Created on: 10-mar-2015
 *      Author: Alberto
 */

#ifndef TEST_PSU_H_

#include "RDACLibrary.h"
#include "defineConstants.cpp"


#define TEST_PSU_H_


#endif /* TEST_PSU_H_ */
void displayCommandMenu( void );
void processCommand( char ch );
void changeSlave(void);
