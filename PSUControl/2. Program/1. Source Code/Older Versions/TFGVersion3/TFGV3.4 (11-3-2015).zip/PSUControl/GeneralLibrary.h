/*
 * GeneralLibrary.h
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#include <stdlib.h>
#include "predef.h"
#include <ctype.h>
#include <basictypes.h>
#include <constants.h>
#include <stdio.h>

#ifndef GENERALLIBRARY_H_
#define GENERALLIBRARY_H_
#endif /* GENERALLIBRARY_H_ */

void mergeBuffer(BYTE buf1[], BYTE buf2[], int size);
void printBuffer(BYTE buf1[], uint bufferSize);
BYTE Ascii2Byte( char* buf );

char* intToBuffer(char * buffer, int data);
void itoa(int n, char s[]);
void reverse(char s[]);
DWORD demux4to16 (int a);
