/*
 * defineConstants.cpp
 *
 *  Created on: 13-feb-2015
 *   Author: Alberto Ibarrondo
 */
#define ERROR_DETAILS 1						// Detailed Error Messages if 1


#define MCF5213_I2C_ADDRESS 0x29						// Can be changed from 0x28 to 0x2F
#define FIRST_SLAVE_ADDRESS 0x1				// U202
#define SECOND_SLAVE_ADDRESS 0x2			// U302

#define TASK_TIMES_PER_SECOND 10
#define TICKS_100MS TICKS_PER_SECOND/10

#define PSU_NUMBER 12
#define ALL_PSUS_INIT 0xFFF



// DEMUX METHOD
#define DEMUX(a) (0x1 << (a-1))

// ALARM ARRAYS ACCESS METHODS
#define _(a,b) a+2*b				// Arrays with 4 items. a=(INFERIOR/SUPERIOR); b=(VOLTAGE/CURRENT)
#define __(a,b,c) a+2*b+4*c			// Arrays with 8/12 items. a=(INFERIOR/SUPERIOR); b=(VOLTAGE/CURRENT);
									//		c=(PROTOCOL_SHUTDOWN/PROTOCOL_MODIFY_VOLTAGE/PROTOCOL_MESSAGE) for alarmProtocols.

// ALARM ARRAYS INDEXING
#define OFF	false
#define ON	true
#define INFERIOR 0					// First alarm array index bit (input "a" of the accessing methods)
#define SUPERIOR 1
#define VOLTAGE 0					// Second alarm array index bit (input "b" of the accessing methods)
#define CURRENT 1
									// Third alarm array index bit for alarmProtocols (input "c" of the accessing methods):
#define PROTOCOL_SHUTDOWN 0			// 	(0) Shut down certain PSUs
#define PROTOCOL_MODIFY_VOLTAGE 1	// 	(1) Modify Voltage
#define PROTOCOL_MESSAGE 2			// 	(2) Send Alarm Message
#define ALARM_PLOTOCOLS_NUM 3

#define ALARM_MESSAGE "ALARM in PSU n� %d. %s %s limit reached"


//selectMuxPSU FUNCTIONs
#define FUNCTION_READ_VOLTAGE 0
#define FUNCTION_READ_CURRENT 1
#define FUNCTION_SET_SCL 2


// IMPORTED VALUES
#define FINMENSAJE '#'
#define addressTransBus 0x3E //
#define addressAddressDriverA 0x3C //
#define addressAddressDriverB 0x3D //
#define potDigA 0x18
#define potDigB 0x4C
#define potDigC 0x1A
#define potDigD 0x4E






//_________________________________________DEFAULT VALUES_______________________________________________//
#define DEFAULT_releStatus false							// Relay flag
#define DEFAULT_psuStatus false								// PSU being used or not
#define DEFAULT_rdacValue 0x200								// RDACs' programmed value
#define DEFAULT_bridgeI2CAdr 0xF							// PSU I2C Bridge address

#define DEFAULT_alarmLimitValues {13, 17, 0.3, 3}			// Inferior (0) and superior (1) voltage alarm LIMITS (magnitude);
															//  and inferior (2) and superior (3) current alarm LIMITS.
#define DEFAULT_alarmLimitTimes	{100, 100, 100, 100}		// Inferior (0) and superior (1) voltage alarm TIMES
															//  (Counter limits which trigger alarmStatus On/Off when reached);
															//  and inferior (2) and superior (3) current alarm TIMES.
#define DEFAULT_alarmProtocols	{1,1,1,1,1,1,1,1,1,1,1,1}	// Activate(TRUE) or ignore(FALSE) each of the protocols when the alarm pops up:
															//  (0-3) Shut down certain PSUs, (4-7) Modify this PSU's Voltage, (8-11) Send Alarm Message.
#define DEFAULT_alarmProtocolShutdown {}					// PSU list to shutdown in alarm protocol Shutdown. Bits 0 to B shutdown
															//  PSUs 1 to 12 if set to TRUE.
#define DEFAULT_alarmProtocolVoltage {15,14,20,6}			// New values for this PSU's voltage when executed this alarm's Modify Voltage Protocol .
#define DEFAULT_alarmCounters {0, 0, 0, 0}					// Variables increasing on each scanning period if alarmLimitReached is ON(TRUE),
															//  until they reach alarmLimitTimes.
															//  They also serve for shutting down alarms when alarmLimitReached is OFF(FALSE).
#define DEFAULT_alarmStatus {false,false,false,false}		// FALSE: alarm hasn't been triggered, not performing any alarm protocols.
															//  TRUE: alarm is ON, performing alarm protocols.
#define DEFAULT_alarmLimitReached {false,false,false,false}	// FALSE: alarm hasn't reached the limit. If alarmStatus is ON, it will start
															//  decreasing the alarmCounter until alarmStatus is OFF(ntimes = alarmLimitTimes)
															//  TRUE: alarm has reached the limit, beginning to increase the alarmCounter
															//  until alarmStatus is ON (ntimes = alarmLimitTimes).

#define DEFAULT_alarmWatch {false,false,false,false}		// FALSE: alarm is not configured, it will neither analyze the system nor trigger the alarmStatus ON.
															//  TRUE: alarm is configured and working, will analyze the system, set the alarmStatus ON
															//  when a limit is reached, and execute the defined alarmProtocols
#define DEFAULT_rShunt 820									// Internal resistor used for RDAC configuration
#define DEFAULT_divisorTension1 0;							// valor de la resistencia R1 del divisor a la entrada del CAD para lectura tension. R303 a R310 y R319 a R322
#define DEFAULT_divisorTension2 0;							// valor de la resistencia R2 del divisor a la entrada del CAD para lectura tension. R311 a R311 y R323 a R326
#define DEFAULT_rAdicPotDigital 0;							// valor de la resistencia R203
#define DEFAULT_rDivisorPotDigital 0;						// valor de la resistencia R202

#define DEFAULT_vOut 0										// CAD value of the output voltage
#define DEFAULT_cOut 0										// CAD value of the output current

#define DEFAULT_initializationTimer 0						// x100ms initial count for PSU switching-on

#define VERIFY_KEY 0x12345678								// Verification key for stored data in FLASH memory
