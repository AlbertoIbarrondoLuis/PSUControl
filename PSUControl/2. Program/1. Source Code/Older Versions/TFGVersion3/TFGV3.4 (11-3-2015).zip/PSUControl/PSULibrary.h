/*
 * PSULibrary.h
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
 */

#ifndef PSULIBRARY_H_

#include "PSU_TYPE.cpp"

#define PSULIBRARY_H_


//-------------------------------VOLTAGE & CURRENT METHODS------------------------------------//
void adjustRdac (int psuNum, int slave, float Voltage);
void updateVoltagePSUs(DWORD selectPSUs);
void readVoltageValue(int psuNum);
void readCurrentValue(int psuNum);
void selectMuxPSU(int psuNum, int function);


//-------------------------------------ALARM METHODS------------------------------------------//
void alarmTask (void *p);
void alarmCheck (int psuNum);
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum);
void refreshAlarmCounters_100ms (void);


//-----------------------------------FLASH MEMORY METHODS-------------------------------------//
void LoadFlashValuesPSU (void);
int saveInFlashValuesPSU (void);
void readFlashValuesPSU(int psuNum, PSU_TYPE *pData);


//-------------------------------------AUXILIARY METHODS--------------------------------------//
void defaultValuesPSU (int psuNum);
void printValuesPSU (int psuNum);


//-----------------------------------SWITCH ON PSUs METHODS-----------------------------------//
void switchONPSUsTask(void *p);
int initializeValuesPSUs(void);
void connectPSU(int psuNum);
void switchONPSUs(DWORD selectedPSUs);
void disconnectPSU(int psuNum);



//___________________________________________________________________________________________//
//                    METHODS NOT BELONGING TO ME - LEFT TO BE REVISED
void EscribeEnDriver(int numDriver,BYTE dato, BYTE mascara);
void EscribeEnTransceptorBus(BYTE address, BYTE dato, BYTE mascara,BYTE * variable);
BYTE SeleccionaAddressPotDig(int numFuente);
void  InicializarBusesControladora(void);
#endif /* PSULIBRARY_H_ */


