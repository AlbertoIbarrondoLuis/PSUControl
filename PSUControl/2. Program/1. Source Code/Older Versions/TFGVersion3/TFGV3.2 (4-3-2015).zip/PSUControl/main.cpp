
/******************************************************************************
 * 								MCF5213 PSU Monitor&Config
 *   General Purpose. Not with a specific use yet.
 *
 *   Author: Alberto Ibarrondo
 *
 *****************************************************************************/
float versionNo =3.2;

#include <basictypes.h>							// BOOL & BYTE
#include <a2d.h>								// Analog to digital converter
#include "GeneralLibrary.h"						// Functions with various general purposes
#include "I2CLibrary.h"							// I2C&SPI Communication
#include "RDACLibrary.h"						// RDAC configuration
#include "PSULibrary.h"							// Heaviest program
#include "defineConstants.cpp"					// Default Values and other Defines


//====================================INICIALIZACIONES===============================================//
extern "C" { void UserMain( void * pd); }
void _init (void);

//---------------------------------------Constants---------------------------------------------------//
const char * AppName="PSUControl";
int freqDiv = 0x19;

BYTE i2CtoSPIAddress = 0x2F;					// Defined by 3 switches.
BYTE bufc[I2C_MAX_BUF_SIZE];
BYTE* pbufc = bufc + 2;



//========================================USERMAIN===================================================//
void UserMain(void * pd) {
	_init();									// Defined below. Contains all the configuration issues.
    char c = sgetchar( 0 );						// Frequently used to stop program until input is received

//--------------------------------------Main Loop----------------------------------------------------//
    while (1) {
    	// TEST_RDAC_ADR_BOTH
		iprintf("\n\n\n\nTEST_RDAC_ADR_BOTH\n");
		iprintf("\n\n\n\n1. Reading 1st RDAC Value,and 2nd RDAC Value, with and without setting SDO in high impedance\n");c = sgetchar( 0 );
		iprintf("\nWITHOUT HIGH IMP\n");
		getRegRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		getRegRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);

		iprintf("\nWITH HIGH IMP\n");c = sgetchar( 0 );
		highImpRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		highImpRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);
		getRegRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		highImpRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		getRegRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);
		highImpRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);

		iprintf("\n\n\n\n2. Configuring Control Register to allow 1st RDAC Value to be updated\n");c = sgetchar( 0 );
		setCtrlRDAC(0,1,0, FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);	// Second bit controls RDAC update permission (1)



		int newvalue = 700;
		iprintf("\n\n\n\n3. Configuring 1st RDAC Value to %d\n", newvalue);c = sgetchar( 0 );
		setRegRDAC(newvalue, FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);



		iprintf("\n\n\n\n4. Reading 1st RDAC CTRL Register, then 2nd, with and without setting SDO in high impedance\n");c = sgetchar( 0 );
		iprintf("\nWITHOUT HIGH IMP\n");
		getCtrlRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		getCtrlRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);
		iprintf("\nWITH HIGH IMP\n");c = sgetchar( 0 );
		highImpRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		highImpRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);
		getCtrlRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		highImpRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		getCtrlRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);
		highImpRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);

		iprintf("\n\n\n\n5. Configuring Control Register in 1st to reject RDAC Value updates, and in 2nd to allow them\n");c = sgetchar( 0 );
		setCtrlRDAC(0,0,0, FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);	// Second bit controls RDAC update permission (0)
		setCtrlRDAC(0,1,0, SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);

		iprintf("\n\n\n\n6. Reading CTRL Register\n");c = sgetchar( 0 );
		getCtrlRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		highImpRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		getCtrlRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);
		highImpRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);



		newvalue = 1000;
		iprintf("\n\n\n\n7. Unsuccessfully configuring RDAC 1st Value to %d, successfully doing it to 2nd\n", newvalue);c = sgetchar( 0 );
		setRegRDAC(newvalue, FIRST_SLAVE_ADDRESS, i2CtoSPIAddress); // There will be no change due to the Control register status in 1st
		setRegRDAC(newvalue, SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);

		iprintf("\n\n\n\n8. Resetting both RDACs - Value is set to midscale\n");c = sgetchar( 0 );
		resetRDAC(FIRST_SLAVE_ADDRESS, i2CtoSPIAddress);
		resetRDAC(SECOND_SLAVE_ADDRESS, i2CtoSPIAddress);
		iprintf("\n\n\n\n----------------PROGRAM END----------------\n");c = sgetchar( 0 );



    }
}




void _init (void){

	//-------------------------------------General System--------------------------------------------//
	SimpleUart(0,SystemBaud);assign_stdio(0);				// Serial port 0 for Data
	SimpleUart(1,SystemBaud);								// Serial port 1 for Debug
	#ifdef _DEBUG
		InitGDBStubNoBreak( 1, 115200 );
	#endif

	OSChangePrio(MAIN_PRIO);								//Other
	EnableSerialUpdate();
	#ifndef _DEBUG
	EnableSmartTraps();
	#endif

	iprintf("\n\n\n\n\n\n\n\nAplication initializing\n");
	putleds((int)versionNo);
	printf("Version Number --> %.2f\n", versionNo);
	//--------------------------------------I2C Bus Connection---------------------------------------//
	I2CInit(MCF5213_I2C_ADDRESS, freqDiv); 						// Initialize I2C with Predefined Address (0x20)
															// Set frequency division to 1280 (66Mhz CF clock --> 25 Khz I2C bus)
															// which is half of the default freqDiv (0x15 = 640)
	iprintf("Initialized I2C address for MCF5213: 0x%x\r\n",MCF5213_I2C_ADDRESS);
	iprintf(" .Set I2C Frequency division: %x (MCF internal CLK / 1280)\r\n",freqDiv);


	//-------------------------------------SPI Bus Connection----------------------------------------//
	configureSPI( false, false, false, 2, i2CtoSPIAddress);	// MSB first, CLK low when idle, data clocked
															//  in on leading edge, frequency = 115KHz

	//----------------------------------Analog to Digital Converter----------------------------------//
	/*
	Pins[11].function( PIN11_AN2 );							// Configure the A2D pins as analog inputs
	Pins[12].function( PIN12_AN1 );
	Pins[13].function( PIN13_AN0 );
	Pins[14].function( PIN14_AN3 );
	Pins[15].function( PIN15_AN7 );
	Pins[16].function( PIN16_AN6 );
	Pins[17].function( PIN17_AN5 );
	Pins[18].function( PIN18_AN4 );

	EnableAD();
	iprintf(" .ADC initialized\r\n",freqDiv);


	*/

    //------------------------------------ RTOS Tasks------------------------------------------------//
    // TODO: convertirlo a aplicaci�n noRTOS con interrupciones. Opcional.
    /*
	OSSimpleTaskCreate( alarmTask, MAIN_PRIO - 2 );
    OSSimpleTaskCreate( switchONPSUsTask, MAIN_PRIO - 1 );
    */
	iprintf("Application initialized\n\nPRESS ONE KEY TO BEGIN \n\n");
}

