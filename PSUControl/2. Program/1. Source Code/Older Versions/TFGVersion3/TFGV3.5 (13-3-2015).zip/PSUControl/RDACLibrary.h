/*
 * RDACcomplexLibrary.h
 *
 *  Created on: 02-feb-2015
 *      Author: Alberto
 */

#ifndef RDACCOMPLEXLIBRARY_H_
#define RDACCOMPLEXLIBRARY_H_
#endif /* RDACCOMPLEXLIBRARY_H_ */


#include "I2CLibrary.h"


//-------------------------------------RDAC METHODS---------------------------------------//
void setCtrlRDAC(BOOL calibrationDisable, BOOL regWriteEnable, BOOL programEnable, BYTE slaveSelect, BYTE I2CAdress);
BYTE getCtrlRDAC(int slaveSelect, BYTE I2CAdress);
void setRegRDAC(int value, BYTE slaveSelect, BYTE I2CAdress);
int getRegRDAC(int slaveSelect, BYTE I2CAdress);
void highImpRDAC(int slaveSelect, BYTE I2CAdress);
void resetRDAC(int slaveSelect, BYTE I2CAdress);
void shutdownRDAC(BOOL shutdownModeOn,int slaveSelect, BYTE I2CAdress);
void donothingRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAdress);



//------------------------------------AUXILIAR METHODS-------------------------------------//
BYTE getResult(void);
void printRegRDAC (BYTE ibuf[]);
void printCtrlRDAC (BYTE ibuf[]);
int voltToNum (float volt, float Rpsu);
float numToVolt (int num, float Rpsu);
int scanFloatValue ( float Rpsu );
void toggleConsoleOutputRDACLib( void );



//------------------------------------BUFFER METHODS---------------------------------------//
// All the messages are stored in the given buffer's first 2 Bytes.
void doNothingCOM(BYTE* buffer);
void writeRegCOM(BYTE* buffer, int value );
void readRegCOM(BYTE* buffer);
void storeRegtoMemCOM(BYTE* buffer);
void resetCOM(BYTE* buffer);
void readMemCOM(BYTE* buffer, BYTE direction );
void writeCtrlCOM(BYTE* buffer, BOOL programEnable, BOOL regWriteEnable, BOOL calibrationDisable );
void readCtrlCOM(BYTE* buffer);
void shutdownCOM(BYTE* buffer, BOOL shutdownModeOn);
void highImpCOM(BYTE* buffer);
