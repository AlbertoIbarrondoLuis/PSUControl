/*
 * Test_PSU.cpp
 *
 *  Created on: 10-mar-2015
 *      Author: Alberto
 */

#define WAIT_FOR_KEYBOARD c = sgetchar(0);

#include "Test_PSU.h"
#include "I2CLibrary.h"
#include "RDACLibrary.h"

char c;
BYTE test_slave_address = SECOND_SLAVE_ADDRESS;	// Set to FIRST_SLAVE_ADDRESS or SECOND_SLAVE_ADDRESS
BYTE test_bridge_address = 0x2F;					// Defined by 3 switches.
float Test_Rpsu = 825;


BOOL sl_addr = false; BOOL i2c_addr = true; BOOL ctrl_allow = false;
BYTE result1; BYTE result2;
BYTE result3; BYTE result4;
BYTE result5; BYTE result6;
BYTE result7; BYTE result8;
BYTE result9; BYTE result10;

void TestMain ( void ){
	displayCommandMenu();
	static char a;
	a = sgetchar( 0 );
	processCommand(a);
	iprintf("\n\n\n\n--------------PROGRAM END----------------\n");
	WAIT_FOR_KEYBOARD
}

void displayCommandMenu( void ){
   iprintf( "\r\n\r\n----------------------- TEST MENU ----------------------\r\n" );
   printf( "I2C: 0x%x       SLAVE: %s, %d\n",  test_bridge_address, (sl_addr?"UPPER":"LOWER"), test_slave_address);
   iprintf( "\nI2C&SPI CONFIG\r\n" );
   iprintf( " (q) Configure SPI Channel\n");
   iprintf( "\nRDAC FUNCTIONS (1 to 9)\r\n" );
   iprintf( " (1) Change RDAC Value\r\n" );
   iprintf( " (2) Read RDAC Value\r\n" );
   iprintf( " (3) Change RDAC Control Register (allow/reject updates)\r\n" );
   iprintf( " (4) Read RDAC Control Register\r\n" );
   iprintf( " (5) Reset RDAC\r\n" );
   iprintf( " (6) High Impedance on SDO for RDAC\r\n" );
   iprintf( " (7) Scaled change RDAC value\r\n" );
   iprintf( "\nADDRESSING OPTIONS\r\n" );
   iprintf( " (a) I2C Address destination (0x2F or 0x28)\r\n" );
   iprintf( " (b) Selected slave (SPI Address)\r\n" );
   iprintf( "\nCOMPLETE TESTS\r\n" );
   iprintf( " (t) TEST_I2C_ADDRESSING\r\n" );
   iprintf( " (u) TEST_RDAC \r\n" );
   iprintf( "--------------------------------------------------------\r\n" );
   iprintf( "\r\nEnter command \r\n" );
}

void processCommand( char ch )
{


	int newvalue;
  	switch ( ch )
   {
		case 'q': case 'Q':
			iprintf("\n\n\n\n(q). Configuring SPI Channel (used as I2C message)\n");
			configureSPI( false, false, false, 2, test_bridge_address);	// MSB first, CLK low when idle, data clocked
			break;
		case '1': case '"':   // In case user just wants to press the '1/"' key
			// 900 = 5V
			iprintf("\n\n\n\n(1). Configuring RDAC Value\n");
			newvalue = scanFloatValue(Test_Rpsu);

			setRegRDAC(newvalue, test_slave_address, test_bridge_address);
			break;

		case '2':
			iprintf("\n\n\n\n(2). Reading RDAC Value\n");
			changeSlave();
			highImpRDAC(test_slave_address, test_bridge_address);
			changeSlave();
			getRegRDAC(test_slave_address, test_bridge_address);
			break;

		case '3':
			ctrl_allow = !ctrl_allow;
			if(ctrl_allow){
				iprintf("\n\n\n\n(3). Configuring control register to ALLOW RDAC Value to be updated\n");
				setCtrlRDAC(0,1,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (1)
			}
			else{
				iprintf("\n\n\n\n(3). Configuring control register to REJECT RDAC Value updates\n");
				setCtrlRDAC(0,0,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)
			}
			break;

		case '4':
			iprintf("\n\n\n\n(4). Reading RDAC Ctrl Value\n");
			changeSlave();
			highImpRDAC(test_slave_address, test_bridge_address);
			changeSlave();
			getCtrlRDAC(test_slave_address, test_bridge_address);
			break;

		case '5':
			iprintf("\n\n\n\n(5). Resetting RDAC to 0x200\n");
			resetRDAC(test_slave_address, test_bridge_address);
			break;

		case '6':
			iprintf("\n\n\n\n(6). Setting RDAC SDO in high impedance\n");
			highImpRDAC(test_slave_address, test_bridge_address);
			break;

		case '7':
			changeSlave();
			highImpRDAC(test_slave_address, test_bridge_address);
			changeSlave();
			newvalue = getRegRDAC(test_slave_address, test_bridge_address);
			toggleConsoleOutputRDACLib();
			toggleConsoleOutputI2CLib();

			iprintf("newvalue = %d\n", newvalue);

			iprintf( "\n\n\n\n(7). Scaled change RDAC value\r\n Command list:\n" );
			iprintf( " (+) More Output Voltage\r\n" );
			iprintf( " (-) Less Output Voltage\r\n" );
			iprintf( " (e) Exit\r\n" );
			iprintf( "\r\nEnter command \r\n >" );
			ch =sgetchar (0);
			while ( ch != 'e' ){
				switch ( ch ){
					case '+':
						newvalue-=1;
						setRegRDAC(newvalue, test_slave_address, test_bridge_address);
						printf( "Output Voltage +: %.2f (n=%d)\r\n", numToVolt(newvalue, Test_Rpsu), newvalue);
						break;

					case '-':
						newvalue+=1;
						setRegRDAC(newvalue, test_slave_address, test_bridge_address);
						printf( "Output Voltage -: %.2f (n=%d)\r\n", numToVolt(newvalue, Test_Rpsu), newvalue);
						break;
					case 'e':
						break;
					default:
						iprintf( "INVALID COMMAND -> %c\r\n", ch);
						break;
				}
				iprintf("\n > ");
				ch =sgetchar (0);
			}
			iprintf("\n > Exiting Scaled change RDAC\n");
			toggleConsoleOutputRDACLib();
			toggleConsoleOutputI2CLib();
			break;

		case 'a': case 'A':
			i2c_addr = !i2c_addr;
			iprintf(" -> Destination I2C Address: \n", test_bridge_address);
			test_bridge_address = (i2c_addr?0x2F:0x28);

			break;
		case 'b': case 'B':
			changeSlave();
			iprintf(" -> Selected %s PSU (SPI dir: 0x%x)\n", (sl_addr?"UPPER":"LOWER"), test_slave_address );
			break;

		case 't': case 'T':
			TEST_I2C_ADDRESSING();
			break;
		case 'u': case 'U':
			TEST_RDAC();
			break;
      default:
         iprintf( "\nINVALID COMMAND -> %c\r\n", ch);
         break;
   }
}

BOOL TEST_I2C_ADDRESSING ( void ){
	iprintf("\n\n\n\n===============TEST_I2C_ADDRESSING===============\n");
	iprintf(" 1.Change address manually in the I2CtoSPIBridge (Component U401) to 0x2F by setting the 3 switches to ZERO\n");
	iprintf("   Shutdown the PSU and disconnect the I2C bus cables, then connect them back and turn on the PSU\n");
	iprintf("  Press one key to begin test\n");
	WAIT_FOR_KEYBOARD
	iprintf(" Sending an I2C message to Address 0x2F\n");
	test_bridge_address = 0x2F;
	result1 = configureSPI( false, false, false, 2, test_bridge_address);
	result1 = (result1==0);
	iprintf(" \n\n 2.Change address manually in the I2CtoSPIBridge (Component U401) to 0x28 by setting the 3 switches to ONE\n");
	iprintf("    Shutdown the PSU and disconnect the I2C bus cables, then connect them back and turn on the PSU\n");
	iprintf("  Press one key to begin test\n");
	WAIT_FOR_KEYBOARD
	iprintf(" Sending an I2C message to Address 0x28\n");
	test_bridge_address = 0x28;
	result2 = configureSPI( false, false, false, 2, test_bridge_address);
	result2 = (result2==0);
	iprintf("\n TEST_I2C_ADDRESSING RESULTS:\n");
	iprintf("\n result1: %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf("\n result2: %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf("\n OVERALL RESULT: %s\n", ((result1&&result2)?"PASSED":"NOT PASSED"));
	return result1&&result2;
}

BOOL TEST_RDAC ( void ){
	iprintf("\n\n\n\n===============TEST_RDAC===============\n");
	iprintf("\nSELECT THE RDAC TO BE TESTED\n");
	iprintf(" (1) UPPER RDAC, Component U202\n");
	iprintf(" (2) LOWER RDAC, Component U302\n");
	char rdac = sgetchar(0);
	sl_addr = (rdac=='1');
	test_slave_address = (sl_addr?FIRST_SLAVE_ADDRESS:SECOND_SLAVE_ADDRESS);
	printf("\nSELECTED %s RDAC, Component %s\n", (rdac=='1'?"UPPER":"LOWER"), (rdac=='1'?"U202":"U302"));
	iprintf("Do you want to check the output voltage during the test? (y/n) \n");
	char v = sgetchar(0);
	/*while (v!='y' || v!='n' || v!='Y' || v!='N'){
		iprintf("Invalid response. Answer YES (y) or NO (n) \n");
		iprintf("Do you want to check the output voltage during the test? (y/n) \n");
		v = sgetchar(0);
	}*/
	BOOL check_volt = (v=='y' || v=='Y');
	iprintf("Output voltage %s be checked during the test\n", (check_volt?"WILL":"WON'T"));
	iprintf(" Press one key to begin test\n");
	WAIT_FOR_KEYBOARD
	iprintf("\n\n\n\n1. Reading RDAC Value\n");
	changeSlave();
	highImpRDAC(test_slave_address, test_bridge_address);
	changeSlave();
	int setvalue1 = getRegRDAC(test_slave_address, test_bridge_address);
	result1 = (setvalue1!=0?true:false);
	if (check_volt){
		printf(" -> Output voltage should be near %.2f\n", numToVolt(setvalue1, Test_Rpsu));
		WAIT_FOR_KEYBOARD
	}

	int newvalue = (setvalue1>1000?800:900);// 900 = 5V;
	iprintf("\n\n\n\n2. Configuring RDAC Value and checking value updating\n");
	newvalue = scanFloatValue(Test_Rpsu);
	setRegRDAC(newvalue, test_slave_address, test_bridge_address);
	int setvalue2 = getRegRDAC(test_slave_address, test_bridge_address);
	result2 = (setvalue2==newvalue);
	if (check_volt){
		printf(" -> Output voltage should be near %.2f\n", numToVolt(setvalue2, Test_Rpsu));
		WAIT_FOR_KEYBOARD
	}

	iprintf("\n\n\n\n3. Configuring Control Register to allow RDAC Value to be updated and reading RDAC CTRL Register\n");
	setCtrlRDAC(0,1,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)
	result3 = getCtrlRDAC(test_slave_address, test_bridge_address);
	result3 = (result3==0x2);

	iprintf("\n\n\n\n4. Configuring Control Register to reject RDAC Value updates and reading RDAC CTRL Register\n");
	setCtrlRDAC(0,0,0, test_slave_address, test_bridge_address);	// Second bit controls RDAC update permission (0)
	result4 = getCtrlRDAC(test_slave_address, test_bridge_address);
	result4 = (result4==0);

	iprintf("\n\n\n\n5. Resetting RDAC - Value is set to midscale - and reading RDAC Value\n");
	resetRDAC(test_slave_address, test_bridge_address);
	int setvalue5 = getRegRDAC(test_slave_address, test_bridge_address);
	result5 = (setvalue5==0x200);
	if (check_volt){
		printf(" -> Output voltage should be near %.2f\n", numToVolt(setvalue5, Test_Rpsu));
		WAIT_FOR_KEYBOARD
	}

	iprintf("\n TEST_RDAC RESULTS FOR %s RDAC\n", (rdac=='1'?"UPPER":"LOWER"));
	iprintf("\n PART 1 - Reading Rdac Value\n");
	iprintf(" ~result1: %s\n", (result1?"PASSED":"NOT PASSED"));
	iprintf("\n PART 2 - Changing Rdac Value\n");
	iprintf(" ~result2: %s\n", (result2?"PASSED":"NOT PASSED"));
	iprintf("\n PART 3 - Allowing Rdac updating\n");
	iprintf(" ~result3: %s\n", (result3?"PASSED":"NOT PASSED"));
	iprintf("\n PART 4 - Rejecting Rdac updates\n");
	iprintf(" ~result4: %s\n", (result4?"PASSED":"NOT PASSED"));
	iprintf("\n PART 5 - Resetting Rdac\n");
	iprintf(" ~result5: %s\n", (result5?"PASSED":"NOT PASSED"));
	result6 = (result1&&result2&&result3&&result4&&result5);
	iprintf("\n OVERALL RESULT: %s\n", (result6?"PASSED":"NOT PASSED"));
	return result6;

}

void changeSlave(void){
	sl_addr = !sl_addr;
	test_slave_address = (sl_addr?FIRST_SLAVE_ADDRESS:SECOND_SLAVE_ADDRESS);
}
