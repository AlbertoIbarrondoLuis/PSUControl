/*
 * I2CLibrary.cpp
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#include "i2CLibrary.h"
#include "defineConstants.cpp"

//---------------------------------------Variables---------------------------------------------------//
BYTE I2CStat;
BYTE bridgeAddress = 0x2F; // 0x28 to 0x2F possible. 3 last bits are configurable with switches

BOOL consoleOutputI2C = true;

BYTE sendBuffer[I2C_MAX_BUF_SIZE];   	// User created I2C output buffer
BYTE* pSendBuf = sendBuffer;         	// Pointer to user I2C output buffer
BYTE receiveBuffer[I2C_MAX_BUF_SIZE];   	// User created I2C output buffer
BYTE* pRecBuf = receiveBuffer;         	// Pointer to user I2C output buffer

//-------------------------------------------------------------------------------------------------------
// sendI2CMessage sends the bufSize Bytes from bufi2c to the bridgeAddress through I2C including a null at the end
//-------------------------------------------------------------------------------------------------------
BYTE sendI2CMessage ( BYTE outputBuffer[], int bufSize, BYTE I2CAdress){
		if(consoleOutputI2C){		iprintf( "I2C msg (0x%x) -> ", I2CAdress );
									printBuffer(outputBuffer, bufSize);}
		I2CStat = I2CSendBuf(I2CAdress, outputBuffer, bufSize);// Send the buffer size plus one to include the null character
		if( I2CStat == I2C_OK )
			if(consoleOutputI2C){	iprintf( " -> I2C OK\n" );}
		else
			if(consoleOutputI2C){	iprintf( " -> I2C ERROR:%d\r\n", I2CStat);
									errorDetails(I2CStat);}
		return I2CStat;
}



//-------------------------------------------------------------------------------------------------------
// configureSPI sends 2 bytes using outputBuffer to configure the SPI channel using the bridge.
// Initialize Order (MSB/LSB first) Clock Polarity (cpol) and Phase (cpha)
// Values from 0 to 3 possible. Default is 0.
//	0 -> 1.8MHz; 1 -> 461KHz; 2 -> 115KHz; 3 -> 58KHz;
//-------------------------------------------------------------------------------------------------------
BYTE configureSPI( BOOL order, BOOL cpol, BOOL cpha, int clkRate, BYTE I2CAdress){
		BYTE configureSPI[2] = {0xF0, 0x20 * order + 0x08 * cpol + 0x04 * cpha+ (((clkRate < 4) && (clkRate > 0))?clkRate:0)};
		BYTE result = sendI2CMessage( configureSPI, 2, I2CAdress);
		if (result==0){
			if(consoleOutputI2C){
				iprintf( " .Configured SPI channel:\r\n" );
				iprintf( "   -   Byte order: %s\n", (order?"LSB of data transmitted first": "MSB of data transmitted first"));
				iprintf( "   -   Clock polarity: %s\n", (order?"SPI Clock HIGH when idle": "SPI Clock HIGH when idle"));
				iprintf( "   -   Clock Phase: %s\n", (order?"Data clocked in on trailing edge": "Data clocked in on leading edge"));
			}
		}
		else{
			if(consoleOutputI2C){
				iprintf( " SPI channel couldn't be configured\r\n" );
			}
		}
		return result;

}



//-------------------------------------------------------------------------------------------------------
// sendSPImessage sends bufSize Bytes from the BufSPI buffer to the selected SPI Slaves (0x0 to 0xF possible)
//-------------------------------------------------------------------------------------------------------
BYTE sendSPImessage ( BYTE outputBuffer[], int bufSize, BYTE slaveSelect, BYTE I2CAdress){
		if (slaveSelect>0x0F){
			iprintf("SPI ERROR: Wrong SPI address");
			return 0xF;	// Not important, just a value different from any I2C Result
		}
		else{
			*pSendBuf++=slaveSelect;
			mergeBuffer(pSendBuf, outputBuffer, bufSize);
			pSendBuf = sendBuffer;
			if(consoleOutputI2C){		iprintf("SPI msg (Sl:%d) --> ", slaveSelect);}
			BYTE I2CcomResult = sendI2CMessage( sendBuffer, bufSize + 1 , I2CAdress);
			return I2CcomResult;
		}
}



//-------------------------------------------------------------------------------------------------------
// readBridgeBuffer reads the bufSize Bytes from the Bridge buffer and writes them into inputBuffer
//-------------------------------------------------------------------------------------------------------
BYTE readBridgeBuffer ( BYTE inputBuffer[], int bufSize){
		if(consoleOutputI2C){		iprintf( "Reading bridge buffer\n" );}
		I2CStat = I2CReadBuf(bridgeAddress, inputBuffer, bufSize);
		if( I2CStat == I2C_OK )
		{
			if(consoleOutputI2C){	iprintf("Data Received -> " );
									printBuffer(inputBuffer, bufSize);}
			if(consoleOutputI2C){	iprintf(" -> I2C OK\r\n" );}
		}
		else{
			if(consoleOutputI2C){	iprintf("I2C ERROR: Failed to read due to error: %d\r\n", I2CStat);
									errorDetails(I2CStat);}
		}
		return I2CStat;
}



//-------------------------------------------------------------------------------------------------------
// toggleconsoleOutputI2C - toggles On and OFF console messages for I2C and SPI message Send-Receive funcs.
//							doesn't currently work well
//-------------------------------------------------------------------------------------------------------
void toggleConsoleOutputI2CLib( void ){
	consoleOutputI2C = !consoleOutputI2C;
	printf("I2C & SPI Output toggled %s\n", (consoleOutputI2C?"ON":"OFF"));
}



//-------------------------------------------------------------------------------------------------------
// errorDetails prints on Console the details of an error ID
//-------------------------------------------------------------------------------------------------------
void errorDetails(BYTE I2CStat){
	switch (I2CStat){
		case 1:
			iprintf( " ~Description: I2C bus is OK for a write\n" );
		case 2:
			iprintf( " ~Description: I2C bus is OK for a read\n");
			break;
		case 3:
			iprintf( " ~Description: I2C finished transmission but still owns but (need to stop or restart)\n");
			break;
		case 4:
			iprintf( " ~Description: A timeout occurred while trying communicate on I2C bus\n");
			break;
		case 5:
			iprintf( " ~Description: A timeout occurred while trying gain I2C bus control\n");
			break;
		case 6:
			iprintf( " ~Description: A read or write was attempted before I2C ready or during a slave transmission\n");
			break;
		case 7:
			iprintf( " ~Description: Lost arbitration during start\n");
			break;
		case 8:
			iprintf( " ~Description: Lost arbitration and then winner addressed our slave address\n");
			break;
		case 9:
			iprintf( " ~Description: Received no ACK from slave device\n");
			break;
		default:
			break;
	}
	iprintf("\n");
}
