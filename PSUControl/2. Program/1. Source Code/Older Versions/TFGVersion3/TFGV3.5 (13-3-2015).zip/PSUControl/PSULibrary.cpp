/*
 * PSULibrary.cpp
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
*/


#include "predef.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <basictypes.h>
#include <a2d.h>
// #include <cfinter.h>       // Interruption Programming - Currently disabled due to the use of RTOS Tasks

#include "RDACLibrary.h"
#include "I2CLibrary.h"
#include "PSULibrary.h"
#include "defineConstants.cpp"

// Variables
BOOL powerONProcess = false; 	// used to initialize the system.
int powerONticks=0; 			// delay counter when initialyzing the system.
BOOL resetPowerON = false;
DWORD switchONListPSUs = 0;		// bits in TRUE are PSUs pending to be switched on

char bufferMOD5270[80]; 		// buffer mensajes tx y rx con MOD5270 via UART

PSU_TYPE psuList[PSU_NUMBER];

BYTE driverA=0; // valor inicial bus U314
BYTE driverB=0; // valor inicial bus U315
BYTE transceptorBus=0; // valor inicial bus U313
BYTE busData=0, mask=0;	// Bus variables



//=====================================================================================================//
//================================    VOLTAGE & CURRENT METHODS    ====================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// adjustRdac - changes the RDAC Register Value (thus modifying its output voltage)
// 					Checks for correct value updating
//-------------------------------------------------------------------------------------------------------
void adjustRdac (int psuNum, float Voltage){
	selectMuxPSU(psuNum, FUNCTION_SET_SCL);
	int desiredValue = voltToNum(Voltage, psuList[psuNum].rShunt);
	setRegRDAC(desiredValue, psuList[psuNum].rdacAdr, psuList[psuNum].bridgeI2CAdr);
	int setValue = getRegRDAC(psuList[psuNum].rdacAdr, psuList[psuNum].bridgeI2CAdr);
	if (desiredValue==setValue){
		psuList[psuNum].rdacValue = Voltage;
	}
	else{
		printf("ERROR: RDAC value %d not properly configured on PSU %d. Value %d set instead", desiredValue, psuNum, setValue);
	}
}
//-------------------------------------------------------------------------------------------------------
// updateVoltagePSUs - Updates both RDAC values with their RAM config for the selected PSUs (marking
//					 its respective bit number as TRUE)
//-------------------------------------------------------------------------------------------------------
void updateVoltagePSUs(DWORD selectPSUs){	// PSUs marked with his corresponding bit to 1 will be switched on.
	int psuNum; int aux = selectPSUs;
	// ajustar fuentes
	for (psuNum=0;psuNum<PSU_NUMBER;psuNum++){
		if(aux & 0x0001){
			if (psuList[psuNum].psuStatus) {
				adjustRdac (psuNum, psuList[psuNum].rdacValue);
			}
		}
		aux=aux>>1;
 	}
	OSTimeDly(TICKS_100MS); // retardo para ajuste de los reguladores
}

//-------------------------------------------------------------------------------------------------------
// readVoltageValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						to voltage.
//-------------------------------------------------------------------------------------------------------
void readVoltageValue(int psuNum){
	float value = 0;
	selectMuxPSU(psuNum, VOLTAGE);
	value = ((float)(ReadA2DResult(0) >> 3) / (4095.0)) * 3.3;
	psuList[psuNum].vOut = value;
}


//-------------------------------------------------------------------------------------------------------
// readCurrentValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						 to current.
// TODO: conversion factor
//-------------------------------------------------------------------------------------------------------
void readCurrentValue(int psuNum){
	float value = 0;
	selectMuxPSU(psuNum, CURRENT);
	value = ((float)(ReadA2DResult(0) >> 3) / (4095.0)) * 3.3;
	psuList[psuNum].cOut = value;
}


//-------------------------------------------------------------------------------------------------------
// selectMuxPSU - Configures the Muxes for a PSU number and the desired function:
//				(0) FUNCTION_READ_VOLTAGE: Allows Voltage reading.
//				(1) FUNCTION_READ_CURRENT: Allows current Reading.
//				(2) FUNCTION_SET_SCL: Allows RDAC updating.
//-------------------------------------------------------------------------------------------------------
void selectMuxPSU(int psuNum, int function){
	PBYTE p=(BYTE *)transceptorBus;
			switch(function){
		case FUNCTION_READ_VOLTAGE:
			if (psuNum>7) psuNum-=8;
			psuNum++; // para fuentes de 1 a 12
			if (psuNum & 0x1) busData=busData|0x1;
			if (psuNum & 0x2) busData=busData|0x2;
			if (psuNum & 0x4) busData=busData|0x80;
			mask=0x83; // modificar solo po p1 y p7
			EscribeEnTransceptorBus(addressTransBus, busData,mask,p);
			busData=0;
			mask=0x70;
			busData=(psuNum<8?0x1:0x2); // las 8 primeras fuentes en canal1
			EscribeEnDriver(2,busData,mask);
			break;

		case FUNCTION_READ_CURRENT:
			psuNum++; // para fuentes de 1 a 12
			if (psuNum & 0x1) busData=busData|0x1;
			if (psuNum & 0x2) busData=busData|0x2;
			if (psuNum & 0x4) busData=busData|0x80;
			mask=0x83; // modificar solo po p1 y p7
			EscribeEnTransceptorBus(addressTransBus, busData,mask,p);

			busData=0; mask=0x70; //out5 out6 y out7 U315
			if (psuNum<8){
				busData=0x4;
			}else{
				psuNum-=4; // desplazamos para que la 8(novena fuente) sea la cuarta y caiga en S4
				if (psuNum & 0x1) busData=busData|0x10;
				if (psuNum & 0x2) busData=busData|0x20;
				if (psuNum & 0x4) busData=busData|0x40;
			}
			EscribeEnDriver(2,busData,mask);
			break;
		case FUNCTION_SET_SCL:
			int scl;
			if (psuNum<12) scl=3;
			if (psuNum<8) scl=2;
			if (psuNum<4) scl=1;
			mask=0x70; // modificar solo p4,p5,p6
			switch(scl){
				case 1:
					busData=0x10;
					break;
				case 2:
					busData=0x20;
					break;
				default:
					busData=0x40;
					break;
			}
			EscribeEnTransceptorBus(addressTransBus, busData,mask,p);
			break;
		default:
			break;
	}
}


//=====================================================================================================//
//======================================    ALARM METHODS    ==========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// alarmTask - Independent process in charge of monitoring all the PSU alarms once every 100ms
//				and executing the programmed protocols once every second if an alarm is triggered.
//-------------------------------------------------------------------------------------------------------
void alarmTask (void *p){
	int generalCounter = 0;
	int psuNumAux = 0;
	while (1)   // Loop forever
	   {	refreshAlarmCounters_100ms();
			generalCounter++;
			if (generalCounter == TASK_TIMES_PER_SECOND){					// Once every second
				generalCounter = 0;
				for (psuNumAux=0; psuNumAux<PSU_NUMBER; psuNumAux++){
					alarmCheck(psuNumAux);
				}
			}
			OSTimeDly((int)(TICKS_PER_SECOND / TASK_TIMES_PER_SECOND));   	// Critical, otherwise the lower tasks wont receive computing time.
	   }
}

//-------------------------------------------------------------------------------------------------------
// alarmCheck - Checks each alarm status for the selected PSU and executes the programmed protocols
//				if activated.
//-------------------------------------------------------------------------------------------------------
void alarmCheck (int psuNum){
	int i;
	for (i=0; i<=3; i++){			// checks each alarm's status (Voltage/Current; Superior/Inferior)
		if(psuList[psuNum].alarmWatch[i] && psuList[psuNum].alarmStatus[i]){
			int j;
			for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){	// goes over each alarm protocol for the activated alarm
				if (psuList[psuNum].alarmProtocols[__(i&1,i&2, j)]){
					executeAlarmProtocol (psuNum, i&1, i&2, j);
				}
			}
		}
	}
}


//-------------------------------------------------------------------------------------------------------
// executeAlarmProtocol - Carries out a different protocol depending of the type of alarm
//						 (SUPERIOR/INFERIOR,VOLTAGE/CURRENT).
//-------------------------------------------------------------------------------------------------------
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum){
	int k;
	switch (protocolNum){		// (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
	case 0:
		WORD shutdown;
		shutdown = psuList[psuNum].alarmProtocolShutdown[_(limit_inf_sup, type_volt_corr)];
		for (k=0; k<12; k++){
			if (shutdown&1){
				// TODO: Apagar las fuentes de forma efectiva

				psuList[psuNum].releStatus = OFF;
				psuList[psuNum].psuStatus = OFF;
			}
			shutdown = shutdown >>1;
		}
		break;
	case 1:
			adjustRdac(psuNum, psuList[psuNum].alarmProtocolVoltage[_(limit_inf_sup,type_volt_corr)]);
		break;
	case 2:
			printf(ALARM_MESSAGE, psuNum, (type_volt_corr==0?"Voltage": "Current"), (limit_inf_sup==0?"Inferior": "Superior"));
			//TODO: Maybe add some other alarm output - left for future implementation
		break;
	}
}

//-------------------------------------------------------------------------------------------------------
// refreshAlarmCounters_100ms - Takes a sample of Voltage and Current for all the PSUs and updates
// 						 		their alarm status, counters and flags by comparing the sample with
//								the programmed limit
//-------------------------------------------------------------------------------------------------------
void refreshAlarmCounters_100ms (void){
	int psuNum;
	for (psuNum=0; psuNum<12; psuNum++){

		readVoltageValue(psuNum);	// VOLTAGE READING

		if(psuList[psuNum].alarmWatch[_(INFERIOR,VOLTAGE)]){									// If INFERIOR VOLTAGE alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(INFERIOR,VOLTAGE)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(INFERIOR,VOLTAGE)]);
			if (psuList[psuNum].alarmLimitReached[_(INFERIOR,VOLTAGE)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]>=psuList[psuNum].alarmLimitTimes[_(INFERIOR,VOLTAGE)]){
					psuList[psuNum].alarmStatus[_(INFERIOR,VOLTAGE)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]=psuList[psuNum].alarmLimitTimes[_(INFERIOR,VOLTAGE)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(INFERIOR,VOLTAGE)] = false;
					}
				}
			}
		}
		if(psuList[psuNum].alarmWatch[_(SUPERIOR,VOLTAGE)]){									// If SUPERIOR VOLTAGE alarm is being watched
																										// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(SUPERIOR,VOLTAGE)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(SUPERIOR,VOLTAGE)]);
			if (psuList[psuNum].alarmLimitReached[_(SUPERIOR,VOLTAGE)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]>=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,VOLTAGE)]){
					psuList[psuNum].alarmStatus[_(SUPERIOR,VOLTAGE)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,VOLTAGE)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(SUPERIOR,VOLTAGE)] = false;
					}
				}
			}
		}

		readCurrentValue(psuNum);	//CURRENT READING

		if(psuList[psuNum].alarmWatch[_(INFERIOR,CURRENT)]){									// If INFERIOR CURRENT alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(INFERIOR,CURRENT)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(INFERIOR,CURRENT)]);
			if (psuList[psuNum].alarmLimitReached[_(INFERIOR,CURRENT)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]>=psuList[psuNum].alarmLimitTimes[_(INFERIOR,CURRENT)]){
					psuList[psuNum].alarmStatus[_(INFERIOR,CURRENT)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]=psuList[psuNum].alarmLimitTimes[_(INFERIOR,CURRENT)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(INFERIOR,CURRENT)] = false;
					}
				}
			}
		}
		if(psuList[psuNum].alarmWatch[_(SUPERIOR,CURRENT)]){									// If SUPERIOR CURRENT alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(SUPERIOR,CURRENT)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(SUPERIOR,CURRENT)]);
			if (psuList[psuNum].alarmLimitReached[_(SUPERIOR,CURRENT)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]>=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,CURRENT)]){
					psuList[psuNum].alarmStatus[_(SUPERIOR,CURRENT)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,CURRENT)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(SUPERIOR,CURRENT)] = false;
					}
				}
			}
		}
	}
}




//=====================================================================================================//
//==================================    SWITCH ON PSUs METHODS    =====================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// switchONPSUsTask - RTOS Task in charge of the PSUs' delayed switching-on process.
//-------------------------------------------------------------------------------------------------------
void switchONPSUsTask(void *p){
	while(1){
		if(resetPowerON){
			powerONticks = 0;
			resetPowerON = false;
		}
		while(switchONListPSUs){
			int i=0;
			int aux=switchONListPSUs;
			for (i=0; i<PSU_NUMBER; i++){
				if(aux & 0x0001){
					if(psuList[i].initializationTimer <= powerONticks){
						switchONListPSUs-=0x0001<<i;
						psuList[i].ReadyToConnect = true;
					}
				}
				aux=aux>>1;
			}
			powerONticks++;
			OSTimeDly(TICKS_100MS);
		}
		OSTimeDly(TICKS_100MS);
	}
}


//-------------------------------------------------------------------------------------------------------
// initializeValuesPSUs - Loads all PSU values from FLASH and checks for each VERIFY_KEY correction.
//						If corrupted, sets the PSU values to default.
//-------------------------------------------------------------------------------------------------------
int initializeValuesPSUs(void){
	 int saveParameters=FALSE;
	 int i=0;
	 PSU_TYPE *pData = (PSU_TYPE *) GetUserParameters();
	 PSU_TYPE *ppsuList = psuList;
	 for (i=0;i<PSU_NUMBER;i++){
	      if (pData->VerifyKey != VERIFY_KEY){ 			// Incorrect Data
	    	  defaultValuesPSU(i);
	    	  saveParameters=TRUE;							// Save values as soon as an invalid key is detected
          }else {											// Correct data
        	  // readFlashValuesPSU(i,pData); 				use in case memory copying didn't work (which currently does)
        	  memcpy (ppsuList, pData, sizeof(PSU_TYPE));
		  }
	      pData++; ppsuList++;								//Next PSU reading
	  }
     if (saveParameters){
    	 saveParameters = saveInFlashValuesPSU ();
     }
     return saveParameters;
}

//-------------------------------------------------------------------------------------------------------
// connectPSU - Connects the selected PSU by switching its Rel� and activates its LED OUT
//-------------------------------------------------------------------------------------------------------
void connectPSU(int psuNum){
	psuList[psuNum].psuStatus=true;
	psuList[psuNum].ReadyToConnect=false;
	if (psuNum<8){
		busData=DEMUX(psuNum);
		mask=!busData;
		EscribeEnDriver(1,0xFF,mask);
	} else {
		psuNum=psuNum-8;
		busData=DEMUX(psuNum);
		mask=!busData;
		EscribeEnDriver(2,0xFF,mask);
	}
	// activar LED OUT ON
	busData=0x80;
	mask=!busData;
	EscribeEnDriver(2,busData,mask);

}

//-------------------------------------------------------------------------------------------------------
// switchONPSUs - Manages the complete PSU switching-on process for the selected PSUs: Initializes
//				its RAM values, changes its RDAC Register values, tells the switchONPSUsTask to
//				begin the delayed switching-on, and connects the Rel�s when the Task announces that
//				it's ready.
//-------------------------------------------------------------------------------------------------------
void switchONPSUs(DWORD selectedPSUs){
	powerONProcess=true;
	initializeValuesPSUs();					// Load psuList values from RAM or set them to default
	updateVoltagePSUs(selectedPSUs);			// Adjust potentiometers with the recorded values (from psuList)

	resetPowerON=true;						// Sends the selectedPSUs to the timed task switchONPSUsTask to
	switchONListPSUs = selectedPSUs;		// 	begin switching-on countdown.

	DWORD aux; int i=0;
	OSTimeDly(2*TICKS_100MS);				// Waits enough time for switchONPSUsTask to begin

	while (selectedPSUs){
		aux = selectedPSUs xor switchONListPSUs;	// PSUs that have completed its switching-on countdown
		for (i=0; i<PSU_NUMBER; i++){				//	but haven't been connected.
			if(aux & 0x0001){
				if(psuList[i].ReadyToConnect){
					connectPSU(i);
					selectedPSUs-=0x0001<<i;		// PSUs not yet connected
				}
			}
			aux=aux>>1;
		}
	}
	powerONProcess=false;
}



//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSU's rel�, updating its LED OUT
//-------------------------------------------------------------------------------------------------------
void disconnectPSU(int psuNum){
	if (psuNum<8){
		busData=DEMUX(psuNum);
		mask=!busData;
		EscribeEnDriver(1,0x00,mask);
	} else {
		psuNum=psuNum-8;
		busData=DEMUX(psuNum);
		mask=!busData;
		EscribeEnDriver(2,0x00,mask);
	}
	// comprobar si se ha de desactivar  led Out On
	if (driverA==0) {
		 if ((driverB & 0x0F)==0){
			 busData=0x80;
			 mask=!busData;
			 EscribeEnDriver(2,0,mask);
		 }
	}
}




//=====================================================================================================//
//==================================    FLASH MEMORY METHODS    =======================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// LoadFlashValuesPSU - Copies the data from the FLASH memory to the psuList in RAM, updating all
//						PSU programmed values. DOESN'T VERIFY DATA INTEGRITY.
//-------------------------------------------------------------------------------------------------------
void LoadFlashValuesPSU (void){
	PSU_TYPE *pData = (PSU_TYPE *) GetUserParameters();
	memcpy (psuList, pData, sizeof(psuList));
	printf("Loaded values of psuList from Flash Mem\n");
}

//-------------------------------------------------------------------------------------------------------
// saveInFlashValuesPSU - Stores the current psuList as a whole in the 8Kbits FLASH memory. For the
//						time being, 2Kbits of data are stored by using this method (the rest remains
//						unused).
//-------------------------------------------------------------------------------------------------------
int saveInFlashValuesPSU (void){
	int aux = SaveUserParameters(psuList, sizeof(psuList));
	printf("Saved values of psuList, for a total of %d Bytes in Flash Mem\n", aux);
	return aux;
}

//-------------------------------------------------------------------------------------------------------
// readFlashValuesPSU - Auxiliary method, not currently in use. Copies the data from one PSU from
//						a FLASH direction to a RAM variable (psuList) one value at a time.
//						Greatly simplified by using instead:
//												memcpy (psuList[psuNum], pData, sizeof(PSU_TYPE));
//-------------------------------------------------------------------------------------------------------
void readFlashValuesPSU(int psuNum, PSU_TYPE *pData){
	psuList[psuNum].releStatus=pData->releStatus;
	psuList[psuNum].psuStatus=pData->psuStatus;
	psuList[psuNum].rdacValue=pData->rdacValue;
	psuList[psuNum].rdacValue=pData->rdacValue;
	psuList[psuNum].bridgeI2CAdr=pData->bridgeI2CAdr;	// Probably required a different address for each psu
	psuList[psuNum].rdacAdr=pData->rdacAdr;
	memcpy(psuList[psuNum].alarmLimitValues, pData->alarmLimitValues, sizeof(psuList[psuNum].alarmLimitValues));
	memcpy(psuList[psuNum].alarmLimitTimes, pData->alarmLimitTimes, sizeof(psuList[psuNum].alarmLimitTimes));
	memcpy(psuList[psuNum].alarmProtocols, pData->alarmProtocols, sizeof(psuList[psuNum].alarmProtocols));
	memcpy(psuList[psuNum].alarmProtocolShutdown, pData->alarmProtocolShutdown, sizeof(psuList[psuNum].alarmProtocolShutdown));
	memcpy(psuList[psuNum].alarmProtocolVoltage, pData->alarmProtocolVoltage, sizeof(psuList[psuNum].alarmProtocolVoltage));
	memcpy(psuList[psuNum].alarmCounters, pData->alarmCounters, sizeof(psuList[psuNum].alarmCounters));
	memcpy(psuList[psuNum].alarmStatus, pData->alarmStatus, sizeof(psuList[psuNum].alarmStatus));
	memcpy(psuList[psuNum].alarmLimitReached, pData->alarmLimitReached, sizeof(psuList[psuNum].alarmLimitReached));
	memcpy(psuList[psuNum].alarmWatch, pData->alarmWatch, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt =  pData->rShunt;
	psuList[psuNum].divisorTension1 =  pData->divisorTension1;
	psuList[psuNum].divisorTension2 =  pData->divisorTension2;
	psuList[psuNum].rAdicPotDigital =  pData->rAdicPotDigital;
	psuList[psuNum].rDivisorPotDigital =  pData->rAdicPotDigital;
	psuList[psuNum].vOut =  pData->vOut;
	psuList[psuNum].cOut =  pData->cOut;
}




//=====================================================================================================//
//====================================    AUXILIARY METHODS    ========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// defaultValuesPSU - Replaces the current PSU values in RAM by those predefined as DEFAULT in
//					file "defineConstants.cpp"
//-------------------------------------------------------------------------------------------------------
void defaultValuesPSU (int psuNum) {
	psuList[psuNum].releStatus=DEFAULT_releStatus;
	psuList[psuNum].psuStatus=DEFAULT_psuStatus;
	psuList[psuNum].rdacValue=DEFAULT_rdacValue;
	psuList[psuNum].bridgeI2CAdr=DEFAULT_bridgeI2CAdr;			// TODO: required a different address for each psu
	psuList[psuNum].rdacAdr=(psuNum&0x1?FIRST_SLAVE_ADDRESS:SECOND_SLAVE_ADDRESS);
	float auxArray1[4]=DEFAULT_alarmLimitValues;
	memcpy(psuList[psuNum].alarmLimitValues, auxArray1, sizeof(psuList[psuNum].alarmLimitValues));
	int auxArray2[4]=DEFAULT_alarmLimitTimes;
	memcpy(psuList[psuNum].alarmLimitTimes, auxArray2, sizeof(psuList[psuNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_alarmProtocols;
	memcpy(psuList[psuNum].alarmProtocols, auxArray3, sizeof(psuList[psuNum].alarmProtocols));
	DWORD k = demux4to16(psuNum+1);
	int auxArray4[4]={k, k, k, k};
	memcpy(psuList[psuNum].alarmProtocolShutdown, auxArray4, sizeof(psuList[psuNum].alarmProtocolShutdown));
	float auxArray5[8]=DEFAULT_alarmProtocolVoltage;
	memcpy(psuList[psuNum].alarmProtocolVoltage, auxArray5, sizeof(psuList[psuNum].alarmProtocolVoltage));
	int auxArray6[4]=DEFAULT_alarmLimitTimes;
	memcpy(psuList[psuNum].alarmCounters, auxArray6, sizeof(psuList[psuNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_alarmStatus;
	memcpy(psuList[psuNum].alarmStatus, auxArray7, sizeof(psuList[psuNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_alarmLimitReached;
	memcpy(psuList[psuNum].alarmLimitReached, auxArray8, sizeof(psuList[psuNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_alarmWatch;
	memcpy(psuList[psuNum].alarmWatch, auxArray9, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt = DEFAULT_rShunt;
	psuList[psuNum].divisorTension1 = DEFAULT_divisorTension1;
	psuList[psuNum].divisorTension2 = DEFAULT_divisorTension2;
	psuList[psuNum].rAdicPotDigital = DEFAULT_rAdicPotDigital;
	psuList[psuNum].rDivisorPotDigital = DEFAULT_rDivisorPotDigital;
	psuList[psuNum].vOut = DEFAULT_vOut;
	psuList[psuNum].cOut = DEFAULT_cOut;
}


//-------------------------------------------------------------------------------------------------------
// printValuesPSU - prints by stdio all the values in RAM from the selected PSU
//-------------------------------------------------------------------------------------------------------
void printValuesPSU (int psuNum) {
	iprintf("PSU-Number: %d\n", psuNum);
	iprintf("- releStatus: %d\n",psuList[psuNum].releStatus);
	iprintf("- psuStatus: %d\n",psuList[psuNum].psuStatus);
	printf("- rdacValue: %d\n",psuList[psuNum].rdacValue);
	printf("- rdacAdr: %d\n",psuList[psuNum].rdacAdr);
	iprintf("- bridgeI2CDir: 0x%x\n",psuList[psuNum].bridgeI2CAdr);
	printf("- alarmLimitValues: {%.2f, %.2f, %.2f, %.2f}\n",
			psuList[psuNum].alarmLimitValues[0], psuList[psuNum].alarmLimitValues[1],
			psuList[psuNum].alarmLimitValues[2],psuList[psuNum].alarmLimitValues[3]);
	iprintf("- alarmLimitTimes: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitTimes[0], psuList[psuNum].alarmLimitTimes[1],
			psuList[psuNum].alarmLimitTimes[2],psuList[psuNum].alarmLimitTimes[3]);
	iprintf("- alarmProtocols: {%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d}\n",
			psuList[psuNum].alarmProtocols[0],psuList[psuNum].alarmProtocols[1],
			psuList[psuNum].alarmProtocols[2],psuList[psuNum].alarmProtocols[3],
			psuList[psuNum].alarmProtocols[4],psuList[psuNum].alarmProtocols[5],
			psuList[psuNum].alarmProtocols[6],psuList[psuNum].alarmProtocols[7],
			psuList[psuNum].alarmProtocols[8],psuList[psuNum].alarmProtocols[9],
			psuList[psuNum].alarmProtocols[10],psuList[psuNum].alarmProtocols[11]);
	iprintf("- alarmProtocolShutdown: {0x%x, 0x%x, 0x%x, 0x%x}\n",
			psuList[psuNum].alarmProtocolShutdown[0], psuList[psuNum].alarmProtocolShutdown[1],
			psuList[psuNum].alarmProtocolShutdown[2],psuList[psuNum].alarmProtocolShutdown[3]);
	printf("- alarmProtocolVoltage:{%.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f, %.2f}\n",
			psuList[psuNum].alarmProtocolVoltage[0],psuList[psuNum].alarmProtocolVoltage[1],
			psuList[psuNum].alarmProtocolVoltage[2],psuList[psuNum].alarmProtocolVoltage[3],
			psuList[psuNum].alarmProtocolVoltage[4],psuList[psuNum].alarmProtocolVoltage[5],
			psuList[psuNum].alarmProtocolVoltage[6],psuList[psuNum].alarmProtocolVoltage[7]);
	iprintf("- alarmCounters: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmCounters[0], psuList[psuNum].alarmCounters[1],
			psuList[psuNum].alarmCounters[2],psuList[psuNum].alarmCounters[3]);
	iprintf("- alarmStatus: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmStatus[0], psuList[psuNum].alarmStatus[1],
			psuList[psuNum].alarmStatus[2],psuList[psuNum].alarmStatus[3]);
	iprintf("- alarmLimitReached: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitReached[0], psuList[psuNum].alarmLimitReached[1],
			psuList[psuNum].alarmLimitReached[2],psuList[psuNum].alarmLimitReached[3]);
	iprintf("- alarmWatch: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmWatch[0], psuList[psuNum].alarmWatch[1],
			psuList[psuNum].alarmWatch[2],psuList[psuNum].alarmWatch[3]);
	iprintf("- rShunt: %d\n",psuList[psuNum].rShunt);
	iprintf("- divisorTension1: %s %d\n",psuList[psuNum].divisorTension1);
	iprintf("- divisorTension2: %d\n",psuList[psuNum].divisorTension2);
	iprintf("- rAdicPotDigital: %d\n",psuList[psuNum].rAdicPotDigital);
	iprintf("- rDivisorPotDigital: %d\n",psuList[psuNum].rDivisorPotDigital);
	iprintf("- vOut: %d\n",psuList[psuNum].vOut);
	iprintf("- cOut: %d\n",psuList[psuNum].cOut);
}






//___________________________________________________________________________________________//
//                    METHODS NOT BELONGING TO ME - LEFT TO BE REVISED

// escribe dato en driver U314(numDriver=1) o U315(numDriver=2)
// actualiza variable en RAM para mantener estado
void EscribeEnDriver(int numDriver,BYTE dato, BYTE mascara){
   BYTE address;
   PBYTE p=(BYTE *)dato;
   if (numDriver == 1){
	   address = addressAddressDriverA;
	   driverA = driverA & mascara;
	   driverA = driverA | dato;
	   dato = driverA;
   } else {
	   address=addressAddressDriverB;
	   driverB = driverB & mascara;
	   driverB = driverB | dato;
	   dato = driverA;
   }
   I2CSendBuf(address, p, (strlen( (const char*)dato ) )+1);
}
// escribe en transceptores de bus. Actualiza la variable en ram necesaria para mantener estado estable
// address = direccion del transceptor. Dato=valor a escribir, variable=valor del bus en ram,mascara=mascara escritura
void EscribeEnTransceptorBus(BYTE address, BYTE dato, BYTE mascara,BYTE * variable){
	PBYTE p=(BYTE *)dato;
	BYTE temp = *variable;
	temp = temp & mascara; //ajustar la nueva var en ram
	temp = temp | dato; //ajustar la nueva var en ram
	*variable = temp; // el contenido apuntado por variable = contenido de temp
	I2CSendBuf(address, p, (strlen( (const char*)dato ) )+1);
}

// determina la direcci�n del potenci�metro digital
BYTE SeleccionaAddressPotDig(int numFuente){
	BYTE address;
	if (numFuente==0 ||numFuente==4||numFuente==8) address=potDigA;
	if (numFuente==1 ||numFuente==5||numFuente==9) address=potDigB;
	if (numFuente==2 ||numFuente==6||numFuente==10) address=potDigC;
	if (numFuente==3 ||numFuente==7||numFuente==11) address=potDigD;
	return address;
}



// pone en los transceptores de bus los valores iniciales
// ning�n SCL , ning�n STROBE, ning�n rel� de fuente ni led on
void  InicializarBusesControladora(void){
	PBYTE p=(BYTE *)transceptorBus;
	EscribeEnTransceptorBus(addressTransBus, *p,0xFF,p);
	p=(BYTE *)driverA;
	EscribeEnTransceptorBus(addressAddressDriverA, *p,0xFF,p);
	p=(BYTE *)driverB;
	EscribeEnTransceptorBus(addressAddressDriverB, *p,0xFF,p);
}
