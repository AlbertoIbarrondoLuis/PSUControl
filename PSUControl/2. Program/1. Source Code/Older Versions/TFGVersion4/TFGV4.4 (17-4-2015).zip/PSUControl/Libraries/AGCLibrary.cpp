/*
 * AGCLibrary.cpp
 *
 *  Created on: 17-abr-2015
 *      Author: Alberto
 */

#include "AGCLibrary.h"

float gainAGC = 1.1;
int rdacCountAGC = 0;

void minAGC( void ){
	rdacCountAGC = RDAC_MIN_VALUE;
	numToGainAGC ( rdacCountAGC );
	setValRDAC(rdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
}

void maxAGC( void ){
	rdacCountAGC = RDAC_MAX_VALUE;
	numToGainAGC ( rdacCountAGC );
	setValRDAC(rdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
}

void changeGainAGC( float num ){
	gainAGC = gainAGC * num;
	gainToNumAGC(gainAGC);
	setValRDAC(rdacCountAGC, AGC_SPI_ADDRESS, AGC_I2C_ADDRESS);
}

float numToGainAGC ( int rdacCount ){
	gainAGC = 1 + (((float)rdacCount + 1)/1024)*100;
	return gainAGC;
}

int gainToNumAGC (float gain){
	rdacCountAGC = (int)((((gain-1)/100)*1024)+1);
	return rdacCountAGC;
}

int getRdacCountAGC ( void ){
	return rdacCountAGC;
}

float getGainAGC ( void ){
	return gainAGC;
}
