/*
 * RDACLibrary.cpp
 *
 *  Created on: 02-feb-2015
 *      Author: Alberto Ibarrondo
 */



#include "RDACLibrary.h"




BOOL readBuffer = true;							// Controls I2C Buffer reading when using doNothingRDAC
BOOL regWriteEnableFlag = false;				// TRUE if RDAC Register can be updated, FALSE if RDAC Register is protected
BOOL consoleOutputRDAC = true;					// Toggles console messages for RDAC functions

BYTE outputBuffer[I2C_MAX_BUF_SIZE];			// Used to send every message
BYTE inputBuffer[I2C_MAX_BUF_SIZE];				// Used to receive every message

char floatScanBuffer[5];									// Scan float value

BYTE result;									// Result Code of SPI Message sending



//=====================================================================================================//
//=========================================    RDAC METHODS    ========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// setCtrlRDAC - Stores the given flags into the RDAC Control Register
//		.	calibrationDisable: Sets RDAC into Calibration (0-Default) or Normal (1) performance mode`.
//		.	regWriteEnable: Protects (0-default) or allows (1) RDAC Register update.
//		.	programEnable: Protects (0-default) or allows (1) 20TP Memory writing.
//-------------------------------------------------------------------------------------------------------
void setCtrlRDAC(BOOL calibrationDisable, BOOL regWriteEnable, BOOL programEnable, BYTE slaveSelect, BYTE I2CAddress){
	writeCtrlCOM(outputBuffer, calibrationDisable, regWriteEnable, programEnable);
	result = sendSPImessage (outputBuffer, 2, slaveSelect, I2CAddress);
	if (result==I2C_OK){
		regWriteEnableFlag = regWriteEnable;
		if(consoleOutputRDAC){iprintf("Configured Ctrl Reg %x in slave %d\n\n", outputBuffer[1], slaveSelect);}
	}
	else{
		if(consoleOutputRDAC){iprintf(" ~ERROR: Ctrl Register couldn't be CONFIGURED in slave %d for I2C 0x%x\n\n", slaveSelect, I2CAddress);}
	}
}



//-------------------------------------------------------------------------------------------------------
// getCtrlRDAC - Returns a BYTE with the RDAC Control Register last 3 bits
//		.	0x04: Sets RDAC into Calibration (0-Default) or Normal (1) performance mode`.
//		.	0x02: Protects (0-default) or allows (1) RDAC Register update.
//		.	0x01: Protects (0-default) or allows (1) 20TP Memory writing.
//-------------------------------------------------------------------------------------------------------
BYTE getCtrlRDAC(int slaveSelect, BYTE I2CAddress){
	readCtrlCOM(outputBuffer);
	result = sendSPImessage (outputBuffer, 2, slaveSelect, I2CAddress);
	donothingRDAC(inputBuffer, slaveSelect, I2CAddress);
	regWriteEnableFlag = (BOOL)(inputBuffer[1]&0x02);
	if(consoleOutputRDAC){
		if (result==I2C_OK){
			printCtrlRDAC (inputBuffer);}		// Prints by console the contents of Ctrl Register
		else{
			printf(" ~ERROR: Ctrl Register couldn't be READ in slave %d for I2C 0x%x\n\n", slaveSelect, I2CAddress);
		}
	}
	return inputBuffer[1]&0x7;
}



//-------------------------------------------------------------------------------------------------------
// setValRDAC - Sets a new value to the RDAC Register (modifying its impedance). Value must be between 0
//				and 0x3FF.
//-------------------------------------------------------------------------------------------------------
void setValRDAC(int value, BYTE slaveSelect, BYTE I2CAddress){
	getCtrlRDAC(slaveSelect,I2CAddress);
	if (!regWriteEnableFlag){
		setCtrlRDAC(0,1,0, slaveSelect, I2CAddress);
	}
	if(consoleOutputRDAC){ if(value<0){iprintf("Value set to RDAC_MAX_VALUE (%d)", RDAC_MAX_VALUE);} if (value>1023){iprintf("Value set to RDAC_MIN_VALUE (0)", RDAC_MIN_VALUE);}}
	value = (value<RDAC_MIN_VALUE?RDAC_MIN_VALUE:value);value = (value>RDAC_MAX_VALUE?RDAC_MAX_VALUE:value);
	writeRegCOM(outputBuffer, value);
	result = sendSPImessage (outputBuffer, 2, slaveSelect, I2CAddress);
	if(consoleOutputRDAC){
		if (result==I2C_OK){
			iprintf("Configured value %d (0x%x) in slave n�%d\n\n", value, value, slaveSelect);
		}
		else{
			printf(" ~ERROR: Value Register couldn't be configured in slave %d for I2C 0x%x\n\n", slaveSelect, I2CAddress);
		}
	}
}



//-------------------------------------------------------------------------------------------------------
// getValRDAC - reads the RDAC Register, containing the impedance value.
//-------------------------------------------------------------------------------------------------------
int getValRDAC(int slaveSelect, BYTE I2CAddress){
	readRegCOM(outputBuffer);
	result = sendSPImessage (outputBuffer, 2, slaveSelect, I2CAddress);
	donothingRDAC(inputBuffer, slaveSelect, I2CAddress);
	if(consoleOutputRDAC){// Prints by console the received value
		if (result==I2C_OK){
			printValRDAC (inputBuffer);
		}
		else{
			printf(" ~ERROR: Value Register couldn't be READ in slave %d for I2C 0x%x\n\n", slaveSelect, I2CAddress);
		}
	}
	return (inputBuffer[0]&0x3)*0x100+inputBuffer[1];
}



//-------------------------------------------------------------------------------------------------------
// highImpRDAC - Sets SDO (MISO pin) in high impedance. Must be used after every command not to interfere
//				 with other slaves.
//-------------------------------------------------------------------------------------------------------
void highImpRDAC(int slaveSelect, BYTE I2CAddress){
	highImpCOM(outputBuffer);
	result = sendSPImessage (outputBuffer, 2, slaveSelect,I2CAddress);
	donothingRDAC(inputBuffer, slaveSelect, I2CAddress);
	if(consoleOutputRDAC){
		if (result ==I2C_OK){
			iprintf("High Impedance in slave %d\n\n", slaveSelect);
		}
		else {
			iprintf(" ~ERROR: High Impedance couldn't be configured in slave %d for I2C 0x%x\n\n", slaveSelect, I2CAddress);
		}
	}
}



//-------------------------------------------------------------------------------------------------------
// resetRDAC - Sets Ctrl Register to Default and impedance value to midscale (0x201)
//-------------------------------------------------------------------------------------------------------
void resetRDAC(int slaveSelect, BYTE I2CAddress){
	resetCOM(outputBuffer);
	result = sendSPImessage (outputBuffer, 2, slaveSelect, I2CAddress);
	donothingRDAC(inputBuffer, slaveSelect, I2CAddress);
}



//-------------------------------------------------------------------------------------------------------
// shutdownRDAC - sets the device into Open Circuit. Doesn't always work
//-------------------------------------------------------------------------------------------------------
void shutdownRDAC(BOOL shutdownModeOn,int slaveSelect, BYTE I2CAddress){
	shutdownCOM(outputBuffer, shutdownModeOn);
	result = sendSPImessage (outputBuffer, 2, slaveSelect, I2CAddress);
	donothingRDAC(inputBuffer, slaveSelect, I2CAddress);
}



//-------------------------------------------------------------------------------------------------------
// doNothingRDAC - empty command. Used to read a SPI response from the I2C Bridge buffer
//-------------------------------------------------------------------------------------------------------
void donothingRDAC(BYTE ibuf[], int slaveSelect, BYTE I2CAddress){
	doNothingCOM(outputBuffer);
	result = sendSPImessage (outputBuffer, 2, slaveSelect, I2CAddress);
	if(readBuffer){
		readBridgeBuffer(ibuf, 2, I2CAddress);
	}
}






//=====================================================================================================//
//======================================    AUXILIAR METHODS    =======================================//
//=====================================================================================================//
BYTE getResult(void){
	return result;
}
void printValRDAC (BYTE ibuf[]){
	printf("Resistor Value: %d (0x%x in hex)\n", ((ibuf[0]&0x3)*0x100 + ibuf[1]), ((ibuf[0]&0x3)*0x100 + ibuf[1]));
}
void printCtrlRDAC (BYTE ibuf[]){
	printf(" Ctrl Rdac Contents:\n");
	printf("  - 20TP programming -> %s\n", (((ibuf[1]&0x01)>0)?"Enabled": "Disabled(default)"));
	printf("  - Register programming -> %s\n", (((ibuf[1]&0x02)>0)?"Enabled": "Disabled(default)"));
	printf("  - Resistor mode -> %s\n", (((ibuf[1]&0x04)>0)?"Normal": "Performance(default)"));
}
int voltToNum (float volt, float Rpsu){
	return (int)((1-((((float)volt/1.25)-1)*Rpsu/20000))*1024);
}
float numToVolt (int num, float Rpsu){
	return 1.25*(1+20000*(1-(float)num/1024)/Rpsu);
}

int scanFloatValue ( float Rpsu ){
	printf(" Enter the new voltage value (ej.: 10.83) -> ");
	int num = voltToNum(atof(gets((char *)floatScanBuffer)), Rpsu);iprintf("\r\n");
	while (num < 0 || num > 1023){
		printf(" ERROR: a value between 1.26V and 32V must be given \n");
		printf(" Reenter the new voltage value (ej.: 5.42) -> ");
		num = voltToNum(atof(gets((char *)floatScanBuffer)), Rpsu);iprintf("\r\n");
	}
	printf(" Setting closest value = %.2f V (n = %d)\n", numToVolt(num, 830), num);
	return num;
}

// Toggles console messages for RDAC functions
void toggleConsoleOutputRDACLib( void ){
	consoleOutputRDAC = !consoleOutputRDAC;
	printf("RDAC Output toggled %s\n", (consoleOutputRDAC?"ON":"OFF"));
}


//=====================================================================================================//
//========================================    BUFFER METHODS    =======================================//
//=====================================================================================================//
// All the messages are stored in the given buffer's first 2 Bytes.


//-------------------------------------------------------------------------------------------------------
// donothing - empty command. Used to advance in reading
//-------------------------------------------------------------------------------------------------------
void doNothingCOM(BYTE* buffer){
	BYTE donothing[2] = {0x00, 0x00};
	mergeBuffer(buffer, donothing, 2);
}


//-------------------------------------------------------------------------------------------------------
// writeReg - command to write a value to the RDAC register. From 0x000 to 0x3FF (0 to 1023).
//-------------------------------------------------------------------------------------------------------
void writeRegCOM(BYTE* buffer, int value){
	if (value >0x3FF){
		value=0x200;
	}
	BYTE writeValue[2] = {0x04+((value & 0x300)>>8), (value & 0x0FF)};
	mergeBuffer(buffer, writeValue, 2);
}


//-------------------------------------------------------------------------------------------------------
// readReg - command to send the RDAC register (containing the resistance value) to the Bridge Buffer
//-------------------------------------------------------------------------------------------------------
void readRegCOM(BYTE* buffer){
	BYTE readValue[2] = {0x08, 0x00};
	mergeBuffer(buffer, readValue, 2);
}


//-------------------------------------------------------------------------------------------------------
// reset -  command to restart the RDAC with a value of 0x200 (midscale)
//-------------------------------------------------------------------------------------------------------
void resetCOM(BYTE* buffer){
	BYTE reset[2] = {0x10, 0x00};
	mergeBuffer(buffer, reset, 2);
}


//-------------------------------------------------------------------------------------------------------
// writeCtrl - command to set each bit of the Control register
//-------------------------------------------------------------------------------------------------------
void writeCtrlCOM(BYTE* buffer, BOOL calibrationDisable, BOOL regWriteEnable, BOOL programEnable ){
	BYTE writeCtrl[2] = {0x18, 0x04*calibrationDisable+ 0x02*regWriteEnable + 0x01*programEnable};
	mergeBuffer(buffer, writeCtrl, 2);
}


//-------------------------------------------------------------------------------------------------------
// readCtrl - command to send the Control register to the Bridge Buffer
//-------------------------------------------------------------------------------------------------------
void readCtrlCOM(BYTE* buffer){
	BYTE readCtrl[2] = {0x1C, 0x00};
	mergeBuffer(buffer, readCtrl, 2);
}


//-------------------------------------------------------------------------------------------------------
// shutdown - command to set the RDAC in open circuit
//-------------------------------------------------------------------------------------------------------
void shutdownCOM(BYTE* buffer, BOOL shutdownModeOn){
	BYTE shutdown[2] = {0x20, 0x00 + 0x01*shutdownModeOn};
	mergeBuffer(buffer, shutdown, 2);
}


//-------------------------------------------------------------------------------------------------------
// highImp - command to set SDO pin in high impedance for minimum power dissipation
//-------------------------------------------------------------------------------------------------------
void highImpCOM(BYTE* buffer){
	BYTE highImp[2] = {0x80, 0x01};
	mergeBuffer(buffer, highImp, 2);
}
