/*
 * TimerInt.cpp
 *
 *  Created on: 15-abr-2015
 *      Author: Alberto
 */


#include "TimerInt.h"

extern "C" {
//
// This function sets up the 5213 interrupt controller
//
void SetIntc(long func, int vector, int level, int prio);
}


volatile DWORD pitr_count_one;
volatile DWORD pitr_count_adc_sampling;

int lastMeasure = 0;

extern BOOL alarmUpdate;
BOOL lastMeasureValid = false;
BYTE samplingFunction = FUNCTION_READ_VOLTAGE;
int psuNum = 0;

//Flags
BOOL readSupplyAuxFLAG = true;	// Sets whether both Supply and Internal voltages are included in a2d routine loop or not





DWORD get_pitr_count_one (void){
	return pitr_count_one;
}
DWORD get_pitr_count_adc_sampling (void){
	return pitr_count_adc_sampling;
}

INTERRUPT( pitr_adc_sampling, 0x2300 )
{
	WORD tmp = sim.pit[0].pcsr; // Use PIT 0

	//
	// Clear PIT 1 refer to table 173 for more information on what
	// bits are being cleared and set
	//
	tmp &= 0xFF0F; // Bits 47 cleared
	tmp |= 0x0F; // Bits 03 set
	sim.pit[0].pcsr = tmp;
	//
	// You can add your ISR code here
	// Do not call any RTOS function with pend or init in the function
	// name
	// Do not call any functions that perform a system I/O read,
	// write, printf, iprint, etc.
	//

	lastMeasure = (ReadA2DResult(0) >> 3);
	lastMeasureValid = (lastMeasure>MINIMUM_LEVEL_ADC);

	if (lastMeasureValid){
		switch (samplingFunction){	//Store Value in the right object
			case FUNCTION_READ_VOLTAGE:
				getPSU(psuNum).vOut= ((float)lastMeasure) / (4095.0) * 3.3 *getGainAGC()*getScaleFactorMUX();
				break;
			case FUNCTION_READ_CURRENT:
				getPSU(psuNum).cOut= ((float)lastMeasure) / (4095.0) * 3.3 *getGainAGC()*getScaleFactorMUX();
				break;
			case FUNCTION_READ_SUPPLY:

				break;
			case FUNCTION_READ_INTERNAL:

				break;
		}
		minAGC();					// Set AGC always to minimum

		// Next PSU, and next samplingFunction (see defineConstants.cpp - MUX) if end reached
		psuNum++;
		if (readSupplyAuxFLAG){
			if((samplingFunction==FUNCTION_READ_VOLTAGE || samplingFunction==FUNCTION_READ_CURRENT) &&  psuNum >= PSU_NUMBER){
				psuNum = 0;
			}
			else if (psuNum >= INT_VCC_n12V){
				psuNum = 0;
			}
			// Next sampling function (restart if last function reached, cyclic)
			samplingFunction = (samplingFunction>FUNCTION_READ_INTERNAL?FUNCTION_READ_VOLTAGE:samplingFunction+1);
		}
		else{
			if (psuNum >= PSU_NUMBER){
				psuNum = 0;
				samplingFunction = !samplingFunction; //Toggle between Voltage (0) and Current(1) functions (see defineConstants.cpp - MUX)
			}
		}

		lastMeasureValid = false;
		setMUX( samplingFunction, (BYTE)psuNum );	// Set muxes for next reading
	}
	else{
		changeGainAGC(MIDSCALE_ADC/lastMeasure);
	}
	pitr_count_adc_sampling++;
	if (pitr_count_adc_sampling >= PITR_TIMES_TO_ALARM){
		alarmUpdate = true;
		pitr_count_adc_sampling = 0;
	}
}
INTERRUPT( my_pitr_func_one, 0x2300 )
{
	WORD tmp = sim.pit[1].pcsr; // Use PIT 1

	tmp &= 0xFF0F; // Bits 47 cleared
	tmp |= 0x0F; // Bits 03 set
	sim.pit[1].pcsr = tmp;
	//
	// You can add your ISR code here
	// Do not call any RTOS function with pend or init in the function
	// name
	// Do not call any functions that perform a system I/O read,
	// write, printf, iprint, etc.
	//
	pitr_count_one++;
}
///////////////////////////////////////////////////////////////////////
// SetUpPITR PIT setup function. See chapter 17 of the 5213 reference
// manual for details.
//
void SetUpPITR(int pitr_ch, WORD clock_interval, BYTE pcsr_pre /* See table 173 in the users manual for bits 811*/) {
	WORD tmp;
	//
	// Populate the interrupt vector in the interrupt controller
	//
	SetIntc((pitr_ch?((long) &my_pitr_func_one):((long) &pitr_adc_sampling)), 55 + pitr_ch, 3 /* IRQ 3 */, (pitr_ch?3:2));
	sim.pit[pitr_ch].pmr = clock_interval; // Set the PIT modulus
	// value
	tmp = pcsr_pre;
	tmp = (tmp << 8) | 0x0F;
	sim.pit[pitr_ch].pcsr = tmp; // Set the system clock
	// divisor to 2
}



