/*
 * I2CLibrary.h
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#ifndef I2CLIBRARY_H_
#define I2CLIBRARY_H_


#include "Headers.h"

//----------------------------------------Functions--------------------------------------------------//
BYTE sendI2CMessage ( BYTE outputBuffer[], int bufSize, BYTE I2CAdress );
BYTE configureSPI( BOOL order, BOOL cpol, BOOL cpha, int clkRate, BYTE I2CAdress );
BYTE sendSPImessage ( BYTE outputBuffer[], int bufSize, BYTE slaveSelect, BYTE BridgeI2CAdress );
BYTE readBridgeBuffer ( BYTE inputBuffer[], int bufSize, BYTE I2CAdress);
void toggleConsoleOutputI2CLib( BOOL outputFLAG );
void errorDetails( BYTE I2CStat );

#endif /* LIBRARY_H_ */

