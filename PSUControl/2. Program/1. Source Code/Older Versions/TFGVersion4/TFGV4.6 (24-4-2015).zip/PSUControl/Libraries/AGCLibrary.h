/*
 * AGCLibrary.h
 *
 *  Created on: 17-abr-2015
 *      Author: Alberto
 */

#ifndef AGCLIBRARY_H_
#define AGCLIBRARY_H_

#include "Headers.h"

#include "Libraries/RDACLibrary.h"

//----------------Configuration functions-------------------//
void minAGC( void );
void maxAGC( void );
void changeGainAGC( float num );

//------------------Conversion functions--------------------//
float numToGainAGC ( int rdacCount );
int gainToNumAGC ( float gain );

//---------------------Getter functions---------------------//
int getRdacCountAGC ( void );
float getGainAGC ( void );
BYTE getI2CResultAGC ( void );

#endif /* AGCLIBRARY_H_ */
