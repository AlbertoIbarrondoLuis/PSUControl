/*
 * PSULibrary.cpp
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
*/



#include "Controller.h"

// Variables
BOOL powerONProcess = false; 	// used to initialize the system.
int powerONticks=0; 			// delay counter when initializing the system.
BOOL resetPowerON = false;		// setting it to TRUE activates the delayed switching-on process
WORD switchONListPSUs = 0;		// bits in TRUE are PSUs pending to be switched on

// Configuration
BOOL AuxAlarmUpdatingFLAG = INIT_AUXILIARY_ALARMS; 	// Controls whether auxiliary voltages are checked
													// for updating their alarms or not at initialization

//char bufferMOD5270[80]; 		// buffer mensajes tx y rx with MOD5270 using UART

PSU_TYPE psuList[PSU_NUMBER];					// MAIN PSU ARRAY LIST
AUX_TYPE auxList [INT_VCC_n12V + 1];		// Supply & Internal voltages List

// -> Aux
int monitorPSU=0;
BOOL alarmUpdate = false;							// Auxiliary flag used to trigger alarm updating

//=====================================================================================================//
//================================    VOLTAGE & CURRENT METHODS    ====================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// adjustRdac - changes the RDAC Register Value (thus modifying its output voltage)
// 					Checks for correct value updating
//-------------------------------------------------------------------------------------------------------
void adjustRdac (int psuNum, float Voltage){
	int desiredValue = voltToNum(Voltage, psuList[psuNum].rShunt);
	setValRDAC(desiredValue, psuList[psuNum].rdacAdr, psuList[psuNum].bridgeI2CAdr);
	int setValue = getValRDAC(psuList[psuNum].rdacAdr, psuList[psuNum].bridgeI2CAdr);
	if (desiredValue==setValue){
		psuList[psuNum].rdacValue = Voltage;
	}
	else{
		iprintf("ERROR: RDAC value %d not properly configured on PSU %d. Value %d set instead", desiredValue, psuNum, setValue);
	}
}


//-------------------------------------------------------------------------------------------------------
// resetRdacs - Hardware rheostat reset
//-------------------------------------------------------------------------------------------------------
void resetRdacs ( void ){
	Pins[21] = 1;
	OSTimeDly(TICKS_100MS);
	Pins[21] = 0;
}


//-------------------------------------------------------------------------------------------------------
// updateVoltagePSUs - Updates both RDAC values with their RAM configuration for the selected PSUs
//					  (marking its respective bit number as TRUE)
//-------------------------------------------------------------------------------------------------------
void updateVoltagePSUs(WORD selectPSUs){	// PSUs marked with his corresponding bit to 1 will be switched on.
	int psuNum; int aux = selectPSUs;
	// ajustar fuentes
	for (psuNum=0;psuNum<PSU_NUMBER;psuNum++){
		if(aux & 0x0001){
			if (psuList[psuNum].psuStatus) {
				adjustRdac (psuNum, psuList[psuNum].rdacValue);
			}
		}
		aux=aux>>1;
 	}
	OSTimeDly(TICKS_100MS); // delay for regulator adjustment
}


//-------------------------------------------------------------------------------------------------------
// readVoltageValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						to voltage. Currently not in use, as this function is executed by PITR 0
//						(see TimerInt.cpp)
//-------------------------------------------------------------------------------------------------------
void readVoltageValue(int psuNum){
	float value = 0, scaleFactor = 0;
	scaleFactor = setMUX((BYTE) FUNCTION_READ_VOLTAGE, (BYTE)psuNum);
	value = ((float)(ReadA2DResult(0) >> 3) / (4095.0)) * 3.3 * scaleFactor*getGainAGC();
	psuList[psuNum].vOut = value;
}


//-------------------------------------------------------------------------------------------------------
// readCurrentValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						to current.Currently not in use, as this function is executed by PITR 0
//						(see TimerInt.cpp)
//-------------------------------------------------------------------------------------------------------
void readCurrentValue(int psuNum){
	float value = 0, scaleFactor = 0;
	scaleFactor = setMUX((BYTE)FUNCTION_READ_CURRENT, (BYTE)psuNum);
	value = ((float)(ReadA2DResult(0) >> 3) / (4095.0)) * 3.3 * scaleFactor * getGainAGC();
	psuList[psuNum].cOut = value;
}


//=====================================================================================================//
//======================================    ALARM METHODS    ==========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// alarmTask - Independent process in charge of monitoring all the PSU alarms once every 100ms
//				and executing the programmed protocols once every second if an alarm is triggered.
//-------------------------------------------------------------------------------------------------------
void alarmTask (void *p){
	/* alarmUpdate is triggered on by PITR0 once every PITR_TIMES_TO_ALARM. Currently not in use
	if (alarmUpdate){
		alarmUpdate = false;
	}
	*/
	int nled = 0;
	BOOL ledFlag = true;
	while (1){
		OSTimeDly(TICKS_100MS);   	// Critical, otherwise the lower tasks wont receive computing time.
		updateAlarms();

		nled++;						// Uses LED 0 as output
			if (nled>=3){
				Pins[28] = ledFlag;
				ledFlag = !ledFlag;
				nled= 0;
			}
	}

}

//-------------------------------------------------------------------------------------------------------
// alarmCheck - Checks each alarm status for the selected PSU and executes the programmed protocols
//				if activated.
//-------------------------------------------------------------------------------------------------------
void alarmCheck (int psuNum, BOOL inf_sup, BOOL volt_corr, BOOL psu_aux){
	if (psu_aux == CHECK_PSU){		// Checking a PSU_TYPE from psuList
		if(psuList[psuNum].alarmWatch[_(inf_sup,volt_corr)]){				// If the selected alarm is being watched (INFERIOR/SUPERIOR, VOLTAGE/CURRENT)
																					// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(inf_sup,volt_corr)]);
			if (psuList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]){			// If limit is exceeded
				psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)]++;					// Increment Alarm Counter

				if (psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)]>=psuList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)]){
																						//  Trigger on the alarm if counter reaches the time limit
					if (psuList[psuNum].alarmStatus[_(inf_sup,volt_corr)] == false ){			// If it's the first time the alarm is triggered, execute protocols
						psuList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = true;
						int j;
						for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){									// Goes over each alarm protocol for the activated alarm
							if (psuList[psuNum].alarmProtocols[__(inf_sup,volt_corr, j)]){
								executeAlarmProtocol (psuNum, inf_sup,volt_corr, j);
							}
						}
					}
					psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)]=psuList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)];
				}																		// Sets the counter to time limit (thus preventing it to increase further)
			}
			else{																	// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)] > 0){			// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)] -= 1;			// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(inf_sup,volt_corr)] == 0){			// And when it hits 0, shut off the alarm.
						psuList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = false;
					}
				}
			}
		}
	}

	else{			// psu_aux = CHECK_AUX    - Checking an AUX_TYPE from auxList
		if(auxList[psuNum].alarmWatch[_(inf_sup,volt_corr)]){				// If the selected alarm is being watched (INFERIOR/SUPERIOR, VOLTAGE/CURRENT)
																					// Refresh alarmLimitReached value
			auxList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]=(auxList[psuNum].vOut <= auxList[psuNum].alarmLimitValues[_(inf_sup,volt_corr)]);
			if (auxList[psuNum].alarmLimitReached[_(inf_sup,volt_corr)]){			// If limit is exceeded
				auxList[psuNum].alarmCounters[_(inf_sup,volt_corr)]++;					// Increment Alarm Counter

				if (auxList[psuNum].alarmCounters[_(inf_sup,volt_corr)]>=auxList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)]){
																						//  Trigger on the alarm if counter reaches the time limit
					if (auxList[psuNum].alarmStatus[_(inf_sup,volt_corr)] == false ){			// If it's the first time the alarm is triggered, execute protocols
						auxList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = true;
						int j;
						for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){									// Goes over each alarm protocol for the activated alarm
							if (auxList[psuNum].alarmProtocols[__(inf_sup,volt_corr, j)]){
								executeAlarmProtocol (psuNum, inf_sup,volt_corr, j);
							}
						}
					}
					auxList[psuNum].alarmCounters[_(inf_sup,volt_corr)]=auxList[psuNum].alarmLimitTimes[_(inf_sup,volt_corr)];
				}																		// Sets the counter to time limit (thus preventing it to increase further)
			}
			else{																	// If limit is not exceeded
				if (auxList[psuNum].alarmCounters[_(inf_sup,volt_corr)] > 0){			// And counter is higher than 0
					auxList[psuNum].alarmCounters[_(inf_sup,volt_corr)] -= 1;			// Decrease counter until it reaches 0
					if (auxList[psuNum].alarmCounters[_(inf_sup,volt_corr)] == 0){			// And when it hits 0, shut off the alarm.
						auxList[psuNum].alarmStatus[_(inf_sup,volt_corr)] = false;
					}
				}
			}
		}
	}
}


//-------------------------------------------------------------------------------------------------------
// executeAlarmProtocol - Carries out a different protocol depending of the type of alarm
//						 (SUPERIOR/INFERIOR,VOLTAGE/CURRENT).
//-------------------------------------------------------------------------------------------------------
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum){
	int k;
	switch (protocolNum){		// (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
	case PROTOCOL_SHUTDOWN:
		WORD shutdown;
		shutdown = psuList[psuNum].alarmProtocolShutdown[_(limit_inf_sup, type_volt_corr)];
		for (k=0; k<12; k++){
			if (shutdown&0x1){
				disconnectPSU(psuNum);
			}
			shutdown = shutdown >>1;
		}
		break;
	case PROTOCOL_MODIFY_VOLTAGE:
			adjustRdac(psuNum, psuList[psuNum].alarmProtocolVoltage[_(limit_inf_sup,type_volt_corr)]);
		break;
	case PROTOCOL_MESSAGE:
			iprintf(ALARM_MESSAGE);
			//TODO: Maybe add some other alarm output - left for future implementation
		break;
	}
}

//-------------------------------------------------------------------------------------------------------
// updateAlarms - Takes a sample of Voltage and Current for all the PSUs and updates
// 				  their alarm status, counters and flags by comparing the sample with
//				  the programmed limit
//-------------------------------------------------------------------------------------------------------
void updateAlarms (void){
	int psuNum;
	// Goes over each PSU in psuList
	for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
		// Check each alarm
		alarmCheck(psuNum, INFERIOR, VOLTAGE, CHECK_PSU);
		alarmCheck(psuNum, SUPERIOR, VOLTAGE, CHECK_PSU);
		alarmCheck(psuNum, INFERIOR, CURRENT, CHECK_PSU);
		alarmCheck(psuNum, SUPERIOR, CURRENT, CHECK_PSU);

	}

	//Same procedure for auxList, controlled by AuxAlarmUpdatingFLAG (default switched off)
	if (AuxAlarmUpdatingFLAG){
		for (psuNum=0; psuNum<=INT_VCC_n12V; psuNum++){
			alarmCheck(psuNum, INFERIOR, VOLTAGE, CHECK_AUX);
			alarmCheck(psuNum, SUPERIOR, VOLTAGE, CHECK_AUX);
			alarmCheck(psuNum, INFERIOR, CURRENT, CHECK_AUX);
			alarmCheck(psuNum, SUPERIOR, CURRENT, CHECK_AUX);
		}
	}
}




//=====================================================================================================//
//================================    PSUs SWITCH ON/OFF METHODS    ===================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// switchONPSUsTask - RTOS Task in charge of the PSUs' delayed switching-on process, connecting the relays
//					  when each PSU reaches its initializationTimer. When every PSU has been connected, the
//					  task is destroyed.
//-------------------------------------------------------------------------------------------------------
void switchONPSUsTask(void *p){
		if(resetPowerON){
			powerONticks = 0;
			resetPowerON = false;
		}
		powerONProcess=true;
		Pins[25]= true;
		while(switchONListPSUs){
			int psuNum=0;
			int aux=switchONListPSUs;
			for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
				if(aux & 0x0001){
					if(psuList[psuNum].initializationTimer <= powerONticks){
						switchONListPSUs-=(0x0001<<psuNum);
						psuList[psuNum].ReadyToConnect = true;
						connectPSU(psuNum);
						adjustRdac (psuNum, psuList[psuNum].rdacValue);
					}
				}
				aux=aux>>1;
			}
			powerONticks++;
			OSTimeDly(TICKS_100MS);
		}
		OSTimeDly(TICKS_PER_SECOND*6);
		powerONProcess=false;
		Pins[25]= false;
		iprintf("Switch On completed\n");
		OSTaskDelete();
}


//-------------------------------------------------------------------------------------------------------
// initializeValuesPSUsAUXs - Loads all PSU values from FLASH and checks for each VERIFY_KEY correction.
//						If corrupted, sets the PSU values to default. Also Initializes the values of
//						auxList to their defaults
//-------------------------------------------------------------------------------------------------------
int initializeValuesPSUsAUXs(void){
	 int saveParameters=FALSE;
	 int i=0;
	 PSU_TYPE *pData = (PSU_TYPE *) GetUserParameters();
	 PSU_TYPE *ppsuList = psuList;
	 for (i=0;i<PSU_NUMBER;i++){
	      if (pData->VerifyKey != VERIFY_KEY){ 			// Incorrect Data
	    	  defaultValuesPSU(i);
	    	  saveParameters=TRUE;							// Save values as soon as an invalid key is detected
          }else {											// Correct data
        	  // readFlashValuesPSU(i,pData); 				use in case memory copying didn't work (which currently does)
        	  memcpy (ppsuList, pData, sizeof(PSU_TYPE));
		  }
	      pData++; ppsuList++;							//Next PSU reading
	  }
     if (saveParameters){
    	 saveParameters = saveInFlashValuesPSU ();
     }

     for (i=0;i<=INT_VCC_n12V; i++){					// Initialize values of auxList to their defaults (auxiliar voltages)
    	 defaultValuesAUX(i);
     }
     return saveParameters;
}

//-------------------------------------------------------------------------------------------------------
// connectPSU - Connects the selected PSU by switching its Rel� and activates its LED OUT
//-------------------------------------------------------------------------------------------------------
void connectPSU(int psuNum){
	connectRelay ( psuNum );
	// TODO: activar LED OUT ON. quiz� esperar alguna medida de tensi�n para asegurar que funciona
	psuList[psuNum].psuStatus=true;
	psuList[psuNum].ReadyToConnect=false;
}

//-------------------------------------------------------------------------------------------------------
// switchONPSUs - Manages the complete PSU switching-on process for the selected PSUs: Initializes
//				its RAM values, changes its RDAC Register values, tells the switchONPSUsTask to
//				begin the delayed switching-on process.
//-------------------------------------------------------------------------------------------------------
void switchONPSUs(WORD selectedPSUs){
	powerONProcess=true;					// Starts switching on the psus. will be terminated by the switchONPSUsTask
	initializeValuesPSUsAUXs();					// Load psuList values from RAM or set them to default

	resetPowerON=true;						// Sends the selectedPSUs to the timed task switchONPSUsTask to
	switchONListPSUs = selectedPSUs;		// 	begin switching-on countdown.

    OSSimpleTaskCreate( switchONPSUsTask, SWITCH_ON_PRIO );	// Creates the OS Task to control the delayed switching-on
}



//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSU's relay, updating its LED OUT, and sets its power to minimum
//-------------------------------------------------------------------------------------------------------
void disconnectPSU(int psuNum){
	psuList[psuNum].ReadyToConnect=false;
	disconnectRelay ( psuNum );
	psuList[psuNum].relayStatus=false;
	adjustRdac(psuNum, INITIAL_VOLTAGE);
	psuList[psuNum].psuStatus=false;
	// TODO: comprobar si se ha de desactivar  led Out On y si el voltaje se ha desconectado
}

//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSUs' relays, updating its LED OUT, and sets their power to minimum
//-------------------------------------------------------------------------------------------------------
void switchOFFPSUs(WORD selectedPSUs){
	disconnectRelaySeveral ( selectedPSUs );
	int psuNum;
	for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
		if(selectedPSUs & 0x0001){
			psuList[psuNum].ReadyToConnect=false;
			disconnectRelay ( psuNum );
			psuList[psuNum].relayStatus=false;
			adjustRdac(psuNum, INITIAL_VOLTAGE);
			psuList[psuNum].psuStatus=false;
		}
		selectedPSUs=selectedPSUs>>1;
	}
	// TODO: desactivar  led Out On. Comprobar el voltaje para asegurar que se ha desconectado
}


//=====================================================================================================//
//==================================    FLASH MEMORY METHODS    =======================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// LoadFlashValuesPSU - Copies the data from the FLASH memory to the psuList in RAM, updating all
//						PSU programmed values. DOESN'T VERIFY DATA INTEGRITY (Use initializeValuesPSUsAUXs()
//						instead)
//-------------------------------------------------------------------------------------------------------
void loadFlashValuesPSU (void){
	PSU_TYPE *pData = (PSU_TYPE *) GetUserParameters();
	memcpy (psuList, pData, sizeof(psuList));
	iprintf("Loaded values of psuList from Flash Mem\n");
}

//-------------------------------------------------------------------------------------------------------
// saveInFlashValuesPSU - Stores the current psuList as a whole in the 8Kbits FLASH memory. For the
//						time being, 2Kbits of data are stored by using this method (the rest remains
//						unused).
//-------------------------------------------------------------------------------------------------------
int saveInFlashValuesPSU (void){
	int aux = SaveUserParameters(psuList, sizeof(psuList));
	iprintf("Saved values of psuList, for a total of %d Bytes in Flash Mem\n", aux);
	return aux;
}

//-------------------------------------------------------------------------------------------------------
// readFlashValuesPSU - Auxiliary method, not currently in use. Copies the data from one PSU from
//						a FLASH direction to a RAM variable (psuList) one value at a time.
//						Greatly simplified by using instead:
//												memcpy (psuList[psuNum], pData, sizeof(PSU_TYPE));
//-------------------------------------------------------------------------------------------------------
void readFlashValuesPSU(int psuNum, PSU_TYPE *pData){
	psuList[psuNum].relayStatus=pData->relayStatus;
	psuList[psuNum].psuStatus=pData->psuStatus;
	psuList[psuNum].rdacValue=pData->rdacValue;
	psuList[psuNum].bridgeI2CAdr=pData->bridgeI2CAdr;	// Probably required a different address for each psu
	psuList[psuNum].rdacAdr=pData->rdacAdr;
	memcpy(psuList[psuNum].alarmLimitValues, pData->alarmLimitValues, sizeof(psuList[psuNum].alarmLimitValues));
	memcpy(psuList[psuNum].alarmLimitTimes, pData->alarmLimitTimes, sizeof(psuList[psuNum].alarmLimitTimes));
	memcpy(psuList[psuNum].alarmProtocols, pData->alarmProtocols, sizeof(psuList[psuNum].alarmProtocols));
	memcpy(psuList[psuNum].alarmProtocolShutdown, pData->alarmProtocolShutdown, sizeof(psuList[psuNum].alarmProtocolShutdown));
	memcpy(psuList[psuNum].alarmProtocolVoltage, pData->alarmProtocolVoltage, sizeof(psuList[psuNum].alarmProtocolVoltage));
	memcpy(psuList[psuNum].alarmCounters, pData->alarmCounters, sizeof(psuList[psuNum].alarmCounters));
	memcpy(psuList[psuNum].alarmStatus, pData->alarmStatus, sizeof(psuList[psuNum].alarmStatus));
	memcpy(psuList[psuNum].alarmLimitReached, pData->alarmLimitReached, sizeof(psuList[psuNum].alarmLimitReached));
	memcpy(psuList[psuNum].alarmWatch, pData->alarmWatch, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt =  pData->rShunt;
	psuList[psuNum].divisorTension1 =  pData->divisorTension1;
	psuList[psuNum].divisorTension2 =  pData->divisorTension2;
	psuList[psuNum].rAdicPotDigital =  pData->rAdicPotDigital;
	psuList[psuNum].rDivisorPotDigital =  pData->rAdicPotDigital;
	psuList[psuNum].vOut =  pData->vOut;
	psuList[psuNum].cOut =  pData->cOut;
}




//=====================================================================================================//
//====================================    AUXILIARY METHODS    ========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// defaultValuesPSU - Replaces the current PSU values in RAM by those predefined as DEFAULT in
//					file "defineConstants.cpp"
//-------------------------------------------------------------------------------------------------------
void defaultValuesPSU (int psuNum) {
	psuList[psuNum].relayStatus=DEFAULT_relayStatus;
	psuList[psuNum].psuStatus=DEFAULT_psuStatus;
	psuList[psuNum].rdacValue=DEFAULT_rdacValue;
	BYTE i2CtoSPIAddress[12]= PSUs_I2C_ADDRESS_ARRAY;
	psuList[psuNum].bridgeI2CAdr=i2CtoSPIAddress[psuNum];
	psuList[psuNum].rdacAdr=(psuNum&0x1?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
	float auxArray1[4]=DEFAULT_alarmLimitValues;
	memcpy(psuList[psuNum].alarmLimitValues, auxArray1, sizeof(psuList[psuNum].alarmLimitValues));
	int auxArray2[4]=DEFAULT_alarmLimitTimes;
	memcpy(psuList[psuNum].alarmLimitTimes, auxArray2, sizeof(psuList[psuNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_alarmProtocols;
	memcpy(psuList[psuNum].alarmProtocols, auxArray3, sizeof(psuList[psuNum].alarmProtocols));
	DWORD k = demux4to16(psuNum+1);
	int auxArray4[4]={k, k, k, k};
	memcpy(psuList[psuNum].alarmProtocolShutdown, auxArray4, sizeof(psuList[psuNum].alarmProtocolShutdown));
	float auxArray5[8]=DEFAULT_alarmProtocolVoltage;
	memcpy(psuList[psuNum].alarmProtocolVoltage, auxArray5, sizeof(psuList[psuNum].alarmProtocolVoltage));
	int auxArray6[4]=DEFAULT_alarmCounters;
	memcpy(psuList[psuNum].alarmCounters, auxArray6, sizeof(psuList[psuNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_alarmStatus;
	memcpy(psuList[psuNum].alarmStatus, auxArray7, sizeof(psuList[psuNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_alarmLimitReached;
	memcpy(psuList[psuNum].alarmLimitReached, auxArray8, sizeof(psuList[psuNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_alarmWatch;
	memcpy(psuList[psuNum].alarmWatch, auxArray9, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt = DEFAULT_rShunt;
	psuList[psuNum].divisorTension1 = DEFAULT_divisorTension1;
	psuList[psuNum].divisorTension2 = DEFAULT_divisorTension2;
	psuList[psuNum].rAdicPotDigital = DEFAULT_rAdicPotDigital;
	psuList[psuNum].rDivisorPotDigital = DEFAULT_rDivisorPotDigital;
	psuList[psuNum].vOut = DEFAULT_vOut;
	psuList[psuNum].cOut = DEFAULT_cOut;
}


//-------------------------------------------------------------------------------------------------------
// printValuesPSU - prints by stdio all the values in RAM from the selected PSU
//-------------------------------------------------------------------------------------------------------
void printValuesPSU (int psuNum) {
	iprintf("PSU-Number: %d\n", psuNum);
	iprintf("- relayStatus: %d\n",psuList[psuNum].relayStatus);
	iprintf("- psuStatus: %d\n",psuList[psuNum].psuStatus);
	iprintf("- rdacValue: %s\n",ftos(psuList[psuNum].rdacValue));
	iprintf("- bridgeI2CDir: 0x%x\n",psuList[psuNum].bridgeI2CAdr);
	iprintf("- rdacAdr: %d\n",psuList[psuNum].rdacAdr);
	iprintf("- alarmLimitValues: {%s, %s, %s, %s}\n",
			ftos(psuList[psuNum].alarmLimitValues[0]), ftos(psuList[psuNum].alarmLimitValues[1]),
			ftos(psuList[psuNum].alarmLimitValues[2]),ftos(psuList[psuNum].alarmLimitValues[3]));

	iprintf("- alarmLimitTimes: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitTimes[0], psuList[psuNum].alarmLimitTimes[1],
			psuList[psuNum].alarmLimitTimes[2],psuList[psuNum].alarmLimitTimes[3]);

	iprintf("- alarmProtocols: {%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d}\n",
			psuList[psuNum].alarmProtocols[0],psuList[psuNum].alarmProtocols[1],
			psuList[psuNum].alarmProtocols[2],psuList[psuNum].alarmProtocols[3],
			psuList[psuNum].alarmProtocols[4],psuList[psuNum].alarmProtocols[5],
			psuList[psuNum].alarmProtocols[6],psuList[psuNum].alarmProtocols[7],
			psuList[psuNum].alarmProtocols[8],psuList[psuNum].alarmProtocols[9],
			psuList[psuNum].alarmProtocols[10],psuList[psuNum].alarmProtocols[11]);
	iprintf("- alarmProtocolShutdown: {0x%x, 0x%x, 0x%x, 0x%x}\n",
			psuList[psuNum].alarmProtocolShutdown[0], psuList[psuNum].alarmProtocolShutdown[1],
			psuList[psuNum].alarmProtocolShutdown[2],psuList[psuNum].alarmProtocolShutdown[3]);
	iprintf("- alarmProtocolVoltage:{%s, %s, %s, %s, %s, %s, %s, %s}\n",
			ftos(psuList[psuNum].alarmProtocolVoltage[0]),ftos(psuList[psuNum].alarmProtocolVoltage[1]),
			ftos(psuList[psuNum].alarmProtocolVoltage[2]),ftos(psuList[psuNum].alarmProtocolVoltage[3]),
			ftos(psuList[psuNum].alarmProtocolVoltage[4]),ftos(psuList[psuNum].alarmProtocolVoltage[5]),
			ftos(psuList[psuNum].alarmProtocolVoltage[6]),ftos(psuList[psuNum].alarmProtocolVoltage[7]));
	iprintf("- alarmCounters: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmCounters[0], psuList[psuNum].alarmCounters[1],
			psuList[psuNum].alarmCounters[2],psuList[psuNum].alarmCounters[3]);
	iprintf("- alarmStatus: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmStatus[0], psuList[psuNum].alarmStatus[1],
			psuList[psuNum].alarmStatus[2],psuList[psuNum].alarmStatus[3]);
	iprintf("- alarmLimitReached: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitReached[0], psuList[psuNum].alarmLimitReached[1],
			psuList[psuNum].alarmLimitReached[2],psuList[psuNum].alarmLimitReached[3]);
	iprintf("- alarmWatch: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmWatch[0], psuList[psuNum].alarmWatch[1],
			psuList[psuNum].alarmWatch[2],psuList[psuNum].alarmWatch[3]);
	iprintf("- rShunt: %d\n",psuList[psuNum].rShunt);
	iprintf("- divisorTension1: %d\n",psuList[psuNum].divisorTension1);
	iprintf("- divisorTension2: %d\n",psuList[psuNum].divisorTension2);
	iprintf("- rAdicPotDigital: %d\n",psuList[psuNum].rAdicPotDigital);
	iprintf("- rDivisorPotDigital: %d\n",psuList[psuNum].rDivisorPotDigital);
	iprintf("- vOut: %d\n",psuList[psuNum].vOut);
	iprintf("- cOut: %d\n",psuList[psuNum].cOut);

}


//-------------------------------------------------------------------------------------------------------
// defaultValuesAUX - Replaces the current AUX values in RAM by those predefined as DEFAULT in
//					file "defineConstants.cpp"
//-------------------------------------------------------------------------------------------------------
void defaultValuesAUX (int auxNum) {
	auxList[auxNum].auxStatus=DEFAULT_auxStatus;
	float auxArray0[14]=DEFAULT_auxVoltage;
	auxList[auxNum].auxVoltage=auxArray0[auxNum];
	float auxArray1[4]= {auxList[auxNum].auxVoltage * AUXILIAR_INF_PERC_ALARM_VALUE, auxList[auxNum].auxVoltage * AUXILIAR_SUP_PERC_ALARM_VALUE, 0, 0 };
	memcpy(auxList[auxNum].alarmLimitValues, auxArray1, sizeof(auxList[auxNum].alarmLimitValues));
	int auxArray2[4]=DEFAULT_auxalarmLimitTimes;
	memcpy(auxList[auxNum].alarmLimitTimes, auxArray2, sizeof(auxList[auxNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_auxalarmProtocols;
	memcpy(auxList[auxNum].alarmProtocols, auxArray3, sizeof(auxList[auxNum].alarmProtocols));
	int auxArray4[4]={0, 0, 0, 0};
	memcpy(auxList[auxNum].alarmProtocolShutdown, auxArray4, sizeof(auxList[auxNum].alarmProtocolShutdown));
	int auxArray6[4]=DEFAULT_auxalarmCounters;
	memcpy(auxList[auxNum].alarmCounters, auxArray6, sizeof(auxList[auxNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_auxalarmStatus;
	memcpy(auxList[auxNum].alarmStatus, auxArray7, sizeof(auxList[auxNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_auxalarmLimitReached;
	memcpy(auxList[auxNum].alarmLimitReached, auxArray8, sizeof(auxList[auxNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_auxalarmWatch;
	memcpy(auxList[auxNum].alarmWatch, auxArray9, sizeof(auxList[auxNum].alarmWatch));
	auxList[auxNum].vOut = DEFAULT_vOut;
}

//-------------------------------------------------------------------------------------------------------
// printValuesAUX - prints by stdio all the values in RAM from the selected PSU
//-------------------------------------------------------------------------------------------------------
void printValuesAUX (int auxNum) {
	iprintf("AUX-Number: %d\n", auxNum);
	iprintf("- auxStatus: %d\n",auxList[auxNum].auxStatus);
	iprintf("- auxVoltage: %s\n",ftos(auxList[auxNum].auxVoltage));
	iprintf("- alarmLimitValues: {%s, %s, %s, %s}\n",
			ftos(auxList[auxNum].alarmLimitValues[0]), ftos(auxList[auxNum].alarmLimitValues[1]),
			ftos(auxList[auxNum].alarmLimitValues[2]),ftos(auxList[auxNum].alarmLimitValues[3]));

	iprintf("- alarmLimitTimes: {%d, %d, %d, %d}\n",
			auxList[auxNum].alarmLimitTimes[0], auxList[auxNum].alarmLimitTimes[1],
			auxList[auxNum].alarmLimitTimes[2],auxList[auxNum].alarmLimitTimes[3]);

	iprintf("- alarmProtocols: {%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d}\n",
			auxList[auxNum].alarmProtocols[0],auxList[auxNum].alarmProtocols[1],
			auxList[auxNum].alarmProtocols[2],auxList[auxNum].alarmProtocols[3],
			auxList[auxNum].alarmProtocols[4],auxList[auxNum].alarmProtocols[5],
			auxList[auxNum].alarmProtocols[6],auxList[auxNum].alarmProtocols[7],
			auxList[auxNum].alarmProtocols[8],auxList[auxNum].alarmProtocols[9],
			auxList[auxNum].alarmProtocols[10],auxList[auxNum].alarmProtocols[11]);
	iprintf("- alarmProtocolShutdown: {0x%x, 0x%x, 0x%x, 0x%x}\n",
			auxList[auxNum].alarmProtocolShutdown[0], auxList[auxNum].alarmProtocolShutdown[1],
			auxList[auxNum].alarmProtocolShutdown[2],auxList[auxNum].alarmProtocolShutdown[3]);
	iprintf("- alarmCounters: {%d, %d, %d, %d}\n",
			auxList[auxNum].alarmCounters[0], auxList[auxNum].alarmCounters[1],
			auxList[auxNum].alarmCounters[2],auxList[auxNum].alarmCounters[3]);
	iprintf("- alarmStatus: {%d, %d, %d, %d}\n",
			auxList[auxNum].alarmStatus[0], auxList[auxNum].alarmStatus[1],
			auxList[auxNum].alarmStatus[2],auxList[auxNum].alarmStatus[3]);
	iprintf("- alarmLimitReached: {%d, %d, %d, %d}\n",
			auxList[auxNum].alarmLimitReached[0], auxList[auxNum].alarmLimitReached[1],
			auxList[auxNum].alarmLimitReached[2],auxList[auxNum].alarmLimitReached[3]);
	iprintf("- alarmWatch: {%d, %d, %d, %d}\n",
			auxList[auxNum].alarmWatch[0], auxList[auxNum].alarmWatch[1],
			auxList[auxNum].alarmWatch[2],auxList[auxNum].alarmWatch[3]);
	iprintf("- vOut: %d\n",auxList[auxNum].vOut);

}
PSU_TYPE getPSU (int psuNum){
	return psuList[psuNum];
}

AUX_TYPE getAUX( int auxNum ){
	return auxList[auxNum];
}
