/*
 * PSULibrary.h
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
 */

#ifndef PSULIBRARY_H_
#include "Headers.h"

#include "defineConstants.cpp"
#include "Libraries/RDACLibrary.h"
#include "Libraries/MUXLibrary.h"
#include "Libraries/I2C&SPILibrary.h"
#include "Libraries/RelayLibrary.h"
#include "Interruption.h"

#define PSULIBRARY_H_


//-------------------------------VOLTAGE & CURRENT METHODS------------------------------------//
void adjustRdac (int psuNum, int slave, float Voltage);
void resetRdacs ( void );
void updateVoltagePSUs(WORD selectPSUs);
void readVoltageValue(int psuNum);
void readCurrentValue(int psuNum);
void selectMuxPSU(int psuNum, int function);


//-------------------------------------ALARM METHODS------------------------------------------//
void alarmTask (void *p);
void alarmCheck (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr);
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum);
void updateAlarms (void);


//-----------------------------------FLASH MEMORY METHODS-------------------------------------//
void loadFlashValuesPSU (void);
int saveInFlashValuesPSU (void);
void readFlashValuesPSU(int psuNum, PSU_TYPE *pData);



//-----------------------------------SWITCH ON PSUs METHODS-----------------------------------//
void switchONPSUsTask(void *p);
int initializeValuesPSUsAUXs(void);
void connectPSU(int psuNum);
void switchONPSUs(WORD selectedPSUs);
void disconnectPSU(int psuNum);
void switchOFFPSUs(WORD selectedPSUs);


//-------------------------------------AUXILIARY METHODS--------------------------------------//
void defaultValuesPSU (int psuNum);
void printValuesPSU (int psuNum);
void defaultValuesAUX (int auxNum);
void printValuesAUX (int auxNum);
PSU_TYPE getPSU (int psuNum);
AUX_TYPE getAUX( int auxNum );


#endif /* PSULIBRARY_H_ */


