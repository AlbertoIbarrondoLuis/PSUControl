/*
 * I2CLibrary.h
 *
 *  Created on: 29-ene-2015
 *      Author: Alberto
 */

#ifndef I2CLIBRARY_H_
#define I2CLIBRARY_H_


#include "predef.h"
#include <ctype.h>
#include <basictypes.h>					// BOOL & BYTE
#include <system.h>
#include <constants.h>
#include <ucos.h>
#include <ucosmcfc.h>
#include <serialirq.h>
#include <stdio.h>						// uint
#include <smarttrap.h>
#include <serialupdate.h>
#include "i2cmulti.h"            		// Used for Multi-Master I2C
#include <string.h>
#include <Pins.h>
#include <bsp.h>            			// MOD5213 board support package interface
#include <gdbstub.h>
#include <utils.h>          			// Include for usage of carrier board LEDs
#include <sim5213.h>        			// Access to MCF5213 register structures
#include <stdlib.h>

#include "Libraries/GeneralLibrary.h"

//----------------------------------------Functions--------------------------------------------------//
BYTE sendI2CMessage ( BYTE outputBuffer[], int bufSize, BYTE I2CAdress );
BYTE configureSPI( BOOL order, BOOL cpol, BOOL cpha, int clkRate, BYTE I2CAdress );
BYTE sendSPImessage ( BYTE outputBuffer[], int bufSize, BYTE slaveSelect, BYTE BridgeI2CAdress );
BYTE readBridgeBuffer ( BYTE inputBuffer[], int bufSize, BYTE I2CAdress);
void toggleConsoleOutputI2CLib( void );
void errorDetails( BYTE I2CStat );

#endif /* LIBRARY_H_ */

