/*
 * BusExpLibrary.h
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#ifndef BUSEXPLIBRARY_H_
#define BUSEXPLIBRARY_H_

#include "predef.h"
#include <stdlib.h>
#include <stdio.h>						// uint
#include <ctype.h>
#include <string.h>
#include <basictypes.h>


#include "I2C&SPILibrary.h"
#endif /* BUSEXPLIBRARY_H_ */
