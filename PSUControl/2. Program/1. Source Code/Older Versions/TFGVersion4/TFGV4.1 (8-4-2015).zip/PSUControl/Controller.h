/*
 * PSULibrary.h
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
 */

#ifndef PSULIBRARY_H_
#include "predef.h"
#include <stdlib.h>
#include <stdio.h>						// uint
#include <ctype.h>
#include <string.h>
#include <basictypes.h>
#include <a2d.h>
// #include <cfinter.h>       // Interruption Programming - Currently disabled due to the use of RTOS Tasks

#include "Libraries/RDACLibrary.h"
#include "Libraries/MUXLibrary.h"
#include "Libraries/I2C&SPILibrary.h"
#include "PSU_TYPE.cpp"
#include "defineConstants.cpp"

#define PSULIBRARY_H_


//-------------------------------VOLTAGE & CURRENT METHODS------------------------------------//
void adjustRdac (int psuNum, int slave, float Voltage);
void updateVoltagePSUs(WORD selectPSUs);
void readVoltageValue(int psuNum);
void readCurrentValue(int psuNum);
void selectMuxPSU(int psuNum, int function);


//-------------------------------------ALARM METHODS------------------------------------------//
void alarmTask (void *p);
void alarmCheck (int psuNum);
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum);
void refreshAlarmCounters_100ms (void);


//-----------------------------------FLASH MEMORY METHODS-------------------------------------//
void loadFlashValuesPSU (void);
int saveInFlashValuesPSU (void);
void readFlashValuesPSU(int psuNum, PSU_TYPE *pData);


//-------------------------------------AUXILIARY METHODS--------------------------------------//
void defaultValuesPSU (int psuNum);
void printValuesPSU (int psuNum);
PSU_TYPE getPSU (int psuNum);

//-----------------------------------SWITCH ON PSUs METHODS-----------------------------------//
void switchONPSUsTask(void *p);
int initializeValuesPSUs(void);
void connectPSU(int psuNum);
void switchONPSUs(WORD selectedPSUs);
void disconnectPSU(int psuNum);



//___________________________________________________________________________________________//
//                    METHODS NOT BELONGING TO ME - LEFT TO BE REVISED
void EscribeEnDriver(int numDriver,BYTE dato, BYTE mascara);
void EscribeEnTransceptorBus(BYTE address, BYTE dato, BYTE mascara,BYTE * variable);
BYTE SeleccionaAddressPotDig(int numFuente);
void InicializarBusesControladora(void);
#endif /* PSULIBRARY_H_ */


