/*
 * Test_PSU.h
 *
 *  Created on: 10-mar-2015
 *      Author: Alberto
 */

#ifndef TEST_PSU_H_
#define TEST_PSU_H_
#include "defineConstants.cpp"
#include <basictypes.h>					// BOOL & BYTE
#include "Libraries/RDACLibrary.h"
#include "Libraries/I2C&SPILibrary.h"
#include "Libraries/RDACLibrary.h"
#include "Controller.h"
#include "PSU_TYPE.cpp"
#include <stdio.h>						// uint
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#endif /* TEST_PSU_H_ */



void TestMain ( void );
void displayCommandMenu( void );
void processCommand( char ch );
void changeSlave( void );

//--------------------------------BATTERY TESTS-------------------------
BOOL BATTERY_TEST_I2C ( void );
BOOL BATTERY_TEST_RDAC ( void );
BOOL BATTERY_TEST_FLASH_MEM( void );
