/*
 * BusExpLibrary.cpp
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#include "Libraries/RelayLibrary.h"

// I2C Addressing
#define BUS_EXP_1 0x39
#define BUS_EXP_2 0x3A
#define BUS_EXP_3 0x3B

#define OE_1_ACT 0x02
#define OE_2_ACT 0x01
#define OE_1_2_ACT 0x00
#define OE_DESAC 0x03

#define STB_1 0x04
#define STB_2 0x08


#define MUX_A 1
#define MUX_B 2
#define MUX_C 3
#define MUX_D 4
#define MUX_E 5

#define SF1_A 0
#define SF1_B 1
#define SF2_A 2
#define SF2_B 3
#define SF3_A 4
#define SF3_B 5
#define SF4_A 6
#define SF4_B 7
#define SF5_A 8
#define SF5_B 9
#define SF6_A 10
#define SF6_B 11

static BYTE I2CData[1] = {0};

BYTE Latch1 = 0;
BYTE Latch2 = 0;

//TODO: Check for Delays from every I2C message to device setting

void activateRelay (int psuNum){
	if (psuNum<SF4_B){
		I2CData[0]= STB_1 | OE_DESAC;
		sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Set Strobe for Latch 1
		Latch1 = Latch1 | (BYTE)DEMUX(psuNum+1);
		I2CData[0]= Latch1;
		sendI2CMessage (I2CData, 1, BUS_EXP_1);	// Send Relay activation flag
		I2CData[0]= OE_1_ACT;
		sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Clear strobes & Enable latch output
	}
	else{
		I2CData[0]= STB_2 | OE_DESAC;
		sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Set Strobe for Latch 2
		Latch2 = Latch2 | (BYTE)DEMUX(psuNum-7);
		I2CData[0]= Latch2;
		sendI2CMessage (I2CData, 1, BUS_EXP_1);	// Send Relay Flag Activation
		I2CData[0]= OE_2_ACT;
		sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Clear strobes & Enable latch output
	}
}

void deactivateRelay (int psuNum){
	if (psuNum<SF4_B){
		I2CData[0]= STB_1 | OE_DESAC;
		sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Set Strobe for Latch 1
		Latch1 = Latch1 & !((BYTE)DEMUX(psuNum+1));
		I2CData[0]= Latch1;
		sendI2CMessage (I2CData, 1, BUS_EXP_1);	// Send Relay activation flag
		I2CData[0]= OE_1_ACT;
		sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Clear strobes & Enable latch output
	}
	else{
		I2CData[0]= STB_2 | OE_DESAC;
		sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Set Strobe for Latch 2
		Latch2 = Latch2 & !((BYTE)DEMUX(psuNum-7));
		I2CData[0]= Latch2;
		sendI2CMessage (I2CData, 1, BUS_EXP_1);	// Send Relay Flag Activation
		I2CData[0]= OE_2_ACT;
		sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Clear strobes & Enable latch output
	}
}

void activateRelays (WORD selectedPSUs){
	BYTE ZeroToSeven = (BYTE)(selectedPSUs & 0x00FF);
	BYTE EightToEleven = (BYTE)((selectedPSUs & 0x0F00)>>8);
	if (ZeroToSeven){
			I2CData[0]= STB_1 | OE_DESAC;
			sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Set Strobe for Latch 1
			Latch1 = Latch1 | ZeroToSeven;
			I2CData[0]= Latch1;
			sendI2CMessage (I2CData, 1, BUS_EXP_1);	// Send Relay activation flag
			I2CData[0]= OE_1_ACT;
			sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Clear strobes & Enable latch output
	}
	if (EightToEleven){
			I2CData[0]= STB_2 | OE_DESAC;
			sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Set Strobe for Latch 2
			Latch2 = Latch2 | EightToEleven;
			I2CData[0]= Latch2;
			sendI2CMessage (I2CData, 1, BUS_EXP_1);	// Send Relay Flag Activation
			I2CData[0]= OE_2_ACT;
			sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Clear strobes & Enable latch output
		}
}

void deactivateRelays (WORD selectedPSUs){
	BYTE ZeroToSeven = (BYTE)(selectedPSUs & 0x00FF);
	BYTE EightToEleven = (BYTE)((selectedPSUs & 0x0F00)>>8);
	if (ZeroToSeven){
			I2CData[0]= STB_1 | OE_DESAC;
			sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Set Strobe for Latch 1
			Latch1 = Latch1 & !(ZeroToSeven);
			I2CData[0]= Latch1;
			sendI2CMessage (I2CData, 1, BUS_EXP_1);	// Send Relay activation flag
			I2CData[0]= OE_1_ACT;
			sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Clear strobes & Enable latch output
	}
	if (EightToEleven){
			I2CData[0]= STB_2 | OE_DESAC;
			sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Set Strobe for Latch 2
			Latch2 = EightToEleven;
			I2CData[0]= Latch2 & !(EightToEleven);
			sendI2CMessage (I2CData, 1, BUS_EXP_1);	// Send Relay Flag Activation
			I2CData[0]= OE_2_ACT;
			sendI2CMessage (I2CData, 1, BUS_EXP_2);	// Clear strobes & Enable latch output
		}
}
