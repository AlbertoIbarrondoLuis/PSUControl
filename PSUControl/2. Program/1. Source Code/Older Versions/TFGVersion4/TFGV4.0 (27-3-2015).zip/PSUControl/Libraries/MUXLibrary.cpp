/*
 * MUXLibrary.cpp
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#include "MUXLibrary.h"

//-------------------------------------------------------------------------------------------------------
// selectMuxPSU - Configures the Muxes for a PSU number and the desired function:
//				(0) FUNCTION_READ_VOLTAGE: Allows Voltage reading.
//				(1) FUNCTION_READ_CURRENT: Allows current Reading.
//				(2) FUNCTION_SET_SCL: Allows RDAC updating.
//-------------------------------------------------------------------------------------------------------
/*
void selectMuxPSU(int psuNum, int function){
	PBYTE p=(BYTE *)transceptorBus;
	switch(function){
		case FUNCTION_READ_VOLTAGE:
			if (psuNum>7) psuNum-=8;
			psuNum++; // para fuentes de 1 a 12
			if (psuNum & 0x1) busData=busData|0x1;
			if (psuNum & 0x2) busData=busData|0x2;
			if (psuNum & 0x4) busData=busData|0x80;
			mask=0x83; // modificar solo po p1 y p7
			EscribeEnTransceptorBus(addressTransBus, busData,mask,p);
			busData=0;
			mask=0x70;
			busData=(psuNum<8?0x1:0x2); // las 8 primeras fuentes en canal1
			EscribeEnDriver(2,busData,mask);
			break;

		case FUNCTION_READ_CURRENT:
			psuNum++; // para fuentes de 1 a 12
			if (psuNum & 0x1) busData=busData|0x1;
			if (psuNum & 0x2) busData=busData|0x2;
			if (psuNum & 0x4) busData=busData|0x80;
			mask=0x83; // modificar solo po p1 y p7
			EscribeEnTransceptorBus(addressTransBus, busData,mask,p);

			busData=0; mask=0x70; //out5 out6 y out7 U315
			if (psuNum<8){
				busData=0x4;
			}else{
				psuNum-=4; // desplazamos para que la 8(novena fuente) sea la cuarta y caiga en S4
				if (psuNum & 0x1) busData=busData|0x10;
				if (psuNum & 0x2) busData=busData|0x20;
				if (psuNum & 0x4) busData=busData|0x40;
			}
			EscribeEnDriver(2,busData,mask);
			break;
		case FUNCTION_SET_SCL:
			int scl;
			if (psuNum<12) scl=3;
			if (psuNum<8) scl=2;
			if (psuNum<4) scl=1;
			mask=0x70; // modificar solo p4,p5,p6
			switch(scl){
				case 1:
					busData=0x10;
					break;
				case 2:
					busData=0x20;
					break;
				default:
					busData=0x40;
					break;
			}
			EscribeEnTransceptorBus(addressTransBus, busData,mask,p);
			break;
		default:
			break;
	}
}
*/
