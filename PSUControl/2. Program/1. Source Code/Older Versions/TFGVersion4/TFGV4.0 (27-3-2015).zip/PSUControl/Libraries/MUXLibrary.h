/*
 * MUXLibrary.h
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#ifndef MUXLIBRARY_H_
#include "predef.h"
#include <stdlib.h>
#include <stdio.h>						// uint
#include <ctype.h>
#include <string.h>
#include <basictypes.h>

#include "I2C&SPILibrary.h"
#define MUXLIBRARY_H_


#endif /* MUXLIBRARY_H_ */
