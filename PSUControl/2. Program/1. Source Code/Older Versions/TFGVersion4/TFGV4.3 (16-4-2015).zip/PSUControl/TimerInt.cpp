/*
 * TimerInt.cpp
 *
 *  Created on: 15-abr-2015
 *      Author: Alberto
 */

#include "Headers.h"
#include "TimerInt.h"

extern "C" {
//
// This function sets up the 5213 interrupt controller
//
void SetIntc(long func, int vector, int level, int prio);
}


volatile DWORD pitr_count_one;
volatile DWORD pitr_count_zero;
DWORD return_pitr_count_one (void){
	return pitr_count_one;
}
DWORD return_pitr_count_zero (void){
	return pitr_count_zero;
}
INTERRUPT( my_pitr_func_zero, 0x2300 )
{
	WORD tmp = sim.pit[0].pcsr; // Use PIT 0

	//
	// Clear PIT 1 refer to table 173 for more information on what
	// bits are being cleared and set
	//
	tmp &= 0xFF0F; // Bits 47 cleared
	tmp |= 0x0F; // Bits 03 set
	sim.pit[0].pcsr = tmp;
	//
	// You can add your ISR code here
	// Do not call any RTOS function with pend or init in the function
	// name
	// Do not call any functions that perform a system I/O read,
	// write, printf, iprint, etc.
	//
	pitr_count_zero++;
}

INTERRUPT( my_pitr_func_one, 0x2300 )
{
	WORD tmp = sim.pit[1].pcsr; // Use PIT 1

	tmp &= 0xFF0F; // Bits 47 cleared
	tmp |= 0x0F; // Bits 03 set
	sim.pit[1].pcsr = tmp;
	//
	// You can add your ISR code here
	// Do not call any RTOS function with pend or init in the function
	// name
	// Do not call any functions that perform a system I/O read,
	// write, printf, iprint, etc.
	//
	pitr_count_one++;
}
///////////////////////////////////////////////////////////////////////
// SetUpPITR PIT setup function. See chapter 17 of the 5213 reference
// manual for details.
//
void SetUpPITR(int pitr_ch, WORD clock_interval, BYTE pcsr_pre /* See table 173 in the users manual for bits 811*/) {
	WORD tmp;
	//
	// Populate the interrupt vector in the interrupt controller
	//
	SetIntc((pitr_ch?((long) &my_pitr_func_one):((long) &my_pitr_func_zero)), 55 + pitr_ch, 3 /* IRQ 3 */, (pitr_ch?3:2));
	sim.pit[pitr_ch].pmr = clock_interval; // Set the PIT modulus
	// value
	tmp = pcsr_pre;
	tmp = (tmp << 8) | 0x0F;
	sim.pit[pitr_ch].pcsr = tmp; // Set the system clock
	// divisor to 2
}



