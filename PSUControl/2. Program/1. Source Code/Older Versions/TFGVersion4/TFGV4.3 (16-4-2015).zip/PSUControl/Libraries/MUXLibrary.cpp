/*
 * MUXLibrary.cpp
 *
 *  Created on: 27-mar-2015
 *      Author: Alberto
 */

#include "MUXLibrary.h"

// MUXES
#define MUX_A 0
#define MUX_B 1
#define MUX_C 2
#define MUX_D 3
#define MUX_E 4


// AUXILIAR
#define EN_MUX_ABCDE 0x8
#define EN_MUX_ADC 0x8
#define SET_EXPANDER_BUS(mux, num) expanderBus[0]=(mux+EN_MUX_ADC)|((num+EN_MUX_ABCDE)<<4)

BYTE expanderBus[1] = {0};

//-------------------------------------------------------------------------------------------------------
// setMuxes - Configures the Muxes for a PSU number (or other voltage generators) and the desired function:
//				(0) FUNCTION_READ_VOLTAGE: Allows Voltage readings.
//				(1) FUNCTION_READ_CURRENT: Allows current Readings.
//				(2) FUNCTION_READ_SUPPLY: Allows Supply voltage readings (Regulating cards).
//				(3) FUNCTION_READ_INTERNAL: Allows internal voltage readings (Controller card).
//			  Returns a float with a scale value for the selected voltage
//-------------------------------------------------------------------------------------------------------

float setMuxes(int function, BYTE selectDev){
	float scaleFactor = 1;
	switch(function){
		case FUNCTION_READ_VOLTAGE:
			if (selectDev > SF4_B){
				selectDev-=8;
				if (selectDev > SF5_B){
					SET_EXPANDER_BUS(MUX_E, selectDev);
					scaleFactor=1.68;
				}
				else {
					SET_EXPANDER_BUS(MUX_B, selectDev);
					scaleFactor=3;
				}
			}
			else{
				SET_EXPANDER_BUS(MUX_A, selectDev);
				scaleFactor=3;
			}
			sendI2CMessage (expanderBus, 1, EXPANDER_I2C_ADDRESS);
			break;
		case FUNCTION_READ_CURRENT:
			if (selectDev > SF4_B){
				selectDev-=4;
				SET_EXPANDER_BUS(MUX_B, selectDev);
				if (selectDev > SF5_B){
					scaleFactor=-1.25;
				}
				else{
					scaleFactor=1.25;
				}
			}
			else{
				SET_EXPANDER_BUS(MUX_C, selectDev);
				scaleFactor=1.25;
			}
			sendI2CMessage (expanderBus, 1, EXPANDER_I2C_ADDRESS);
			break;
		case FUNCTION_READ_SUPPLY:
			if (selectDev > SUP_12V_F_C){
				if (selectDev == SUP_12V_F_D){
					expanderBus[0] = (5+EN_MUX_ADC);
				}
				else{
					selectDev-=8;
					SET_EXPANDER_BUS(MUX_E, selectDev);
				}
			}
			else{
				SET_EXPANDER_BUS(MUX_D, selectDev);
			}
			sendI2CMessage (expanderBus, 1, EXPANDER_I2C_ADDRESS);
			switch (selectDev){
				case SUP_42V_UNREG: scaleFactor = 5; break;
				case SUP_35V_UNREG: case SUP_32V_REG: case SUP_16V_REG: scaleFactor = 3; break;
				case SUP_n20_UNREG:  scaleFactor = -2; break;
				case SUP_16V_UNREG:  scaleFactor = 1.68; break; case SUP_n16_REG: scaleFactor = -1.68; break;
				case SUP_12V_F_A: case SUP_12V_F_B: case SUP_12V_F_C: case SUP_12V_F_D:  scaleFactor = 3.68/3; break;
			}
			break;
		case FUNCTION_READ_INTERNAL:
			if (selectDev == INT_VCC_n12V){
				SET_EXPANDER_BUS(MUX_E, selectDev);
				scaleFactor = -1;
			}
			else{
				SET_EXPANDER_BUS(MUX_B, selectDev);
			}
			sendI2CMessage (expanderBus, 1, EXPANDER_I2C_ADDRESS);
			break;
		default:
			iprintf("Unsupported Function");
			break;
	}
	scaleFactor = scaleFactor * 4.3 * 4;
	return scaleFactor;
}
