/*
 * Headers.h
 *
 *  Created on: 09-abr-2015
 *      Author: Alberto
 */

#ifndef HEADERS_H_

#include "predef.h"
#include <ctype.h>
#include <basictypes.h>					// BOOL & BYTE
#include <system.h>
#include <constants.h>
#include <ucos.h>
#include <ucosmcfc.h>
#include <serialirq.h>
#include <stdio.h>						// uint
#include <smarttrap.h>
#include <serialupdate.h>
#include "i2cmulti.h"            		// Used for Multi-Master I2C
#include <string.h>
#include <Pins.h>
#include <bsp.h>            			// MOD5213 board support package interface
#include <gdbstub.h>
#include <utils.h>          			// Include for usage of carrier board LEDs
#include <sim5213.h>        			// Access to MCF5213 register structures
#include <stdlib.h>
#include <a2d.h>
#include <cfinter.h>
#include <..\MOD5213\system\sim5213.h>

#include "Libraries/GeneralLibrary.h"
#include "defineConstants.cpp"
#include "PSU_TYPE.cpp"

#define HEADERS_H_

#endif /* HEADERS_H_ */
