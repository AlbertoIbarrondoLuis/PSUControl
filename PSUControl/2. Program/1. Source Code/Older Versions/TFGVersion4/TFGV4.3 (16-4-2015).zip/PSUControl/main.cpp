
/******************************************************************************
 * 								MCF5213 12-PSU Controller
 *   General Purpose. Not with a specific use yet.
 *
 *   Author: Alberto Ibarrondo
 *
 *****************************************************************************/
float versionNo =4.3;

#define WAIT_FOR_KEYBOARD c = sgetchar(0);

#include <basictypes.h>							// BOOL & BYTE
#include <a2d.h>								// Analog to digital converter
#include "Libraries/GeneralLibrary.h"			// Functions with various general purposes
#include "Libraries/I2C&SPILibrary.h"			// I2C&SPI Communication
#include "Libraries/RDACLibrary.h"				// RDAC configuration
#include "Libraries/MUXLibrary.h"				// RDAC configuration

#include "Controller.h"							// Heaviest program - contains the PSUControl functionalities
#include "defineConstants.cpp"					// Default Values and other Defines

#include "Test_PSU.h"

#include "TimerInt.h"

//====================================INICIALIZATIONS===============================================//
extern "C" {
	void UserMain( void * pd);

	// This function sets up the 5213 interrupt controller
	void SetIntc(long func, int vector, int level, int prio);
}
void _init (void);

//---------------------------------------Variables---------------------------------------------------//
const char * AppName="PSUControl";
BYTE i2CtoSPIAddress[12]= PSUs_I2C_ADDRESS_ARRAY;					// Defined by 3 switches.
char m;					// used to stop program waiting for user input


//-------------------------------------TimerInterrupt------------------------------------------------//

//========================================USERMAIN===================================================//
void UserMain(void * pd) {
	_init();									// Defined below. Contains all the configuration issues.
//--------------------------------------Main Loop----------------------------------------------------//
	 while (1) {
    	TestMain();
    }
}




void _init (void){

	//-------------------------------------General System--------------------------------------------//
	SimpleUart(0,SystemBaud);assign_stdio(0);				// Serial port 0 for Data
	SimpleUart(1,SystemBaud);								// Serial port 1 for Debug
	#ifdef _DEBUG
		InitGDBStubNoBreak( 1, 115200 );
	#endif

	OSChangePrio(MAIN_PRIO);								//Other
	EnableSerialUpdate();
	#ifndef _DEBUG
	EnableSmartTraps();
	#endif

	iprintf("\n\n\n\n\n\n\n\nAplication initializing\n");
	putleds((int)versionNo);
	printf("Version Number --> %.2f\n", versionNo);
	//--------------------------------------I2C Bus Connection---------------------------------------//
	I2CInit(MCF5213_I2C_ADDRESS, I2C_FREQUENCY); 			// Initialize I2C with Predefined Address (0x20)
															// Set frequency division to 768 (66Mhz CF clock --> 88,25 Khz I2C bus)
	iprintf("Initialized I2C address for MCF5213: 0x%x\r\n",MCF5213_I2C_ADDRESS);
	iprintf(" .Set I2C Frequency division: %x (MCF internal CLK / 1280)\r\n",I2C_FREQUENCY);


	//-------------------------------------SPI Bus Connection----------------------------------------//
	int i;
	for (i = 0; i<PSU_NUMBER; i++){
		configureSPI( false, false, false, 2, i2CtoSPIAddress[i]);	// MSB first, CLK low when idle, data clocked
																//  in on leading edge, frequency = 115KHz
	}

	//-----------------------------------RDACs with minimum value------------------------------------//
	for (i = 0; i<PSU_NUMBER; i++){
		setValRDAC(INITIAL_VOLTAGE, (i&0x1?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS), i2CtoSPIAddress[i]);
	}

	//----------------------------------Analog to Digital Converter----------------------------------//
	/*
	Pins[11].function( PIN11_AN2 );							// Configure the A2D pins as analog inputs
	Pins[12].function( PIN12_AN1 );
	Pins[13].function( PIN13_AN0 );
	Pins[14].function( PIN14_AN3 );
	Pins[15].function( PIN15_AN7 );
	Pins[16].function( PIN16_AN6 );
	Pins[17].function( PIN17_AN5 );
	Pins[18].function( PIN18_AN4 );

	EnableAD();
	iprintf(" .ADC initialized\r\n",freqDiv);


	*/
	//---------------------------------------TimerInterrupts-----------------------------------------//
	SetUpPITR(0 /* Use PITR 0 */, 16588 /* Wait 16588 clocks */, 1 /*Divide by 2 from table 173*/);
	SetUpPITR(1 /* Use PITR 1 */, 16588 /* Wait 16588 clocks */, 1 /*Divide by 2 from table 173*/);

    //----------------------------------------- RTOS Tasks-------------------------------------------//
    // TODO: convertirlo a aplicaci�n noRTOS con interrupciones. Opcional.
    /*
	OSSimpleTaskCreate( alarmTask, MAIN_PRIO - 2 );
    OSSimpleTaskCreate( switchONPSUsTask, MAIN_PRIO - 1 );
    */
	iprintf("Application initialized\n\nPRESS ONE KEY TO BEGIN \n\n");
}

