/*
 * PSULibrary.cpp
 *
 *  Created on: 04-feb-2015
 *   Author: Alberto Ibarrondo
*/



#include "Controller.h"

// Variables
BOOL powerONProcess = false; 	// used to initialize the system.
int powerONticks=0; 			// delay counter when initializing the system.
BOOL resetPowerON = false;		// setting it to TRUE activates the delayed switching-on process
WORD switchONListPSUs = 0;		// bits in TRUE are PSUs pending to be switched on

char bufferMOD5270[80]; 		// buffer mensajes tx y rx with MOD5270 using UART

PSU_TYPE psuList[PSU_NUMBER];	// MAIN PSU ARRAY LIST

BYTE driverA=0; // valor inicial bus U314
BYTE driverB=0; // valor inicial bus U315
BYTE transceptorBus=0; // valor inicial bus U313
BYTE busData=0, mask=0;	// Bus variables
// -> Aux
int monitorPSU=0;

//=====================================================================================================//
//================================    VOLTAGE & CURRENT METHODS    ====================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// adjustRdac - changes the RDAC Register Value (thus modifying its output voltage)
// 					Checks for correct value updating
//-------------------------------------------------------------------------------------------------------
void adjustRdac (int psuNum, float Voltage){
	int desiredValue = voltToNum(Voltage, psuList[psuNum].rShunt);
	setValRDAC(desiredValue, psuList[psuNum].rdacAdr, psuList[psuNum].bridgeI2CAdr);
	int setValue = getValRDAC(psuList[psuNum].rdacAdr, psuList[psuNum].bridgeI2CAdr);
	if (desiredValue==setValue){
		psuList[psuNum].rdacValue = Voltage;
	}
	else{
		iprintf("ERROR: RDAC value %d not properly configured on PSU %d. Value %d set instead", desiredValue, psuNum, setValue);
	}
}
//-------------------------------------------------------------------------------------------------------
// updateVoltagePSUs - Updates both RDAC values with their RAM config for the selected PSUs (marking
//					 its respective bit number as TRUE)
//-------------------------------------------------------------------------------------------------------
void updateVoltagePSUs(WORD selectPSUs){	// PSUs marked with his corresponding bit to 1 will be switched on.
	int psuNum; int aux = selectPSUs;
	// ajustar fuentes
	for (psuNum=0;psuNum<PSU_NUMBER;psuNum++){
		if(aux & 0x0001){
			if (psuList[psuNum].psuStatus) {
				adjustRdac (psuNum, psuList[psuNum].rdacValue);
			}
		}
		aux=aux>>1;
 	}
	OSTimeDly(TICKS_100MS); // retardo para ajuste de los reguladores
}


//-------------------------------------------------------------------------------------------------------
// readVoltageValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						to voltage.
//-------------------------------------------------------------------------------------------------------
void readVoltageValue(int psuNum){
	float value = 0, scaleFactor = 0;
	scaleFactor = setMuxes(FUNCTION_READ_VOLTAGE, (BYTE)psuNum);
	//TODO: loop to get ADC value between 40 and 90%
	value = ((float)(ReadA2DResult(0) >> 3) / (4095.0)) * 3.3 * scaleFactor;
	psuList[psuNum].vOut = value;
}


//-------------------------------------------------------------------------------------------------------
// readCurrentValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						 to current.
//-------------------------------------------------------------------------------------------------------
void readCurrentValue(int psuNum){
	float value = 0, scaleFactor = 0;
	scaleFactor = setMuxes(FUNCTION_READ_CURRENT, (BYTE)psuNum);
	value = ((float)(ReadA2DResult(0) >> 3) / (4095.0)) * 3.3;
	psuList[psuNum].cOut = value;
}


//-------------------------------------------------------------------------------------------------------
// readCurrentValue - Reads a sample of the ADC by properly configuring the Muxes and converts it
//						 to current.
//-------------------------------------------------------------------------------------------------------
void monitorTask(void *p){
	for (monitorPSU = 0; monitorPSU < PSU_NUMBER; monitorPSU ++){
		readVoltageValue(monitorPSU);	// VOLTAGE READING
		readCurrentValue(monitorPSU);	//CURRENT READING
	}
	OSTimeDly(TICKS_100MS);
}

//=====================================================================================================//
//======================================    ALARM METHODS    ==========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// alarmTask - Independent process in charge of monitoring all the PSU alarms once every 100ms
//				and executing the programmed protocols once every second if an alarm is triggered.
//-------------------------------------------------------------------------------------------------------
void alarmTask (void *p){
	int generalCounter = 0;
	int psuNumAux = 0;
	while (1)   // Loop forever
	   {	refreshAlarmCounters();
			generalCounter++;
			if (generalCounter == TASK_TIMES_PER_SECOND){					// Once every second
				generalCounter = 0;
				for (psuNumAux=0; psuNumAux<PSU_NUMBER; psuNumAux++){
					alarmCheck(psuNumAux);
				}
			}
			OSTimeDly(TICKS_PER_SECOND);   	// Critical, otherwise the lower tasks wont receive computing time.
	   }
}

//-------------------------------------------------------------------------------------------------------
// alarmCheck - Checks each alarm status for the selected PSU and executes the programmed protocols
//				if activated.
//-------------------------------------------------------------------------------------------------------
void alarmCheck (int psuNum){
	int i;
	for (i=0; i<=3; i++){			// checks each alarm's status (Voltage/Current; Superior/Inferior)
		if(psuList[psuNum].alarmWatch[i] && psuList[psuNum].alarmStatus[i]){
			int j;
			for (j=0; j<ALARM_PLOTOCOLS_NUM; j++){	// goes over each alarm protocol for the activated alarm
				if (psuList[psuNum].alarmProtocols[__(i&1,i&2, j)]){
					executeAlarmProtocol (psuNum, i&1, i&2, j);
				}
			}
		}
	}
}


//-------------------------------------------------------------------------------------------------------
// executeAlarmProtocol - Carries out a different protocol depending of the type of alarm
//						 (SUPERIOR/INFERIOR,VOLTAGE/CURRENT).
//-------------------------------------------------------------------------------------------------------
void executeAlarmProtocol (int psuNum, BOOL limit_inf_sup, BOOL type_volt_corr, int protocolNum){
	int k;
	switch (protocolNum){		// (0) Shut down certain PSUs, (1) Modify Voltage, (2) Send Alarm Message.
	case PROTOCOL_SHUTDOWN:
		WORD shutdown;
		shutdown = psuList[psuNum].alarmProtocolShutdown[_(limit_inf_sup, type_volt_corr)];
		for (k=0; k<12; k++){
			if (shutdown&0x1){
				disconnectPSU(psuNum);
			}
			shutdown = shutdown >>1;
		}
		break;
	case PROTOCOL_MODIFY_VOLTAGE:
			adjustRdac(psuNum, psuList[psuNum].alarmProtocolVoltage[_(limit_inf_sup,type_volt_corr)]);
		break;
	case PROTOCOL_MESSAGE:
			iprintf(ALARM_MESSAGE);
			//TODO: Maybe add some other alarm output - left for future implementation
		break;
	}
}

//-------------------------------------------------------------------------------------------------------
// refreshAlarmCounters_100ms - Takes a sample of Voltage and Current for all the PSUs and updates
// 						 		their alarm status, counters and flags by comparing the sample with
//								the programmed limit
//-------------------------------------------------------------------------------------------------------
void refreshAlarmCounters (void){
	int psuNum;
	for (psuNum=0; psuNum<12; psuNum++){
		if(psuList[psuNum].alarmWatch[_(INFERIOR,VOLTAGE)]){									// If INFERIOR VOLTAGE alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(INFERIOR,VOLTAGE)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(INFERIOR,VOLTAGE)]);
			if (psuList[psuNum].alarmLimitReached[_(INFERIOR,VOLTAGE)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]>=psuList[psuNum].alarmLimitTimes[_(INFERIOR,VOLTAGE)]){
					psuList[psuNum].alarmStatus[_(INFERIOR,VOLTAGE)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)]=psuList[psuNum].alarmLimitTimes[_(INFERIOR,VOLTAGE)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(INFERIOR,VOLTAGE)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(INFERIOR,VOLTAGE)] = false;
					}
				}
			}
		}
		if(psuList[psuNum].alarmWatch[_(SUPERIOR,VOLTAGE)]){									// If SUPERIOR VOLTAGE alarm is being watched
																										// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(SUPERIOR,VOLTAGE)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(SUPERIOR,VOLTAGE)]);
			if (psuList[psuNum].alarmLimitReached[_(SUPERIOR,VOLTAGE)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]>=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,VOLTAGE)]){
					psuList[psuNum].alarmStatus[_(SUPERIOR,VOLTAGE)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)]=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,VOLTAGE)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(SUPERIOR,VOLTAGE)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(SUPERIOR,VOLTAGE)] = false;
					}
				}
			}
		}

		if(psuList[psuNum].alarmWatch[_(INFERIOR,CURRENT)]){									// If INFERIOR CURRENT alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(INFERIOR,CURRENT)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(INFERIOR,CURRENT)]);
			if (psuList[psuNum].alarmLimitReached[_(INFERIOR,CURRENT)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]>=psuList[psuNum].alarmLimitTimes[_(INFERIOR,CURRENT)]){
					psuList[psuNum].alarmStatus[_(INFERIOR,CURRENT)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)]=psuList[psuNum].alarmLimitTimes[_(INFERIOR,CURRENT)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(INFERIOR,CURRENT)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(INFERIOR,CURRENT)] = false;
					}
				}
			}
		}
		if(psuList[psuNum].alarmWatch[_(SUPERIOR,CURRENT)]){									// If SUPERIOR CURRENT alarm is being watched
																								// Refresh alarmLimitReached value
			psuList[psuNum].alarmLimitReached[_(SUPERIOR,CURRENT)]=(psuList[psuNum].vOut <= psuList[psuNum].alarmLimitValues[_(SUPERIOR,CURRENT)]);
			if (psuList[psuNum].alarmLimitReached[_(SUPERIOR,CURRENT)]){						// If limit is exceeded
				psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]++;							// Increment Alarm Counter
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]>=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,CURRENT)]){
					psuList[psuNum].alarmStatus[_(SUPERIOR,CURRENT)] = true;					// Trigger on the alarm if counter reaches the time limit
					psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)]=psuList[psuNum].alarmLimitTimes[_(SUPERIOR,CURRENT)];
				}																				// Sets the counter to limit value
			}
			else{																				// If limit is not exceeded
				if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] > 0){					// And counter is higher than 0
					psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] -= 1;					// Decrease counter until it reaches 0
					if (psuList[psuNum].alarmCounters[_(SUPERIOR,CURRENT)] == 0){				// And when it hits 0, trigger off the alarm.
						psuList[psuNum].alarmStatus[_(SUPERIOR,CURRENT)] = false;
					}
				}
			}
		}
	}
}




//=====================================================================================================//
//================================    PSUs SWITCH ON/OFF METHODS    ===================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// switchONPSUsTask - RTOS Task in charge of the PSUs' delayed switching-on process, connecting the relays
//					  when each PSU reaches its initializationTimer. When every PSU has been connected, the
//					  task is destroyed.
//-------------------------------------------------------------------------------------------------------
void switchONPSUsTask(void *p){
		if(resetPowerON){
			powerONticks = 0;
			resetPowerON = false;
		}
		while(switchONListPSUs){
			int psuNum=0;
			int aux=switchONListPSUs;
			for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
				if(aux & 0x0001){
					if(psuList[psuNum].initializationTimer <= powerONticks){
						switchONListPSUs-=(0x0001<<psuNum);
						psuList[psuNum].ReadyToConnect = true;
						connectPSU(psuNum);
						adjustRdac (psuNum, psuList[psuNum].rdacValue);
					}
				}
				aux=aux>>1;
			}
			powerONticks++;
			OSTimeDly(TICKS_100MS);
		}
		OSTimeDly(TICKS_100MS);
		powerONProcess=false;
		OSTaskDelete();
}


//-------------------------------------------------------------------------------------------------------
// initializeValuesPSUs - Loads all PSU values from FLASH and checks for each VERIFY_KEY correction.
//						If corrupted, sets the PSU values to default.
//-------------------------------------------------------------------------------------------------------
int initializeValuesPSUs(void){
	 int saveParameters=FALSE;
	 int i=0;
	 PSU_TYPE *pData = (PSU_TYPE *) GetUserParameters();
	 PSU_TYPE *ppsuList = psuList;
	 for (i=0;i<PSU_NUMBER;i++){
	      if (pData->VerifyKey != VERIFY_KEY){ 			// Incorrect Data
	    	  defaultValuesPSU(i);
	    	  saveParameters=TRUE;							// Save values as soon as an invalid key is detected
          }else {											// Correct data
        	  // readFlashValuesPSU(i,pData); 				use in case memory copying didn't work (which currently does)
        	  memcpy (ppsuList, pData, sizeof(PSU_TYPE));
		  }
	      pData++; ppsuList++;								//Next PSU reading
	  }
     if (saveParameters){
    	 saveParameters = saveInFlashValuesPSU ();
     }
     return saveParameters;
}

//-------------------------------------------------------------------------------------------------------
// connectPSU - Connects the selected PSU by switching its Rel� and activates its LED OUT
//-------------------------------------------------------------------------------------------------------
void connectPSU(int psuNum){
	connectRelay ( psuNum );
	// TODO: activar LED OUT ON. quiz� esperar alguna medida de tensi�n para asegurar que funciona
	psuList[psuNum].psuStatus=true;
	psuList[psuNum].ReadyToConnect=false;
}

//-------------------------------------------------------------------------------------------------------
// switchONPSUs - Manages the complete PSU switching-on process for the selected PSUs: Initializes
//				its RAM values, changes its RDAC Register values, tells the switchONPSUsTask to
//				begin the delayed switching-on process.
//-------------------------------------------------------------------------------------------------------
void switchONPSUs(WORD selectedPSUs){
	powerONProcess=true;					// Starts switching on the psus. will be terminated by the switchONPSUsTask
	initializeValuesPSUs();					// Load psuList values from RAM or set them to default

	resetPowerON=true;						// Sends the selectedPSUs to the timed task switchONPSUsTask to
	switchONListPSUs = selectedPSUs;		// 	begin switching-on countdown.

    OSSimpleTaskCreate( switchONPSUsTask, SWITCH_ON_PRIO );	// Creates the OS Task to control the delayed switching-on
}



//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSU's relay, updating its LED OUT, and sets its power to minimum
//-------------------------------------------------------------------------------------------------------
void disconnectPSU(int psuNum){
	psuList[psuNum].ReadyToConnect=false;
	disconnectRelay ( psuNum );
	psuList[psuNum].relayStatus=false;
	adjustRdac(psuNum, INITIAL_VOLTAGE);
	psuList[psuNum].psuStatus=false;
	// TODO: comprobar si se ha de desactivar  led Out On
}

//-------------------------------------------------------------------------------------------------------
// disconnectPSU - Disconnects the selected PSUs' relays, updating its LED OUT, and sets their power to minimum
//-------------------------------------------------------------------------------------------------------
void switchOFFPSUs(WORD selectedPSUs){
	disconnectRelaySeveral ( selectedPSUs );
	int psuNum;
	for (psuNum=0; psuNum<PSU_NUMBER; psuNum++){
		if(selectedPSUs & 0x0001){
			psuList[psuNum].ReadyToConnect=false;
			disconnectRelay ( psuNum );
			psuList[psuNum].relayStatus=false;
			adjustRdac(psuNum, INITIAL_VOLTAGE);
			psuList[psuNum].psuStatus=false;
		}
		selectedPSUs=selectedPSUs>>1;
	}
	// TODO: desactivar  led Out On. Comprobar el voltaje para asegurar que se ha desconectado
}


//=====================================================================================================//
//==================================    FLASH MEMORY METHODS    =======================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// LoadFlashValuesPSU - Copies the data from the FLASH memory to the psuList in RAM, updating all
//						PSU programmed values. DOESN'T VERIFY DATA INTEGRITY (Use initializeValuesPSUs()
//						instead)
//-------------------------------------------------------------------------------------------------------
void loadFlashValuesPSU (void){
	PSU_TYPE *pData = (PSU_TYPE *) GetUserParameters();
	memcpy (psuList, pData, sizeof(psuList));
	iprintf("Loaded values of psuList from Flash Mem\n");
}

//-------------------------------------------------------------------------------------------------------
// saveInFlashValuesPSU - Stores the current psuList as a whole in the 8Kbits FLASH memory. For the
//						time being, 2Kbits of data are stored by using this method (the rest remains
//						unused).
//-------------------------------------------------------------------------------------------------------
int saveInFlashValuesPSU (void){
	int aux = SaveUserParameters(psuList, sizeof(psuList));
	iprintf("Saved values of psuList, for a total of %d Bytes in Flash Mem\n", aux);
	return aux;
}

//-------------------------------------------------------------------------------------------------------
// readFlashValuesPSU - Auxiliary method, not currently in use. Copies the data from one PSU from
//						a FLASH direction to a RAM variable (psuList) one value at a time.
//						Greatly simplified by using instead:
//												memcpy (psuList[psuNum], pData, sizeof(PSU_TYPE));
//-------------------------------------------------------------------------------------------------------
void readFlashValuesPSU(int psuNum, PSU_TYPE *pData){
	psuList[psuNum].relayStatus=pData->relayStatus;
	psuList[psuNum].psuStatus=pData->psuStatus;
	psuList[psuNum].rdacValue=pData->rdacValue;
	psuList[psuNum].bridgeI2CAdr=pData->bridgeI2CAdr;	// Probably required a different address for each psu
	psuList[psuNum].rdacAdr=pData->rdacAdr;
	memcpy(psuList[psuNum].alarmLimitValues, pData->alarmLimitValues, sizeof(psuList[psuNum].alarmLimitValues));
	memcpy(psuList[psuNum].alarmLimitTimes, pData->alarmLimitTimes, sizeof(psuList[psuNum].alarmLimitTimes));
	memcpy(psuList[psuNum].alarmProtocols, pData->alarmProtocols, sizeof(psuList[psuNum].alarmProtocols));
	memcpy(psuList[psuNum].alarmProtocolShutdown, pData->alarmProtocolShutdown, sizeof(psuList[psuNum].alarmProtocolShutdown));
	memcpy(psuList[psuNum].alarmProtocolVoltage, pData->alarmProtocolVoltage, sizeof(psuList[psuNum].alarmProtocolVoltage));
	memcpy(psuList[psuNum].alarmCounters, pData->alarmCounters, sizeof(psuList[psuNum].alarmCounters));
	memcpy(psuList[psuNum].alarmStatus, pData->alarmStatus, sizeof(psuList[psuNum].alarmStatus));
	memcpy(psuList[psuNum].alarmLimitReached, pData->alarmLimitReached, sizeof(psuList[psuNum].alarmLimitReached));
	memcpy(psuList[psuNum].alarmWatch, pData->alarmWatch, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt =  pData->rShunt;
	psuList[psuNum].divisorTension1 =  pData->divisorTension1;
	psuList[psuNum].divisorTension2 =  pData->divisorTension2;
	psuList[psuNum].rAdicPotDigital =  pData->rAdicPotDigital;
	psuList[psuNum].rDivisorPotDigital =  pData->rAdicPotDigital;
	psuList[psuNum].vOut =  pData->vOut;
	psuList[psuNum].cOut =  pData->cOut;
}




//=====================================================================================================//
//====================================    AUXILIARY METHODS    ========================================//
//=====================================================================================================//

//-------------------------------------------------------------------------------------------------------
// defaultValuesPSU - Replaces the current PSU values in RAM by those predefined as DEFAULT in
//					file "defineConstants.cpp"
//-------------------------------------------------------------------------------------------------------
void defaultValuesPSU (int psuNum) {
	psuList[psuNum].relayStatus=DEFAULT_relayStatus;
	psuList[psuNum].psuStatus=DEFAULT_psuStatus;
	psuList[psuNum].rdacValue=DEFAULT_rdacValue;
	BYTE i2CtoSPIAddress[12]= PSUs_I2C_ADDRESS_ARRAY;
	psuList[psuNum].bridgeI2CAdr=i2CtoSPIAddress[psuNum];
	psuList[psuNum].rdacAdr=(psuNum&0x1?FIRST_SLAVE_SPI_ADDRESS:SECOND_SLAVE_SPI_ADDRESS);
	float auxArray1[4]=DEFAULT_alarmLimitValues;
	memcpy(psuList[psuNum].alarmLimitValues, auxArray1, sizeof(psuList[psuNum].alarmLimitValues));
	int auxArray2[4]=DEFAULT_alarmLimitTimes;
	memcpy(psuList[psuNum].alarmLimitTimes, auxArray2, sizeof(psuList[psuNum].alarmLimitTimes));
	BOOL auxArray3[12]=DEFAULT_alarmProtocols;
	memcpy(psuList[psuNum].alarmProtocols, auxArray3, sizeof(psuList[psuNum].alarmProtocols));
	DWORD k = demux4to16(psuNum+1);
	int auxArray4[4]={k, k, k, k};
	memcpy(psuList[psuNum].alarmProtocolShutdown, auxArray4, sizeof(psuList[psuNum].alarmProtocolShutdown));
	float auxArray5[8]=DEFAULT_alarmProtocolVoltage;
	memcpy(psuList[psuNum].alarmProtocolVoltage, auxArray5, sizeof(psuList[psuNum].alarmProtocolVoltage));
	int auxArray6[4]=DEFAULT_alarmLimitTimes;
	memcpy(psuList[psuNum].alarmCounters, auxArray6, sizeof(psuList[psuNum].alarmCounters));
	BOOL auxArray7[4]=DEFAULT_alarmStatus;
	memcpy(psuList[psuNum].alarmStatus, auxArray7, sizeof(psuList[psuNum].alarmStatus));
	BOOL auxArray8[4]=DEFAULT_alarmLimitReached;
	memcpy(psuList[psuNum].alarmLimitReached, auxArray8, sizeof(psuList[psuNum].alarmLimitReached));
	BOOL auxArray9[4]=DEFAULT_alarmWatch;
	memcpy(psuList[psuNum].alarmWatch, auxArray9, sizeof(psuList[psuNum].alarmWatch));
	psuList[psuNum].rShunt = DEFAULT_rShunt;
	psuList[psuNum].divisorTension1 = DEFAULT_divisorTension1;
	psuList[psuNum].divisorTension2 = DEFAULT_divisorTension2;
	psuList[psuNum].rAdicPotDigital = DEFAULT_rAdicPotDigital;
	psuList[psuNum].rDivisorPotDigital = DEFAULT_rDivisorPotDigital;
	psuList[psuNum].vOut = DEFAULT_vOut;
	psuList[psuNum].cOut = DEFAULT_cOut;
}


//-------------------------------------------------------------------------------------------------------
// printValuesPSU - prints by stdio all the values in RAM from the selected PSU
//-------------------------------------------------------------------------------------------------------
void printValuesPSU (int psuNum) {
	iprintf("PSU-Number: %d\n", psuNum);
	iprintf("- relayStatus: %d\n",psuList[psuNum].relayStatus);
	iprintf("- psuStatus: %d\n",psuList[psuNum].psuStatus);
	iprintf("- rdacValue: %s\n",ftos(psuList[psuNum].rdacValue));
	iprintf("- bridgeI2CDir: 0x%x\n",psuList[psuNum].bridgeI2CAdr);
	iprintf("- rdacAdr: %d\n",psuList[psuNum].rdacAdr);
	iprintf("- alarmLimitValues: {%s, %s, %s, %s}\n",
			ftos(psuList[psuNum].alarmLimitValues[0]), ftos(psuList[psuNum].alarmLimitValues[1]),
			ftos(psuList[psuNum].alarmLimitValues[2]),ftos(psuList[psuNum].alarmLimitValues[3]));

	iprintf("- alarmLimitTimes: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitTimes[0], psuList[psuNum].alarmLimitTimes[1],
			psuList[psuNum].alarmLimitTimes[2],psuList[psuNum].alarmLimitTimes[3]);

	iprintf("- alarmProtocols: {%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d}\n",
			psuList[psuNum].alarmProtocols[0],psuList[psuNum].alarmProtocols[1],
			psuList[psuNum].alarmProtocols[2],psuList[psuNum].alarmProtocols[3],
			psuList[psuNum].alarmProtocols[4],psuList[psuNum].alarmProtocols[5],
			psuList[psuNum].alarmProtocols[6],psuList[psuNum].alarmProtocols[7],
			psuList[psuNum].alarmProtocols[8],psuList[psuNum].alarmProtocols[9],
			psuList[psuNum].alarmProtocols[10],psuList[psuNum].alarmProtocols[11]);
	iprintf("- alarmProtocolShutdown: {0x%x, 0x%x, 0x%x, 0x%x}\n",
			psuList[psuNum].alarmProtocolShutdown[0], psuList[psuNum].alarmProtocolShutdown[1],
			psuList[psuNum].alarmProtocolShutdown[2],psuList[psuNum].alarmProtocolShutdown[3]);
	iprintf("- alarmProtocolVoltage:{%s, %s, %s, %s, %s, %s, %s, %s}\n",
			ftos(psuList[psuNum].alarmProtocolVoltage[0]),ftos(psuList[psuNum].alarmProtocolVoltage[1]),
			ftos(psuList[psuNum].alarmProtocolVoltage[2]),ftos(psuList[psuNum].alarmProtocolVoltage[3]),
			ftos(psuList[psuNum].alarmProtocolVoltage[4]),ftos(psuList[psuNum].alarmProtocolVoltage[5]),
			ftos(psuList[psuNum].alarmProtocolVoltage[6]),ftos(psuList[psuNum].alarmProtocolVoltage[7]));
	iprintf("- alarmCounters: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmCounters[0], psuList[psuNum].alarmCounters[1],
			psuList[psuNum].alarmCounters[2],psuList[psuNum].alarmCounters[3]);
	iprintf("- alarmStatus: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmStatus[0], psuList[psuNum].alarmStatus[1],
			psuList[psuNum].alarmStatus[2],psuList[psuNum].alarmStatus[3]);
	iprintf("- alarmLimitReached: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmLimitReached[0], psuList[psuNum].alarmLimitReached[1],
			psuList[psuNum].alarmLimitReached[2],psuList[psuNum].alarmLimitReached[3]);
	iprintf("- alarmWatch: {%d, %d, %d, %d}\n",
			psuList[psuNum].alarmWatch[0], psuList[psuNum].alarmWatch[1],
			psuList[psuNum].alarmWatch[2],psuList[psuNum].alarmWatch[3]);
	iprintf("- rShunt: %d\n",psuList[psuNum].rShunt);
	iprintf("- divisorTension1: %d\n",psuList[psuNum].divisorTension1);
	iprintf("- divisorTension2: %d\n",psuList[psuNum].divisorTension2);
	iprintf("- rAdicPotDigital: %d\n",psuList[psuNum].rAdicPotDigital);
	iprintf("- rDivisorPotDigital: %d\n",psuList[psuNum].rDivisorPotDigital);
	iprintf("- vOut: %d\n",psuList[psuNum].vOut);
	iprintf("- cOut: %d\n",psuList[psuNum].cOut);

}


PSU_TYPE getPSU (int psuNum){
	return psuList[psuNum];
}
